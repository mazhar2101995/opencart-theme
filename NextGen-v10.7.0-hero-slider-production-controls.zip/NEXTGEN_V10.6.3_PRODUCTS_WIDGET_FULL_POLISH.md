# NextGen v10.6.3 — Products Widget Full Polish

## Why this patch was required

The previous unified Products widget was still showing several production issues:

- Wishlist / Compare / Quick View buttons rendered as blank white circles because the inline SVGs were inheriting an unsuitable `currentColor`.
- Product cards looked unfinished and inconsistent with a modern Journal/Shopify-style storefront.
- Tabs were rendered, but the inline tab runtime searched for tab buttons inside the panel container, so tab switching could fail.
- Slider needed stronger viewport/card/control styling and reliable runtime behavior.
- Builder preview could squeeze four cards into a very narrow inspector/canvas area, making the admin view unusable.
- Product images needed a cleaner contain-style presentation instead of aggressive cropping.

## Changes

### 1. Unified Products widget

The widget remains one widget with three display modes:

- Tabs
- Slider
- Grid

Mode-specific controls remain conditional in the builder inspector.

### 2. Tabs runtime

Fixed the tab event binding so the script correctly finds:

- tab buttons from the Products widget wrapper
- tab panels from the panel container

Only the selected panel is shown.

### 3. Slider runtime / presentation

- Proper overflow viewport.
- Track remains horizontal.
- Cards calculate their width from the selected responsive column count.
- Previous / Next and dots continue to use the unified widget runtime.
- Resize recalculates card positions.
- Disabled controls are visually indicated when loop is off.

### 4. Product action icons

Wishlist, Compare and Quick View now use inline SVG icons with explicit:

- `stroke`
- `stroke-width`
- `fill:none`
- explicit icon color

This avoids theme/global CSS changing the icons to white/invisible.

### 5. Product card redesign

The unified card now defaults to:

- white card surface
- subtle border
- soft shadow
- rounded corners
- clean square media area
- `object-fit: contain`
- consistent typography spacing
- visible circular action buttons
- strong dark Add to Cart button
- hover elevation
- explicit icon hover state

The defaults are deliberately neutral so demo themes can override them through the widget settings.

### 6. Admin Builder preview

The Products preview now uses a safer minimum card width instead of squeezing four cards into a tiny canvas column.

- Better image presentation.
- Explicit SVG icon color.
- Cleaner action buttons.
- Slider preview remains horizontally controlled.
- Narrow canvas uses fewer visible cards rather than microscopic cards.

## Validation

- PHP syntax checked for `universal_widget_renderers.php`.
- JavaScript syntax checked for `ecommerce.js`.
- JavaScript syntax checked for `builder-ui.js`.

## Cache refresh after installation

After replacing the package:

1. Refresh OpenCart Modifications.
2. Refresh NextGen/theme cache if enabled.
3. Hard refresh browser with `Ctrl + F5`.
4. Re-open the Products widget in Builder.
5. Test Grid, Slider and Tabs separately.
6. Test Wishlist, Compare and Quick View icons.
7. Test desktop, tablet and mobile preview widths.

## V10.6.4 Product Card Controls + Always-Visible Icons

### Fixed
- Product action SVG icons are now explicitly visible at rest, not only on hover.
- Wishlist / Compare / Quick View icons are configurable from Builder > Products > Action Icons.
- Previous / Next slider arrow icons are configurable from Builder > Products > Slider Arrows.
- Added product-card controls for badge text, Add to Cart label, model visibility, action size, icon size, gaps, offsets, borders, shadows, colors, card spacing, image sizing, typography, rating, prices and button styling.
- Added image height and fit controls.
- Added configurable slider dot size/colors/active scale.
- Added action-position modes: Image Overlay, Below Card, Hover, Always Visible.
- Product model is now available to the unified renderer.
- Arrow controls now render SVG icons instead of text glyphs.

### Icon options
- Wishlist: Heart, Heart Filled, Bookmark, Plus
- Compare: Swap, Compare, Plus
- Quick View: Eye, Search, Bookmark
- Previous Arrow: Chevron Left, Arrow Left, Caret Left
- Next Arrow: Chevron Right, Arrow Right, Caret Right
