<?php
class NextGenRuntimeContext {
    public function build(array $context=array()) {
        return array(
            'route'=>isset($context['route']) ? $context['route'] : '',
            'template_type'=>isset($context['template_type']) ? $context['template_type'] : '',
            'store_id'=>isset($context['store_id']) ? (int)$context['store_id'] : 0,
            'language_id'=>isset($context['language_id']) ? (int)$context['language_id'] : 0,
            'customer_id'=>isset($context['customer_id']) ? (int)$context['customer_id'] : 0,
            'device'=>isset($context['device']) ? $context['device'] : 'desktop'
        );
    }
}
