<?php
class NextGenStorefrontRenderService {
    private $runtime;
    private $templateResolver;

    public function __construct($runtime,$templateResolver) {
        $this->runtime=$runtime;
        $this->templateResolver=$templateResolver;
    }

    public function render(array $templates,array $context=array()) {
        $resolved=$this->templateResolver->resolve($templates,$context);

        if($resolved['status']!=='ok') {
            return array(
                'status'=>'fallback',
                'html'=>'',
                'reason'=>$resolved['status']
            );
        }

        $payload=array(
            'context'=>$context,
            'template'=>$resolved['template'],
            'document'=>$resolved['document']
        );

        if(method_exists($this->runtime,'run')) {
            $result=$this->runtime->run($payload);
            if(is_array($result) && isset($result['html'])) {
                return $result;
            }
        }

        return array(
            'status'=>'resolved',
            'html'=>'',
            'template'=>$resolved['template'],
            'document'=>$resolved['document']
        );
    }
}
