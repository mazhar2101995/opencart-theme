<?php
class NextGenMigrationManager {
    public function plan(array $migrations, $fromVersion, $toVersion) {
        $planned = array();
        foreach ($migrations as $migration) {
            if (!empty($migration['version']) && version_compare($migration['version'], $fromVersion, '>')) {
                $planned[] = $migration;
            }
        }
        usort($planned, function($a,$b) {
            return version_compare($a['version'], $b['version']);
        });
        return $planned;
    }

    public function status(array $appliedVersions) {
        return array('applied'=>$appliedVersions,'count'=>count($appliedVersions));
    }
}
