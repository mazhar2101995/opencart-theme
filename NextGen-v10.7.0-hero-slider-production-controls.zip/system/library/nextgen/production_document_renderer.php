<?php
class NextGenProductionDocumentRenderer {
    private $widgetRenderer;
    private $assetCollector;

    public function __construct($widgetRenderer,$assetCollector=null) {
        $this->widgetRenderer=$widgetRenderer;
        $this->assetCollector=$assetCollector;
    }

    public function render(array $document,array $context=array()) {
        if (!$this->widgetRenderer) {
            return array('status'=>'failed','error'=>'Widget renderer unavailable.','html'=>'');
        }

        $result=$this->widgetRenderer->renderDocument($document,$context);

        if (!is_array($result)) {
            return array('status'=>'failed','error'=>'Renderer returned an invalid result.','html'=>'');
        }

        if ($this->assetCollector && !empty($result['assets'])) {
            if (!empty($result['assets']['css'])) {
                foreach ($result['assets']['css'] as $url) $this->assetCollector->addCss($url);
            }
            if (!empty($result['assets']['js'])) {
                foreach ($result['assets']['js'] as $url) $this->assetCollector->addJs($url);
            }
            if (!empty($result['assets']['preload'])) {
                foreach ($result['assets']['preload'] as $item) {
                    if (is_array($item)) {
                        $this->assetCollector->addPreload(
                            isset($item['url'])?$item['url']:'',
                            isset($item['as'])?$item['as']:''
                        );
                    }
                }
            }
        }

        return array(
            'status'=>isset($result['status'])?$result['status']:'ok',
            'html'=>isset($result['html'])?$result['html']:'',
            'assets'=>$this->assetCollector ? $this->assetCollector->output() : array()
        );
    }
}
