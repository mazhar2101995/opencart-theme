<?php
class NextGenChildThemeResolver {
    public function resolve($theme,$child='') {
        $theme=$this->safe($theme);
        $child=$this->safe($child);
        return $child ? array($child,$theme) : array($theme);
    }

    public function assetPath($theme,$child,$relative) {
        foreach($this->resolve($theme,$child) as $candidate) {
            $path='catalog/view/theme/'.$candidate.'/'.$relative;
            if(is_file(DIR_APPLICATION.$path) || is_file(DIR_CATALOG.$path)) return $path;
        }
        return 'catalog/view/theme/'.$this->safe($theme).'/'.$relative;
    }

    private function safe($value) {
        return preg_replace('/[^A-Za-z0-9_-]/','',(string)$value);
    }
}
