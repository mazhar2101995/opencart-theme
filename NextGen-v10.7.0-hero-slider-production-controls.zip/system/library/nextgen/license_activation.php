<?php
class NextGenLicenseActivation {
    public function activationRequest($licenseKey,$package,$domain,$installationId) {
        return array(
            'license_key'=>$licenseKey,
            'package'=>$package,
            'domain'=>$domain,
            'installation_id'=>$installationId,
            'action'=>'activate'
        );
    }

    public function activationResult(array $response) {
        return array(
            'activated'=>isset($response['status']) && in_array($response['status'],array('active','trial'),true),
            'status'=>isset($response['status']) ? $response['status'] : 'unknown',
            'expires_at'=>isset($response['expires_at']) ? $response['expires_at'] : null
        );
    }
}
