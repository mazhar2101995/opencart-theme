<?php
/**
 * NextGen Production Runtime Orchestrator
 *
 * Presentation only. OpenCart controllers, sessions, cart, checkout,
 * authorization and business rules remain authoritative.
 */
class NextGenProductionRuntime {
    private $services=array();
    private $assetCollector=null;

    public function register($name,$service) {
        $this->services[$name]=$service;
    }

    public function service($name) {
        return isset($this->services[$name]) ? $this->services[$name] : null;
    }

    public function setAssetCollector($collector) {
        $this->assetCollector=$collector;
    }

    public function assets() {
        return $this->assetCollector;
    }

    public function pipeline() {
        return array(
            'context',
            'template_assignment',
            'document_load',
            'document_validation',
            'conditions',
            'dynamic_data',
            'widget_resolution',
            'recursive_widget_render',
            'asset_collection',
            'seo',
            'performance',
            'accessibility',
            'finalize'
        );
    }

    public function run(array $payload) {
        foreach ($this->pipeline() as $stage) {
            if (isset($payload['runtime_error'])) break;
            $payload['runtime_stage']=$stage;
            $payload=$this->executeStage($stage,$payload);
        }
        return $payload;
    }

    private function executeStage($stage,array $payload) {
        if (isset($this->services[$stage]) && is_callable($this->services[$stage])) {
            $result=call_user_func($this->services[$stage],$payload);
            return is_array($result) ? $result : $payload;
        }
        return $payload;
    }
}
