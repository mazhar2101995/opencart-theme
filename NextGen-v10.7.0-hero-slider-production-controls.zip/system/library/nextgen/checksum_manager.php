<?php
class NextGenChecksumManager {
    public function fileHash($path) {
        if (!is_file($path)) return null;
        return hash_file('sha256', $path);
    }

    public function verify($path, $expected) {
        $actual = $this->fileHash($path);
        return $actual !== null && hash_equals(strtolower($expected), strtolower($actual));
    }
}
