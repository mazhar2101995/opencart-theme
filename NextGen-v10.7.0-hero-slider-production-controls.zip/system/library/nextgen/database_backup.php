<?php
class NextGenDatabaseBackup {
    private $db;
    public function __construct($db) { $this->db=$db; }

    public function createPlan($package,$version) {
        return array(
            'package'=>$package,
            'version'=>$version,
            'method'=>'database_snapshot',
            'required'=>true,
            'status'=>'planned'
        );
    }

    public function restoreContract(array $backup) {
        return array(
            'backup'=>$backup,
            'restore_required'=>true,
            'verification_required'=>true
        );
    }
}
