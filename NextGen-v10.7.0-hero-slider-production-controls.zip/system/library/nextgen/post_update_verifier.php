<?php
class NextGenPostUpdateVerifier {
    public function verify(array $checks=array()) {
        $failed=array();
        foreach ($checks as $name=>$passed) {
            if (!$passed) $failed[]=$name;
        }
        return array(
            'passed'=>empty($failed),
            'failed'=>$failed,
            'rollback_required'=>!empty($failed)
        );
    }
}
