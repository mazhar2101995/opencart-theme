<?php
class NextGenProductionContract {
    public function requirements() {
        return array(
            'open_cart'=>'authoritative for commerce, session, customer, order, payment, shipping',
            'nextgen'=>'authoritative for presentation, builder documents and theme assets',
            'events'=>true,
            'ocmod'=>false,
            'vqmod'=>false,
            'storefront_ai_runtime'=>false,
            'published_documents_only'=>true,
            'fallback_required'=>true
        );
    }
}
