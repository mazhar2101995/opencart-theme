<?php
function nextgen_register_catalog_search_widgets(&$registry) {
    if (!class_exists('NextGenCatalogSearchSchema')) {
        require_once DIR_SYSTEM . 'library/nextgen/catalog_search_schema.php';
    }
    foreach (NextGenCatalogSearchSchema::widgets() as $id => $definition) {
        $registry[$id] = $definition;
        $registry[$id]['controls'] = NextGenCatalogSearchSchema::controls($id);
    }
}
