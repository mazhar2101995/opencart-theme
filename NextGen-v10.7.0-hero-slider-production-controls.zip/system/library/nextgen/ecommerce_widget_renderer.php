<?php
class NextGenEcommerceWidgetRenderer {
    public function renderProductCard(array $product,array $settings=array()) {
        $image=isset($product['image'])?$product['image']:'';
        $name=isset($product['name'])?$product['name']:'';
        $href=isset($product['href'])?$product['href']:'#';
        $price=isset($product['price'])?$product['price']:'';
        $special=isset($product['special'])?$product['special']:'';

        $html='<article class="ng-product-card">';
        if($image) $html.='<a class="ng-product-card__image" href="'.htmlspecialchars($href,ENT_QUOTES,'UTF-8').'"><img src="'.htmlspecialchars($image,ENT_QUOTES,'UTF-8').'" alt="'.htmlspecialchars($name,ENT_QUOTES,'UTF-8').'"></a>';
        $html.='<div class="ng-product-card__body">';
        $html.='<a class="ng-product-card__name" href="'.htmlspecialchars($href,ENT_QUOTES,'UTF-8').'">'.htmlspecialchars($name,ENT_QUOTES,'UTF-8').'</a>';
        if($special) $html.='<div class="ng-product-card__price"><del>'.htmlspecialchars($price,ENT_QUOTES,'UTF-8').'</del> <strong>'.htmlspecialchars($special,ENT_QUOTES,'UTF-8').'</strong></div>';
        else $html.='<div class="ng-product-card__price">'.htmlspecialchars($price,ENT_QUOTES,'UTF-8').'</div>';
        $html.='<div class="ng-product-card__actions"><button type="button" class="ng-add-to-cart" data-product-id="'.(int)(isset($product['product_id'])?$product['product_id']:0).'">Add to Cart</button></div>';
        $html.='</div></article>';
        return $html;
    }

    public function renderCollection(array $products,array $settings=array()) {
        $layout=isset($settings['layout'])?$settings['layout']:'grid';
        $class='ng-product-collection ng-product-collection--'.preg_replace('/[^a-z0-9_-]/i','',$layout);
        $html='<div class="'.$class.'">';
        foreach($products as $product) $html.=$this->renderProductCard(is_array($product)?$product:array(),$settings);
        return $html.'</div>';
    }

    public function renderProductPage(array $product,array $settings=array()) {
        $html='<div class="ng-product-page">';
        if(isset($product['image']) && $product['image']) {
            $html.='<div class="ng-product-page__gallery"><img src="'.htmlspecialchars($product['image'],ENT_QUOTES,'UTF-8').'" alt="'.htmlspecialchars(isset($product['name'])?$product['name']:'',ENT_QUOTES,'UTF-8').'"></div>';
        }
        $html.='<div class="ng-product-page__content">';
        $html.='<h1>'.htmlspecialchars(isset($product['name'])?$product['name']:'',ENT_QUOTES,'UTF-8').'</h1>';
        if(isset($product['model'])) $html.='<div class="ng-product-page__model">'.htmlspecialchars($product['model'],ENT_QUOTES,'UTF-8').'</div>';
        if(isset($product['price'])) $html.='<div class="ng-product-page__price">'.htmlspecialchars($product['price'],ENT_QUOTES,'UTF-8').'</div>';
        if(isset($product['description'])) $html.='<div class="ng-product-page__description">'.$product['description'].'</div>';
        $html.='<div class="ng-product-page__actions"><input type="number" min="1" value="1" class="ng-product-quantity"><button type="button" class="ng-add-to-cart" data-product-id="'.(int)(isset($product['product_id'])?$product['product_id']:0).'">Add to Cart</button></div>';
        $html.='</div></div>';
        return $html;
    }
}
