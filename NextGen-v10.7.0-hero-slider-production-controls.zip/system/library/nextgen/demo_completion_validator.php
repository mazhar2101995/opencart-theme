<?php
class NextGenDemoCompletionValidator {
    public function validate(array $manifest) {
        $required=array('key','name','document');
        foreach($required as $field) if(!array_key_exists($field,$manifest)) return false;
        return is_array($manifest['document']);
    }
}
