<?php
class NextGenGlobalPartRenderer {
    public function renderHeader(array $header=array()) {
        $logo=isset($header['logo'])?$header['logo']:'';
        $name=isset($header['store_name'])?$header['store_name']:'Store';

        $html='<header class="ng-global-header">';
        if($logo) {
            $html.='<a class="ng-global-header__logo" href="'.htmlspecialchars(isset($header['home'])?$header['home']:'/',ENT_QUOTES,'UTF-8').'">';
            $html.='<img src="'.htmlspecialchars($logo,ENT_QUOTES,'UTF-8').'" alt="'.htmlspecialchars($name,ENT_QUOTES,'UTF-8').'">';
            $html.='</a>';
        } else {
            $html.='<a class="ng-global-header__brand" href="/">'.htmlspecialchars($name,ENT_QUOTES,'UTF-8').'</a>';
        }
        $html.='</header>';
        return $html;
    }

    public function renderFooter(array $footer=array()) {
        $name=isset($footer['store_name'])?$footer['store_name']:'Store';
        $copyright=isset($footer['copyright'])?$footer['copyright']:'';

        return '<footer class="ng-global-footer"><div class="ng-global-footer__store">'.
            htmlspecialchars($name,ENT_QUOTES,'UTF-8').
            '</div><div class="ng-global-footer__copyright">'.
            htmlspecialchars($copyright,ENT_QUOTES,'UTF-8').
            '</div></footer>';
    }
}
