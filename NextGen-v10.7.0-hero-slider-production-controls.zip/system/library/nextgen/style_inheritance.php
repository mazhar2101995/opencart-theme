<?php
class NextGenStyleInheritance {
    public static function resolve(array $widget, array $template, array $global, array $defaults = array()) {
        $output = array();
        $keys = array_unique(array_merge(
            array_keys($defaults),
            array_keys($global),
            array_keys($template),
            isset($widget['settings']) ? array_keys($widget['settings']) : array()
        ));

        foreach ($keys as $key) {
            $local = isset($widget['settings'][$key]) ? $widget['settings'][$key] : null;
            $templateValue = isset($template[$key]) ? $template[$key] : null;
            $globalValue = isset($global[$key]) ? $global[$key] : null;
            $default = isset($defaults[$key]) ? $defaults[$key] : null;

            $output[$key] = NextGenBuilderUx::resolveStyle(
                $local,
                $templateValue !== null ? $templateValue : $globalValue,
                $default
            );
        }

        return $output;
    }
}
