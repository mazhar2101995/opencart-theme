<?php
class NextGenProductPageSchema {
    public static function widgets() {
        return [
            'product-gallery' => [
                'title' => 'Product Gallery',
                'category' => 'product-page',
                'template' => 'builder/product/product-gallery',
                'supports' => ['responsive','dynamic','animation','custom_css'],
            ],
            'product-title' => ['title'=>'Product Title','category'=>'product-page','template'=>'builder/product/product-title'],
            'product-model' => ['title'=>'Product Model','category'=>'product-page','template'=>'builder/product/product-model'],
            'product-sku' => ['title'=>'Product SKU','category'=>'product-page','template'=>'builder/product/product-sku'],
            'product-ean' => ['title'=>'Product EAN','category'=>'product-page','template'=>'builder/product/product-ean'],
            'product-manufacturer' => ['title'=>'Manufacturer','category'=>'product-page','template'=>'builder/product/product-manufacturer'],
            'product-rating' => ['title'=>'Rating','category'=>'product-page','template'=>'builder/product/product-rating'],
            'product-review-count' => ['title'=>'Review Count','category'=>'product-page','template'=>'builder/product/product-review-count'],
            'product-price' => ['title'=>'Price','category'=>'product-page','template'=>'builder/product/product-price'],
            'product-special-price' => ['title'=>'Special Price','category'=>'product-page','template'=>'builder/product/product-special-price'],
            'product-tax' => ['title'=>'Tax','category'=>'product-page','template'=>'builder/product/product-tax'],
            'product-discount' => ['title'=>'Discount','category'=>'product-page','template'=>'builder/product/product-discount'],
            'product-options' => ['title'=>'Options','category'=>'product-page','template'=>'builder/product/product-options'],
            'product-quantity' => ['title'=>'Quantity','category'=>'product-page','template'=>'builder/product/product-quantity'],
            'product-add-to-cart' => ['title'=>'Add to Cart','category'=>'product-page','template'=>'builder/product/product-add-to-cart'],
            'product-buy-now' => ['title'=>'Buy Now','category'=>'product-page','template'=>'builder/product/product-buy-now'],
            'product-wishlist' => ['title'=>'Wishlist','category'=>'product-page','template'=>'builder/product/product-wishlist'],
            'product-compare' => ['title'=>'Compare','category'=>'product-page','template'=>'builder/product/product-compare'],
            'product-stock-status' => ['title'=>'Stock Status','category'=>'product-page','template'=>'builder/product/product-stock-status'],
            'product-description' => ['title'=>'Description','category'=>'product-page','template'=>'builder/product/product-description'],
            'product-attributes' => ['title'=>'Attributes','category'=>'product-page','template'=>'builder/product/product-attributes'],
            'product-specifications' => ['title'=>'Specifications','category'=>'product-page','template'=>'builder/product/product-specifications'],
            'product-downloads' => ['title'=>'Downloads','category'=>'product-page','template'=>'builder/product/product-downloads'],
            'product-reviews' => ['title'=>'Reviews','category'=>'product-page','template'=>'builder/product/product-reviews'],
            'related-products' => ['title'=>'Related Products','category'=>'product-page','template'=>'builder/product/related-products'],
            'recently-viewed' => ['title'=>'Recently Viewed','category'=>'product-page','template'=>'builder/product/recently-viewed'],
        ];
    }

    public static function controls($widget_id) {
        $common = [
            ['id'=>'show_label','type'=>'toggle','label'=>'Show Label','default'=>true],
            ['id'=>'label','type'=>'text','label'=>'Label','default'=>''],
            ['id'=>'alignment','type'=>'select','label'=>'Alignment','options'=>['left'=>'Left','center'=>'Center','right'=>'Right'],'default'=>'left'],
            ['id'=>'visibility','type'=>'responsive','label'=>'Responsive Visibility'],
            ['id'=>'animation','type'=>'animation','label'=>'Animation'],
            ['id'=>'custom_class','type'=>'text','label'=>'Custom Class','default'=>''],
            ['id'=>'custom_id','type'=>'text','label'=>'Custom ID','default'=>''],
            ['id'=>'custom_css','type'=>'textarea','label'=>'Custom CSS','default'=>''],
        ];

        $map = [
            'product-gallery' => array_merge([
                ['id'=>'gallery_layout','type'=>'select','label'=>'Gallery Layout','options'=>['grid'=>'Grid','slider'=>'Slider','stacked'=>'Stacked'],'default'=>'slider'],
                ['id'=>'thumbnail_position','type'=>'select','label'=>'Thumbnail Position','options'=>['bottom'=>'Bottom','left'=>'Left','right'=>'Right'],'default'=>'bottom'],
                ['id'=>'show_arrows','type'=>'toggle','label'=>'Show Arrows','default'=>true],
                ['id'=>'show_dots','type'=>'toggle','label'=>'Show Dots','default'=>true],
                ['id'=>'lightbox','type'=>'toggle','label'=>'Enable Lightbox','default'=>true],
                ['id'=>'swipe','type'=>'toggle','label'=>'Touch Swipe','default'=>true],
            ], $common),
            'product-options' => array_merge([
                ['id'=>'layout','type'=>'select','label'=>'Layout','options'=>['stacked'=>'Stacked','inline'=>'Inline'],'default'=>'stacked'],
                ['id'=>'required_marker','type'=>'toggle','label'=>'Required Marker','default'=>true],
            ], $common),
            'product-add-to-cart' => array_merge([
                ['id'=>'button_style','type'=>'select','label'=>'Button Style','options'=>['solid'=>'Solid','outline'=>'Outline','text'=>'Text'],'default'=>'solid'],
                ['id'=>'icon_position','type'=>'select','label'=>'Icon Position','options'=>['left'=>'Left','right'=>'Right','none'=>'None'],'default'=>'left'],
                ['id'=>'quantity','type'=>'toggle','label'=>'Show Quantity','default'=>true],
            ], $common),
            'product-buy-now' => array_merge([
                ['id'=>'button_style','type'=>'select','label'=>'Button Style','options'=>['solid'=>'Solid','outline'=>'Outline','text'=>'Text'],'default'=>'outline'],
            ], $common),
            'product-description' => array_merge([
                ['id'=>'mode','type'=>'select','label'=>'Display Mode','options'=>['full'=>'Full','accordion'=>'Accordion','tabs'=>'Tabs'],'default'=>'full'],
            ], $common),
            'product-reviews' => array_merge([
                ['id'=>'layout','type'=>'select','label'=>'Layout','options'=>['list'=>'List','accordion'=>'Accordion'],'default'=>'list'],
                ['id'=>'show_form','type'=>'toggle','label'=>'Show Review Form','default'=>true],
            ], $common),
        ];

        return isset($map[$widget_id]) ? $map[$widget_id] : $common;
    }
}
