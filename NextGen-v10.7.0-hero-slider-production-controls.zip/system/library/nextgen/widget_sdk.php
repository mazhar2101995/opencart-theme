<?php
/**
 * Custom Widget SDK v2.5.
 */
class NextGenWidgetSdk {
    public static function definition($id, $name, $category, array $controls = array(), array $assets = array()) {
        return array(
            'id' => $id,
            'name' => $name,
            'category' => $category,
            'controls' => $controls,
            'assets' => $assets,
            'render' => array(
                'type' => 'twig',
                'template' => 'extension/nextgen/widget/' . $id
            )
        );
    }

    public static function control($type, $id, $label, array $options = array()) {
        return array_merge(array(
            'type' => $type,
            'id' => $id,
            'label' => $label
        ), $options);
    }

    public static function asset($type, $path, array $options = array()) {
        return array_merge(array(
            'type' => $type,
            'path' => $path
        ), $options);
    }
}
