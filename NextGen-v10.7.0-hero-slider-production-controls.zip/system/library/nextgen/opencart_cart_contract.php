<?php
class NextGenOpenCartCartContract {
    public function addToCart($productId,$quantity=1,array $options=array()) {
        return array(
            'method'=>'POST',
            'route'=>'checkout/cart/add',
            'product_id'=>(int)$productId,
            'quantity'=>max(1,(int)$quantity),
            'options'=>$options
        );
    }

    public function buyNow($productId,$quantity=1,array $options=array()) {
        $payload=$this->addToCart($productId,$quantity,$options);
        $payload['after_success']='checkout/cart';
        return $payload;
    }

    public function wishlist($productId) {
        return array('method'=>'POST','route'=>'account/wishlist/add','product_id'=>(int)$productId);
    }

    public function compare($productId) {
        return array('method'=>'POST','route'=>'product/compare/add','product_id'=>(int)$productId);
    }

    public function quickView($productId) {
        return array('method'=>'GET','route'=>'product/product/quickview','product_id'=>(int)$productId);
    }
}
