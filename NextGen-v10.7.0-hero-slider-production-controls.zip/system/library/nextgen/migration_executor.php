<?php
class NextGenMigrationExecutor {
    private $db;

    public function __construct($db) { $this->db=$db; }

    public function validate(array $migration) {
        return !empty($migration['id'])
            && !empty($migration['version'])
            && !empty($migration['sql']);
    }

    public function execute(array $migration) {
        if (!$this->validate($migration)) {
            return array('status'=>'blocked','error'=>'Invalid migration definition.');
        }

        // Production packages should supply reviewed SQL. Execution is deliberately
        // isolated here so transactions, backup checks and audit logging can wrap it.
        $queries=preg_split('/;\s*(?:\r?\n|$)/', trim($migration['sql']));
        $executed=0;

        foreach ($queries as $sql) {
            $sql=trim($sql);
            if ($sql === '') continue;
            $this->db->query($sql);
            $executed++;
        }

        return array(
            'status'=>'executed',
            'migration_id'=>$migration['id'],
            'version'=>$migration['version'],
            'queries'=>$executed
        );
    }
}
