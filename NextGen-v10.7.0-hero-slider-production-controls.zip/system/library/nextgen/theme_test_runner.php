<?php
/**
 * NextGen Theme Test Runner v2.4
 * Framework-level validation. Does not execute arbitrary PHP from documents.
 */
class NextGenThemeTestRunner {
    public function run(array $document, array $context = array()) {
        $report = array(
            'status' => 'passed',
            'tests' => array(),
            'summary' => array(
                'passed' => 0,
                'warnings' => 0,
                'failed' => 0
            )
        );

        $this->testDocumentShape($document, $report);
        $this->testWidgetNodes($document, $report);
        $this->testAccessibility($document, $report);
        $this->testResponsive($document, $report);
        $this->testSecurityBoundary($document, $report);

        if ($report['summary']['failed'] > 0) {
            $report['status'] = 'failed';
        } elseif ($report['summary']['warnings'] > 0) {
            $report['status'] = 'warning';
        }

        return $report;
    }

    private function add(&$report, $name, $status, $message) {
        $report['tests'][] = array(
            'name' => $name,
            'status' => $status,
            'message' => $message
        );

        if ($status === 'passed') $report['summary']['passed']++;
        elseif ($status === 'warning') $report['summary']['warnings']++;
        else $report['summary']['failed']++;
    }

    private function testDocumentShape($document, &$report) {
        if (!is_array($document)) {
            $this->add($report, 'document.shape', 'failed', 'Document must be an array.');
            return;
        }

        if (!isset($document['type']) || $document['type'] !== 'root') {
            $this->add($report, 'document.root', 'failed', 'Document root must have type=root.');
            return;
        }

        $this->add($report, 'document.shape', 'passed', 'Document root is valid.');
    }

    private function testWidgetNodes($node, &$report) {
        if (!is_array($node)) return;

        if (isset($node['type']) && $node['type'] === 'widget') {
            if (empty($node['widget'])) {
                $this->add($report, 'widget.type', 'failed', 'Widget node is missing widget identifier.');
            } else {
                $this->add($report, 'widget.' . $node['widget'], 'passed', 'Widget identifier exists.');
            }
        }

        foreach ($node as $value) {
            if (is_array($value)) {
                $this->testWidgetNodes($value, $report);
            }
        }
    }

    private function testAccessibility($node, &$report) {
        if (!is_array($node)) return;

        if (isset($node['widget']) && $node['widget'] === 'image') {
            $settings = isset($node['settings']) && is_array($node['settings'])
                ? $node['settings'] : array();

            if (empty($settings['alt']) && empty($settings['decorative'])) {
                $this->add($report, 'accessibility.image-alt', 'warning',
                    'Image widget should provide alt text or be explicitly decorative.');
            }
        }

        foreach ($node as $value) {
            if (is_array($value)) $this->testAccessibility($value, $report);
        }
    }

    private function testResponsive($node, &$report) {
        if (!is_array($node)) return;

        if (isset($node['settings']['responsive']) && is_array($node['settings']['responsive'])) {
            $responsive = $node['settings']['responsive'];
            foreach ($responsive as $key => $value) {
                if (is_array($value) &&
                    isset($value['desktop']) &&
                    isset($value['tablet']) &&
                    isset($value['mobile'])) {
                    $this->add($report, 'responsive.' . $key, 'passed',
                        'Responsive desktop/tablet/mobile values are defined.');
                }
            }
        }

        foreach ($node as $value) {
            if (is_array($value)) $this->testResponsive($value, $report);
        }
    }

    private function testSecurityBoundary($node, &$report) {
        if (!is_array($node)) return;

        if (isset($node['settings']['execute_php']) && $node['settings']['execute_php']) {
            $this->add($report, 'security.php-execution', 'failed',
                'Builder documents must not execute arbitrary PHP.');
        }

        if (isset($node['settings']['authorization']) && $node['settings']['authorization']) {
            $this->add($report, 'security.presentation-only', 'warning',
                'Presentation conditions must not be used as authorization.');
        }

        foreach ($node as $value) {
            if (is_array($value)) $this->testSecurityBoundary($value, $report);
        }
    }
}
