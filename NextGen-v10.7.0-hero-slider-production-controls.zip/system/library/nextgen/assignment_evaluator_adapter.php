<?php
class NextGenAssignmentEvaluatorAdapter {
    private $evaluator;

    public function __construct($evaluator=null) {
        $this->evaluator=$evaluator;
    }

    public function matches(array $assignment,array $context=array()) {
        if($this->evaluator && method_exists($this->evaluator,'matches')) {
            return (bool)$this->evaluator->matches($assignment,$context);
        }

        if(isset($assignment['route']) && $assignment['route']!=='' &&
           $assignment['route']!==$context['route']) return false;

        if(isset($assignment['template_type']) && $assignment['template_type']!=='' &&
           $assignment['template_type']!==$context['template_type']) return false;

        if(isset($assignment['store_id']) && (int)$assignment['store_id']!==(int)$context['store_id']) return false;

        if(isset($assignment['language_id']) && (int)$assignment['language_id']!==(int)$context['language_id']) return false;

        return true;
    }
}
