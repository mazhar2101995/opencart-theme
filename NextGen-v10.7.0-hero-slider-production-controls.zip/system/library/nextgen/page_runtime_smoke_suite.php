<?php
class NextGenPageRuntimeSmokeSuite {
    public function run(array $cases) {
        $results=array();
        foreach($cases as $name=>$case) {
            $results[$name]=array(
                'route'=>isset($case['route'])?$case['route']:'',
                'template_type'=>isset($case['template_type'])?$case['template_type']:'',
                'context_ready'=>isset($case['context']) && is_array($case['context']),
                'status'=>'ready'
            );
        }
        return array(
            'status'=>'passed',
            'cases'=>$results
        );
    }
}
