<?php
class NextGenUpdateExecutor {
    public function preflight(array $context) {
        $required=array('backup_ok','package_ok','compatibility_ok','lock_ok');
        $failed=array();

        foreach ($required as $key) {
            if (empty($context[$key])) $failed[]=$key;
        }

        return array(
            'ready'=>empty($failed),
            'failed'=>$failed
        );
    }

    public function failure($stage,$message) {
        return array(
            'status'=>'failed',
            'stage'=>$stage,
            'message'=>$message,
            'rollback_required'=>true,
            'publish'=>'blocked'
        );
    }

    public function success($version) {
        return array(
            'status'=>'active',
            'version'=>$version,
            'verified'=>true,
            'rollback_available'=>true
        );
    }
}
