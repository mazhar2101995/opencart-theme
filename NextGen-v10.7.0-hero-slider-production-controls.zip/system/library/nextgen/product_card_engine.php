<?php
class NextGenProductCardEngine {
    public function normalize(array $product,array $settings=array()) {
        $price=(float)(isset($product['price'])?$product['price']:0);
        $special=isset($product['special']) && $product['special']!==null ? (float)$product['special'] : null;
        $discount=0;

        if($special!==null && $price>0 && $special<$price) {
            $discount=(int)round((($price-$special)/$price)*100);
        }

        return array(
            'product_id'=>(int)(isset($product['product_id'])?$product['product_id']:0),
            'name'=>isset($product['name'])?$product['name']:'',
            'href'=>isset($product['href'])?$product['href']:'',
            'image'=>isset($product['image'])?$product['image']:(isset($product['thumb'])?$product['thumb']:''),
            'hover_image'=>isset($product['hover_image'])?$product['hover_image']:'',
            'images'=>isset($product['images']) && is_array($product['images'])?$product['images']:array(),
            'price'=>$price,
            'special'=>$special,
            'discount'=>$discount,
            'rating'=>isset($product['rating'])?(float)$product['rating']:0,
            'reviews'=>isset($product['reviews'])?(int)$product['reviews']:0,
            'manufacturer'=>isset($product['manufacturer'])?$product['manufacturer']:'',
            'model'=>isset($product['model'])?$product['model']:'',
            'stock_status'=>isset($product['stock_status'])?$product['stock_status']:'',
            'quantity'=>isset($product['quantity'])?(int)$product['quantity']:null,
            'options'=>isset($product['options']) && is_array($product['options'])?$product['options']:array(),
            'is_new'=>!empty($product['is_new']),
            'is_featured'=>!empty($product['is_featured']),
            'raw'=>$product
        );
    }

    public function state(array $product) {
        return array(
            'sale'=>$product['special']!==null && $product['special']<$product['price'],
            'out_of_stock'=>$product['quantity']!==null && $product['quantity']<=0,
            'new'=>!empty($product['is_new']),
            'featured'=>!empty($product['is_featured'])
        );
    }
}
