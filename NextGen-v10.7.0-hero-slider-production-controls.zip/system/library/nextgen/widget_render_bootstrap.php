<?php
class NextGenWidgetRenderBootstrap {
    public function registerDefaults($registry,$assets=null) {
        $defaults=new NextGenDefaultWidgetRenderers();
        $defaults->register($registry,$assets);
        return $registry;
    }
}
