<?php
class NextGenEventInstaller {
    public function install(array $events) {
        $installed=array();

        foreach ($events as $event) {
            if (empty($event['code']) || empty($event['trigger']) || empty($event['action'])) continue;

            $installed[] = array(
                'code'=>$event['code'],
                'trigger'=>$event['trigger'],
                'action'=>$event['action'],
                'status'=>isset($event['status']) ? (int)$event['status'] : 1,
                'sort_order'=>isset($event['sort_order']) ? (int)$event['sort_order'] : 0
            );
        }

        return array(
            'status'=>'planned',
            'events'=>$installed,
            'count'=>count($installed)
        );
    }
}
