<?php
/**
 * NextGen Asset Dependency Collector v2.2
 * Collects only declared page/widget assets and deduplicates them.
 */
class NextGenAssetDependencyCollector {
    private $css = array();
    private $js = array();
    private $preload = array();

    public function requireCss($id, $href, $critical = false) {
        if (!$href) return;
        $this->css[$id] = array('href'=>$href, 'critical'=>(bool)$critical);
    }

    public function requireJs($id, $src, $defer = true) {
        if (!$src) return;
        $this->js[$id] = array('src'=>$src, 'defer'=>(bool)$defer);
    }

    public function requirePreload($id, $href, $as='image', $type='') {
        if (!$href) return;
        $this->preload[$id] = array('href'=>$href, 'as'=>$as, 'type'=>$type);
    }

    public function cssTags() {
        $html = '';
        foreach ($this->css as $item) {
            $href = htmlspecialchars($item['href'], ENT_QUOTES, 'UTF-8');
            $html .= '<link rel="stylesheet" href="' . $href . '">' . "\n";
        }
        return $html;
    }

    public function jsTags() {
        $html = '';
        foreach ($this->js as $item) {
            $src = htmlspecialchars($item['src'], ENT_QUOTES, 'UTF-8');
            $html .= '<script src="' . $src . '"' . ($item['defer'] ? ' defer' : '') . '></script>' . "\n";
        }
        return $html;
    }

    public function preloadTags() {
        return NextGenPerformanceEngine::preload(array_values($this->preload));
    }

    public function all() {
        return array(
            'css' => $this->css,
            'js' => $this->js,
            'preload' => $this->preload
        );
    }
}
