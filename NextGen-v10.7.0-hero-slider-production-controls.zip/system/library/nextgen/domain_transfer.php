<?php
class NextGenDomainTransfer {
    public function request($licenseKey,$oldDomain,$newDomain,$installationId) {
        return array(
            'action'=>'transfer',
            'license_key'=>$licenseKey,
            'old_domain'=>$oldDomain,
            'new_domain'=>$newDomain,
            'installation_id'=>$installationId
        );
    }

    public function validate(array $response) {
        return !empty($response['status'])
            && in_array($response['status'],array('pending','approved','completed'),true);
    }
}
