<?php
class NextGenBackupManager {
    public function createPlan($package, $version, array $files = array()) {
        return array(
            'package'=>$package,
            'version'=>$version,
            'timestamp'=>date('c'),
            'files'=>$files,
            'database_snapshot_required'=>true,
            'status'=>'planned'
        );
    }

    public function validatePlan(array $plan) {
        return !empty($plan['package'])
            && !empty($plan['version'])
            && isset($plan['files'])
            && !empty($plan['database_snapshot_required']);
    }
}
