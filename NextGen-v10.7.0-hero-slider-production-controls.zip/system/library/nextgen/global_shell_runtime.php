<?php
class NextGenGlobalShellRuntime {
    public function build(array $context=array()) {
        return array(
            'header'=>isset($context['header'])&&is_array($context['header'])?$context['header']:array(),
            'announcement'=>isset($context['announcement'])&&is_array($context['announcement'])?$context['announcement']:array(),
            'footer'=>isset($context['footer'])&&is_array($context['footer'])?$context['footer']:array(),
            'global_sections'=>isset($context['global_sections'])&&is_array($context['global_sections'])?$context['global_sections']:array()
        );
    }

    public function placement(array $settings=array()) {
        return array(
            'header'=>isset($settings['header'])?$settings['header']:'before-content',
            'announcement'=>isset($settings['announcement'])?$settings['announcement']:'before-header',
            'footer'=>isset($settings['footer'])?$settings['footer']:'after-content'
        );
    }
}
