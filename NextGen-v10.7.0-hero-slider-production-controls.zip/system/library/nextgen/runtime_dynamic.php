<?php
class NextGenRuntimeDynamic {
    public function resolve($value,array $context=array()) {
        if (!is_string($value)) return $value;
        if (strpos($value,'{{') !== 0) return $value;

        $key=trim($value,'{} ');
        $parts=explode('.',$key);
        $current=$context;

        foreach ($parts as $part) {
            if (!is_array($current) || !array_key_exists($part,$current)) return null;
            $current=$current[$part];
        }

        return $current;
    }
}
