<?php
require_once(DIR_SYSTEM . 'library/nextgen/media_url.php');

/**
 * NextGen universal storefront widget coverage.
 *
 * The Builder and storefront use the same widget ids. This registry fills
 * presentation gaps for widgets that do not have a dedicated renderer yet,
 * so a saved widget never silently disappears from the live page.
 */
class NextGenUniversalWidgetRenderers {
    public function register($registry) {
        $self = $this;
        $definitions = array(
            'button_group'=>function($n,$c) use ($self){ return $self->buttonGroup($n); },
            'icon_box'=>function($n,$c) use ($self){ return $self->iconBox($n); },
            'html'=>function($n,$c) use ($self){ return $self->html($n); },
            'video'=>function($n,$c) use ($self){ return $self->video($n); },
            'gallery'=>function($n,$c) use ($self){ return $self->gallery($n); },
            'image_carousel'=>function($n,$c) use ($self){ return $self->gallery($n,true); },
            'video_popup'=>function($n,$c) use ($self){ return $self->videoPopup($n); },
            'products'=>function($n,$c) use ($self){ return $self->products($n,$c); },
            'product_categories'=>function($n,$c) use ($self){ return $self->simpleBlock($n,'Product Categories'); },
            'category_grid'=>function($n,$c) use ($self){ return $self->categoryGrid($n,$c); },
            'manufacturer'=>function($n,$c) use ($self){ return $self->simpleBlock($n,'Manufacturer / Brand'); },
            'search'=>function($n,$c) use ($self){ return $self->simpleBlock($n,'Search'); },
            'product_filter'=>function($n,$c) use ($self){ return $self->simpleBlock($n,'Product Filter'); },
            'pagination'=>function($n,$c) use ($self){ return $self->simpleBlock($n,'Pagination'); },
            'rating'=>function($n,$c) use ($self){ return $self->simpleBlock($n,'Rating'); },
            'add_to_cart'=>function($n,$c) use ($self){ return $self->action($n,'Add to Cart'); },
            'wishlist'=>function($n,$c) use ($self){ return $self->action($n,'♡ Wishlist'); },
            'compare'=>function($n,$c) use ($self){ return $self->action($n,'⇄ Compare'); },
            'quick_view'=>function($n,$c) use ($self){ return $self->action($n,'Quick View'); },
            'hero'=>function($n,$c) use ($self){ return $self->hero($n); },
            'hero_slider'=>function($n,$c) use ($self){ return $self->hero($n,true); },
            'social_links'=>function($n,$c) use ($self){ return $self->simpleBlock($n,'Social Links'); },
            'footer'=>function($n,$c) use ($self){ return $self->simpleBlock($n,'Footer'); },
            'menu'=>function($n,$c) use ($self){ return $self->simpleBlock($n,'Navigation / Mega Menu'); },
            'logo'=>function($n,$c) use ($self){ return $self->simpleBlock($n,'Logo'); },
            'account'=>function($n,$c) use ($self){ return $self->simpleBlock($n,'Account'); },
            'cart'=>function($n,$c) use ($self){ return $self->simpleBlock($n,'Cart'); },
            'conditions'=>function($n,$c) use ($self){ return $self->simpleBlock($n,'Conditional Section'); }
        );
        foreach ($definitions as $type=>$renderer) {
            if (!$registry->hasWidget($type)) $registry->registerWidget($type,$renderer);
        }
    }
    private function setting($n,$key,$default='') { return isset($n['settings'][$key]) ? $n['settings'][$key] : $default; }
    private function esc($v) { return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8'); }
    private function imageUrl($value) { return NextGenMediaUrl::url($value); }
    private function buttonGroup($n) { return '<div class="ng-widget ng-button-group"><a href="'. $this->esc($this->setting($n,'url','#')) .'">'. $this->esc($this->setting($n,'text','Button')) .'</a></div>'; }
    private function iconBox($n) { return '<div class="ng-widget ng-icon-box"><div class="ng-icon-box__icon">'. $this->esc($this->setting($n,'icon','★')) .'</div><div><h3>'. $this->esc($this->setting($n,'title','Icon Box')) .'</h3><p>'. $this->esc($this->setting($n,'text','Description')) .'</p></div></div>'; }
    private function html($n) { return '<div class="ng-widget ng-html">'. (string)$this->setting($n,'html','') .'</div>'; }
    private function video($n) { $src=$this->esc($this->setting($n,'src','')); return '<div class="ng-widget ng-video">'.($src?'<video controls preload="metadata" src="'.$src.'"></video>':'<div class="ng-media-placeholder">Video — configure media</div>').'</div>'; }
    private function videoPopup($n) { return '<button type="button" class="ng-widget ng-video-popup">▶ '. $this->esc($this->setting($n,'text','Play Video')) .'</button>'; }
    private function gallery($n,$carousel=false) { $items=$this->setting($n,'images',array()); if(!is_array($items))$items=array(); $html='<div class="ng-widget ng-gallery'.($carousel?' ng-gallery-carousel':'').'">'; foreach($items as $item){$src=is_array($item)?($item['src']??($item['image']??'')):$item; if($src)$html.='<img src="'.$this->esc($this->imageUrl($src)).'" alt="" loading="lazy">';} if($html==='<div class="ng-widget ng-gallery'.($carousel?' ng-gallery-carousel':'').'">')$html.='<div class="ng-media-placeholder">Gallery — add images</div>'; return $html.'</div>'; }
    private function categoryGrid($n,$context=array()) {
        $s=isset($n['settings'])&&is_array($n['settings'])?$n['settings']:array();
        $all=isset($context['categories'])&&is_array($context['categories'])?$context['categories']:array();
        $selected=isset($s['categoryIds'])&&is_array($s['categoryIds'])?$s['categoryIds']:array();
        if(!$selected && isset($s['categories'])&&is_array($s['categories'])) foreach($s['categories'] as $c){if(is_array($c)&&isset($c['category_id']))$selected[]=(int)$c['category_id'];}
        $items=array();
        foreach($selected as $id){$id=(int)$id;if(isset($all[$id]))$items[]=$all[$id];}
        if(!$items && isset($s['categories'])&&is_array($s['categories'])) $items=$s['categories'];

        $cols=max(1,min(8,(int)($s['columns']??4)));$gap=max(0,(int)($s['gap']??20));
        $showName=isset($s['showName'])?$s['showName']!==false:true;
        $namePos=(string)($s['namePosition']??'overlay');
        $nameOverlayPos=(string)($s['nameOverlayPosition']??'bottom-center');
        $nameAlign=(string)($s['nameAlign']??'center');
        $nameHeight=(string)($s['nameHeight']??'48px');
        $allowedNamePos=array('top-left','top-center','top-right','center-left','center','center-right','bottom-left','bottom-center','bottom-right');
        if(!in_array($nameOverlayPos,$allowedNamePos,true))$nameOverlayPos='bottom-center';
        if(!in_array($nameAlign,array('left','center','right'),true))$nameAlign='center';
        $buttonDisplay=(string)($s['buttonDisplay']??'hover');$buttonText=(string)($s['buttonText']??'Shop Now');
        $fit=(string)($s['imageFit']??'cover');$height=(string)($s['imageHeight']??'320px');$mode=(string)($s['displayMode']??'grid');
        $autoplay=isset($s['autoplay'])?$s['autoplay']!==false:true;$interval=max(1000,(int)($s['interval']??4000));
        $arrows=isset($s['arrows'])?$s['arrows']!==false:true;$dots=isset($s['dots'])?$s['dots']!==false:true;$loop=isset($s['loop'])?$s['loop']!==false:true;
        $prevIcon=(string)($s['arrowPrevIcon']??'chevron-left');$nextIcon=(string)($s['arrowNextIcon']??'chevron-right');
        $icons=array('chevron-left'=>'‹','arrow-left'=>'←','angle-left'=>'❮','double-left'=>'«','caret-left'=>'‹','chevron-right'=>'›','arrow-right'=>'→','angle-right'=>'❯','double-right'=>'»','caret-right'=>'›');
        $prevGlyph=$icons[$prevIcon]??'‹';$nextGlyph=$icons[$nextIcon]??'›';
        $safeId=preg_replace('/[^a-zA-Z0-9_-]/','-',(string)(isset($n['id'])?$n['id']:uniqid('cat_',false)));$scope='.ng-category-grid-'.$safeId;
        $css=function($v){return preg_replace('/[^a-zA-Z0-9#%(),.\-+_\s\/]/','',(string)$v);};
        $style='<style data-nextgen-category-grid="'.$this->esc($safeId).'">';
        $style.=$scope.'{--ng-category-columns:'.$cols.';--ng-category-gap:'.$gap.'px;--ng-category-image-height:'.$css($height).';--ng-category-name-height:'.$css($nameHeight).';--ng-category-fit:'.$css($fit).';width:100%;box-sizing:border-box;}';
        $style.=$scope.' .ng-category-card{position:relative;min-width:0;box-sizing:border-box;overflow:hidden;}';
        $style.=$scope.' .ng-category-card__media{position:relative;display:block;width:100%;height:var(--ng-category-image-height);overflow:hidden;text-decoration:none;box-sizing:border-box;}';
        $style.=$scope.' .ng-category-card__media img{display:block;width:100%;height:100%;object-fit:var(--ng-category-fit);object-position:center;transition:transform .3s ease;box-sizing:border-box;}';
        $style.=$scope.' .ng-category-card__placeholder{display:flex;width:100%;height:100%;align-items:center;justify-content:center;background:#eef0f2;color:#64748b;}';
        $style.=$scope.' .ng-category-card__name{box-sizing:border-box;z-index:4;text-decoration:none;display:inline-flex;width:max-content;max-width:calc(100% - 32px);height:var(--ng-category-name-height);min-width:0;min-height:var(--ng-category-name-height);max-height:var(--ng-category-name-height);line-height:1.2;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;writing-mode:horizontal-tb;overflow-wrap:normal;word-break:normal;align-items:center;justify-content:center;}';
        $style.=$scope.' .ng-category-card__name--below{display:block;width:100%;text-align:'.$nameAlign.';}';
        $style.=$scope.' .ng-category-card__name--overlay{position:absolute;}';
        $positions=array(
            'top-left'=>'top:16px;left:16px;','top-center'=>'top:16px;left:50%;transform:translateX(-50%);',
            'top-right'=>'top:16px;right:16px;','center-left'=>'top:50%;left:16px;transform:translateY(-50%);',
            'center'=>'top:50%;left:50%;transform:translate(-50%,-50%);','center-right'=>'top:50%;right:16px;transform:translateY(-50%);',
            'bottom-left'=>'bottom:16px;left:16px;','bottom-center'=>'bottom:16px;left:50%;transform:translateX(-50%);','bottom-right'=>'bottom:16px;right:16px;'
        );
        foreach($positions as $pk=>$pv)$style.=$scope.' .ng-category-card__name--overlay.pos-'.$pk.'{'.$pv.'}';
        $cardStyle=$scope.' .ng-category-card{';
        foreach(array('cardBackground'=>'background','cardBorderColor'=>'border-color','cardBorderWidth'=>'border-width','cardRadius'=>'border-radius','cardShadow'=>'box-shadow') as $k=>$prop){if(isset($s[$k])&&$s[$k]!=='')$cardStyle.=$prop.':'.$css($s[$k]).';';}
        $style.=$cardStyle.'}';
        if(isset($s['responsive'])&&is_array($s['responsive'])){
            foreach(array('tablet'=>'900px','mobile'=>'600px') as $dev=>$bp){$r='';$rr=$s['responsive'];foreach(array('columns'=>'--ng-category-columns','gap'=>'--ng-category-gap','imageHeight'=>'--ng-category-image-height','nameHeight'=>'--ng-category-name-height','imageFit'=>'--ng-category-fit') as $k=>$var){if(isset($rr[$k][$dev])&&$rr[$k][$dev]!=='')$r.=$var.':'.$css($rr[$k][$dev]).($k==='gap'?'px':'').';';}if($r)$style.='@media(max-width:'.$bp.'){'.$scope.'{'.$r.'}}';}
        }
        if($showName){
            $name=$scope.' .ng-category-card__name';
            $style.=$name.'{';
            foreach(array('nameColor'=>'color','nameBackground'=>'background','namePadding'=>'padding','nameRadius'=>'border-radius','nameFontFamily'=>'font-family','nameFontSize'=>'font-size','nameFontWeight'=>'font-weight','nameLetterSpacing'=>'letter-spacing','nameTransform'=>'text-transform','nameShadow'=>'text-shadow') as $k=>$prop){
                if(isset($s[$k])&&$s[$k]!=='') $style.=$prop.':'.$css($s[$k]).';';
            }
            $style.='}';
        }
        $button=$scope.' .ng-category-card__button';
        $hoverState=(isset($s['states'])&&is_array($s['states'])&&isset($s['states']['hover'])&&is_array($s['states']['hover']))?$s['states']['hover']:array();
        $style.=$button.'{position:absolute;left:50%;bottom:16px;transform:translate(-50%,10px);opacity:0;z-index:5;display:inline-flex;align-items:center;justify-content:center;white-space:nowrap;text-decoration:none;cursor:pointer;transition:opacity .2s ease,transform .2s ease;';
        foreach(array('buttonColor'=>'color','buttonBackground'=>'background','buttonBorderColor'=>'border-color','buttonBorderWidth'=>'border-width','buttonBorderStyle'=>'border-style','buttonRadius'=>'border-radius','buttonPadding'=>'padding','buttonFontSize'=>'font-size','buttonFontWeight'=>'font-weight') as $k=>$prop){if(isset($s[$k])&&$s[$k]!=='')$style.=$prop.':'.$css($s[$k]).';';}$style.='}';
        $style.=$scope.' .ng-category-card:hover .ng-category-card__button,.'.$safeId.' .ng-category-card__button.is-always{opacity:1;transform:translate(-50%,0);}';
        if($buttonDisplay==='always')$style.=$scope.' .ng-category-card__button{opacity:1;transform:translate(-50%,0);}';
        $style.=$button.':hover{';
        foreach(array('buttonHoverColor'=>'color','buttonHoverBackground'=>'background','buttonHoverBorderColor'=>'border-color') as $k=>$prop){
            $v=isset($hoverState[$k])?$hoverState[$k]:(isset($s[$k])?$s[$k]:'');
            if(is_array($v)&&isset($v['desktop'])) $v=$v['desktop'];
            if($v!=='') $style.=$prop.':'.$css($v).' !important;';
        }
        $style.='}';
        $hoverFilter=isset($hoverState['hoverFilter'])?$hoverState['hoverFilter']:'';$hoverTransform=isset($hoverState['hoverTransform'])?$hoverState['hoverTransform']:'';if($hoverFilter!==''||$hoverTransform!==''){$style.=$scope.' .ng-category-card:hover .ng-category-card__media img{'.($hoverFilter!==''?'filter:'.$css($hoverFilter).';':'').($hoverTransform!==''?'transform:'.$css($hoverTransform).';':'').'}';}
        $overlayColor=isset($s['overlayColor'])?$s['overlayColor']:'';$overlayOpacity=isset($s['overlayOpacity'])?$s['overlayOpacity']:'';if($overlayColor!==''||$overlayOpacity!==''){$style.=$scope.' .ng-category-card__media:after{content:"";position:absolute;inset:0;background:'.$css($overlayColor!==''?$overlayColor:'transparent').';opacity:'.$css($overlayOpacity!==''?$overlayOpacity:'1').';pointer-events:none;}';}
        if($mode==='grid'){
            $style.=$scope.'{display:grid;grid-template-columns:repeat(var(--ng-category-columns),minmax(0,1fr));gap:var(--ng-category-gap);align-items:stretch;}';
        } else {
            $style.=$scope.'{position:relative;display:block;}'.$scope.' .ng-category-slider-viewport{display:block;overflow:hidden;width:100%;box-sizing:border-box;}'.$scope.' .ng-category-grid-track{display:flex!important;flex-wrap:nowrap!important;gap:var(--ng-category-gap);width:100%;transition:transform .45s ease;will-change:transform;}'.$scope.' .ng-category-grid-track .ng-category-card{flex:0 0 calc((100% - (var(--ng-category-columns) - 1)*var(--ng-category-gap))/var(--ng-category-columns))!important;width:calc((100% - (var(--ng-category-columns) - 1)*var(--ng-category-gap))/var(--ng-category-columns))!important;max-width:calc((100% - (var(--ng-category-columns) - 1)*var(--ng-category-gap))/var(--ng-category-columns))!important;min-width:0!important;}'.$scope.' .ng-category-slider-arrow{position:absolute;top:50%;transform:translateY(-50%);z-index:20;border:0;cursor:pointer;display:flex!important;align-items:center;justify-content:center;width:42px;height:42px;padding:0;border-radius:50%;background:rgba(255,255,255,.96);color:#111827!important;font-family:Arial,Helvetica,sans-serif!important;font-size:28px!important;font-weight:400!important;line-height:1!important;box-shadow:0 4px 16px rgba(0,0,0,.18);text-indent:0;visibility:visible!important;}'.$scope.' .ng-category-slider-arrow__icon{display:block!important;color:#111827!important;font-family:Arial,Helvetica,sans-serif!important;font-size:28px!important;font-weight:400!important;line-height:1!important;}'.$scope.' .ng-category-slider-prev{left:12px;}'.$scope.' .ng-category-slider-next{right:12px;}'.$scope.' .ng-category-slider-dots{display:flex;gap:7px;justify-content:center;margin-top:16px;}'.$scope.' .ng-category-slider-dot{width:7px;height:7px;border:0;border-radius:50%;background:#c7cbd1;padding:0;cursor:pointer;}'.$scope.' .ng-category-slider-dot.is-active{background:#111827;}';
        }
        $style.='</style>';
        $html=$style;
        if($mode==='slider'){
            $html.='<div class="ng-widget ng-category-grid ng-category-grid-'.$this->esc($safeId).' ng-category-grid--slider" data-ng-category-slider="1" data-autoplay="'.($autoplay?'1':'0').'" data-interval="'.$interval.'" data-loop="'.($loop?'1':'0').'" data-columns="'.$cols.'">';
            $html.='<div class="ng-category-slider-viewport"><div class="ng-category-grid-track">';
        } else {
            $html.='<div class="ng-widget ng-category-grid ng-category-grid-'.$this->esc($safeId).'">';
        }
        foreach($items as $item){
            $name=$this->esc($item['name']??'Category');$img=$this->esc($this->imageUrl($item['image']??''));$href=$this->esc($item['url']??'#');
            $html.='<article class="ng-category-card">';
            $html.='<a class="ng-category-card__media" href="'.$href.'">'.($img?'<img src="'.$img.'" alt="'.$name.'" loading="lazy">':'<span class="ng-category-card__placeholder">'.$name.'</span>');
            if($showName&&$namePos==='overlay')$html.='<span class="ng-category-card__name ng-category-card__name--overlay pos-'.$this->esc($nameOverlayPos).'">'.$name.'</span>';
            if($buttonDisplay!=='never')$html.='<span class="ng-category-card__button'.($buttonDisplay==='always'?' is-always':'').'">'.$this->esc($buttonText).'</span>';
            $html.='</a>';
            if($showName&&$namePos==='below')$html.='<a class="ng-category-card__name ng-category-card__name--below" style="text-align:'.$this->esc($nameAlign).';" href="'.$href.'">'.$name.'</a>';
            $html.='</article>';
        }
        if(!$items)$html.='<div class="ng-media-placeholder">Select categories to display.</div>';
        if($mode==='slider'){
            $html.='</div></div>';
            if($arrows && count($items)>1)$html.='<button type="button" class="ng-category-slider-arrow ng-category-slider-prev" aria-label="Previous"><span class="ng-category-slider-arrow__icon">'.$this->esc($prevGlyph).'</span></button><button type="button" class="ng-category-slider-arrow ng-category-slider-next" aria-label="Next"><span class="ng-category-slider-arrow__icon">'.$this->esc($nextGlyph).'</span></button>';
            if($dots && count($items)>$cols){$pages=count($items);$html.='<div class="ng-category-slider-dots" aria-label="Category slider pagination">';for($i=0;$i<$pages;$i++)$html.='<button type="button" class="ng-category-slider-dot'.($i===0?' is-active':'').'" data-slide="'.$i.'" aria-label="Slide '.($i+1).'" aria-current="'.($i===0?'true':'false').'"></button>';$html.='</div>'; }
            $html.='</div>';
            if(count($items)>1){
                $html.='<script>(function(){var script=document.currentScript,root=script?script.previousElementSibling:null;if(!root)return;var viewport=root.querySelector(".ng-category-slider-viewport"),track=root.querySelector(".ng-category-grid-track"),originalCards=[].slice.call(track.querySelectorAll(":scope > .ng-category-card")),prev=root.querySelector(".ng-category-slider-prev"),next=root.querySelector(".ng-category-slider-next"),dots=[].slice.call(root.querySelectorAll(".ng-category-slider-dot")),cols=parseInt(root.getAttribute("data-columns"),10)||4,originalCount=originalCards.length,loop=root.getAttribute("data-loop")==="1",index=0,timer=null,resetTimer=null,step=0;if(originalCount<=cols)return;if(loop){originalCards.slice(0,Math.min(cols,originalCount)).forEach(function(card){var clone=card.cloneNode(true);clone.setAttribute("aria-hidden","true");track.appendChild(clone);});}function measure(){var card=track.querySelector(":scope > .ng-category-card");if(!card)return;var gap=parseFloat(getComputedStyle(track).columnGap||getComputedStyle(track).gap)||0;step=card.getBoundingClientRect().width+gap;}function activeDot(){var pos=loop?(index%originalCount):index;dots.forEach(function(d,j){d.classList.toggle("is-active",j===pos);d.setAttribute("aria-current",j===pos?"true":"false");});}function apply(animate){measure();track.style.transition=animate?"transform .45s ease":"none";track.style.transform="translate3d(-"+(Math.max(0,index)*step)+"px,0,0)";activeDot();}function go(i){if(loop){if(i<0){track.style.transition="none";index=originalCount;apply(false);requestAnimationFrame(function(){requestAnimationFrame(function(){index=originalCount-1;apply(true);});});return;}if(i>=originalCount){index=originalCount;apply(true);if(resetTimer)clearTimeout(resetTimer);resetTimer=setTimeout(function(){index=0;apply(false);},470);return;}index=i;}else{index=Math.max(0,Math.min(originalCount-cols,i));}apply(true);}if(prev)prev.onclick=function(){if(resetTimer)clearTimeout(resetTimer);go(index-1);};if(next)next.onclick=function(){if(resetTimer)clearTimeout(resetTimer);go(index+1);};dots.forEach(function(d,j){d.onclick=function(){if(resetTimer)clearTimeout(resetTimer);go(j);};});function start(){if(root.getAttribute("data-autoplay")!=="1"||originalCount<=cols)return;if(timer)clearInterval(timer);timer=setInterval(function(){go(index+1);},Math.max(1000,parseInt(root.getAttribute("data-interval"),10)||4000));}function stop(){if(timer){clearInterval(timer);timer=null;}if(resetTimer){clearTimeout(resetTimer);resetTimer=null;}}root.addEventListener("mouseenter",stop);root.addEventListener("mouseleave",start);window.addEventListener("resize",function(){apply(false);});apply(false);start();})();</script>';
            }
        }
        return $html;
    }

    private function products($n,$c) {
        $s=isset($n['settings'])&&is_array($n['settings'])?$n['settings']:array();
        $source=(string)($s['source']??'latest');
        if(isset($s['productIds']) && is_string($s['productIds'])) $s['productIds']=array_values(array_filter(array_map('intval',preg_split('/[,\s]+/',trim($s['productIds'])))));
        if(isset($s['tabs_json']) && is_string($s['tabs_json'])) { $decoded=json_decode($s['tabs_json'],true); if(is_array($decoded)) $s['tabs']=$decoded; }
        $mode=(string)($s['displayMode']??'grid');
        $limit=max(1,min(60,(int)($s['limit']??8)));
        $cols=max(1,min(8,(int)($s['columns']??4)));
        $tablet=max(1,min(6,(int)($s['columnsTablet']??3)));
        $mobile=max(1,min(4,(int)($s['columnsMobile']??2)));
        $gap=max(0,(int)($s['gap']??22));
        $arrowPosition=(string)($s['arrowPosition']??'middle-outside');
        $arrowOffsetY=(string)($s['arrowOffsetY']??'0px');
        if(!in_array($arrowPosition,array('bottom','middle-outside','middle-inside','top'),true)) $arrowPosition='middle-outside';
        $items=array();
        if($source==='custom' && !empty($s['productIds']) && isset($c['product_lookup']) && is_callable($c['product_lookup'])) {
            $items=call_user_func($c['product_lookup'],array_map('intval',$s['productIds']));
        } elseif($source==='category' && !empty($s['categoryId']) && isset($c['category_lookup']) && is_callable($c['category_lookup'])) {
            $items=call_user_func($c['category_lookup'],(int)$s['categoryId']);
        } elseif(isset($c['product_source_lookup']) && is_callable($c['product_source_lookup'])) {
            $items=call_user_func($c['product_source_lookup'],$source);

        } else {
            $items=isset($c['products'])&&is_array($c['products'])?$c['products']:array();
        }
        $items=array_slice($items,0,$limit);
        $items=$this->normalizeProducts($items);
        $scope='ng-products-'.preg_replace('/[^a-zA-Z0-9_-]/','-',(string)($n['id']??uniqid('products_',false)));
        $widgetWidthMode=(string)($s['widgetWidthMode']??'boxed');
        if(!in_array($widgetWidthMode,array('full','boxed','custom'),true)) $widgetWidthMode='boxed';
        $widgetWidth=(string)($s['widgetWidth']??'100%');
        $widgetMaxWidth=(string)($s['widgetMaxWidth']??'1400px');
        $widgetAlign=(string)($s['widgetAlign']??'center');
        if(!in_array($widgetAlign,array('left','center','right'),true)) $widgetAlign='center';
        $widgetMargin=($widgetAlign==='left'?'0 auto 0 0':($widgetAlign==='right'?'0 0 0 auto':'0 auto'));
        $widgetOuterX=(string)($s['widgetPaddingX']??'0px');
        $style='<style data-nextgen-products="'.$this->esc($scope).'">';
        $style.='.'.$scope.'{--ng-products-cols:'.$cols.';--ng-products-tablet:'.$tablet.';--ng-products-mobile:'.$mobile.';--ng-products-gap:'.$gap.'px;}';
        if($widgetWidthMode==='full') {
            $style.='.'.$scope.'{width:100%;max-width:none;margin:0;padding-left:'.$this->escCssValue($widgetOuterX).';padding-right:'.$this->escCssValue($widgetOuterX).';}';
        } elseif($widgetWidthMode==='custom') {
            $style.='.'.$scope.'{width:'.$this->escCssValue($widgetWidth).';max-width:'.$this->escCssValue($widgetMaxWidth).';margin:'.$widgetMargin.';padding-left:'.$this->escCssValue($widgetOuterX).';padding-right:'.$this->escCssValue($widgetOuterX).';}';
        } else {
            $style.='.'.$scope.'{width:100%;max-width:'.$this->escCssValue($widgetMaxWidth).';margin:'.$widgetMargin.';padding-left:'.$this->escCssValue($widgetOuterX).';padding-right:'.$this->escCssValue($widgetOuterX).';}';
        }
        $style.='.'.$scope.' .ng-products__grid{display:grid;grid-template-columns:repeat(var(--ng-products-cols),minmax(0,1fr));gap:var(--ng-products-gap);}';
        $style.='.'.$scope.' .ng-products__track{display:flex;gap:var(--ng-products-gap);transition:transform '.max(100,(int)($s['speed']??450)).'ms ease;will-change:transform;}';
        $style.='.'.$scope.' .ng-products__track > .ng-product-card{flex:0 0 calc((100% - (var(--ng-products-cols) - 1)*var(--ng-products-gap))/var(--ng-products-cols));min-width:0;}';
        $style.='.'.$scope.' .ng-product-card{position:relative;min-width:0;background:'.$this->escCssValue($s['cardBackground']??'#ffffff').';border:'.$this->escCssValue($s['cardBorderWidth']??'1px').' '.$this->escCssValue($s['cardBorderStyle']??'solid').' '.$this->escCssValue($s['cardBorderColor']??'#e8e8e8').'!important;border-radius:'.$this->escCssValue($s['cardRadius']??'14px').';box-shadow:'.$this->escCssValue($s['cardShadow']??'0 8px 28px rgba(15,23,42,.06)').';overflow:hidden;transition:transform .25s ease,box-shadow .25s ease;}';
        $animation=(string)($s['cardAnimation']??'lift');
        $style.='.'.$scope.' .ng-product-card:hover{transform:'.($animation==='zoom'?'scale(1.02)':($animation==='lift'?'translateY(-4px)':'none')).';}';
        $style.='.'.$scope.' .ng-product-card-media{position:relative;display:block;overflow:hidden;background:'.$this->escCssValue($s['imageBackground']??'#f7f7f5').';aspect-ratio:1/1;line-height:0;}';
        if(!empty($s['imageHeight'])) $style.='.'.$scope.' .ng-product-card-media{height:'.$this->escCssValue($s['imageHeight']).';aspect-ratio:auto;}';
        $style.='.'.$scope.' .ng-product-card-media img{display:block;width:100%;height:100%;aspect-ratio:auto;object-fit:'. $this->escCssValue($s['imageFit']??'contain') .';transition:opacity .3s ease,transform '. $this->escCssValue($s['imageTransitionDuration']??'400ms') .' ease;}';
        $style.='.'.$scope.' .ng-product-image-hover{position:absolute;inset:0;opacity:0;}';
        $style.='.'.$scope.' .ng-product-card:hover .ng-product-image-hover{opacity:1;}';
        $style.='.'.$scope.' .ng-product-card:hover .ng-product-image-primary{transform:scale('.$this->escCssValue($s['imageHoverScale']??'1.03').');}';
        $style.='.'.$scope.' .ng-product-card-body{padding:14px;}';
        $style.='.'.$scope.' .ng-product-card-brand{font-size:10px;letter-spacing:.12em;text-transform:uppercase;opacity:.6;margin-bottom:5px;}';
        $style.='.'.$scope.' .ng-product-card-title{margin:0 0 7px;font-size:'.$this->escCssValue($s['productTitleSize']??'15px').';font-weight:'.$this->escCssValue($s['productTitleWeight']??'600').';}';
        $style.='.'.$scope.' .ng-product-card-title a{text-decoration:none;color:'.$this->escCssValue($s['productTitleColor']??'inherit').';}';
        $style.='.'.$scope.' .ng-product-card-price{display:flex;gap:8px;align-items:center;color:'.$this->escCssValue($s['priceColor']??'inherit').';margin-bottom:10px;}';
        $style.='.'.$scope.' .ng-product-card-price .ng-price-old{text-decoration:line-through;opacity:.55;font-size:.9em;}';
        $style.='.'.$scope.' .ng-product-card-actions{position:absolute;top:12px;right:12px;display:flex;flex-direction:column;gap:8px;opacity:1;transform:none;transition:opacity .2s ease,transform .2s ease;z-index:5;}';
        $actionPosition=(string)($s['actionPosition']??'overlay');
        if($actionPosition==='below') $style.='.'.$scope.' .ng-product-card-actions{position:static;display:flex;flex-direction:row;justify-content:flex-end;padding:10px 14px 0;gap:8px;opacity:1;transform:none;}';
        if($actionPosition==='hover') $style.='.'.$scope.' .ng-product-card-actions{opacity:0;transform:translateY(4px);pointer-events:none;} .'.$scope.' .ng-product-card:hover .ng-product-card-actions{opacity:1;transform:none;pointer-events:auto;}';
        if($actionPosition==='always') $style.='.'.$scope.' .ng-product-card-actions{opacity:1;transform:none;}';
        $style.='.'.$scope.' .ng-product-card:hover .ng-product-card-actions{opacity:1;transform:none;}';
        $style.='.'.$scope.' .ng-product-action{width:38px;height:38px;border:1px solid '.$this->escCssValue($s['actionBorderColor']??'rgba(17,24,39,.10)').';border-radius:'.$this->escCssValue($s['actionRadius']??'50%').';background:'.$this->escCssValue($s['actionBackground']??'rgba(255,255,255,.96)').';color:'.$this->escCssValue($s['actionColor']??'#111827').' !important;box-shadow:0 5px 18px rgba(0,0,0,.12);cursor:pointer;display:flex;align-items:center;justify-content:center;transition:transform .2s ease,background .2s ease;}';
        $style.='.'.$scope.' .ng-product-card-actions{top:'.$this->escCssValue($s['actionOffsetTop']??'12px').';right:'.$this->escCssValue($s['actionOffsetRight']??'12px').';gap:'.$this->escCssValue($s['actionGap']??'8px').';}';
        $style.='.'.$scope.' .ng-product-action{width:'.$this->escCssValue($s['actionSize']??'40px').';height:'.$this->escCssValue($s['actionSize']??'40px').';border-width:'.$this->escCssValue($s['actionBorderWidth']??'1px').';border-style:'.$this->escCssValue($s['actionBorderStyle']??'solid').';box-shadow:'.$this->escCssValue($s['actionShadow']??'0 5px 18px rgba(0,0,0,.12)').';}';
        $style.='.'.$scope.' .ng-product-action svg,.'.$scope.' .ng-product-action svg *{display:block!important;width:'.$this->escCssValue($s['actionIconSize']??'18px').'!important;height:'.$this->escCssValue($s['actionIconSize']??'18px').'!important;fill:none!important;stroke:'.$this->escCssValue($s['actionColor']??'#111827').'!important;stroke-width:'.$this->escCssValue($s['actionIconStroke']??'1.8').'!important;stroke-linecap:round!important;stroke-linejoin:round!important;visibility:visible!important;opacity:1!important;}';
        $style.='.'.$scope.' .ng-product-action:hover svg,.'.$scope.' .ng-product-action:hover svg *{stroke:'.$this->escCssValue($s['actionHoverColor']??'#ffffff').'!important;}';
        $style.='.'.$scope.' .ng-product-card-badge{position:absolute;left:12px;top:12px;z-index:4;padding:6px 9px;border-radius:999px;background:'.$this->escCssValue($s['badgeBackground']??'#111827').';color:'.$this->escCssValue($s['badgeColor']??'#ffffff').';font-size:10px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;}';
        $style.='.'.$scope.' .ng-product-card-body{padding:'.$this->escCssValue($s['cardPadding']??'18px').' '.$this->escCssValue($s['cardPaddingX']??'18px').' '.$this->escCssValue($s['cardPaddingBottom']??'18px').';}';
        $style.='.'.$scope.' .ng-product-card-brand{color:'.$this->escCssValue($s['brandColor']??'#94a3b8').';font-size:'.$this->escCssValue($s['brandFontSize']??'10px').';font-weight:'.$this->escCssValue($s['brandFontWeight']??'600').';letter-spacing:'.$this->escCssValue($s['brandLetterSpacing']??'.12em').';margin-bottom:'.$this->escCssValue($s['brandMarginBottom']??'8px').';}';
        $style.='.'.$scope.' .ng-product-card-model{font-size:'.$this->escCssValue($s['modelFontSize']??'12px').';color:'.$this->escCssValue($s['modelColor']??'#64748b').';margin-bottom:6px;}';
        $style.='.'.$scope.' .ng-product-card-title{margin-bottom:'.$this->escCssValue($s['titleMarginBottom']??'10px').';}';
        $style.='.'.$scope.' .ng-product-card-rating{color:'.$this->escCssValue($s['ratingColor']??'#f59e0b').';font-size:'.$this->escCssValue($s['ratingSize']??'13px').';margin-bottom:'.$this->escCssValue($s['ratingMarginBottom']??'9px').';}';
        $style.='.'.$scope.' .ng-product-card-rating span{color:'.$this->escCssValue($s['reviewCountColor']??'#94a3b8').';font-size:.9em;}';
        $style.='.'.$scope.' .ng-price-current,.'.$scope.' .ng-price-special{font-size:'.$this->escCssValue($s['priceFontSize']??'16px').';font-weight:'.$this->escCssValue($s['priceFontWeight']??'700').';color:'.$this->escCssValue($s['priceColor']??'#111827').';}';
        $style.='.'.$scope.' .ng-price-old{text-decoration:line-through;color:'.$this->escCssValue($s['oldPriceColor']??'#94a3b8').';font-size:'.$this->escCssValue($s['oldPriceFontSize']??'13px').';}';
        $style.='.'.$scope.' .ng-product-card-price{margin-bottom:'.$this->escCssValue($s['priceMarginBottom']??'16px').';}';
        $style.='.'.$scope.' .ng-product-add-cart{border-radius:'.$this->escCssValue($s['cartRadius']??'9px').';padding:'.$this->escCssValue($s['cartPadding']??'13px 16px').';background:'.$this->escCssValue($s['cartBackground']??'#111827').'!important;color:'.$this->escCssValue($s['cartColor']??'#ffffff').'!important;font-size:'.$this->escCssValue($s['cartFontSize']??'12px').';font-weight:'.$this->escCssValue($s['cartFontWeight']??'700').';border:'.$this->escCssValue($s['cartBorderWidth']??'0px').' '.$this->escCssValue($s['cartBorderStyle']??'solid').' '.$this->escCssValue($s['cartBorderColor']??'transparent').'!important;letter-spacing:'.$this->escCssValue($s['cartLetterSpacing']??'.05em').';}';
        $style.='.'.$scope.' .ng-product-add-cart:hover{background:'.$this->escCssValue($s['cartHoverBackground']??'#000000').'!important;color:'.$this->escCssValue($s['cartHoverColor']??'#ffffff').'!important;}';
        $style.='.'.$scope.' .ng-products-prev,.'.$scope.' .ng-products-next{width:'.$this->escCssValue($s['arrowSize']??'42px').';height:'.$this->escCssValue($s['arrowSize']??'42px').';border:'.$this->escCssValue($s['arrowBorderWidth']??'1px').' '.$this->escCssValue($s['arrowBorderStyle']??'solid').' '.$this->escCssValue($s['arrowBorderColor']??'#e2e8f0').'!important;border-radius:'.$this->escCssValue($s['arrowRadius']??'50%').';background:'.$this->escCssValue($s['arrowBackground']??'#ffffff').'!important;color:'.$this->escCssValue($s['arrowColor']??'#111827').'!important;box-shadow:'.$this->escCssValue($s['arrowShadow']??'0 5px 18px rgba(0,0,0,.10)').';font-size:0;display:inline-flex;align-items:center;justify-content:center;}';
        $style.='.'.$scope.' .ng-products-prev svg,.'.$scope.' .ng-products-next svg{width:'.$this->escCssValue($s['arrowIconSize']??'18px').'!important;height:'.$this->escCssValue($s['arrowIconSize']??'18px').'!important;stroke:'.$this->escCssValue($s['arrowColor']??'#111827').'!important;}';
        $style.='.'.$scope.' .ng-products-prev:hover,.'.$scope.' .ng-products-next:hover{background:'.$this->escCssValue($s['arrowHoverBackground']??'#111827').'!important;color:'.$this->escCssValue($s['arrowHoverColor']??'#ffffff').'!important;}';
        $style.='.'.$scope.' .ng-products-prev:hover svg,.'.$scope.' .ng-products-next:hover svg{stroke:'.$this->escCssValue($s['arrowHoverColor']??'#ffffff').'!important;}';
        $style.='.'.$scope.' .ng-products-dot{width:'.$this->escCssValue($s['dotSize']??'7px').';height:'.$this->escCssValue($s['dotSize']??'7px').';background:'.$this->escCssValue($s['dotColor']??'#cbd5e1').';opacity:1;}';
        $style.='.'.$scope.' .ng-products-dot.is-active{background:'.$this->escCssValue($s['dotActiveColor']??'#111827').';transform:scale('.$this->escCssValue($s['dotActiveScale']??'1.25').');}';
        $style.='.'.$scope.' .ng-products-slider-controls{display:flex;align-items:center;justify-content:flex-end;gap:8px;margin-top:16px;}';
        $style.='.'.$scope.' .ng-products-arrow-controls{display:flex;align-items:center;gap:8px;}';
        $style.='.'.$scope.' .ng-products-slider-controls.is-middle-outside{position:absolute;left:0;right:0;top:calc(50% + '.$this->escCssValue($arrowOffsetY).');transform:translateY(-50%);margin:0;justify-content:space-between;pointer-events:none;z-index:20;}';
        $style.='.'.$scope.' .ng-products-slider-controls.is-middle-outside .ng-products-arrow-controls{display:contents;}';
        $style.='.'.$scope.' .ng-products-slider-controls.is-middle-outside .ng-products-prev{transform:translateX(calc(-1 * '.$this->escCssValue($s['arrowOffsetX']??'18px').'));}';
        $style.='.'.$scope.' .ng-products-slider-controls.is-middle-outside .ng-products-next{transform:translateX('.$this->escCssValue($s['arrowOffsetX']??'18px').');}';
        $style.='.'.$scope.' .ng-products-slider-controls.is-middle-outside .ng-products-prev,.'.$scope.' .ng-products-slider-controls.is-middle-outside .ng-products-next{pointer-events:auto;}';
        $style.='.'.$scope.' .ng-products-slider-controls.is-middle-inside{position:absolute;left:0;right:0;top:calc(50% + '.$this->escCssValue($arrowOffsetY).');transform:translateY(-50%);margin:0;justify-content:space-between;pointer-events:none;z-index:20;}';
        $style.='.'.$scope.' .ng-products-slider-controls.is-middle-inside .ng-products-arrow-controls{display:contents;}';
        $style.='.'.$scope.' .ng-products-slider-controls.is-middle-inside .ng-products-prev,.'.$scope.' .ng-products-slider-controls.is-middle-inside .ng-products-next{pointer-events:auto;}';
        $style.='.'.$scope.' .ng-products-slider-controls.is-top{justify-content:flex-end;margin:0 0 16px;}';
        $style.='.'.$scope.' .ng-products-slider-controls.is-bottom{justify-content:flex-end;margin-top:16px;}';
        $style.='.'.$scope.' .ng-products-slider-dots{display:flex;align-items:center;justify-content:center;gap:6px;}';
        $style.='.'.$scope.' .ng-product-action:hover{transform:scale(1.08);background:'.$this->escCssValue($s['actionHoverBackground']??'#111827').'!important;color:'.$this->escCssValue($s['actionHoverColor']??'#ffffff').'!important;border-color:'.$this->escCssValue($s['actionHoverBorderColor']??($s['actionBorderColor']??'rgba(17,24,39,.10)')).'!important;}';
        $style.='.'.$scope.' .ng-product-action svg{display:block;width:18px;height:18px;fill:none;stroke:currentColor !important;stroke-width:'.$this->escCssValue($s['actionIconStroke']??'1.8').';stroke-linecap:round;stroke-linejoin:round;pointer-events:none;}';
        $style.='.'.$scope.' .ng-product-add-cart{width:100%;max-width:none;border:'.$this->escCssValue($s['cartBorderWidth']??'0px').' '.$this->escCssValue($s['cartBorderStyle']??'solid').' '.$this->escCssValue($s['cartBorderColor']??'transparent').'!important;padding:'.$this->escCssValue($s['cartPadding']??'12px 14px').';border-radius:'.$this->escCssValue($s['cartRadius']??'8px').';background:'.$this->escCssValue($s['cartBackground']??'#111827').'!important;color:'.$this->escCssValue($s['cartColor']??'#fff').'!important;font-size:'.$this->escCssValue($s['cartFontSize']??'12px').';font-weight:'.$this->escCssValue($s['cartFontWeight']??'700').';letter-spacing:'.$this->escCssValue($s['cartLetterSpacing']??'.04em').';text-transform:uppercase;cursor:pointer;transition:transform .2s ease,background .2s ease,opacity .2s ease;}';
        $style.='.'.$scope.' .ng-product-add-cart:hover{background:'.$this->escCssValue($s['cartHoverBackground']??'#000').'!important;color:'.$this->escCssValue($s['cartHoverColor']??'#fff').'!important;transform:translateY(-1px);}';
        $style.='.'.$scope.' .ng-products__viewport,.'.$scope.' .ng-products-viewport{overflow:hidden;width:100%;}';
        $style.='.'.$scope.' .ng-products__track{align-items:stretch;}';
        $style.='.'.$scope.' .ng-products-tabs{justify-content:'. $this->escCssValue($s['tabsAlign']??'center') .';gap:'.$this->escCssValue($s['tabsGap']??'8px').';margin-bottom:'.$this->escCssValue($s['tabsMarginBottom']??'24px').';}';
        $style.='.'.$scope.' .ng-products-tab{color:'.$this->escCssValue($s['tabsColor']??'#94a3b8').';background:'.$this->escCssValue($s['tabsBackground']??'transparent').';border:'.$this->escCssValue($s['tabsBorderWidth']??'0px').' solid '.$this->escCssValue($s['tabsBorderColor']??'transparent').';border-radius:'.$this->escCssValue($s['tabsRadius']??'0px').';padding:'.$this->escCssValue($s['tabsPadding']??'9px 14px').';font-size:'.$this->escCssValue($s['tabsFontSize']??'13px').';font-weight:'.$this->escCssValue($s['tabsFontWeight']??'600').';text-transform:'.$this->escCssValue($s['tabsTextTransform']??'uppercase').';border-bottom-width:'.$this->escCssValue($s['tabsBorderWidth']??'2px').';border-bottom-color:'.$this->escCssValue($s['tabsBorderColor']??'transparent').';}';
        $style.='.'.$scope.' .ng-products-tab:hover{color:'.$this->escCssValue($s['tabsHoverColor']??($s['tabsColor']??'#111827')).'!important;background:'.$this->escCssValue($s['tabsHoverBackground']??'transparent').'!important;}';
        $style.='.'.$scope.' .ng-products-tab.is-active{color:'.$this->escCssValue($s['tabsActiveColor']??'#111827').'!important;background:'.$this->escCssValue($s['tabsActiveBackground']??'transparent').'!important;border-bottom-color:'.$this->escCssValue($s['tabsActiveBorderColor']??'#111827').'!important;}';
        if(isset($s['responsive']) && is_array($s['responsive'])){
            $rr=$s['responsive'];
            foreach(array('tablet'=>'900px','mobile'=>'600px') as $dev=>$bp){
                $r='';
                $rwMode=isset($rr['widgetWidthMode'][$dev])?(string)$rr['widgetWidthMode'][$dev]:'';
                $rwWidth=isset($rr['widgetWidth'][$dev])?(string)$rr['widgetWidth'][$dev]:'';
                $rwMax=isset($rr['widgetMaxWidth'][$dev])?(string)$rr['widgetMaxWidth'][$dev]:'';
                $rwAlign=isset($rr['widgetAlign'][$dev])?(string)$rr['widgetAlign'][$dev]:'';
                $rwPad=isset($rr['widgetPaddingX'][$dev])?(string)$rr['widgetPaddingX'][$dev]:'';
                if($rwMode!==''){
                    if($rwMode==='full') $r.='.'.$scope.'{width:100%;max-width:none;}';
                    elseif($rwMode==='custom'){
                        if($rwWidth!=='') $r.='.'.$scope.'{width:'.$this->escCssValue($rwWidth).';}';
                        if($rwMax!=='') $r.='.'.$scope.'{max-width:'.$this->escCssValue($rwMax).';}';
                    } else {
                        $r.='.'.$scope.'{width:100%;'.($rwMax!==''?'max-width:'.$this->escCssValue($rwMax).';':'').' }';
                    }
                } else {
                    if($rwWidth!=='') $r.='.'.$scope.'{width:'.$this->escCssValue($rwWidth).';}';
                    if($rwMax!=='') $r.='.'.$scope.'{max-width:'.$this->escCssValue($rwMax).';}';
                }
                if($rwAlign==='left') $r.='.'.$scope.'{margin-left:0;margin-right:auto;}';
                elseif($rwAlign==='right') $r.='.'.$scope.'{margin-left:auto;margin-right:0;}';
                elseif($rwAlign==='center') $r.='.'.$scope.'{margin-left:auto;margin-right:auto;}';
                if($rwPad!=='') $r.='.'.$scope.'{padding-left:'.$this->escCssValue($rwPad).';padding-right:'.$this->escCssValue($rwPad).';}';
                $map=array(
                    'cardBorderWidth'=>array('.ng-product-card','border-width','unit'),
                    'cardRadius'=>array('.ng-product-card','border-radius','raw'),
                    'imageHeight'=>array('.ng-product-card-media','height','raw'),
                    'brandFontSize'=>array('.ng-product-card-brand','font-size','raw'),
                    'brandFontWeight'=>array('.ng-product-card-brand','font-weight','raw'),
                    'productTitleSize'=>array('.ng-product-card-title','font-size','raw'),
                    'productTitleWeight'=>array('.ng-product-card-title','font-weight','raw'),
                    'ratingSize'=>array('.ng-product-card-rating','font-size','raw'),
                    'priceFontSize'=>array('.ng-price-current,.'.$scope.' .ng-price-special','font-size','raw'),
                    'priceFontWeight'=>array('.ng-price-current,.'.$scope.' .ng-price-special','font-weight','raw'),
                    'cartRadius'=>array('.ng-product-add-cart','border-radius','raw'),
                    'cartFontSize'=>array('.ng-product-add-cart','font-size','raw'),
                    'cartBorderWidth'=>array('.ng-product-add-cart','border-width','raw'),
                    'actionSize'=>array('.ng-product-action','width,height','raw'),
                    'actionIconSize'=>array('.ng-product-action svg','width,height','raw'),
                    'actionGap'=>array('.ng-product-card-actions','gap','raw'),
                    'actionRadius'=>array('.ng-product-action','border-radius','raw'),
                    'arrowSize'=>array('.ng-products-prev,.'.$scope.' .ng-products-next','width,height','raw'),
                    'arrowIconSize'=>array('.ng-products-prev svg,.'.$scope.' .ng-products-next svg','width,height','raw')
                );
                foreach($map as $k=>$cfg){
                    if(!isset($rr[$k][$dev])||$rr[$k][$dev]==='')continue;
                    $v=$this->escCssValue($rr[$k][$dev]);
                    if($cfg[1]==='width,height') $r.='.'.$scope.' '.$cfg[0].'{width:'.$v.';height:'.$v.';}';
                    else $r.='.'.$scope.' '.$cfg[0].'{'.$cfg[1].':'.$v.';}';
                }
                if($r)$style.='@media(max-width:'.$bp.'){'.$r.'}';
            }
        }
        $style.='@media(max-width:900px){.'.$scope.' .ng-products__grid{grid-template-columns:repeat(var(--ng-products-tablet),minmax(0,1fr));}.'.$scope.' .ng-products__track > .ng-product-card{flex-basis:calc((100% - (var(--ng-products-tablet) - 1)*var(--ng-products-gap))/var(--ng-products-tablet));}}';
        $style.='@media(max-width:600px){.'.$scope.' .ng-products__grid{grid-template-columns:repeat(var(--ng-products-mobile),minmax(0,1fr));}.'.$scope.' .ng-products__track > .ng-product-card{flex-basis:calc((100% - (var(--ng-products-mobile) - 1)*var(--ng-products-gap))/var(--ng-products-mobile));}}';
        $style.='</style>';
        $html=$style.'<section class="ng-widget ng-products '.$scope.'" data-ng-products data-mode="'.$this->esc($mode).'" data-columns="'.$cols.'" data-autoplay="'.(!empty($s['autoplay'])?'1':'0').'" data-interval="'.max(1000,(int)($s['interval']??4500)).'" data-loop="'.(!empty($s['loop'])?'1':'0').'">';
        if($mode==='tabs') {
            $tabs=isset($s['tabs'])&&is_array($s['tabs'])?$s['tabs']:array();
            if(!$tabs)$tabs=array(array('label'=>'Latest Products','source'=>'latest','limit'=>$limit));
            $html.='<div class="ng-products-tabs" role="tablist">';
            foreach($tabs as $i=>$tab){$label=$this->esc($tab['label']??('Tab '.($i+1)));$html.='<button type="button" class="ng-products-tab'.($i===0?' is-active':'').'" data-products-tab="'.$i.'" aria-selected="'.($i===0?'true':'false').'">'.$label.'</button>';}
            $html.='</div><div class="ng-products-tab-panels">';
            foreach($tabs as $i=>$tab){
                $tabSource=(string)($tab['source']??'latest');$tabItems=array();
                if($tabSource==='custom' && !empty($tab['productIds']) && isset($c['product_lookup']) && is_callable($c['product_lookup'])) { $tabIds=is_array($tab['productIds']??null)?$tab['productIds']:array_values(array_filter(array_map('intval',preg_split('/[,\s]+/',trim((string)($tab['productIds']??''))))));$tabItems=call_user_func($c['product_lookup'],$tabIds); }
                elseif($tabSource==='category' && !empty($tab['categoryId']) && isset($c['category_lookup']) && is_callable($c['category_lookup']))$tabItems=call_user_func($c['category_lookup'],(int)$tab['categoryId']);
                elseif(isset($c['product_source_lookup'])&&is_callable($c['product_source_lookup']))$tabItems=call_user_func($c['product_source_lookup'],$tabSource);
                $tabLimit=max(1,min(60,(int)($tab['limit']??$limit)));
                $tabItems=$this->normalizeProducts(array_slice((array)$tabItems,0,$tabLimit));
                $html.='<div class="ng-products-tab-panel" data-products-panel="'.$i.'"'.($i===0?'':' hidden').'>'; 
                $html.='<div class="ng-products__grid">';foreach($tabItems as $p)$html.=$this->renderUnifiedProductCard($p,$s);if(!$tabItems)$html.='<div class="ng-media-placeholder">No products available for this tab.</div>';$html.='</div></div>';
            }
            $html.='</div>';
        } else {
            $html.='<div class="ng-products-viewport"><div class="'.($mode==='slider'?'ng-products__track':'ng-products__grid').'">';
            foreach($items as $p) $html.=$this->renderUnifiedProductCard($p,$s);
            if(!$items)$html.='<div class="ng-media-placeholder">No products available for this source.</div>';
            $html.='</div></div>';
        }
        if($mode==='tabs')$html.='<script>(function(){var panelsRoot=document.currentScript.previousElementSibling,wrap=panelsRoot?panelsRoot.parentElement:null,tabs=wrap?wrap.querySelectorAll(".ng-products-tab"):[],panels=panelsRoot?panelsRoot.querySelectorAll(".ng-products-tab-panel"):[];for(var i=0;i<tabs.length;i++){tabs[i].addEventListener("click",function(){var idx=this.getAttribute("data-products-tab");for(var j=0;j<tabs.length;j++){var active=String(j)===String(idx);tabs[j].classList.toggle("is-active",active);tabs[j].setAttribute("aria-selected",active?"true":"false");if(panels[j])panels[j].hidden=!active;}});}})();</script>';
        if($mode==='slider' && count($items)>$cols && (!empty($s['arrows']) || !empty($s['dots']))) {
            $html.='<div class="ng-products-slider-controls is-'.$this->esc($arrowPosition).'">';
            if(!empty($s['arrows'])) {
                $html.='<div class="ng-products-arrow-controls">';
                $html.='<button type="button" class="ng-products-prev" aria-label="Previous">'.$this->renderProductIcon($s['arrowPrevIcon']??'chevron-left').'</button>';
                $html.='<button type="button" class="ng-products-next" aria-label="Next">'.$this->renderProductIcon($s['arrowNextIcon']??'chevron-right').'</button>';
                $html.='</div>';
            }
            if(!empty($s['dots'])) {
                $dotCount=max(1,count($items)-$cols+1);
                $html.='<div class="ng-products-slider-dots" role="tablist">';
                for($di=0;$di<$dotCount;$di++) $html.='<button type="button" class="ng-products-dot'.($di===0?' is-active':'').'" data-products-dot="'.$di.'" aria-label="Go to slide '.($di+1).'" ></button>';
                $html.='</div>';
            }
            $html.='</div>';
        }
        $html.='</section>';
        /* Slider runtime is initialized by assets/js/widgets/ecommerce.js. */
        return $html;
    }

    private function normalizeProducts($items){
        $out=array();
        foreach((array)$items as $p){
            if(!is_array($p)) continue;
            $thumb=(string)($p['thumb']??'');
            $original=(string)($p['image']??'');
            $out[]=array(
                'product_id'=>(int)($p['product_id']??0),
                'name'=>(string)($p['name']??'Product'),
                'image'=>$thumb!==''?$thumb:$original,
                'image_original'=>$original,
                'href'=>(string)($p['href']??'#'),
                'price'=>(string)($p['price']??''),
                'special'=>isset($p['special'])?$p['special']:null,
                'manufacturer'=>(string)($p['manufacturer']??''),
                'model'=>(string)($p['model']??''),
                'rating'=>(float)($p['rating']??0),
                'reviews'=>(int)($p['reviews']??0),
                'additional_images'=>isset($p['additional_images'])?(array)$p['additional_images']:array()
            );
        }
        return $out;
    }

    private function renderUnifiedProductCard($p,$s){
        $name=$this->esc($p['name']);
        $href=$this->esc($p['href']);
        $image=$this->esc($this->imageUrl($p['image']));
        $original=$this->esc($this->imageUrl($p['image_original']??''));
        $special=$p['special']!==null?(string)$p['special']:'';
        $price=$this->esc($p['price']);
        $esc=function($v){return $this->esc((string)$v);};
        $icon=function($name){
            $name=strtolower(trim((string)$name));
            $icons=array(
                'heart'=>'<path d="M20.84 8.72c0 5.06-8.84 10.27-8.84 10.27S3.16 13.78 3.16 8.72A4.72 4.72 0 0 1 12 6.1a4.72 4.72 0 0 1 8.84 2.62Z"/>',
                'heart-filled'=>'<path d="M12 20.35S3 14.9 3 8.7A5 5 0 0 1 12 6.1a5 5 0 0 1 9 2.6c0 6.2-9 11.65-9 11.65Z" fill="currentColor" stroke="currentColor"/>',
                'eye'=>'<path d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6Z"/><circle cx="12" cy="12" r="2.6"/>',
                'search'=>'<circle cx="10.8" cy="10.8" r="6.2"/><path d="m16 16 5 5"/>',
                'bookmark'=>'<path d="M6 4.5A2.5 2.5 0 0 1 8.5 2h7A2.5 2.5 0 0 1 18 4.5V21l-6-3.8L6 21V4.5Z"/>',
                'plus'=>'<path d="M12 5v14M5 12h14"/>',
                'swap'=>'<path d="M7 4v15M4 7l3-3 3 3M17 20V5M14 17l3 3 3-3"/>',
                'compare'=>'<path d="M8 5v14M5 8l3-3 3 3M16 19V5M13 8l3-3 3 3"/>',
                'arrow-left'=>'<path d="m15 18-6-6 6-6"/>',
                'arrow-right'=>'<path d="m9 18 6-6-6-6"/>',
                'chevron-left'=>'<path d="m14 18-6-6 6-6"/>',
                'chevron-right'=>'<path d="m10 18 6-6-6-6"/>',
                'caret-left'=>'<path d="m14 5-7 7 7 7" fill="currentColor" stroke="none"/>',
                'caret-right'=>'<path d="m10 5 7 7-7 7" fill="currentColor" stroke="none"/>',
                'x'=>'<path d="m6 6 12 12M18 6 6 18"/>'
            );
            return $icons[$name]??$icons['heart'];
        };
        $svg=function($name) use ($icon){
            return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false" class="ng-action-icon"><g fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">'.$icon($name).'</g></svg>';
        };
        $actionButton=function($action,$iconName,$label) use ($svg,$esc,$p){
            return '<button type="button" class="ng-product-action ng-product-action-'.$action.'" data-action="'.$esc($action).'" data-product-id="'.(int)$p['product_id'].'" aria-label="'.$esc($label).'" title="'.$esc($label).'">'.$svg($iconName).'</button>';
        };
        $html='<article class="ng-product-card" data-product-id="'.(int)$p['product_id'].'">';
        if($image){
            $fallback=$original && $original!==$image ? ' data-ng-image-fallback="'.$original.'"' : '';
            $html.='<a class="ng-product-card-media" href="'.$href.'"><img class="ng-product-image-primary" src="'.$image.'"'.$fallback.' alt="'.$name.'" loading="lazy" decoding="async">';
            if(!empty($s['showHoverImage'])&&!empty($p['additional_images'][0]))$html.='<img class="ng-product-image-hover" src="'.$this->esc($this->imageUrl($p['additional_images'][0])).'" alt="" loading="lazy" decoding="async">';
            if(!empty($s['showLabels']) && ($special || !empty($s['saleBadgeText']) || !empty($s['newBadgeText']))){
                if($special && !empty($s['saleBadgeText'])) $html.='<span class="ng-product-card-badge ng-product-card-badge-sale">'.$esc($s['saleBadgeText']).'</span>';
                elseif(!$special && !empty($s['newBadgeText'])) $html.='<span class="ng-product-card-badge ng-product-card-badge-new">'.$esc($s['newBadgeText']).'</span>';
            }
            $html.='</a>';
        }
        if(!empty($s['showWishlist'])||!empty($s['showCompare'])||!empty($s['showQuickView'])){
            $html.='<div class="ng-product-card-actions">';
            if(($s['showWishlist']??true)!==false)$html.=$actionButton('wishlist',$s['wishlistIcon']??'heart','Wishlist');
            if(($s['showCompare']??true)!==false)$html.=$actionButton('compare',$s['compareIcon']??'swap','Compare');
            if(($s['showQuickView']??true)!==false)$html.=$actionButton('quick-view',$s['quickViewIcon']??'eye','Quick View');
            $html.='</div>';
        }
        $html.='<div class="ng-product-card-body">';
        if(!empty($s['showBrand'])&&$p['manufacturer'])$html.='<div class="ng-product-card-brand">'.$this->esc($p['manufacturer']).'</div>';
        if(!empty($s['showModel']) && !empty($p['model']))$html.='<div class="ng-product-card-model">'.$this->esc($p['model']).'</div>';
        $html.='<h3 class="ng-product-card-title"><a href="'.$href.'">'.$name.'</a></h3>';
        if(!empty($s['showRating'])&&$p['rating']>0)$html.='<div class="ng-product-card-rating" aria-label="Rating '.(float)$p['rating'].' out of 5">'.str_repeat('★',(int)round($p['rating'])).' <span>('.(int)$p['reviews'].')</span></div>';
        if(($s['showPrice']??true)!==false)$html.='<div class="ng-product-card-price">'.($special?'<span class="ng-price-special">'.$this->esc($special).'</span><span class="ng-price-old">'.$price.'</span>':'<span class="ng-price-current">'.$price.'</span>').'</div>';
        if(($s['showActions']??true)!==false)$html.='<button type="button" class="ng-product-add-cart" data-action="add-to-cart" data-product-id="'.(int)$p['product_id'].'">'.$esc($s['addToCartText']??'Add to Cart').'</button>';
        return $html.'</div></article>';
    }

    private function renderProductIcon($name){
        $map=array(
            'heart'=>'<path d="M20.84 8.72c0 5.06-8.84 10.27-8.84 10.27S3.16 13.78 3.16 8.72A4.72 4.72 0 0 1 12 6.1a4.72 4.72 0 0 1 8.84 2.62Z"/>',
            'eye'=>'<path d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6Z"/><circle cx="12" cy="12" r="2.6"/>',
            'search'=>'<circle cx="10.8" cy="10.8" r="6.2"/><path d="m16 16 5 5"/>',
            'bookmark'=>'<path d="M6 4.5A2.5 2.5 0 0 1 8.5 2h7A2.5 2.5 0 0 1 18 4.5V21l-6-3.8L6 21V4.5Z"/>',
            'arrow-left'=>'<path d="m15 18-6-6 6-6"/>',
            'arrow-right'=>'<path d="m9 18 6-6-6-6"/>',
            'chevron-left'=>'<path d="m14 18-6-6 6-6"/>',
            'chevron-right'=>'<path d="m10 18 6-6-6-6"/>',
            'caret-left'=>'<path d="m14 5-7 7 7 7" fill="currentColor" stroke="none"/>',
            'caret-right'=>'<path d="m10 5 7 7-7 7" fill="currentColor" stroke="none"/>',
            'plus'=>'<path d="M12 5v14M5 12h14"/>',
            'minus'=>'<path d="M5 12h14"/>',
            'x'=>'<path d="m6 6 12 12M18 6 6 18"/>'
        );
        $n=strtolower(trim((string)$name));$body=$map[$n]??$map['chevron-right'];
        return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false" class="ng-products-arrow-icon"><g fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">'.$body.'</g></svg>';
    }

    private function escCssValue($v){return preg_replace('/[^a-zA-Z0-9#%(),.\-+_\s\/]/','',(string)$v);}
    private function hero($n,$slider=false) {
        if ($slider) return $this->heroSlider($n);
        $s = isset($n['settings']) && is_array($n['settings']) ? $n['settings'] : array();
        $responsive = isset($s['responsive']) && is_array($s['responsive']) ? $s['responsive'] : array();
        $getDevice = function($key,$device,$default='') use ($s,$responsive) {
            if (isset($responsive[$key]) && is_array($responsive[$key]) && isset($responsive[$key][$device]) && $responsive[$key][$device] !== '') return $responsive[$key][$device];
            if ($device === 'desktop' && isset($s[$key]) && $s[$key] !== '') return $s[$key];
            return $default;
        };
        $get = function($key,$default='') use ($getDevice) { return $getDevice($key,'desktop',$default); };
        $getHoverDevice = function($key,$device,$default='') use ($s) {
            $states=isset($s['states'])&&is_array($s['states'])?$s['states']:array();
            $hover=isset($states['hover'])&&is_array($states['hover'])?$states['hover']:array();
            $rr=isset($hover['responsive'])&&is_array($hover['responsive'])?$hover['responsive']:array();
            if(isset($rr[$key])&&is_array($rr[$key])&&isset($rr[$key][$device])&&$rr[$key][$device]!=='') return $rr[$key][$device];
            if($device!=='desktop'&&isset($rr[$key])&&is_array($rr[$key])&&isset($rr[$key]['desktop'])&&$rr[$key]['desktop']!=='') return $rr[$key]['desktop'];
            if(isset($hover[$key])&&$hover[$key]!=='') return $hover[$key];
            $direct='buttonHover'.ucfirst($key);
            return isset($s[$direct])&&$s[$direct]!==''?$s[$direct]:$default;
        };
        $css = function($v) {
            $v=(string)$v;
            return str_replace(array('</style>','</STYLE>','{','}',';'),array('','','','',''),$v);
        };
        $nodeId=preg_replace('/[^a-zA-Z0-9_-]/','-',(string)(isset($n['id'])?$n['id']:'hero'));
        if($nodeId==='') $nodeId='hero';
        $scope='.ng-rendered-widget.ng-node-'.$nodeId.' > .ng-universal-hero';
        $content=$scope.' .ng-universal-hero__content';
        $heading=$content.' > h1,'.$content.' > h2,'.$content.' > h3,'.$content.' > h4,'.$content.' > h5,'.$content.' > h6';
        $body=$content.' > p';
        $button=$content.' > a.ng-premium-hero-button';

        $widthMode=(string)$get('widthMode','contained');
        $height=(string)$get('minHeight','520px');
        $contentPos=(string)$get('contentPosition','left center');
        $contentMax=(string)$get('contentMaxWidth','760px');
        $contentPadding=(string)$get('contentPadding','');
        $textAlign=(string)$get('textAlign',$get('heroTextAlign','left'));
        $contentGap=(string)$get('contentGap','16px');
        $customWidth=(string)$get('customWidth','100%');
        $pos=(string)$get('backgroundPositionCustom',$get('backgroundPosition','center center'));
        $size=(string)$get('backgroundSize','cover');
        $repeat=(string)$get('backgroundRepeat','no-repeat');
        $bg=(string)$get('backgroundColor','');
        $overlay=(string)$get('overlayColor',$get('overlay',''));
        $overlayOpacity=(string)$get('overlayOpacity','');
        $img=$this->imageUrl($get('image',''));
        $mobile=$this->imageUrl($get('mobileImage',''));
        $mediaType=(string)$get('mediaType','image');
        $videoUrl=(string)$get('videoUrl','');
        $poster=$this->imageUrl($get('videoPoster',$get('image','')));
        $imageOpacity=(string)$get('imageOpacity','1');
        $imageFilter=(string)$get('imageFilter','');

        $parts=preg_split('/\s+/',trim($contentPos));
        $h=$parts[0]?:'left'; $v=$parts[1]?:'center';
        $align=$h==='right'?'flex-end':($h==='center'?'center':'flex-start');
        $justify=$v==='top'?'flex-start':($v==='bottom'?'flex-end':'center');

        $headingTag=(string)$get('headingTag','h2');
        if(!in_array($headingTag,array('h1','h2','h3','h4','h5','h6'),true)) $headingTag='h2';
        $headingText=$this->esc($get('heading','Your headline'));
        $bodyText=$this->esc($get('text','Your supporting content'));
        $buttonText=$this->esc($get('button','Shop Now'));
        $url=$this->esc($get('url','#'));
        $target=((string)$get('target','_self')==='_blank')?' target="_blank" rel="noopener noreferrer"':'';

        $style='--ng-hero-min-height:'.$css($height).';--ng-hero-content-max-width:'.$css($contentMax).';--ng-hero-content-padding:'.$css($contentPadding).';--ng-hero-text-align:'.$css($textAlign).';--ng-hero-content-gap:'.$css($contentGap).';--ng-hero-align-items:'.$align.';--ng-hero-justify-content:'.$justify.';';
        if($bg!=='') $style.='--ng-hero-background-color:'.$css($bg).';';
        if($overlay!=='') $style.='--ng-hero-overlay-color:'.$css($overlay).';';
        if($overlayOpacity!=='') $style.='--ng-hero-overlay-opacity:'.$css($overlayOpacity).';';

        $eyebrowMap=array('heroEyebrowFontFamily'=>'font-family','heroEyebrowSize'=>'font-size','heroEyebrowWeight'=>'font-weight','heroEyebrowLineHeight'=>'line-height','heroEyebrowLetterSpacing'=>'letter-spacing','heroEyebrowWordSpacing'=>'word-spacing','heroEyebrowTransform'=>'text-transform','heroEyebrowDecoration'=>'text-decoration','heroEyebrowStyle'=>'font-style','heroEyebrowColor'=>'color','heroEyebrowShadow'=>'text-shadow');
        $headingMap=array('heroHeadingFontFamily'=>'font-family','heroHeadingSize'=>'font-size','heroHeadingWeight'=>'font-weight','heroHeadingLineHeight'=>'line-height','heroHeadingLetterSpacing'=>'letter-spacing','heroHeadingWordSpacing'=>'word-spacing','heroHeadingTransform'=>'text-transform','heroHeadingDecoration'=>'text-decoration','heroHeadingStyle'=>'font-style','heroHeadingColor'=>'color','heroHeadingShadow'=>'text-shadow');
        $bodyMap=array('heroBodyFontFamily'=>'font-family','heroBodySize'=>'font-size','heroBodyWeight'=>'font-weight','heroBodyLineHeight'=>'line-height','heroBodyLetterSpacing'=>'letter-spacing','heroBodyWordSpacing'=>'word-spacing','heroBodyTransform'=>'text-transform','heroBodyDecoration'=>'text-decoration','heroBodyStyle'=>'font-style','heroBodyColor'=>'color','heroBodyShadow'=>'text-shadow');
        $buttonMap=array('buttonFontFamily'=>'font-family','buttonFontSize'=>'font-size','buttonFontWeight'=>'font-weight','buttonLineHeight'=>'line-height','buttonLetterSpacing'=>'letter-spacing','buttonTransform'=>'text-transform','buttonDecoration'=>'text-decoration','buttonStyle'=>'font-style','buttonBackground'=>'background','buttonColor'=>'color','buttonRadius'=>'border-radius','buttonPadding'=>'padding','buttonBorderWidth'=>'border-width','buttonBorderStyle'=>'border-style','buttonBorderColor'=>'border-color','buttonShadow'=>'box-shadow');
        $emit=function($map,$device) use ($getDevice,$css){$o='';foreach($map as $key=>$prop){$v=$getDevice($key,$device,'');if($v!==''&&$v!==null)$o.=$prop.':'.$css($v).' !important;';}return $o;};
        $rules=$scope.'{position:relative !important;display:block !important;min-height:'.$css($height).' !important;overflow:hidden !important;box-sizing:border-box !important;background:'.($bg!==''?$css($bg):'transparent').' !important;}';
        if($widthMode==='full') $rules.=$scope.'{width:100% !important;max-width:100% !important;margin-left:0 !important;margin-right:0 !important;transform:none !important;}';
        elseif($widthMode==='full_bleed') $rules.=$scope.'{width:100vw !important;max-width:100vw !important;margin-left:50% !important;margin-right:0 !important;transform:translateX(-50%) !important;}';
        elseif($widthMode==='wide') $rules.=$scope.'{width:calc(100% + 4vw) !important;max-width:none !important;margin-left:-2vw !important;}';
        elseif($widthMode==='custom') $rules.=$scope.'{width:'.$css($customWidth).' !important;max-width:'.$css($customWidth).' !important;margin-left:auto !important;margin-right:auto !important;}';
        $rules.=$scope.' .ng-universal-hero__media{position:absolute !important;inset:0 !important;z-index:0 !important;overflow:hidden !important;background:'.($bg!==''?$css($bg):'transparent').' !important;}';
        $rules.=$scope.' .ng-universal-hero__media img,'.$scope.' .ng-universal-hero__media video{width:100% !important;height:100% !important;display:block !important;object-fit:'.$css($size==='contain'?'contain':'cover').' !important;object-position:'.$css($pos).' !important;';
        if($imageOpacity!=='') $rules.='opacity:'.$css($imageOpacity).' !important;';
        if($imageFilter!=='') $rules.='filter:'.$css($imageFilter).' !important;';
        $rules.='}';
        $rules.=$content.'{position:relative !important;z-index:3 !important;display:flex !important;flex-direction:column !important;max-width:'.$css($contentMax).' !important;padding:'.$css($contentPadding).' !important;gap:'.$css($contentGap).' !important;text-align:'.$css($textAlign).' !important;align-items:'.$align.' !important;justify-content:'.$justify.' !important;box-sizing:border-box !important;height:100% !important;min-height:var(--ng-hero-min-height) !important;}';
        if($emit($eyebrowMap,'desktop')!=='')$rules.=$content.' > .ng-premium-hero-eyebrow{'.$emit($eyebrowMap,'desktop').'}';
        if($emit($headingMap,'desktop')!=='')$rules.=$heading.'{'.$emit($headingMap,'desktop').'}';
        if($emit($bodyMap,'desktop')!=='')$rules.=$body.'{'.$emit($bodyMap,'desktop').'}';
        if($emit($buttonMap,'desktop')!=='')$rules.=$button.'{'.$emit($buttonMap,'desktop').'}';
        if($overlay!=='')$rules.=$scope.' .ng-universal-hero__overlay{background:'.$css($overlay).' !important;}';
        if($overlayOpacity!=='')$rules.=$scope.' .ng-universal-hero__overlay{opacity:'.$css($overlayOpacity).' !important;}';
        // Resolve shared Normal/Hover state values after normal widget settings.
        $states=isset($s['states'])&&is_array($s['states'])?$s['states']:array();
        $stateHover=isset($states['hover'])&&is_array($states['hover'])?$states['hover']:array();
        $hoverBg=$getHoverDevice('buttonHoverBackground','desktop','');
        $hoverColor=$getHoverDevice('buttonHoverColor','desktop','');
        $hoverBorder=$getHoverDevice('buttonHoverBorderColor','desktop','');
        $hoverRadius=$getHoverDevice('buttonHoverRadius','desktop','');
        $hoverBorderWidth=$getHoverDevice('buttonHoverBorderWidth','desktop','');
        $hoverBorderStyle=$getHoverDevice('buttonHoverBorderStyle','desktop','');
        $hoverShadow=$getHoverDevice('buttonHoverShadow','desktop','');
        $hoverTransform=$getHoverDevice('buttonHoverTransform','desktop','');
        if($hoverBg!==''||$hoverColor!==''||$hoverBorder!==''||$hoverBorderWidth!==''||$hoverBorderStyle!==''||$hoverRadius!==''||$hoverShadow!==''||$hoverTransform!=='')$rules.=$button.':hover{'.($hoverBg!==''?'background:'.$css($hoverBg).' !important;':'').($hoverColor!==''?'color:'.$css($hoverColor).' !important;':'').($hoverBorder!==''?'border-color:'.$css($hoverBorder).' !important;':'').($hoverBorderWidth!==''?'border-width:'.$css($hoverBorderWidth).' !important;':'').($hoverBorderStyle!==''?'border-style:'.$css($hoverBorderStyle).' !important;':'').($hoverRadius!==''?'border-radius:'.$css($hoverRadius).' !important;':'').($hoverShadow!==''?'box-shadow:'.$css($hoverShadow).' !important;':'').($hoverTransform==='lift'?'transform:translateY(-2px) !important;':($hoverTransform==='scale'?'transform:scale(1.03) !important;':'')).'}';        $heroHoverBg=$getHoverDevice('heroHoverBackground','desktop','');$heroHoverOverlay=$getHoverDevice('heroHoverOverlayColor','desktop','');$heroHoverOverlayOpacity=$getHoverDevice('heroHoverOverlayOpacity','desktop','');$heroHoverOpacity=$getHoverDevice('heroHoverOpacity','desktop','');$heroHoverFilter=$getHoverDevice('heroHoverFilter','desktop','');$heroHoverTransform=$getHoverDevice('heroHoverTransform','desktop','');
        if($heroHoverBg!==''||$heroHoverOpacity!==''||$heroHoverFilter!==''||$heroHoverTransform!=='')$rules.=$scope.':hover{'.($heroHoverBg!==''?'background:'.$css($heroHoverBg).' !important;':'').($heroHoverOpacity!==''?'opacity:'.$css($heroHoverOpacity).' !important;':'').($heroHoverFilter!==''?'filter:'.$css($heroHoverFilter).' !important;':'').($heroHoverTransform!==''?'transform:'.$css($heroHoverTransform).' !important;':'').'}';
        if($heroHoverOverlay!==''||$heroHoverOverlayOpacity!=='')$rules.=$scope.':hover .ng-universal-hero__overlay{'.($heroHoverOverlay!==''?'background:'.$css($heroHoverOverlay).' !important;':'').($heroHoverOverlayOpacity!==''?'opacity:'.$css($heroHoverOverlayOpacity).' !important;':'').'}';
        foreach(array('tablet'=>'900px','mobile'=>'600px') as $device=>$break){
            $r='';$ee=$emit($eyebrowMap,$device);$hh=$emit($headingMap,$device);$bb=$emit($bodyMap,$device);$bt=$emit($buttonMap,$device);
            if($ee!=='')$r.=$content.' > .ng-premium-hero-eyebrow{'.$ee.'}';if($hh!=='')$r.=$heading.'{'.$hh.'}';if($bb!=='')$r.=$body.'{'.$bb.'}';if($bt!=='')$r.=$button.'{'.$bt.'}';
            $mh=$getDevice('minHeight',$device,'');if($mh!=='')$r.=$scope.'{min-height:'.$css($mh).' !important;}';
            $cm=$getDevice('contentMaxWidth',$device,'');if($cm!=='')$r.=$content.'{max-width:'.$css($cm).' !important;}';
            $cp=$getDevice('contentPadding',$device,'');if($cp!=='')$r.=$content.'{padding:'.$css($cp).' !important;}';
            $ta=$getDevice('textAlign',$device,$getDevice('heroTextAlign',$device,''));if($ta!=='')$r.=$content.'{text-align:'.$css($ta).' !important;}';
            $hb=$getHoverDevice('buttonHoverBackground',$device,'');$hc=$getHoverDevice('buttonHoverColor',$device,'');$hbo=$getHoverDevice('buttonHoverBorderColor',$device,'');$hbr=$getHoverDevice('buttonHoverRadius',$device,'');$hbw=$getHoverDevice('buttonHoverBorderWidth',$device,'');$hbst=$getHoverDevice('buttonHoverBorderStyle',$device,'');$hbs=$getHoverDevice('buttonHoverShadow',$device,'');$hbt=$getHoverDevice('buttonHoverTransform',$device,'');
            if($hb!==''||$hc!==''||$hbo!==''||$hbw!==''||$hbst!==''||$hbr!==''||$hbs!==''||$hbt!==''){$r.=$button.':hover{'.($hb!==''?'background:'.$css($hb).' !important;':'').($hc!==''?'color:'.$css($hc).' !important;':'').($hbo!==''?'border-color:'.$css($hbo).' !important;':'').($hbw!==''?'border-width:'.$css($hbw).' !important;':'').($hbst!==''?'border-style:'.$css($hbst).' !important;':'').($hbr!==''?'border-radius:'.$css($hbr).' !important;':'').($hbs!==''?'box-shadow:'.$css($hbs).' !important;':'').($hbt==='lift'?'transform:translateY(-2px) !important;':($hbt==='scale'?'transform:scale(1.03) !important;':($hbt!==''&&$hbt!=='none'?'transform:'.$css($hbt).' !important;':''))).'}';}            $hhb=$getHoverDevice('heroHoverBackground',$device,'');$hho=$getHoverDevice('heroHoverOverlayColor',$device,'');$hhop=$getHoverDevice('heroHoverOverlayOpacity',$device,'');$hho2=$getHoverDevice('heroHoverOpacity',$device,'');$hhf=$getHoverDevice('heroHoverFilter',$device,'');$hht=$getHoverDevice('heroHoverTransform',$device,'');if($hhb!==''||$hho2!==''||$hhf!==''||$hht!=='')$r.=$scope.':hover{'.($hhb!==''?'background:'.$css($hhb).' !important;':'').($hho2!==''?'opacity:'.$css($hho2).' !important;':'').($hhf!==''?'filter:'.$css($hhf).' !important;':'').($hht!==''?'transform:'.$css($hht).' !important;':'').'}';if($hho!==''||$hhop!=='')$r.=$scope.':hover .ng-universal-hero__overlay{'.($hho!==''?'background:'.$css($hho).' !important;':'').($hhop!==''?'opacity:'.$css($hhop).' !important;':'').'}';
            $imgOpD=$getDevice('imageOpacity',$device,'');$imgFilterD=$getDevice('imageFilter',$device,'');if($imgOpD!=='')$r.=$scope.' .ng-universal-hero__media img,'.$scope.' .ng-universal-hero__media video{opacity:'.$css($imgOpD).' !important;}';if($imgFilterD!=='')$r.=$scope.' .ng-universal-hero__media img,'.$scope.' .ng-universal-hero__media video{filter:'.$css($imgFilterD).' !important;}';$posD=$getDevice('backgroundPositionCustom',$device,$getDevice('backgroundPosition',$device,''));if($posD!=='')$r.=$scope.' .ng-universal-hero__media img,'.$scope.' .ng-universal-hero__media video{object-position:'.$css($posD).' !important;}';
            $sizeD=$getDevice('backgroundSize',$device,'');if($sizeD!=='')$r.=$scope.' .ng-universal-hero__media img{object-fit:'.$css($sizeD==='contain'?'contain':'cover').' !important;}';
            $cpD=$getDevice('contentPosition',$device,'');if($cpD!==''){ $pp=preg_split('/\s+/',trim((string)$cpD));$hh2=$pp[0]?:'left';$vv2=$pp[1]?:'center';$aa=$hh2==='right'?'flex-end':($hh2==='center'?'center':'flex-start');$jj=$vv2==='top'?'flex-start':($vv2==='bottom'?'flex-end':'center');$r.=$content.'{align-items:'.$aa.' !important;justify-content:'.$jj.' !important;}'; }
            if($device==='mobile'&&$mobile)$r.=$scope.' .ng-universal-hero__media img{content:url("'.$this->esc($mobile).'") !important;}';
            if($r!=='')$rules.='@media (max-width:'.$break.'){'.$r.'}';
        }
        $html='<style data-nextgen-hero-runtime="'.$this->esc($nodeId).'">'.$rules.'</style>';
        $html.='<section class="ng-widget ng-universal-hero" data-nextgen-hero-node="'.$this->esc($nodeId).'" style="'.$style.'">';
        $html.='<div class="ng-universal-hero__media" aria-hidden="true">';
        if($img)$html.='<img src="'.$this->esc($img).'" alt="" aria-hidden="true" loading="eager">';
        if($mediaType==='video'&&$videoUrl!==''){$html.='<video class="ng-universal-hero__video" autoplay muted loop playsinline preload="metadata"';if($poster)$html.=' poster="'.$this->esc($poster).'"';$html.='><source src="'.$this->esc($videoUrl).'" type="video/mp4"></video>';}
        $html.='</div><div class="ng-universal-hero__overlay" aria-hidden="true"></div><div class="ng-universal-hero__content">';
        if($get('eyebrow','')!=='')$html.='<span class="ng-premium-hero-eyebrow">'.$this->esc($get('eyebrow','')).'</span>';
        $html.='<'.$headingTag.'>'.$headingText.'</'.$headingTag.'>';
        if($get('text','')!=='')$html.='<p>'.$bodyText.'</p>';
        if($get('button','')!=='')$html.='<a class="ng-premium-hero-button" href="'.$url.'"'.$target.'>'.$buttonText.'</a>';
        $html.='</div></section>';
        return $html;
    }
    private function heroSlider($n) {
        $s=isset($n['settings'])&&is_array($n['settings'])?$n['settings']:array();
        $slides=isset($s['slides'])&&is_array($s['slides'])?$s['slides']:array();
        if(!$slides)$slides=array(array('title'=>'Slide 1','eyebrow'=>'NEXTGEN HERO','heading'=>'Your headline','text'=>'Your supporting content','button'=>'Shop Now','url'=>'#','target'=>'_self','image'=>'','mobileImage'=>'','mediaType'=>'image','videoUrl'=>'','videoPoster'=>'','backgroundPosition'=>'center center','backgroundSize'=>'cover','backgroundRepeat'=>'no-repeat','contentPosition'=>'left center','textAlign'=>'left','overlayColor'=>'#000000','overlayOpacity'=>.25));
        $responsive=isset($s['responsive'])&&is_array($s['responsive'])?$s['responsive']:array();
        $get=function($key,$default='')use($s){return isset($s[$key])&&$s[$key]!==''?$s[$key]:$default;};
        $css=function($v){return preg_replace('/[^a-zA-Z0-9#%(),.\-+_\s\/\\:]/','',(string)$v);};
        $id=preg_replace('/[^a-zA-Z0-9_-]/','-',(string)($n['id']??uniqid('hero_slider_',false)));if($id==='')$id='hero_slider';
        $scope='.ng-rendered-widget.ng-node-'.$id.' > .ng-hero-slider';
        $width=$get('widthMode','contained');$customWidth=$get('customWidth','100%');$height=$get('minHeight','680px');$contentMax=$get('contentMaxWidth','760px');$padding=$get('contentPadding','70px 7vw');$gap=$get('contentGap','16px');$contentPos=$get('contentPosition','left center');$textAlign=$get('textAlign','left');
        $transition=$get('transition','slide');$speed=max(100,(int)$get('speed',650));$interval=max(1000,(int)$get('interval',5000));$autoplay=$get('autoplay',true)!==false;$loop=$get('loop',true)!==false;$pauseHover=$get('pauseOnHover',true)!==false;$pauseFocus=$get('pauseOnFocus',true)!==false;$swipe=$get('swipe',true)!==false;$keyboard=$get('keyboard',true)!==false;$easing=$get('easing','ease');
        $icons=array('chevron-left'=>'‹','arrow-left'=>'←','angle-left'=>'❮','double-left'=>'«','caret-left'=>'‹','chevron-right'=>'›','arrow-right'=>'→','angle-right'=>'❯','double-right'=>'»','caret-right'=>'›');
        $prev=$icons[$get('arrowPrevIcon','chevron-left')]??'‹';$next=$icons[$get('arrowNextIcon','chevron-right')]??'›';
        $safe=function($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');};
        $posParts=preg_split('/\s+/',trim($contentPos));$hh=$posParts[0]??'left';$vv=$posParts[1]??'center';$align=$hh==='right'?'flex-end':($hh==='center'?'center':'flex-start');$justify=$vv==='top'?'flex-start':($vv==='bottom'?'flex-end':'center');
        $style='--ng-hero-slider-height:'.$css($height).';--ng-hero-slider-content-max:'.$css($contentMax).';--ng-hero-slider-padding:'.$css($padding).';--ng-hero-slider-gap:'.$css($gap).';--ng-hero-slider-align:'.$align.';--ng-hero-slider-justify:'.$justify.';--ng-hero-slider-text-align:'.$css($textAlign).';--ng-hero-slider-speed:'.$speed.'ms;--ng-hero-slider-easing:'.$css($easing).';--ng-hero-slider-bg:'.$css($get('backgroundColor','transparent')).';--ng-hero-slider-overlay:'.$css($get('overlayColor','transparent')).';--ng-hero-slider-overlay-opacity:'.$css($get('overlayOpacity','.25')).';';
        $rules=$scope.'{position:relative;display:block;width:100%;min-height:var(--ng-hero-slider-height);overflow:hidden;box-sizing:border-box;background:var(--ng-hero-slider-bg);border:'.$css($get('containerBorderWidth','0px')).' '.$css($get('containerBorderStyle','solid')).' '.$css($get('containerBorderColor','transparent')).';border-radius:'.$css($get('containerRadius','0px')).';box-shadow:'.$css($get('containerShadow','none')).';}';
        if($width==='full')$rules.=$scope.'{width:100%;max-width:100%;margin-left:0;margin-right:0;}';elseif($width==='full_bleed')$rules.=$scope.'{width:100vw;max-width:100vw;margin-left:50%;transform:translateX(-50%);}';elseif($width==='wide')$rules.=$scope.'{width:calc(100% + 4vw);max-width:none;margin-left:-2vw;}';elseif($width==='custom')$rules.=$scope.'{width:'.$css($customWidth).';max-width:'.$css($customWidth).';margin-left:auto;margin-right:auto;}';
        $rules.=$scope.' .ng-hero-slider__viewport{position:relative;width:100%;min-height:inherit;overflow:hidden;}';
        $rules.=$scope.' .ng-hero-slider__track{display:flex;width:100%;min-height:inherit;transition:transform '.$speed.'ms '.$css($easing).';will-change:transform;}';
        $rules.=$scope.' .ng-hero-slider__slide{position:relative;flex:0 0 100%;min-height:var(--ng-hero-slider-height);overflow:hidden;box-sizing:border-box;}';
        if($transition==='fade'){$rules.=$scope.'[data-transition="fade"] .ng-hero-slider__track{display:block;height:100%;min-height:inherit;transform:none!important;}'.$scope.'[data-transition="fade"] .ng-hero-slider__slide{position:absolute;inset:0;width:100%;opacity:0;pointer-events:none;transition:opacity '.$speed.'ms '.$css($easing).';}'.$scope.'[data-transition="fade"] .ng-hero-slider__slide.is-active{opacity:1;pointer-events:auto;}';}
        $rules.=$scope.' .ng-hero-slider__media{position:absolute;inset:0;z-index:0;overflow:hidden;background:var(--slide-bg,#111827);}'.$scope.' .ng-hero-slider__media img,'.$scope.' .ng-hero-slider__media video{display:block;width:100%;height:100%;object-fit:var(--slide-fit,cover);object-position:var(--slide-position,center center);opacity:var(--slide-opacity,1);filter:var(--slide-filter,none);background:var(--slide-bg,#111827);transition:transform '.$speed.'ms '.$css($easing).';}'.$scope.' .ng-hero-slider__overlay{position:absolute;inset:0;z-index:1;background:var(--slide-overlay,#000);opacity:var(--slide-overlay-opacity,.25);pointer-events:none;}';
        $rules.=$scope.' .ng-hero-slider__content{position:relative;z-index:2;display:flex;flex-direction:column;align-items:var(--slide-align,var(--ng-hero-slider-align));justify-content:var(--slide-justify,var(--ng-hero-slider-justify));max-width:var(--ng-hero-slider-content-max);min-height:var(--ng-hero-slider-height);padding:var(--ng-hero-slider-padding);gap:var(--ng-hero-slider-gap);box-sizing:border-box;text-align:var(--slide-text-align,var(--ng-hero-slider-text-align));color:#fff;}';
        $maps=array(
          'eyebrow'=>array('heroEyebrowFontFamily'=>'font-family','heroEyebrowSize'=>'font-size','heroEyebrowWeight'=>'font-weight','heroEyebrowLineHeight'=>'line-height','heroEyebrowLetterSpacing'=>'letter-spacing','heroEyebrowWordSpacing'=>'word-spacing','heroEyebrowTransform'=>'text-transform','heroEyebrowDecoration'=>'text-decoration','heroEyebrowStyle'=>'font-style','heroEyebrowColor'=>'color','heroEyebrowShadow'=>'text-shadow'),
          'heading'=>array('heroHeadingFontFamily'=>'font-family','heroHeadingSize'=>'font-size','heroHeadingWeight'=>'font-weight','heroHeadingLineHeight'=>'line-height','heroHeadingLetterSpacing'=>'letter-spacing','heroHeadingWordSpacing'=>'word-spacing','heroHeadingTransform'=>'text-transform','heroHeadingDecoration'=>'text-decoration','heroHeadingStyle'=>'font-style','heroHeadingColor'=>'color','heroHeadingShadow'=>'text-shadow'),
          'body'=>array('heroBodyFontFamily'=>'font-family','heroBodySize'=>'font-size','heroBodyWeight'=>'font-weight','heroBodyLineHeight'=>'line-height','heroBodyLetterSpacing'=>'letter-spacing','heroBodyWordSpacing'=>'word-spacing','heroBodyTransform'=>'text-transform','heroBodyDecoration'=>'text-decoration','heroBodyStyle'=>'font-style','heroBodyColor'=>'color','heroBodyShadow'=>'text-shadow'),
          'button'=>array('buttonFontFamily'=>'font-family','buttonFontSize'=>'font-size','buttonFontWeight'=>'font-weight','buttonLineHeight'=>'line-height','buttonLetterSpacing'=>'letter-spacing','buttonTransform'=>'text-transform','buttonDecoration'=>'text-decoration','buttonStyle'=>'font-style','buttonBackground'=>'background','buttonColor'=>'color','buttonRadius'=>'border-radius','buttonPadding'=>'padding','buttonBorderWidth'=>'border-width','buttonBorderStyle'=>'border-style','buttonBorderColor'=>'border-color','buttonShadow'=>'box-shadow')
        );
        foreach($maps as $section=>$map){$rule='';foreach($map as $k=>$p){$v=$get($k,'');if($v!=='')$rule.=$p.':'.$css($v).' !important;';}if($rule){if($section==='eyebrow')$sel='.ng-hero-slider__eyebrow';elseif($section==='heading')$sel='.ng-hero-slider__heading';elseif($section==='body')$sel='.ng-hero-slider__body';else $sel='.ng-hero-slider__button';$rules.=$scope.' '.$sel.'{'.$rule.'}';}}
        $rules.=$scope.' .ng-hero-slider__button{display:inline-flex;align-items:center;justify-content:center;text-decoration:none;cursor:pointer;}';
        $hb=$get('buttonHoverBackground','');$hc=$get('buttonHoverColor','');$hbc=$get('buttonHoverBorderColor','');$hbw=$get('buttonHoverBorderWidth','');$hbs=$get('buttonHoverBorderStyle','');$hbr=$get('buttonHoverRadius','');$hsh=$get('buttonHoverShadow','');$htr=$get('buttonHoverTransform','');$hr='';if($hb!=='')$hr.='background:'.$css($hb).'!important;';if($hc!=='')$hr.='color:'.$css($hc).'!important;';if($hbc!=='')$hr.='border-color:'.$css($hbc).'!important;';if($hbw!=='')$hr.='border-width:'.$css($hbw).'!important;';if($hbs!=='')$hr.='border-style:'.$css($hbs).'!important;';if($hbr!=='')$hr.='border-radius:'.$css($hbr).'!important;';if($hsh!=='')$hr.='box-shadow:'.$css($hsh).'!important;';if($htr==='lift')$hr.='transform:translateY(-2px)!important;';elseif($htr==='scale')$hr.='transform:scale(1.03)!important;';if($hr)$rules.=$scope.' .ng-hero-slider__button:hover{'.$hr.'}';
        $aw=$get('arrows',true)!==false;$arrowPos=$get('arrowPosition','middle-inside');$ax=$get('arrowOffsetX','24px');$ay=$get('arrowOffsetY','0px');$as=$get('arrowSize','48px');$ais=$get('arrowIconSize','22px');$abg=$get('arrowBackground','#fff');$ac=$get('arrowColor','#111827');$ahbg=$get('arrowHoverBackground','#111827');$ahc=$get('arrowHoverColor','#fff');$abc=$get('arrowBorderColor','transparent');$abw=$get('arrowBorderWidth','0px');$abs=$get('arrowBorderStyle','solid');$ar=$get('arrowRadius','50%');$ash=$get('arrowShadow','0 8px 24px rgba(0,0,0,.18)');
        $rules.=$scope.' .ng-hero-slider__arrow{position:absolute;z-index:6;width:'.$css($as).';height:'.$css($as).';padding:0;display:flex;align-items:center;justify-content:center;border:'.$css($abw).' '.$css($abs).' '.$css($abc).';border-radius:'.$css($ar).';background:'.$css($abg).';color:'.$css($ac).';box-shadow:'.$css($ash).';font-size:'.$css($ais).';line-height:1;cursor:pointer;transform:none;transition:all .2s ease;}'.$scope.' .ng-hero-slider__arrow:hover{background:'.$css($ahbg).';color:'.$css($ahc).';}';
        if($arrowPos==='middle-inside'){$rules.=$scope.' .ng-hero-slider__prev{left:'.$css($ax).';top:calc(50% + '.$css($ay).');transform:translateY(-50%);}'.$scope.' .ng-hero-slider__next{right:'.$css($ax).';top:calc(50% + '.$css($ay).');transform:translateY(-50%);}';}elseif($arrowPos==='middle-outside'){$rules.=$scope.' .ng-hero-slider__prev{left:0;top:calc(50% + '.$css($ay).');transform:translate(-50%,-50%);}'.$scope.' .ng-hero-slider__next{right:0;top:calc(50% + '.$css($ay).');transform:translate(50%,-50%);}';}elseif($arrowPos==='top-left'){$rules.=$scope.' .ng-hero-slider__prev{left:'.$css($ax).';top:'.$css($ay).';}'.$scope.' .ng-hero-slider__next{left:calc('.$css($ax).' + '.$css($as).' + 8px);top:'.$css($ay).';}';}elseif($arrowPos==='top-right'){$rules.=$scope.' .ng-hero-slider__next{right:'.$css($ax).';top:'.$css($ay).';}'.$scope.' .ng-hero-slider__prev{right:calc('.$css($ax).' + '.$css($as).' + 8px);top:'.$css($ay).';}';}elseif($arrowPos==='bottom-left'){$rules.=$scope.' .ng-hero-slider__prev{left:'.$css($ax).';bottom:'.$css($ay).';}'.$scope.' .ng-hero-slider__next{left:calc('.$css($ax).' + '.$css($as).' + 8px);bottom:'.$css($ay).';}';}else{$rules.=$scope.' .ng-hero-slider__next{right:'.$css($ax).';bottom:'.$css($ay).';}'.$scope.' .ng-hero-slider__prev{right:calc('.$css($ax).' + '.$css($as).' + 8px);bottom:'.$css($ay).';}';}
        $dotShow=$get('dots',true)!==false;$dotSize=$get('dotSize','8px');$dotGap=$get('dotGap','8px');$dotColor=$get('dotColor','rgba(255,255,255,.55)');$dotActive=$get('dotActiveColor','#fff');$dotActiveWidth=$get('dotActiveWidth','26px');$dotActiveRadius=$get('dotActiveRadius','8px');$dotPos=$get('dotPosition','bottom-center');$dx=$get('dotOffsetX','0px');$dy=$get('dotOffsetY','22px');
        $rules.=$scope.' .ng-hero-slider__dots{position:absolute;z-index:6;display:flex;gap:'.$css($dotGap).';align-items:center;}'.$scope.' .ng-hero-slider__dot{width:'.$css($dotSize).';height:'.$css($dotSize).';padding:0;border:0;border-radius:50%;background:'.$css($dotColor).';cursor:pointer;transition:all .2s ease;}'.$scope.' .ng-hero-slider__dot.is-active{width:'.$css($dotActiveWidth).';border-radius:'.$css($dotActiveRadius).';background:'.$css($dotActive).';}';
        if($dotPos==='bottom-center')$rules.=$scope.' .ng-hero-slider__dots{left:calc(50% + '.$css($dx).');bottom:'.$css($dy).';transform:translateX(-50%);}';elseif($dotPos==='bottom-left')$rules.=$scope.' .ng-hero-slider__dots{left:'.$css($dx).';bottom:'.$css($dy).';}';elseif($dotPos==='bottom-right')$rules.=$scope.' .ng-hero-slider__dots{right:'.$css($dx).';bottom:'.$css($dy).';}';elseif($dotPos==='top-center')$rules.=$scope.' .ng-hero-slider__dots{left:calc(50% + '.$css($dx).');top:'.$css($dy).';transform:translateX(-50%);}';elseif($dotPos==='top-left')$rules.=$scope.' .ng-hero-slider__dots{left:'.$css($dx).';top:'.$css($dy).';}';else$rules.=$scope.' .ng-hero-slider__dots{right:'.$css($dx).';top:'.$css($dy).';}';
        if($get('progress',false)!==false)$rules.=$scope.' .ng-hero-slider__progress{position:absolute;left:0;width:100%;height:'.$css($get('progressHeight','3px')).';background:'.$css($get('progressColor','#fff')).';z-index:7;transform-origin:left center;}';
        if($get('progressPosition','bottom')==='top')$rules.=$scope.' .ng-hero-slider__progress{top:0;}';else$rules.=$scope.' .ng-hero-slider__progress{bottom:0;}';
        $counterPos=$get('counterPosition','top-right');$rules.=$scope.' .ng-hero-slider__counter{position:absolute;z-index:7;color:'.$css($get('counterColor','#fff')).';background:'.$css($get('counterBackground','rgba(0,0,0,.35)')).';border-radius:'.$css($get('counterRadius','999px')).';padding:'.$css($get('counterPadding','6px 10px')).';font-size:12px;line-height:1;}';
        if(strpos($counterPos,'top-')===0)$rules.=$scope.' .ng-hero-slider__counter{top:16px;}';else$rules.=$scope.' .ng-hero-slider__counter{bottom:16px;}';if(strpos($counterPos,'left')!==false)$rules.=$scope.' .ng-hero-slider__counter{left:16px;}';elseif(strpos($counterPos,'right')!==false)$rules.=$scope.' .ng-hero-slider__counter{right:16px;}';else$rules.=$scope.' .ng-hero-slider__counter{left:50%;transform:translateX(-50%);}';
        foreach(array('tablet'=>'900px','mobile'=>'600px') as $dev=>$bp){$rr='';if(isset($responsive['minHeight'][$dev])&&$responsive['minHeight'][$dev]!=='')$rr.=$scope.'{--ng-hero-slider-height:'.$css($responsive['minHeight'][$dev]).';}';if(isset($responsive['contentMaxWidth'][$dev])&&$responsive['contentMaxWidth'][$dev]!=='')$rr.=$scope.' .ng-hero-slider__content{max-width:'.$css($responsive['contentMaxWidth'][$dev]).';}';if(isset($responsive['contentPadding'][$dev])&&$responsive['contentPadding'][$dev]!=='')$rr.=$scope.' .ng-hero-slider__content{padding:'.$css($responsive['contentPadding'][$dev]).';}';if(isset($responsive['contentGap'][$dev])&&$responsive['contentGap'][$dev]!=='')$rr.=$scope.' .ng-hero-slider__content{gap:'.$css($responsive['contentGap'][$dev]).';}';if(isset($responsive['textAlign'][$dev])&&$responsive['textAlign'][$dev]!=='')$rr.=$scope.' .ng-hero-slider__content{text-align:'.$css($responsive['textAlign'][$dev]).';}';if(isset($responsive['arrowSize'][$dev])&&$responsive['arrowSize'][$dev]!=='')$rr.=$scope.' .ng-hero-slider__arrow{width:'.$css($responsive['arrowSize'][$dev]).';height:'.$css($responsive['arrowSize'][$dev]).';}';if(isset($responsive['arrowIconSize'][$dev])&&$responsive['arrowIconSize'][$dev]!=='')$rr.=$scope.' .ng-hero-slider__arrow{font-size:'.$css($responsive['arrowIconSize'][$dev]).';}';if(isset($responsive['dotSize'][$dev])&&$responsive['dotSize'][$dev]!=='')$rr.=$scope.' .ng-hero-slider__dot{width:'.$css($responsive['dotSize'][$dev]).';height:'.$css($responsive['dotSize'][$dev]).';}';if($rr)$rules.='@media (max-width:'.$bp.'){'.$rr.'}';}
        $html='<style data-nextgen-hero-slider-runtime="'.$safe($id).'">'.$rules.'</style>';
        $html.='<section class="ng-widget ng-hero-slider" data-ng-hero-slider="1" data-transition="'.$safe($transition).'" data-autoplay="'.($autoplay?'1':'0').'" data-interval="'.$interval.'" data-speed="'.$speed.'" data-loop="'.($loop?'1':'0').'" data-pause-hover="'.($pauseHover?'1':'0').'" data-pause-focus="'.($pauseFocus?'1':'0').'" data-swipe="'.($swipe?'1':'0').'" data-keyboard="'.($keyboard?'1':'0').'" data-arrows="'.($aw?'1':'0').'" style="'.$style.'"><div class="ng-hero-slider__viewport"><div class="ng-hero-slider__track">';
        foreach($slides as $i=>$slide){$slide=is_array($slide)?$slide:array();$active=$i===0?' is-active':'';$mediaType=(string)($slide['mediaType']??'image');$img=$this->imageUrl($slide['image']??'');$mobile=$this->imageUrl($slide['mobileImage']??'');$bgPos=(string)($slide['backgroundPosition']??$get('backgroundPosition','center center'));$bgSize=(string)($slide['backgroundSize']??$get('backgroundSize','cover'));$bgRep=(string)($slide['backgroundRepeat']??$get('backgroundRepeat','no-repeat'));$overlay=(string)($slide['overlayColor']??$get('overlayColor','transparent'));$op=(string)($slide['overlayOpacity']??$get('overlayOpacity','.25'));$cp=(string)($slide['contentPosition']??$contentPos);$ta=(string)($slide['textAlign']??$textAlign);$pp=preg_split('/\s+/',trim($cp));$sh=$pp[0]??'left';$sv=$pp[1]??'center';$sa=$sh==='right'?'flex-end':($sh==='center'?'center':'flex-start');$sj=$sv==='top'?'flex-start':($sv==='bottom'?'flex-end':'center');$ey=$this->esc($slide['eyebrow']??'');$he=$this->esc($slide['heading']??'');$tx=$this->esc($slide['text']??'');$bt=$this->esc($slide['button']??'');$url=$this->esc($slide['url']??'#');$target=((string)($slide['target']??'_self')==='_blank')?' target="_blank" rel="noopener noreferrer"':'';$tag='h2';$media='';if($mediaType==='video'&&($slide['videoUrl']??'')){ $poster=$this->imageUrl($slide['videoPoster']??$slide['image']??'');$media='<video autoplay muted loop playsinline preload="metadata"'.($poster?' poster="'.$safe($poster).'"':'').'><source src="'.$safe($slide['videoUrl']).'" type="video/mp4"></video>'; } elseif($img){$media='<img src="'.$safe($img).'"'.($mobile?' data-mobile-image="'.$safe($mobile).'"':'').' alt="" loading="eager">';} $html.='<article class="ng-hero-slider__slide'.$active.'" data-index="'.$i.'" style="--slide-position:'.$css($bgPos).';--slide-fit:'.$css($bgSize==='contain'?'contain':'cover').';--slide-bg:'.$css($get('backgroundColor','#111827')).';--slide-overlay:'.$css($overlay).';--slide-overlay-opacity:'.$css($op).';--slide-align:'.$sa.';--slide-justify:'.$sj.';--slide-text-align:'.$css($ta).';--slide-opacity:'.$css($get('imageOpacity','1')).';--slide-filter:'.$css($get('imageFilter','none')).';"><div class="ng-hero-slider__media">'.$media.'</div><div class="ng-hero-slider__overlay"></div><div class="ng-hero-slider__content">'.($ey?'<span class="ng-hero-slider__eyebrow">'.$ey.'</span>':'').($he?'<'.$tag.' class="ng-hero-slider__heading">'.$he.'</'.$tag.'>':'').($tx?'<p class="ng-hero-slider__body">'.$tx.'</p>':'').($bt?'<a class="ng-hero-slider__button" href="'.$url.'"'.$target.'>'.$bt.'</a>':'').'</div></article>';}
        $html.='</div>';
        if($aw&&count($slides)>1)$html.='<button type="button" class="ng-hero-slider__arrow ng-hero-slider__prev" aria-label="Previous slide"><span>'.$safe($prev).'</span></button><button type="button" class="ng-hero-slider__arrow ng-hero-slider__next" aria-label="Next slide"><span>'.$safe($next).'</span></button>';
        if($dotShow&&count($slides)>1){$html.='<div class="ng-hero-slider__dots" role="tablist">';foreach($slides as $i=>$slide)$html.='<button type="button" class="ng-hero-slider__dot'.($i===0?' is-active':'').'" data-index="'.$i.'" aria-label="Go to slide '.($i+1).'"></button>';$html.='</div>';}
        if($get('progress',false)!==false)$html.='<div class="ng-hero-slider__progress" aria-hidden="true"></div>';
        if($get('showCounter',false)!==false&&count($slides)>1)$html.='<div class="ng-hero-slider__counter"><span class="ng-hero-slider__current">1</span> / '.count($slides).'</div>';
        $html.='</div></section>';
        if(count($slides)>1){$html.='<script>(function(){var root=document.currentScript&&document.currentScript.previousElementSibling;if(!root)return;var track=root.querySelector(".ng-hero-slider__track"),slides=[].slice.call(root.querySelectorAll(".ng-hero-slider__slide")),prev=root.querySelector(".ng-hero-slider__prev"),next=root.querySelector(".ng-hero-slider__next"),dots=[].slice.call(root.querySelectorAll(".ng-hero-slider__dot")),counter=root.querySelector(".ng-hero-slider__current"),index=0,timer=null,paused=false,startX=0,dragging=false,resetTimer=null,loop=root.getAttribute("data-loop")==="1",fade=root.getAttribute("data-transition")==="fade",speed=parseInt(root.getAttribute("data-speed"),10)||650;function render(animate){slides.forEach(function(s,i){s.classList.toggle("is-active",i===index);});dots.forEach(function(d,i){d.classList.toggle("is-active",i===index);d.setAttribute("aria-current",i===index?"true":"false");});if(counter)counter.textContent=String(index+1);if(!fade){track.style.transition=animate?"transform "+speed+"ms "+getComputedStyle(track).transitionTimingFunction:"none";track.style.transform="translate3d(-"+(index*100)+"%,0,0)";}var m=slides[index]&&slides[index].querySelector("img[data-mobile-image]");if(m&&window.matchMedia("(max-width:600px)").matches)m.src=m.getAttribute("data-mobile-image");}function go(i){if(loop){if(i<0)i=slides.length-1;if(i>=slides.length)i=0;}else{i=Math.max(0,Math.min(slides.length-1,i));}index=i;render(true);restart();}function restart(){if(timer)clearInterval(timer);if(root.getAttribute("data-autoplay")!=="1"||paused)return;timer=setInterval(function(){go(index+1);},Math.max(1000,parseInt(root.getAttribute("data-interval"),10)||5000));}function stop(){if(timer){clearInterval(timer);timer=null;}}function pause(){paused=true;stop();}function resume(){paused=false;restart();}if(prev)prev.onclick=function(){go(index-1)};if(next)next.onclick=function(){go(index+1)};dots.forEach(function(d){d.onclick=function(){go(parseInt(d.getAttribute("data-index"),10)||0)}});if(root.getAttribute("data-pause-hover")==="1"){root.addEventListener("mouseenter",pause);root.addEventListener("mouseleave",resume);}if(root.getAttribute("data-pause-focus")==="1"){root.addEventListener("focusin",pause);root.addEventListener("focusout",resume);}if(root.getAttribute("data-keyboard")==="1")root.addEventListener("keydown",function(e){if(e.key==="ArrowLeft"){e.preventDefault();go(index-1)}else if(e.key==="ArrowRight"){e.preventDefault();go(index+1)}});if(root.getAttribute("data-swipe")==="1"){root.addEventListener("touchstart",function(e){if(e.touches&&e.touches[0]){startX=e.touches[0].clientX;dragging=true;}},{passive:true});root.addEventListener("touchend",function(e){if(!dragging)return;dragging=false;var x=e.changedTouches&&e.changedTouches[0]?e.changedTouches[0].clientX:startX;if(Math.abs(x-startX)>45)go(index+(x<startX?1:-1));},{passive:true});}render(false);restart();})();</script>';}
        return $html;
    }
    private function action($n,$label) { return '<button type="button" class="ng-widget ng-action">'.$this->esc($label).'</button>'; }
    private function simpleBlock($n,$label) { return '<div class="ng-widget ng-generic-control"><span>'.$this->esc($label).'</span></div>'; }
}
