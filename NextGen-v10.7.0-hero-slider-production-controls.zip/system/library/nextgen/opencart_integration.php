<?php
class NextGenOpenCartIntegration {
    public function environment() {
        return array(
            'opencart'=>defined('VERSION') ? VERSION : null,
            'php'=>PHP_VERSION,
            'db_prefix'=>defined('DB_PREFIX') ? DB_PREFIX : null
        );
    }

    public function routes() {
        return array(
            'admin_package'=>'extension/theme/nextgen/package',
            'admin_updater'=>'extension/theme/nextgen/updater',
            'frontend_package'=>'extension/theme/nextgen/package'
        );
    }

    public function architecture() {
        return array(
            'events'=>true,
            'ocmod'=>false,
            'vqmod'=>false,
            'core_modification'=>false
        );
    }
}
