<?php
class NextGenCompatibilityManifest {
    public function check(array $manifest, array $environment) {
        $issues = array();
        if (!empty($manifest['requires_opencart']) && !empty($environment['opencart'])) {
            if (!$this->versionSatisfies($environment['opencart'], $manifest['requires_opencart'])) {
                $issues[] = 'OpenCart version requirement is not satisfied.';
            }
        }
        if (!empty($manifest['requires_php']) && !empty($environment['php'])) {
            if (!$this->versionSatisfies($environment['php'], $manifest['requires_php'])) {
                $issues[] = 'PHP version requirement is not satisfied.';
            }
        }
        return array('compatible'=>empty($issues),'issues'=>$issues);
    }

    private function versionSatisfies($actual, $requirement) {
        if (strpos($requirement, '>=') === 0) return version_compare($actual, trim(substr($requirement,2)), '>=');
        if (strpos($requirement, '>') === 0) return version_compare($actual, trim(substr($requirement,1)), '>');
        if (strpos($requirement, '<=') === 0) return version_compare($actual, trim(substr($requirement,2)), '<=');
        if (strpos($requirement, '<') === 0) return version_compare($actual, trim(substr($requirement,1)), '<');
        return version_compare($actual, trim($requirement), '==');
    }
}
