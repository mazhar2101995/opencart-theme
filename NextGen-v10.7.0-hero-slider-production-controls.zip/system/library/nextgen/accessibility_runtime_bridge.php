<?php
class NextGenAccessibilityRuntimeBridge {
    private $engine;
    public function __construct($engine) { $this->engine=$engine; }

    public function attributes(array $node=array()) {
        if(!$this->engine || !method_exists($this->engine,'attributes')) return array();
        return $this->engine->attributes($node);
    }
}
