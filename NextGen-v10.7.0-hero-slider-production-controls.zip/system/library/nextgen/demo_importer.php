<?php
class NextGenDemoImporter {
    public function validate($demo) {
        return !empty($demo['slug'])
            && !empty($demo['name'])
            && !empty($demo['document'])
            && !empty($demo['tokens']);
    }

    public function plan(array $demo) {
        if (!$this->validate($demo)) {
            return array('valid'=>false,'error'=>'Invalid demo package.');
        }

        return array(
            'valid'=>true,
            'steps'=>array(
                'backup_current_theme_state',
                'create_demo_documents',
                'create_header_footer',
                'apply_design_tokens',
                'create_global_components',
                'assign_templates',
                'refresh_theme_cache',
                'verify_rendering'
            ),
            'requires_confirmation'=>true
        );
    }
}
