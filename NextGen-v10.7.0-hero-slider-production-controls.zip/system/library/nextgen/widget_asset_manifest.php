<?php
class NextGenWidgetAssetManifest {
    private $map=array(
        'heading'=>array(),
        'text'=>array(),
        'text_editor'=>array(),
        'button'=>array(),
        'image'=>array(),
        'icon'=>array(),
        'spacer'=>array(),
        'divider'=>array(),
        'product_card'=>array(
            'css'=>array('catalog/view/theme/nextgen/stylesheet/product-card-production.css'),
            'js'=>array('catalog/view/theme/nextgen/javascript/product-card-production.js')
        ),
        'products'=>array(
            'css'=>array('catalog/view/theme/nextgen/stylesheet/ecommerce-widgets.css'),
            'js'=>array('catalog/view/theme/nextgen/assets/js/widgets/ecommerce-interactions.js')
        ),
        'product_grid'=>array(
            'css'=>array('catalog/view/theme/nextgen/stylesheet/ecommerce-runtime.css')
        ),
        'product_list'=>array(
            'css'=>array('catalog/view/theme/nextgen/stylesheet/ecommerce-runtime.css')
        ),
        'product_carousel'=>array(
            'css'=>array('catalog/view/theme/nextgen/stylesheet/ecommerce-runtime.css'),
            'js'=>array('catalog/view/theme/nextgen/javascript/ecommerce-runtime.js')
        )
    );

    public function get($widgetType) {
        return isset($this->map[$widgetType]) ? $this->map[$widgetType] : array();
    }
}
