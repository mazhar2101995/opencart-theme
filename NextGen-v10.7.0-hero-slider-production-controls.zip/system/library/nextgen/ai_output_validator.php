<?php
/**
 * AI output safety boundary.
 */
class NextGenAiOutputValidator {
    public static function validate(array $output) {
        $result = array(
            'valid' => true,
            'errors' => array(),
            'warnings' => array()
        );

        if (isset($output['execute_php']) && $output['execute_php']) {
            $result['valid'] = false;
            $result['errors'][] = 'Arbitrary PHP execution is not allowed.';
        }

        if (isset($output['authorization']) && $output['authorization']) {
            $result['valid'] = false;
            $result['errors'][] = 'AI output cannot define authorization rules.';
        }

        if (isset($output['widgets']) && !is_array($output['widgets'])) {
            $result['valid'] = false;
            $result['errors'][] = 'Widget collection must be an array.';
        }

        return $result;
    }
}
