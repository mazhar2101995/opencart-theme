<?php
return array(
    'products'=>array('css'=>array('ecommerce-widgets.css'),'js'=>array('widgets/ecommerce-interactions.js')),
    'product_card'=>array('css'=>array('ecommerce-widgets.css'),'js'=>array('ecommerce-widgets.js')),
    'product_grid'=>array('css'=>array('ecommerce-widgets.css'),'js'=>array('ecommerce-widgets.js')),
    'product_list'=>array('css'=>array('ecommerce-widgets.css'),'js'=>array('ecommerce-widgets.js')),
    'product_carousel'=>array('css'=>array('ecommerce-widgets.css'),'js'=>array('ecommerce-widgets.js')),
    'product_slider'=>array('css'=>array('ecommerce-widgets.css'),'js'=>array('ecommerce-widgets.js')),
    'product_page'=>array('css'=>array('ecommerce-widgets.css'),'js'=>array('ecommerce-widgets.js'))
);
