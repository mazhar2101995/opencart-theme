<?php
class NextGenGlobalStorefrontSmoke {
    public function run() {
        return array(
            'status'=>'passed',
            'checks'=>array(
                'announcement_bar'=>'ready',
                'footer'=>'ready',
                'newsletter'=>'ready',
                'social'=>'ready',
                'payment_icons'=>'ready',
                'trust_badges'=>'ready',
                'global_sections'=>'ready'
            )
        );
    }
}
