<?php
class NextGenPublishedDocumentResolver {
    private $repository;

    public function __construct($repository=null) {
        $this->repository=$repository;
    }

    public function resolve(array $assignment,array $context=array()) {
        $documentId=isset($assignment['document_id']) ? (int)$assignment['document_id'] : 0;

        if(!$documentId || !$this->repository) {
            return array('status'=>'not_found','document'=>null);
        }

        if(method_exists($this->repository,'getPublished')) {
            $document=$this->repository->getPublished($documentId);
        } elseif(method_exists($this->repository,'get')) {
            $document=$this->repository->get($documentId);
        } else {
            $document=null;
        }

        if(!is_array($document)) {
            return array('status'=>'not_found','document'=>null);
        }

        if(isset($document['status']) && $document['status']!=='published') {
            return array('status'=>'not_published','document'=>null);
        }

        return array('status'=>'ok','document'=>$document);
    }
}
