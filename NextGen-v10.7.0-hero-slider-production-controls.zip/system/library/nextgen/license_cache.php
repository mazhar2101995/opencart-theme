<?php
class NextGenLicenseCache {
    public function sanitize(array $license) {
        $allowed=array('status','expires_at','package','installation_id','checked_at');
        $safe=array();

        foreach ($allowed as $key) {
            if (isset($license[$key])) $safe[$key]=$license[$key];
        }

        return $safe;
    }

    public function isUsable(array $license) {
        if (empty($license['status'])) return false;
        if (!in_array($license['status'],array('active','trial'),true)) return false;
        if (!empty($license['expires_at']) && strtotime($license['expires_at']) < time()) return false;
        return true;
    }
}
