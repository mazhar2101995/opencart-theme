<?php
class NextGenPackageManifest {
    public function validate(array $manifest) {
        $required = array('name','display_name','version','type','requires_opencart');
        foreach ($required as $key) {
            if (empty($manifest[$key])) return array('valid'=>false,'error'=>"Missing manifest field: {$key}");
        }
        if (!preg_match('/^[0-9]+\.[0-9]+\.[0-9]+(?:[-+][A-Za-z0-9.-]+)?$/', $manifest['version'])) {
            return array('valid'=>false,'error'=>'Invalid semantic version.');
        }
        if (!in_array($manifest['type'], array('theme','extension','component'), true)) {
            return array('valid'=>false,'error'=>'Unsupported package type.');
        }
        return array('valid'=>true,'error'=>null);
    }

    public function normalize(array $manifest) {
        $defaults = array(
            'description'=>'',
            'author'=>'',
            'license'=>'',
            'homepage'=>'',
            'requires'=>array(),
            'conflicts'=>array(),
            'files'=>array(),
            'migrations'=>array(),
            'checksum'=>'',
            'signature'=>''
        );
        return array_replace($defaults, $manifest);
    }
}
