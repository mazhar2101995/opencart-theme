<?php
class NextGenStorefrontSearchRuntime {
    public function config(array $data=array()) {
        return array(
            'action'=>isset($data['action'])?$data['action']:'index.php?route=product/search',
            'query_name'=>isset($data['query_name'])?$data['query_name']:'search',
            'suggestions'=>!empty($data['suggestions']),
            'min_chars'=>isset($data['min_chars'])?(int)$data['min_chars']:2
        );
    }
}
