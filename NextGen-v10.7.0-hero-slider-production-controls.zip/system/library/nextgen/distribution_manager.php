<?php
class NextGenDistributionManager {
    public function packageStructure() {
        return array(
            'manifest.json',
            'README.md',
            'LICENSE',
            'files/',
            'migrations/',
            'assets/',
            'docs/'
        );
    }

    public function distributionPolicy() {
        return array(
            'ocmod'=>false,
            'vqmod'=>false,
            'event_architecture'=>true,
            'signed_package_ready'=>true,
            'checksum'=>'sha256',
            'rollback'=>'required'
        );
    }
}
