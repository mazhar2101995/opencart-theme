<?php
/**
 * Frontend quality diagnostics foundation.
 * Diagnostics are intended for development/admin usage only.
 */
class NextGenFrontendDiagnostics {
    public static function inspect(array $document) {
        $result = array(
            'warnings' => array(),
            'stats' => array(
                'nodes' => 0,
                'widgets' => 0,
                'sections' => 0,
                'containers' => 0,
                'columns' => 0
            )
        );

        self::walk($document, $result);

        return $result;
    }

    private static function walk($node, array &$result) {
        if (!is_array($node)) return;

        if (isset($node['type'])) {
            $result['stats']['nodes']++;
            $type = $node['type'];

            if (isset($result['stats'][$type . 's'])) {
                $result['stats'][$type . 's']++;
            }

            if ($type === 'widget') {
                $result['stats']['widgets']++;

                if (empty($node['widget'])) {
                    $result['warnings'][] = 'Widget node is missing widget type.';
                }
            }

            if ($type === 'image' && empty($node['settings']['alt'])) {
                $result['warnings'][] = 'Image widget should define meaningful alt text or explicitly mark the image decorative.';
            }
        }

        foreach ($node as $child) {
            if (is_array($child)) {
                if (isset($child['type'])) self::walk($child, $result);
                else foreach ($child as $nested) self::walk($nested, $result);
            }
        }
    }
}
