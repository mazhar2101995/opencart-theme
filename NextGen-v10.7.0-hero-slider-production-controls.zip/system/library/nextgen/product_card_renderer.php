<?php
class NextGenProductCardRenderer {
    private $engine;
    private $actions;

    public function __construct($engine=null,$actions=null) {
        $this->engine=$engine ?: new NextGenProductCardEngine();
        $this->actions=$actions ?: new NextGenOpenCartCartContract();
    }

    public function register($registry) {
        $self=$this;
        $registry->registerWidget('product_card',function($node,$context) use ($self) {
            return $self->render($node,$context);
        });
    }

    private function setting($node,$key,$default=true) {
        return isset($node['settings'][$key])?$node['settings'][$key]:$default;
    }

    public function render($node,$context=array()) {
        $raw=isset($node['product']) && is_array($node['product'])?$node['product']:array();
        $p=$this->engine->normalize($raw);
        $state=$this->engine->state($p);

        $name=htmlspecialchars($p['name'],ENT_QUOTES,'UTF-8');
        $href=htmlspecialchars($p['href'],ENT_QUOTES,'UTF-8');
        $html='<article class="ng-product-card ng-product-card--production" data-product-id="'.(int)$p['product_id'].'">';

        if($state['sale']) $html.='<span class="ng-product-badge ng-product-badge--sale">-'.$p['discount'].'%</span>';
        elseif($state['new']) $html.='<span class="ng-product-badge ng-product-badge--new">New</span>';
        elseif($state['featured']) $html.='<span class="ng-product-badge ng-product-badge--featured">Featured</span>';

        if($p['image']) {
            $html.='<div class="ng-product-card__media">';
            $html.='<a href="'.$href.'"><img class="ng-product-card__image" src="'.htmlspecialchars($p['image'],ENT_QUOTES,'UTF-8').'" alt="'.$name.'" loading="lazy">';
            if($p['hover_image']) {
                $html.='<img class="ng-product-card__hover-image" src="'.htmlspecialchars($p['hover_image'],ENT_QUOTES,'UTF-8').'" alt="" loading="lazy">';
            }
            $html.='</a>';
            $html.='<div class="ng-product-card__actions">';
            $html.='<button type="button" data-ng-action="wishlist" data-product-id="'.(int)$p['product_id'].'" aria-label="Add to wishlist">♡</button>';
            $html.='<button type="button" data-ng-action="compare" data-product-id="'.(int)$p['product_id'].'" aria-label="Compare product">⇄</button>';
            $html.='<button type="button" data-ng-action="quick-view" data-product-id="'.(int)$p['product_id'].'" aria-label="Quick view">⌕</button>';
            $html.='</div></div>';
        }

        $html.='<div class="ng-product-card__body">';
        if($p['manufacturer']) $html.='<div class="ng-product-card__brand">'.htmlspecialchars($p['manufacturer'],ENT_QUOTES,'UTF-8').'</div>';
        $html.='<h3 class="ng-product-card__name"><a href="'.$href.'">'.$name.'</a></h3>';

        if($p['rating']>0) {
            $html.='<div class="ng-product-card__rating" aria-label="Rating '.(float)$p['rating'].' out of 5">';
            $html.=str_repeat('★',(int)round($p['rating']));
            $html.=' <span>('.$p['reviews'].')</span></div>';
        }

        $html.='<div class="ng-product-card__price">';
        if($state['sale']) {
            $html.='<del>'.htmlspecialchars((string)$p['price'],ENT_QUOTES,'UTF-8').'</del> ';
            $html.='<strong>'.htmlspecialchars((string)$p['special'],ENT_QUOTES,'UTF-8').'</strong>';
        } else {
            $html.='<strong>'.htmlspecialchars((string)$p['price'],ENT_QUOTES,'UTF-8').'</strong>';
        }
        $html.='</div>';

        if($p['options']) {
            $html.='<div class="ng-product-card__options">';
            foreach($p['options'] as $option) {
                if(!is_array($option)) continue;
                $label=htmlspecialchars(isset($option['name'])?$option['name']:'Option',ENT_QUOTES,'UTF-8');
                $html.='<label>'.$label.'<select name="option['.(int)(isset($option['product_option_id'])?$option['product_option_id']:0).']">';
                if(isset($option['product_option_value']) && is_array($option['product_option_value'])) {
                    foreach($option['product_option_value'] as $value) {
                        if(!is_array($value)) continue;
                        $vid=(int)(isset($value['product_option_value_id'])?$value['product_option_value_id']:0);
                        $vname=htmlspecialchars(isset($value['name'])?$value['name']:'',ENT_QUOTES,'UTF-8');
                        $html.='<option value="'.$vid.'">'.$vname.'</option>';
                    }
                }
                $html.='</select></label>';
            }
            $html.='</div>';
        }

        if(!$state['out_of_stock']) {
            $html.='<div class="ng-product-card__purchase">';
            $html.='<input type="number" min="1" value="1" data-ng-quantity="'.(int)$p['product_id'].'" aria-label="Quantity">';
            $html.='<button type="button" class="ng-product-card__add" data-ng-action="add-to-cart" data-product-id="'.(int)$p['product_id'].'">Add to Cart</button>';
            $html.='<button type="button" class="ng-product-card__buy" data-ng-action="buy-now" data-product-id="'.(int)$p['product_id'].'">Buy Now</button>';
            $html.='</div>';
        } else {
            $html.='<div class="ng-product-card__stock ng-product-card__stock--out">Out of Stock</div>';
        }

        $html.='</div></article>';
        return $html;
    }
}
