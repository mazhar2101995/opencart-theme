<?php
/**
 * Global Style Engine.
 * Converts centralized design settings into frontend CSS variables.
 */
class NextGenGlobalStyleEngine {
    public static function defaults() {
        return array(
            'color_primary' => '#111111',
            'color_secondary' => '#666666',
            'color_accent' => '#2563eb',
            'color_background' => '#ffffff',
            'color_surface' => '#f8fafc',
            'color_text' => '#111827',
            'color_muted' => '#6b7280',
            'font_body' => 'system-ui, sans-serif',
            'font_heading' => 'system-ui, sans-serif',
            'font_base_size' => '16px',
            'line_height' => '1.5',
            'container_max_width' => '1280px',
            'space_unit' => '4px',
            'radius_sm' => '4px',
            'radius_md' => '8px',
            'radius_lg' => '16px'
        );
    }

    public static function css(array $settings) {
        $map = array(
            'color_primary' => '--ng-color-primary',
            'color_secondary' => '--ng-color-secondary',
            'color_accent' => '--ng-color-accent',
            'color_background' => '--ng-color-background',
            'color_surface' => '--ng-color-surface',
            'color_text' => '--ng-color-text',
            'color_muted' => '--ng-color-muted',
            'font_body' => '--ng-font-body',
            'font_heading' => '--ng-font-heading',
            'font_base_size' => '--ng-font-size',
            'line_height' => '--ng-line-height',
            'container_max_width' => '--ng-container-max',
            'space_unit' => '--ng-space-unit',
            'radius_sm' => '--ng-radius-sm',
            'radius_md' => '--ng-radius-md',
            'radius_lg' => '--ng-radius-lg'
        );

        $css = ':root{';
        foreach ($map as $setting => $variable) {
            if (isset($settings[$setting]) && is_scalar($settings[$setting])) {
                $css .= $variable . ':' . $settings[$setting] . ';';
            }
        }
        return $css . '}';
    }
}
