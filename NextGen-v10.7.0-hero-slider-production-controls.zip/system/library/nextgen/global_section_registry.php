<?php
class NextGenGlobalSectionRegistry {
    protected $sections=array();

    public function register($key,array $definition=array()) {
        if(!$key) return false;
        $this->sections[$key]=$definition;
        return true;
    }

    public function get($key) {
        return isset($this->sections[$key])?$this->sections[$key]:null;
    }

    public function all() {
        return $this->sections;
    }
}
