<?php
function nextgen_register_global_components(&$registry) {
    if (!class_exists('NextGenGlobalComponentSchema')) {
        require_once DIR_SYSTEM . 'library/nextgen/global_component_schema.php';
    }
    foreach (NextGenGlobalComponentSchema::components() as $id => $definition) {
        $registry[$id] = $definition;
        $registry[$id]['controls'] = NextGenGlobalComponentSchema::controls($id);
    }
}
