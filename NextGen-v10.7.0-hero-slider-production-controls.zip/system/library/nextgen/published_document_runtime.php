<?php
class NextGenPublishedDocumentRuntime {
    public function normalize($document) {
        if(!is_array($document)) return null;
        $status=isset($document['status'])?$document['status']:'';
        if($status && $status!=='published') return null;

        $json=isset($document['document_json'])?$document['document_json']:null;
        if(is_string($json)) {
            $decoded=json_decode($json,true);
            if(json_last_error()===JSON_ERROR_NONE) $document['document_json']=$decoded;
        }
        return $document;
    }

    public function isRenderable($document) {
        return is_array($document) &&
            (!isset($document['status']) || $document['status']==='published') &&
            !empty($document['document_json']);
    }
}
