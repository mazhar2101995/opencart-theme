<?php
class NextGenTemplateImportExport {
    public function export(array $template) {
        return json_encode([
            'schema' => 'nextgen-template',
            'schema_version' => 1,
            'exported_at' => date('c'),
            'template' => [
                'key' => $template['template_key'] ?? '',
                'name' => $template['name'] ?? '',
                'type' => $template['type'] ?? 'page',
                'category' => $template['category'] ?? 'general',
                'status' => $template['status'] ?? 'draft',
                'version' => (int)($template['version'] ?? 1),
                'document' => $template['document'] ?? json_decode($template['document_json'] ?? '{}', true),
            ]
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    }

    public function validate($payload) {
        $data = is_array($payload) ? $payload : json_decode($payload, true);

        if (!is_array($data)) {
            return ['valid'=>false, 'errors'=>['Invalid JSON']];
        }

        $errors = [];

        if (($data['schema'] ?? '') !== 'nextgen-template') {
            $errors[] = 'Invalid template schema';
        }

        if (!isset($data['template']) || !is_array($data['template'])) {
            $errors[] = 'Missing template object';
        }

        if (isset($data['template']['document']) && !is_array($data['template']['document'])) {
            $errors[] = 'Template document must be an object';
        }

        return ['valid'=>!$errors, 'errors'=>$errors, 'data'=>$data];
    }

    public function import($payload) {
        $result = $this->validate($payload);
        if (!$result['valid']) return $result;

        return [
            'valid' => true,
            'template' => $result['data']['template']
        ];
    }
}
