<?php
class NextGenOpenCartEventInstaller {
    private $events=array();

    private function buildEvents() {
        if ($this->events) return $this->events;
        $this->events=array(
            array('code'=>'nextgen_admin_column_left','trigger'=>'admin/view/common/column_left/before','action'=>'extension/theme/nextgen/menu','sort_order'=>10),
            array('code'=>'nextgen_presentation_before_all','trigger'=>'catalog/controller/*/before','action'=>'extension/theme/nextgen/presentation/before','sort_order'=>1),
            array('code'=>'nextgen_presentation_view_before','trigger'=>'catalog/view/*/before','action'=>'extension/theme/nextgen/presentation/view_before','sort_order'=>1100),
            array('code'=>'nextgen_presentation_after_all','trigger'=>'catalog/controller/*/after','action'=>'extension/theme/nextgen/presentation/after','sort_order'=>9999)
        );
        return $this->events;
    }

    public function definitions() { return $this->buildEvents(); }

    public function install($db) {
        $installed=array();
        // Remove all previous route-specific/legacy presentation events.
        $db->query("DELETE FROM `".DB_PREFIX."event` WHERE `code` LIKE 'nextgen_presentation_before_%' OR `code` LIKE 'nextgen_presentation_after_%' OR `code` IN ('nextgen_presentation_before','nextgen_presentation_after','nextgen_header_before','nextgen_footer_before','nextgen_presentation_view_before')");
        foreach($this->buildEvents() as $event) {
            $code=$db->escape($event['code']);
            $trigger=$db->escape($event['trigger']);
            $action=$db->escape($event['action']);
            $sort=(int)$event['sort_order'];

            $db->query("DELETE FROM `".DB_PREFIX."event` WHERE `code`='".$code."'");
            $db->query("INSERT INTO `".DB_PREFIX."event`
                SET `code`='".$code."', `trigger`='".$trigger."', `action`='".$action."',
                    `status`='1', `sort_order`='".$sort."'");
            $installed[]=$event['code'];
        }
        return $installed;
    }

    public function uninstall($db) {
        foreach($this->buildEvents() as $event) {
            $code=$db->escape($event['code']);
            $db->query("DELETE FROM `".DB_PREFIX."event` WHERE `code`='".$code."'");
        }
        return true;
    }
}
