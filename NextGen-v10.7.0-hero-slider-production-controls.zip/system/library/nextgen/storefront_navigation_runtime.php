<?php
class NextGenStorefrontNavigationRuntime {
    public function normalize(array $data=array()) {
        return array(
            'logo'=>isset($data['logo'])?$data['logo']:'',
            'home'=>isset($data['home'])?$data['home']:'/',
            'store_name'=>isset($data['store_name'])?$data['store_name']:'',
            'menu'=>isset($data['menu'])&&is_array($data['menu'])?$data['menu']:array(),
            'search'=>isset($data['search'])&&is_array($data['search'])?$data['search']:array(),
            'account'=>isset($data['account'])&&is_array($data['account'])?$data['account']:array(),
            'wishlist'=>isset($data['wishlist'])?$data['wishlist']:'',
            'compare'=>isset($data['compare'])?$data['compare']:'',
            'cart'=>isset($data['cart'])&&is_array($data['cart'])?$data['cart']:array()
        );
    }

    public function menuItem(array $item) {
        return array(
            'name'=>isset($item['name'])?$item['name']:'',
            'href'=>isset($item['href'])?$item['href']:'#',
            'children'=>isset($item['children'])&&is_array($item['children'])?$item['children']:array(),
            'mega'=>!empty($item['mega'])
        );
    }
}
