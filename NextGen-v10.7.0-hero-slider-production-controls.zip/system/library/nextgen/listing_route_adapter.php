<?php
class NextGenListingRouteAdapter {
    public function type($route) {
        if($route==='product/category') return 'category';
        if($route==='product/search') return 'search';
        if($route==='product/manufacturer') return 'manufacturer';
        return 'listing';
    }

    public function endpoint($type) {
        $map=array(
            'category'=>'index.php?route=product/category',
            'search'=>'index.php?route=product/search',
            'manufacturer'=>'index.php?route=product/manufacturer'
        );
        return isset($map[$type])?$map[$type]:'index.php';
    }
}
