<?php
class NextGenProductGalleryRuntime {
    public function normalize(array $images=array(),$main='') {
        $result=array();
        if($main) $result[]=array('src'=>$main,'type'=>'main');
        foreach($images as $image) {
            if(is_string($image) && $image) $result[]=array('src'=>$image,'type'=>'gallery');
            elseif(is_array($image) && !empty($image['src'])) $result[]=array(
                'src'=>$image['src'],
                'type'=>isset($image['type'])?$image['type']:'gallery',
                'alt'=>isset($image['alt'])?$image['alt']:''
            );
        }
        return $result;
    }

    public function settings(array $settings=array()) {
        return array(
            'arrows'=>isset($settings['arrows'])?(bool)$settings['arrows']:true,
            'dots'=>isset($settings['dots'])?(bool)$settings['dots']:true,
            'swipe'=>isset($settings['swipe'])?(bool)$settings['swipe']:true,
            'autoplay'=>isset($settings['autoplay'])?(bool)$settings['autoplay']:false,
            'speed'=>isset($settings['speed'])?(int)$settings['speed']:4000,
            'loop'=>isset($settings['loop'])?(bool)$settings['loop']:true
        );
    }
}
