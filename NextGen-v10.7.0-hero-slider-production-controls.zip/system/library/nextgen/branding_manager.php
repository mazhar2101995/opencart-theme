<?php
/**
 * White-label / branding foundation.
 */
class NextGenBrandingManager {
    public static function sanitize(array $branding) {
        $allowed = array(
            'brand_name',
            'logo',
            'favicon',
            'admin_logo',
            'primary_color',
            'accent_color',
            'support_url',
            'documentation_url'
        );

        $out = array();
        foreach ($allowed as $key) {
            if (isset($branding[$key]) && is_scalar($branding[$key])) {
                $out[$key] = trim((string)$branding[$key]);
            }
        }
        return $out;
    }
}
