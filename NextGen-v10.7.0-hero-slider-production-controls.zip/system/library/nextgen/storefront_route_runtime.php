<?php
class NextGenStorefrontRouteRuntime {
    public function map($route) {
        $map=array(
            'common/home'=>'homepage',
            'product/product'=>'product',
            'product/category'=>'category',
            'product/search'=>'search',
            'product/manufacturer'=>'manufacturer',
            'information/information'=>'information',
            'error/not_found'=>'404',
            'checkout/cart'=>'cart',
            'account/account'=>'account'
        );
        return isset($map[$route])?$map[$route]:'custom';
    }

    public function shouldUseNextGen(array $context) {
        return !empty($context['nextgen_enabled']) &&
            !empty($context['published_document']);
    }
}
