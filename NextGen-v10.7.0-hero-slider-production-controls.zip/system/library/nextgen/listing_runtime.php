<?php
class NextGenListingRuntime {
    public function normalize(array $data=array()) {
        return array(
            'title'=>isset($data['title'])?$data['title']:'',
            'description'=>isset($data['description'])?$data['description']:'',
            'image'=>isset($data['image'])?$data['image']:'',
            'products'=>isset($data['products'])&&is_array($data['products'])?$data['products']:array(),
            'filters'=>isset($data['filters'])&&is_array($data['filters'])?$data['filters']:array(),
            'sorts'=>isset($data['sorts'])&&is_array($data['sorts'])?$data['sorts']:array(),
            'pagination'=>isset($data['pagination'])&&is_array($data['pagination'])?$data['pagination']:array(),
            'breadcrumbs'=>isset($data['breadcrumbs'])&&is_array($data['breadcrumbs'])?$data['breadcrumbs']:array(),
            'query'=>isset($data['query'])?$data['query']:''
        );
    }

    public function state(array $query=array()) {
        return array(
            'page'=>max(1,(int)(isset($query['page'])?$query['page']:1)),
            'sort'=>isset($query['sort'])?$query['sort']:'',
            'order'=>isset($query['order'])?$query['order']:'',
            'limit'=>isset($query['limit'])?(int)$query['limit']:0,
            'filter'=>isset($query['filter'])?$query['filter']:''
        );
    }
}
