<?php
class NextGenListingWidgetRenderer {
    public function renderCategory(array $context=array()) {
        return $this->renderListing($context,'category');
    }

    public function renderSearch(array $context=array()) {
        return $this->renderListing($context,'search');
    }

    public function renderManufacturer(array $context=array()) {
        return $this->renderListing($context,'manufacturer');
    }

    protected function renderListing(array $context,$type) {
        $html='<main class="ng-listing ng-listing--'.$type.'">';
        if(!empty($context['breadcrumbs'])) {
            $html.='<nav class="ng-breadcrumbs" aria-label="Breadcrumb">';
            foreach($context['breadcrumbs'] as $crumb) {
                if(!is_array($crumb)) continue;
                $html.='<a href="'.htmlspecialchars(isset($crumb['href'])?$crumb['href']:'#',ENT_QUOTES,'UTF-8').'">'.htmlspecialchars(isset($crumb['text'])?$crumb['text']:'',ENT_QUOTES,'UTF-8').'</a>';
            }
            $html.='</nav>';
        }

        $html.='<header class="ng-listing__header">';
        $html.='<h1>'.htmlspecialchars(isset($context['title'])?$context['title']:'',ENT_QUOTES,'UTF-8').'</h1>';
        if(!empty($context['description'])) $html.='<div class="ng-listing__description">'.$context['description'].'</div>';
        if(!empty($context['image'])) $html.='<img class="ng-listing__image" src="'.htmlspecialchars($context['image'],ENT_QUOTES,'UTF-8').'" alt="">';
        if($type==='search' && isset($context['query'])) $html.='<div class="ng-search-query">'.htmlspecialchars($context['query'],ENT_QUOTES,'UTF-8').'</div>';
        $html.='</header>';

        $html.='<div class="ng-listing__toolbar">';
        $html.=$this->renderFilters(isset($context['filters'])?$context['filters']:array());
        $html.=$this->renderSorts(isset($context['sorts'])?$context['sorts']:array());
        $html.='</div>';

        $html.='<div class="ng-listing__products">';
        foreach(isset($context['products'])?$context['products']:array() as $product) {
            if(!is_array($product)) continue;
            $html.='<article class="ng-listing-product">';
            if(!empty($product['image'])) $html.='<img src="'.htmlspecialchars($product['image'],ENT_QUOTES,'UTF-8').'" alt="'.htmlspecialchars(isset($product['name'])?$product['name']:'',ENT_QUOTES,'UTF-8').'">';
            $html.='<a href="'.htmlspecialchars(isset($product['href'])?$product['href']:'#',ENT_QUOTES,'UTF-8').'">'.htmlspecialchars(isset($product['name'])?$product['name']:'',ENT_QUOTES,'UTF-8').'</a>';
            if(isset($product['price'])) $html.='<div>'.htmlspecialchars($product['price'],ENT_QUOTES,'UTF-8').'</div>';
            $html.='</article>';
        }
        $html.='</div>';

        $html.=$this->renderPagination(isset($context['pagination'])?$context['pagination']:array());
        return $html.'</main>';
    }

    protected function renderFilters(array $filters) {
        if(!$filters) return '';
        $html='<div class="ng-listing-filters">';
        foreach($filters as $filter) {
            if(!is_array($filter)) continue;
            $html.='<label>'.htmlspecialchars(isset($filter['name'])?$filter['name']:'Filter',ENT_QUOTES,'UTF-8');
            $html.='<select data-ng-filter="'.htmlspecialchars(isset($filter['key'])?$filter['key']:'',ENT_QUOTES,'UTF-8').'">';
            foreach(isset($filter['values'])?$filter['values']:array() as $value) {
                if(!is_array($value)) continue;
                $html.='<option value="'.htmlspecialchars(isset($value['value'])?$value['value']:'',ENT_QUOTES,'UTF-8').'">'.htmlspecialchars(isset($value['label'])?$value['label']:'',ENT_QUOTES,'UTF-8').'</option>';
            }
            $html.='</select></label>';
        }
        return $html.'</div>';
    }

    protected function renderSorts(array $sorts) {
        if(!$sorts) return '';
        $html='<div class="ng-listing-sorts"><select data-ng-sort>';
        foreach($sorts as $sort) {
            if(!is_array($sort)) continue;
            $html.='<option value="'.htmlspecialchars(isset($sort['value'])?$sort['value']:'',ENT_QUOTES,'UTF-8').'">'.htmlspecialchars(isset($sort['text'])?$sort['text']:'',ENT_QUOTES,'UTF-8').'</option>';
        }
        return $html.'</select></div>';
    }

    protected function renderPagination(array $pagination) {
        if(!$pagination) return '';
        $html='<nav class="ng-pagination" aria-label="Pagination">';
        foreach(isset($pagination['links'])?$pagination['links']:array() as $link) {
            if(!is_array($link)) continue;
            $html.='<a href="'.htmlspecialchars(isset($link['href'])?$link['href']:'#',ENT_QUOTES,'UTF-8').'">'.htmlspecialchars(isset($link['text'])?$link['text']:'',ENT_QUOTES,'UTF-8').'</a>';
        }
        return $html.'</nav>';
    }
}
