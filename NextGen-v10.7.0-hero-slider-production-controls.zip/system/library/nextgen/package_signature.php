<?php
class NextGenPackageSignature {
    public function canonicalPayload(array $manifest) {
        unset($manifest['signature']);
        ksort($manifest);
        return json_encode($manifest, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
    }

    public function verify(array $manifest, $signature, $publicKey) {
        if (!$signature || !$publicKey) {
            return array('valid'=>false,'error'=>'Signature or public key missing.');
        }

        $payload=$this->canonicalPayload($manifest);
        $result=openssl_verify($payload, base64_decode($signature), $publicKey, OPENSSL_ALGO_SHA256);

        return array(
            'valid'=>$result === 1,
            'error'=>$result === 1 ? null : 'Package signature verification failed.'
        );
    }
}
