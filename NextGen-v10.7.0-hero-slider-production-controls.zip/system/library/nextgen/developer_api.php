<?php
/**
 * NextGen Developer API v2.5
 * Registration layer for third-party theme extensions.
 */
class NextGenDeveloperApi {
    private $registry;
    private $widgets = array();
    private $providers = array();
    private $hooks = array();
    private $filters = array();

    public function __construct($registry = null) {
        $this->registry = $registry;
    }

    public function registerWidget($id, array $definition) {
        if (!$this->validId($id)) return false;
        $definition['id'] = $id;
        $definition['source'] = isset($definition['source']) ? $definition['source'] : 'developer';
        $this->widgets[$id] = $definition;
        return true;
    }

    public function registerDynamicProvider($id, callable $provider) {
        if (!$this->validId($id)) return false;
        $this->providers[$id] = $provider;
        return true;
    }

    public function addHook($event, callable $callback, $priority = 100) {
        if (!$event) return false;
        $this->hooks[$event][] = array(
            'callback' => $callback,
            'priority' => (int)$priority
        );
        usort($this->hooks[$event], function($a, $b) {
            return $a['priority'] <=> $b['priority'];
        });
        return true;
    }

    public function addFilter($name, callable $callback, $priority = 100) {
        if (!$name) return false;
        $this->filters[$name][] = array(
            'callback' => $callback,
            'priority' => (int)$priority
        );
        usort($this->filters[$name], function($a, $b) {
            return $a['priority'] <=> $b['priority'];
        });
        return true;
    }

    public function applyHook($event, $payload = null) {
        if (empty($this->hooks[$event])) return $payload;
        foreach ($this->hooks[$event] as $item) {
            $payload = call_user_func($item['callback'], $payload);
        }
        return $payload;
    }

    public function applyFilter($name, $value, array $args = array()) {
        if (empty($this->filters[$name])) return $value;
        foreach ($this->filters[$name] as $item) {
            $value = call_user_func($item['callback'], $value, $args);
        }
        return $value;
    }

    public function getWidgets() {
        return $this->widgets;
    }

    public function getProviders() {
        return $this->providers;
    }

    private function validId($id) {
        return is_string($id) && preg_match('/^[a-z0-9][a-z0-9_.-]*$/', $id);
    }
}
