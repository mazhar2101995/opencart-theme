<?php
class NextGenSecurityRuntime {
    public function safeText($value) {
        return htmlspecialchars((string)$value,ENT_QUOTES,'UTF-8');
    }

    public function safeUrl($value) {
        $value=trim((string)$value);
        if(preg_match('/^(javascript|data|vbscript):/i',$value)) return '#';
        return $value;
    }

    public function className($value) {
        return preg_replace('/[^A-Za-z0-9_-]/','',(string)$value);
    }

    public function validateDocument(array $document) {
        return !isset($document['execute_php']) &&
            !isset($document['authorization']) &&
            !isset($document['server_code']);
    }
}
