<?php
require_once(DIR_SYSTEM . 'library/nextgen/media_url.php');

class NextGenWidgetRenderEngine {
    private $registry;
    private $assets;

    public function __construct($registry=null,$assets=null) {
        $this->registry=$registry;
        $this->assets=$assets;
    }

    public function renderDocument(array $document,array $context=array()) {
        if (isset($document['root']) && is_array($document['root'])) {
            $document=$document['root'];
        }
        if (empty($document) || !isset($document['type']) || $document['type'] !== 'root') {
            return array('status'=>'failed','html'=>'','error'=>'Builder root missing.');
        }

        $html=$this->renderNode($document,$context);

        return array(
            'status'=>'ok',
            'html'=>$html,
            'assets'=>$this->assets ? $this->assets->output() : array()
        );
    }

    public function renderNode(array $node,array $context=array()) {
        if (!empty($node['settings']['visible']) && $node['settings']['visible'] === false) {
            return '';
        }

        $type=isset($node['type']) ? $node['type'] : '';

        if (in_array($type,array('root','section','container','inner_container','row','column','flex','grid'))) {
            return $this->renderLayoutNode($node,$context);
        }

        return $this->renderWidgetNode($node,$context);
    }

    private function renderLayoutNode(array $node,array $context=array()) {
        $children=isset($node['children']) && is_array($node['children']) ? $node['children'] : array();
        $inner='';

        foreach ($children as $child) {
            if (is_array($child)) {
                $inner.=$this->renderNode($child,$context);
            }
        }

        $type=isset($node['type'])?(string)$node['type']:'node';
        $settings=isset($node['settings'])&&is_array($node['settings'])?$node['settings']:array();
        $type=isset($node['type'])?(string)$node['type']:'';
        $device=isset($context['device'])&&in_array($context['device'],array('desktop','tablet','mobile'),true)?$context['device']:'desktop';
        $getSetting=function($key,$fallback=null) use ($settings,$device){
            // Desktop uses the canonical/base setting first. Older documents can
            // contain a stale responsive.desktop value (for example Grid) while
            // the inspector correctly shows the base setting (for example Flexbox).
            // Let the base value win on desktop, while tablet/mobile still use
            // their explicit responsive overrides.
            if($device==='desktop'){
                if(isset($settings[$key])&&$settings[$key]!==''&&$settings[$key]!==null&&!is_array($settings[$key])) return $settings[$key];
                if(isset($settings['responsive'])&&is_array($settings['responsive'])&&isset($settings['responsive'][$key])&&is_array($settings['responsive'][$key])){
                    $rv=$settings['responsive'][$key];
                    if(isset($rv['desktop'])&&$rv['desktop']!==''&&$rv['desktop']!==null) return $rv['desktop'];
                }
                return $fallback;
            }
            if(isset($settings['responsive'])&&is_array($settings['responsive'])&&isset($settings['responsive'][$key])&&is_array($settings['responsive'][$key])){
                $rv=$settings['responsive'][$key];
                if(isset($rv[$device])&&$rv[$device]!==''&&$rv[$device]!==null)return $rv[$device];
                if($device==='mobile'){
                    if(isset($rv['tablet'])&&$rv['tablet']!==''&&$rv['tablet']!==null)return $rv['tablet'];
                    if(isset($rv['desktop'])&&$rv['desktop']!==''&&$rv['desktop']!==null)return $rv['desktop'];
                } elseif($device==='tablet'){
                    if(isset($rv['desktop'])&&$rv['desktop']!==''&&$rv['desktop']!==null)return $rv['desktop'];
                }
            }
            if(isset($settings[$key])&&$settings[$key]!==''&&$settings[$key]!==null&&!is_array($settings[$key]))return $settings[$key];
            return $fallback;
        };
        $safeId=preg_replace('/[^a-zA-Z0-9_-]/','-',(string)(isset($node['id'])?$node['id']:''));
        $class='ng-node ng-node-'.preg_replace('/[^a-z0-9_-]/i','-',strtolower($type));
        if ($type==='section') { $class.=' ng-section'; if(!empty($getSetting('sticky',''))) $class.=' ng-section-sticky'; if(!empty($getSetting('shapeTop',''))) $class.=' ng-shape-top-'.preg_replace('/[^a-z0-9_-]/i','-',strtolower((string)$getSetting('shapeTop',''))); if(!empty($getSetting('shapeBottom',''))) $class.=' ng-shape-bottom-'.preg_replace('/[^a-z0-9_-]/i','-',strtolower((string)$getSetting('shapeBottom',''))); }
        if ($type==='container') {
            $class.=' ng-container';
            $widthMode=(string)$getSetting('widthMode','boxed');
            if($widthMode==='full_bleed'||$widthMode==='full-width'||$widthMode==='viewport')$widthMode='full';
            if(!in_array($widthMode,array('boxed','full','wide','custom'),true))$widthMode='boxed';
            $class.=' ng-container--'.$widthMode;
        }
        if ($type==='column') $class.=' ng-column';
        if (!empty($node['id'])) {
            $class.=' ng-node-'.preg_replace('/[^a-z0-9_-]/i','-',strtolower($node['id']));
        }
        $style=array();
        $map=array('background'=>'background','backgroundColor'=>'background-color','backgroundImage'=>'background-image','backgroundPosition'=>'background-position','backgroundSize'=>'background-size','backgroundRepeat'=>'background-repeat','background_color'=>'background','padding'=>'padding','margin'=>'margin','width'=>'width','maxWidth'=>'max-width','max_width'=>'max-width','minHeight'=>'min-height','min_height'=>'min-height','borderRadius'=>'border-radius','borderWidth'=>'border-width','borderStyle'=>'border-style','borderColor'=>'border-color','radius'=>'border-radius','boxShadow'=>'box-shadow','shadow'=>'box-shadow','overflow'=>'overflow','display'=>'display','height'=>'height','minWidth'=>'min-width','maxHeight'=>'max-height','position'=>'position','zIndex'=>'z-index','z_index'=>'z-index','containerWidth'=>'--ng-container-width','contentMaxWidth'=>'--ng-content-max-width','contentAlign'=>'text-align','verticalAlign'=>'align-items','stickyOffset'=>'top','justifyItems'=>'justify-items','justifySelf'=>'justify-self','alignSelf'=>'align-self');
        foreach($map as $key=>$css){$value=$getSetting($key,null);if($value!==null&&$value!=='')$style[$css]=(string)$value;}
        if($type==='section') {
            // Section owns the page canvas.  The inspector exposes Content Width
            // (Boxed / Full Width), so make that setting authoritative at runtime.
            // Without this, a section stayed boxed at ~1320px and every child
            // Container/Widget could never reach the storefront edges.
            $sectionWidth=(string)$getSetting('contentWidth','full');
            if($sectionWidth==='full'||$sectionWidth==='full_width'||$sectionWidth==='100%') {
                $style['width']='100%';
                $style['max-width']='none';
                $style['margin-left']='0';
                $style['margin-right']='0';
            } else {
                $sectionMax=(string)$getSetting('maxWidth','1320px');
                $style['width']='100%';
                $style['max-width']=$sectionMax!==''?$sectionMax:'1320px';
                $style['margin-left']='auto';
                $style['margin-right']='auto';
            }
        }
        if($type==='container') {
            $layout=(string)$getSetting('layout','flex');
            if($layout==='grid') {
                $style['display']='grid';
                $gridColumns=$getSetting('gridColumns','');
                $gridCount=(int)$getSetting('gridColumnCount',count($children) ?: 1);
                $style['grid-template-columns']=$gridColumns!==''?(string)$gridColumns:'repeat('.max(1,min(12,$gridCount)).',minmax(0,1fr))';
                $gap=(string)$getSetting('gap','24px');
                $style['gap']=$gap;
                $columnGap=$getSetting('columnGap','');
                $rowGap=$getSetting('rowGap','');
                if($columnGap!=='')$style['column-gap']=(string)$columnGap;
                if($rowGap!=='')$style['row-gap']=(string)$rowGap;
                $style['justify-items']=(string)$getSetting('justifyItems','stretch');
                $style['align-items']=(string)$getSetting('alignItems','stretch');
            } else {
                // Flexbox is the default Container layout. Match the builder
                // preview exactly so sibling widgets stack/align the same way on
                // the real storefront.
                $style['display']='flex';
                $style['flex-direction']=(string)$getSetting('direction','column');
                $style['flex-wrap']=(string)$getSetting('wrap','nowrap');
                $style['justify-content']=(string)$getSetting('justify','flex-start');
                $style['align-items']=(string)$getSetting('align','stretch');
                $style['gap']=(string)$getSetting('gap','24px');
                $columnGap=$getSetting('columnGap','');
                $rowGap=$getSetting('rowGap','');
                if($columnGap!=='')$style['column-gap']=(string)$columnGap;
                if($rowGap!=='')$style['row-gap']=(string)$rowGap;
            }
            $mode=(string)$getSetting('widthMode','boxed');
            if($mode==='full_bleed'||$mode==='full-width'||$mode==='viewport')$mode='full';
            if($mode==='full'){ $style['width']='100%';$style['max-width']='100%';$style['margin-left']='0';$style['margin-right']='0'; }
            elseif($mode==='wide'){ $style['width']='calc(100% + 4vw)';$style['max-width']='none';$style['margin-left']='-2vw';$style['margin-right']='0'; }
            elseif($mode==='custom'){ $cw=(string)$getSetting('customWidth','100%');$style['width']=$cw;$style['max-width']=$cw;$style['margin-left']='auto';$style['margin-right']='auto'; }
            else { if(!isset($style['width']))$style['width']=(string)$getSetting('width','100%'); if(!isset($style['max-width']))$style['max-width']=(string)$getSetting('maxWidth','1320px');$style['margin-left']='auto';$style['margin-right']='auto'; }
        }
        $gridSpan=(int)$getSetting('gridColumnSpan',0);
        if($type!=='section' && $type!=='container' && $gridSpan>1) $style['grid-column']='span '.max(1,min(12,$gridSpan));
        if (isset($settings['heroHeadingSize']) && $settings['heroHeadingSize']!=='') $style['--ng-hero-heading-size']=(string)$settings['heroHeadingSize'];
        if (isset($settings['heroHeadingWeight']) && $settings['heroHeadingWeight']!=='') $style['--ng-hero-heading-weight']=(string)$settings['heroHeadingWeight'];
        if (isset($settings['heroBodySize']) && $settings['heroBodySize']!=='') $style['--ng-hero-body-size']=(string)$settings['heroBodySize'];
        if (isset($settings['contentMaxWidth']) && $settings['contentMaxWidth']!=='') $style['--ng-hero-content-max-width']=(string)$settings['contentMaxWidth'];
        if (isset($settings['contentPadding']) && $settings['contentPadding']!=='') $style['--ng-hero-content-padding']=(string)$settings['contentPadding'];
        if (isset($settings['arrowSize']) && $settings['arrowSize']!=='') $style['--ng-arrow-size']=(string)$settings['arrowSize'];
        if (isset($settings['arrowOffset']) && $settings['arrowOffset']!=='') $style['--ng-arrow-offset']=(string)$settings['arrowOffset'];
        if (isset($settings['arrowBackground']) && $settings['arrowBackground']!=='') $style['--ng-arrow-bg']=(string)$settings['arrowBackground'];
        if (isset($settings['arrowColor']) && $settings['arrowColor']!=='') $style['--ng-arrow-color']=(string)$settings['arrowColor'];
        if (isset($settings['dotColor']) && $settings['dotColor']!=='') $style['--ng-dot-color']=(string)$settings['dotColor'];
        if(isset($settings['textShadowX'])||isset($settings['textShadowY'])||isset($settings['textShadowBlur'])||isset($settings['textShadowColor'])){ $tx=(string)($settings['textShadowX']??'0px'); $ty=(string)($settings['textShadowY']??'0px'); $tb=(string)($settings['textShadowBlur']??'0px'); $tc=(string)($settings['textShadowColor']??'rgba(0,0,0,.25)'); $style['text-shadow']=$tx.' '.$ty.' '.$tb.' '.$tc; }
        if(isset($settings['transformOrigin'])&&$settings['transformOrigin']!=='')$style['transform-origin']=(string)$settings['transformOrigin'];
        if(isset($settings['class'])&&preg_match('/^[A-Za-z0-9 _-]+$/',(string)$settings['class']))$class.=' '.trim($settings['class']);
        $style_attr='';
        foreach($style as $key=>$value){$style_attr.=$key.':'.htmlspecialchars($value,ENT_QUOTES,'UTF-8').';';}
        // Defensive initialization prevents PHP 8.x undefined-variable warnings.
        $attrs='';
        if (!empty($settings['id']) && preg_match('/^[A-Za-z0-9_-]+$/',(string)$settings['id'])) $safeId=(string)$settings['id'];
        if(!empty($settings['customCss']) && $safeId!==''){
            $custom=(string)$settings['customCss'];$custom=str_replace(array('</style>','</STYLE>'),array('',''),$custom);$custom=preg_replace('/@import\s+[^;]+;/i','',$custom);$custom=str_replace('selector','.ng-node.ng-node-'.preg_replace('/[^a-zA-Z0-9_-]/','-', $safeId),$custom);
        } else $custom='';
        if(!empty($settings['customAttributes'])){
            $pairs=preg_split('/[\r\n,]+/',(string)$settings['customAttributes']);
            foreach($pairs as $pair){$pair=trim($pair);if($pair==='')continue;$kv=explode('|',$pair,2);if(count($kv)!==2)continue;$ak=preg_replace('/[^A-Za-z0-9_:-]/','',(string)$kv[0]);$av=trim((string)$kv[1]);if($ak===''||preg_match('/^(on|style$)/i',$ak))continue;$attrs.=' '.htmlspecialchars($ak,ENT_QUOTES,'UTF-8').'="'.htmlspecialchars($av,ENT_QUOTES,'UTF-8').'"';}
        }
        if(!empty($settings['id']) && preg_match('/^[A-Za-z0-9_-]+$/',(string)$settings['id']))$attrs.=' id="'.htmlspecialchars((string)$settings['id'],ENT_QUOTES,'UTF-8').'"';
        if(!empty($context['front_editor']) && !empty($node['id'])){
            $attrs.=' data-nextgen-node-id="'.htmlspecialchars((string)$node['id'],ENT_QUOTES,'UTF-8').'" data-nextgen-node-type="'.htmlspecialchars((string)$type,ENT_QUOTES,'UTF-8').'"';
        }
        if($style_attr)$attrs.=' style="'.$style_attr.'"';
        $responsive=$this->responsiveStyleTag($node,$safeId,$context);
        $layoutResponsive=$this->layoutResponsiveStyleTag($node,$safeId,$context);
        return ($custom!==''?'<style data-nextgen-layout-style="'.htmlspecialchars($safeId,ENT_QUOTES,'UTF-8').'">'.$custom.'</style>':'').$layoutResponsive.$responsive.'<div'.$attrs.'>'.$inner.'</div>';
    }

    private function renderWidgetNode(array $node,array $context=array()) {
        $type=isset($node['type']) ? $node['type'] : '';

        $renderer=$this->registry ? $this->registry->getWidget($type) : null;

        if (is_callable($renderer)) {
            $result=call_user_func($renderer,$node,$context,$this);
            $html=is_array($result) ? (isset($result['html'])?$result['html']:'') : (string)$result;
            return $this->decorateWidget($html,$node,$context);
        }

        return $this->decorateWidget($this->fallbackWidget($node,$context),$node,$context);
    }

    private function decorateWidget($html,array $node,array $context=array()) {
        $settings=isset($node['settings'])&&is_array($node['settings'])?$node['settings']:array();
        $type=isset($node['type'])?(string)$node['type']:'';
        $device=isset($context['device'])&&in_array($context['device'],array('desktop','tablet','mobile'),true)?$context['device']:'desktop';

        // Resolve a widget setting consistently with the layout renderer.
        // Responsive widget values take precedence, then fall back to the
        // non-responsive setting. This closure must live inside decorateWidget()
        // because widget-level decoration also reads these settings.
        $getSetting=function($key,$fallback=null) use ($settings,$device){
            if(isset($settings['responsive'])&&is_array($settings['responsive'])
                &&isset($settings['responsive'][$key])&&is_array($settings['responsive'][$key])){
                $rv=$settings['responsive'][$key];

                if(isset($rv[$device])&&$rv[$device]!==''&&$rv[$device]!==null){
                    return $rv[$device];
                }

                if($device==='mobile'){
                    if(isset($rv['tablet'])&&$rv['tablet']!==''&&$rv['tablet']!==null)return $rv['tablet'];
                    if(isset($rv['desktop'])&&$rv['desktop']!==''&&$rv['desktop']!==null)return $rv['desktop'];
                } elseif($device==='tablet'){
                    if(isset($rv['desktop'])&&$rv['desktop']!==''&&$rv['desktop']!==null)return $rv['desktop'];
                    if(isset($rv['mobile'])&&$rv['mobile']!==''&&$rv['mobile']!==null)return $rv['mobile'];
                } else {
                    if(isset($rv['tablet'])&&$rv['tablet']!==''&&$rv['tablet']!==null)return $rv['tablet'];
                }
            }

            if(isset($settings[$key])&&$settings[$key]!==''&&$settings[$key]!==null&&!is_array($settings[$key])){
                return $settings[$key];
            }

            return $fallback;
        };

        $id=isset($node['id'])?(string)$node['id']:'';
        $safeId=preg_replace('/[^a-zA-Z0-9_-]/','-', $id);
        $class='ng-rendered-widget';
        // Keep a stable node-scoped class on every rendered widget.
        // Universal widget renderers (Hero, Slider, etc.) scope their runtime
        // CSS to .ng-rendered-widget.ng-node-<nodeId>; without this class the
        // storefront receives the HTML but none of the saved widget styles can
        // match the element. The builder preview did not expose this because it
        // renders with its own preview CSS.
        if ($safeId!=='') $class.=' ng-node-'.preg_replace('/[^a-zA-Z0-9_-]/','-', $safeId);
        $motion=isset($settings['animation'])?(string)$settings['animation']:'';
        $motionMap=array('fade'=>'fade','fade-up'=>'fade-up','fade-down'=>'fade-down','zoom-in'=>'zoom-in','slide-left'=>'slide-left','slide-right'=>'slide-right');
        if(isset($motionMap[$motion])) $class.=' ng-motion ng-motion-'.str_replace('_','-',$motionMap[$motion]);
        if (!empty($settings['class']) && preg_match('/^[A-Za-z0-9 _-]+$/',(string)$settings['class'])) $class.=' '.trim($settings['class']);
        $widthMode=isset($settings['widthMode'])?(string)$settings['widthMode']:'';
        if ($widthMode==='full') $class.=' ng-widget-width-full';
        elseif ($widthMode==='full_bleed') $class.=' ng-widget-width-full-bleed';
        elseif ($widthMode==='wide') $class.=' ng-widget-width-wide';
        $style=array();
        $map=array('color'=>'color','backgroundColor'=>'background-color','background'=>'background','backgroundImage'=>'background-image','backgroundPosition'=>'background-position','backgroundSize'=>'background-size','backgroundRepeat'=>'background-repeat','fontFamily'=>'font-family','fontSize'=>'font-size','fontWeight'=>'font-weight','lineHeight'=>'line-height','letterSpacing'=>'letter-spacing','wordSpacing'=>'word-spacing','textTransform'=>'text-transform','textDecoration'=>'text-decoration','fontStyle'=>'font-style','textAlign'=>'text-align','margin'=>'margin','padding'=>'padding','width'=>'width','maxWidth'=>'max-width','minHeight'=>'min-height','borderWidth'=>'border-width','borderStyle'=>'border-style','borderColor'=>'border-color','radius'=>'border-radius','borderRadius'=>'border-radius','shadow'=>'box-shadow','opacity'=>'opacity','display'=>'display','objectFit'=>'object-fit','objectPosition'=>'object-position','filter'=>'filter','transform'=>'transform','transition'=>'transition','direction'=>'direction','textShadow'=>'text-shadow','textStrokeWidth'=>'-webkit-text-stroke-width','textStrokeColor'=>'-webkit-text-stroke-color');
        foreach($map as $key=>$css){$value=$getSetting($key,null);if($value!==null&&$value!=='')$style[$css]=(string)$value;}
        if(isset($settings['textShadowX'])||isset($settings['textShadowY'])||isset($settings['textShadowBlur'])||isset($settings['textShadowColor'])){ $tx=(string)($settings['textShadowX']??'0px'); $ty=(string)($settings['textShadowY']??'0px'); $tb=(string)($settings['textShadowBlur']??'0px'); $tc=(string)($settings['textShadowColor']??'rgba(0,0,0,.25)'); $style['text-shadow']=$tx.' '.$ty.' '.$tb.' '.$tc; }
        if(isset($motionMap[$motion])){
            $style['--ng-motion-duration']=((int)(isset($settings['animationDuration'])?$settings['animationDuration']:500)).'ms';
            $style['--ng-motion-delay']=((int)(isset($settings['animationDelay'])?$settings['animationDelay']:0)).'ms';
            $style['--ng-motion-easing']=(string)(isset($settings['animationEasing'])?$settings['animationEasing']:'ease');
            $style['--ng-motion-name']='ng'.str_replace(' ','',ucwords(str_replace('-',' ',$motion)));
        }
        $stateCss='';
        $selector=$safeId!==''?'.ng-rendered-widget.ng-node-'.preg_replace('/[^a-zA-Z0-9_-]/','-', $safeId):'';
        $stateMap=array('hover'=>':hover','focus'=>':focus','active'=>':active');
        foreach($stateMap as $stateName=>$pseudo){
            if(empty($settings['states'][$stateName]) || !is_array($settings['states'][$stateName])) continue;
            $st=$settings['states'][$stateName]; $rules=array();
            $stateProps=array('color'=>'color','backgroundColor'=>'background-color','background'=>'background','fontFamily'=>'font-family','fontSize'=>'font-size','fontWeight'=>'font-weight','lineHeight'=>'line-height','letterSpacing'=>'letter-spacing','wordSpacing'=>'word-spacing','textTransform'=>'text-transform','textDecoration'=>'text-decoration','fontStyle'=>'font-style','textAlign'=>'text-align','opacity'=>'opacity','borderColor'=>'border-color','borderWidth'=>'border-width','borderStyle'=>'border-style','borderRadius'=>'border-radius','shadow'=>'box-shadow','transform'=>'transform','filter'=>'filter');
            foreach($stateProps as $key=>$prop){if(isset($st[$key])&&$st[$key]!==''&&$st[$key]!==null)$rules[]=$prop.':'.htmlspecialchars((string)$st[$key],ENT_QUOTES,'UTF-8').' !important;';}
            if(!empty($rules)&&$selector!=='')$stateCss.=$selector.$pseudo.' > .ng-widget,'. $selector.$pseudo.' > .ng-widget h1,'. $selector.$pseudo.' > .ng-widget h2,'. $selector.$pseudo.' > .ng-widget h3,'. $selector.$pseudo.' > .ng-widget h4,'. $selector.$pseudo.' > .ng-widget h5,'. $selector.$pseudo.' > .ng-widget h6,'. $selector.$pseudo.' > .ng-widget p,'. $selector.$pseudo.' > .ng-widget a,'. $selector.$pseudo.' > .ng-widget button{'.implode('',$rules).'}';
        }
        if(!empty($settings['customCss']) && $selector!==''){
            $custom=(string)$settings['customCss'];
            $custom=str_replace(array('</style>','</STYLE>'),array('',''),$custom);
            $custom=preg_replace('/@import\s+[^;]+;/i','',$custom);
            $custom=preg_replace('/url\s*\(\s*["\']?javascript:/i','url(', $custom);
            $custom=str_replace('selector',$selector,$custom);
            $stateCss.=$custom;
        }
        // Widget visual styles must reach the actual widget element, not only
        // the layout wrapper. Containers/sections own layout sizing, while the
        // inner .ng-widget owns typography, colors, borders, backgrounds and
        // effects. This keeps builder preview and storefront output consistent.
        $visualMap=array(
            'color'=>'color','backgroundColor'=>'background-color','background'=>'background',
            'backgroundImage'=>'background-image','backgroundPosition'=>'background-position','backgroundSize'=>'background-size',
            'backgroundRepeat'=>'background-repeat','fontFamily'=>'font-family','fontSize'=>'font-size','fontWeight'=>'font-weight',
            'lineHeight'=>'line-height','letterSpacing'=>'letter-spacing','wordSpacing'=>'word-spacing','textTransform'=>'text-transform',
            'textDecoration'=>'text-decoration','fontStyle'=>'font-style','textAlign'=>'text-align','direction'=>'direction',
            'borderWidth'=>'border-width','borderStyle'=>'border-style','borderColor'=>'border-color','radius'=>'border-radius',
            'borderRadius'=>'border-radius','shadow'=>'box-shadow','opacity'=>'opacity','filter'=>'filter','textShadow'=>'text-shadow',
            'textStrokeWidth'=>'-webkit-text-stroke-width','textStrokeColor'=>'-webkit-text-stroke-color','transition'=>'transition'
        );
        $innerRules=array();
        foreach($visualMap as $key=>$prop){
            if(isset($style[$prop]) && $style[$prop]!=='') $innerRules[]=$prop.':'.$this->escCss((string)$style[$prop]).';';
        }
        // Button-specific normal settings use their own names so they do not
        // collide with the generic widget typography controls.
        if($type==='button'){
            $buttonMap=array('buttonColor'=>'color','buttonBackground'=>'background-color','buttonBorderColor'=>'border-color','buttonBorderWidth'=>'border-width','buttonBorderStyle'=>'border-style','buttonRadius'=>'border-radius','buttonPadding'=>'padding','buttonFontSize'=>'font-size','buttonFontWeight'=>'font-weight','buttonFontFamily'=>'font-family','buttonLineHeight'=>'line-height','buttonLetterSpacing'=>'letter-spacing','buttonTransform'=>'text-transform','buttonDecoration'=>'text-decoration','buttonStyle'=>'font-style','buttonShadow'=>'box-shadow');
            foreach($buttonMap as $key=>$prop){$v=$getSetting($key,null);if($v!==null&&$v!=='')$innerRules[]=$prop.':'.$this->escCss((string)$v).';';}
        }
        if($innerRules && $selector!=='') $stateCss.=$selector.' > .ng-widget{'.implode('',$innerRules).'}';
        if($type==='button' && $selector!==''){
            $hr=array();
            $hoverSettings=(isset($settings['states']['hover'])&&is_array($settings['states']['hover']))?$settings['states']['hover']:array();
            foreach(array('buttonHoverColor'=>'color','buttonHoverBackground'=>'background-color','buttonHoverBorderColor'=>'border-color','buttonHoverBorderWidth'=>'border-width','buttonHoverBorderStyle'=>'border-style','buttonHoverRadius'=>'border-radius','buttonHoverShadow'=>'box-shadow') as $key=>$prop){
                $v=null;
                if(isset($hoverSettings[$key])&&$hoverSettings[$key]!==''&&$hoverSettings[$key]!==null)$v=$hoverSettings[$key];
                elseif(isset($settings[$key])&&$settings[$key]!=='')$v=$settings[$key];
                if($v!==null)$hr[]=$prop.':'.$this->escCss((string)$v).' !important;';
            }
            if(isset($hoverSettings['responsive'])&&is_array($hoverSettings['responsive'])){
                foreach(array('buttonHoverColor'=>'color','buttonHoverBackground'=>'background-color','buttonHoverBorderColor'=>'border-color','buttonHoverBorderWidth'=>'border-width','buttonHoverBorderStyle'=>'border-style','buttonHoverRadius'=>'border-radius','buttonHoverShadow'=>'box-shadow') as $key=>$prop){
                    if(isset($hoverSettings['responsive'][$key]['desktop'])&&$hoverSettings['responsive'][$key]['desktop']!=='')$hr[]=$prop.':'.$this->escCss((string)$hoverSettings['responsive'][$key]['desktop']).';';
                }
            }
            if($hr)$stateCss.=$selector.' > .ng-widget-button:hover{'.implode('',$hr).'}';
        }
        // Apply widget visual controls directly to the actual rendered widget element.
        // The wrapper is intentionally kept for layout, but typography/colors/borders
        // must not depend on a selector matching perfectly. Inline styles make the
        // storefront result deterministic and prevent the base theme CSS from
        // silently overriding builder settings.
        $inlineRules=array();
        foreach($style as $prop=>$value){
            $inlineRules[]=$prop.':'.$this->escCss((string)$value).' !important;';
        }
        if($type==='button'){
            foreach($buttonMap as $key=>$prop){
                $v=$getSetting($key,null);
                if($v!==null&&$v!=='') $inlineRules[]=$prop.':'.$this->escCss((string)$v).' !important;';
            }
        }
        if($inlineRules){
            $inlineStyle=implode('',$inlineRules);
            $html=preg_replace_callback('/(<[a-z][^>]*\bclass=["\'][^"\']*\bng-widget\b[^"\']*["\'][^>]*)(>)/i',function($m) use ($inlineStyle){
                if(preg_match('/\sstyle=["\']([^"\']*)["\']/i',$m[1],$sm)){
                    $merged=rtrim($sm[1],';').';'.$inlineStyle;
                    $tag=preg_replace('/\sstyle=["\'][^"\']*["\']/i',' style="'.htmlspecialchars($merged,ENT_QUOTES,'UTF-8').'"',$m[1],1);
                } else {
                    $tag=$m[1].' style="'.htmlspecialchars($inlineStyle,ENT_QUOTES,'UTF-8').'"';
                }
                return $tag.$m[2];
            },$html,1);
        }
        $styleAttr='';foreach($style as $key=>$value){$styleAttr.=$key.':'.htmlspecialchars($value,ENT_QUOTES,'UTF-8').';';}
        if (!empty($settings['visibility']) && is_array($settings['visibility'])) { foreach ($settings['visibility'] as $device=>$visible) { if ($visible === false) $class .= ' ng-hide-' . preg_replace('/[^a-z0-9_-]/i','-',strtolower($device)); } }
        if (!empty($settings['id']) && preg_match('/^[A-Za-z0-9_-]+$/',(string)$settings['id'])) $safeId=(string)$settings['id'];
        $attrs=' class="'.htmlspecialchars($class,ENT_QUOTES,'UTF-8').'"';
        if($safeId!=='')$attrs.=' id="'.htmlspecialchars($safeId,ENT_QUOTES,'UTF-8').'"';
        if(!empty($settings['customAttributes'])){
            $pairs=preg_split('/[\r\n,]+/',(string)$settings['customAttributes']);
            foreach($pairs as $pair){$pair=trim($pair);if($pair==='')continue;$kv=explode('|',$pair,2);if(count($kv)!==2)continue;$ak=preg_replace('/[^A-Za-z0-9_:-]/','',(string)$kv[0]);$av=trim((string)$kv[1]);if($ak===''||preg_match('/^(on|style$)/i',$ak))continue;$attrs.=' '.htmlspecialchars($ak,ENT_QUOTES,'UTF-8').'="'.htmlspecialchars($av,ENT_QUOTES,'UTF-8').'"';}
        }
        if(isset($motionMap[$motion])){
            $attrs.=' data-ng-motion="'.htmlspecialchars($motion,ENT_QUOTES,'UTF-8').'" data-ng-motion-duration="'.(int)(isset($settings['animationDuration'])?$settings['animationDuration']:500).'" data-ng-motion-delay="'.(int)(isset($settings['animationDelay'])?$settings['animationDelay']:0).'" data-ng-motion-easing="'.htmlspecialchars((string)(isset($settings['animationEasing'])?$settings['animationEasing']:'ease'),ENT_QUOTES,'UTF-8').'"';
        }
        if(!empty($node['id']) && !empty($context['front_editor'])){
            $attrs.=' data-nextgen-node-id="'.htmlspecialchars((string)$node['id'],ENT_QUOTES,'UTF-8').'" data-nextgen-node-type="'.htmlspecialchars((string)($node['type']??''),ENT_QUOTES,'UTF-8').'"';
        }
        $childrenHtml='';
        if (!empty($node['children']) && is_array($node['children'])) {
            foreach ($node['children'] as $child) {
                if (is_array($child)) {
                    $childrenHtml .= $this->renderNode($child,$context);
                }
            }
        }
        if ($childrenHtml !== '') {
            $html .= '<div class="ng-inner-widget-slot" data-nextgen-slot="inner">'.$childrenHtml.'</div>';
        }
        $responsive=$this->responsiveStyleTag($node,$safeId,$context);
        return $responsive.'<div'.$attrs.'>'.$html.'</div>';
    }

    private function layoutResponsiveStyleTag(array $node,$safeId,array $context=array()) {
        $type=isset($node['type'])?(string)$node['type']:'';
        if(!in_array($type,array('section','container','column'),true)) return '';
        $settings=isset($node['settings'])&&is_array($node['settings'])?$node['settings']:array();
        $r=isset($settings['responsive'])&&is_array($settings['responsive'])?$settings['responsive']:array();
        $id=preg_replace('/[^a-zA-Z0-9_-]/','-',(string)$safeId);
        if($id===''||empty($r))return '';
        $selector='.ng-node.ng-node-'.$id;
        $css='';
        foreach(array('tablet'=>'900px','mobile'=>'600px') as $device=>$break){
            $rules=array();
            foreach(array('width'=>'width','maxWidth'=>'max-width','minWidth'=>'min-width','minHeight'=>'min-height','height'=>'height','padding'=>'padding','margin'=>'margin','gap'=>'gap','columnGap'=>'column-gap','rowGap'=>'row-gap','gridColumns'=>'grid-template-columns','justifyItems'=>'justify-items','align'=>'align-items','direction'=>'flex-direction','wrap'=>'flex-wrap','justify'=>'justify-content','position'=>'position','zIndex'=>'z-index','overflow'=>'overflow') as $key=>$prop){
                if(isset($r[$key])&&is_array($r[$key])&&isset($r[$key][$device])&&$r[$key][$device]!=='')$rules[]=$prop.':'.$this->escCss((string)$r[$key][$device]).';';
            }
            if($type!=='section'&&$type!=='container'&&isset($r['gridColumnSpan'])&&is_array($r['gridColumnSpan'])&&isset($r['gridColumnSpan'][$device])&&$r['gridColumnSpan'][$device]!==''){$span=max(1,min(12,(int)$r['gridColumnSpan'][$device]));$rules[]='grid-column:span '.$span.';';}
            if($type==='container'&&isset($r['widthMode'])&&is_array($r['widthMode'])&&isset($r['widthMode'][$device])){
                $mode=(string)$r['widthMode'][$device];
                if($mode==='full'||$mode==='full_bleed'||$mode==='full-width'||$mode==='viewport'){$rules[]='width:100vw;';$rules[]='max-width:100vw;';$rules[]='margin-left:calc(50% - 50vw);';$rules[]='margin-right:calc(50% - 50vw);';}
                elseif($mode==='wide'){$rules[]='width:calc(100% + 4vw);';$rules[]='max-width:none;';$rules[]='margin-left:-2vw;';$rules[]='margin-right:0;';}
                elseif($mode==='custom'){$cw=isset($r['customWidth'])&&is_array($r['customWidth'])&&isset($r['customWidth'][$device])?$r['customWidth'][$device]:'100%';$rules[]='width:'.$this->escCss((string)$cw).';';$rules[]='max-width:'.$this->escCss((string)$cw).';';$rules[]='margin-left:auto;';$rules[]='margin-right:auto;';}
                else{$rules[]='width:'.(isset($r['width'])&&is_array($r['width'])&&isset($r['width'][$device])?$this->escCss((string)$r['width'][$device]):'100%').';';if(isset($r['maxWidth'])&&is_array($r['maxWidth'])&&isset($r['maxWidth'][$device])&&$r['maxWidth'][$device]!=='')$rules[]='max-width:'.$this->escCss((string)$r['maxWidth'][$device]).';';$rules[]='margin-left:auto;';$rules[]='margin-right:auto;';}
            }
            if($type==='container' && isset($r['gridColumnCount'])&&is_array($r['gridColumnCount'])&&isset($r['gridColumnCount'][$device])&&$r['gridColumnCount'][$device]!==''){$count=max(1,min(12,(int)$r['gridColumnCount'][$device]));$rules[]='grid-template-columns:repeat('.$count.',minmax(0,1fr));';}
            if(!empty($rules))$css.='@media(max-width:'.$break.'){'.$selector.'{'.str_replace(';',' !important;',implode('',$rules)).'}}';
        }
        return $css;
    }

    private function responsiveStyleTag(array $node,$safeId,array $context=array()) {
        $settings=isset($node['settings'])&&is_array($node['settings'])?$node['settings']:array();
        $type=isset($node['type'])?(string)$node['type']:'';
        $r=isset($settings['responsive'])&&is_array($settings['responsive'])?$settings['responsive']:array();
        $id=preg_replace('/[^a-zA-Z0-9_-]/','-',(string)$safeId);
        if($id==='' || empty($r)) return '';
        $map=array(
            'fontFamily'=>'font-family','fontSize'=>'font-size','fontWeight'=>'font-weight','lineHeight'=>'line-height',
            'letterSpacing'=>'letter-spacing','wordSpacing'=>'word-spacing','textTransform'=>'text-transform',
            'textDecoration'=>'text-decoration','fontStyle'=>'font-style','textAlign'=>'text-align','color'=>'color',
            'backgroundColor'=>'background-color','backgroundImage'=>'background-image','backgroundPosition'=>'background-position',
            'backgroundSize'=>'background-size','backgroundRepeat'=>'background-repeat','margin'=>'margin','padding'=>'padding',
            'width'=>'width','maxWidth'=>'max-width','minWidth'=>'min-width','minHeight'=>'min-height','height'=>'height',
            'gap'=>'gap','borderWidth'=>'border-width','borderStyle'=>'border-style','borderColor'=>'border-color',
            'radius'=>'border-radius','opacity'=>'opacity','display'=>'display','position'=>'position','zIndex'=>'z-index',
            'overflow'=>'overflow','justifySelf'=>'justify-self','alignSelf'=>'align-self','direction'=>'direction','textShadow'=>'text-shadow','textStrokeWidth'=>'-webkit-text-stroke-width','textStrokeColor'=>'-webkit-text-stroke-color','objectFit'=>'object-fit','objectPosition'=>'object-position','transform'=>'transform','heroHeadingSize'=>'--ng-hero-heading-size','heroBodySize'=>'--ng-hero-body-size','heroHeadingWeight'=>'--ng-hero-heading-weight','heroHeadingColor'=>'--ng-hero-heading-color','heroBodyColor'=>'--ng-hero-body-color','contentGap'=>'--ng-hero-content-gap'
        );
        $css='';
        $baseRules=array();
        $typographyMap=array('fontFamily'=>'font-family','fontSize'=>'font-size','fontWeight'=>'font-weight','lineHeight'=>'line-height','letterSpacing'=>'letter-spacing','wordSpacing'=>'word-spacing','textTransform'=>'text-transform','textDecoration'=>'text-decoration','fontStyle'=>'font-style','textAlign'=>'text-align','color'=>'color','textShadow'=>'text-shadow');
        foreach($typographyMap as $key=>$prop){
            if(isset($settings[$key])&&$settings[$key]!==''&&$settings[$key]!==null)$baseRules[]=$prop.':'.$this->escCss((string)$settings[$key]).';';
        }
        foreach($typographyMap as $key=>$prop){
            if(isset($r[$key]) && is_array($r[$key]) && isset($r[$key]['desktop']) && $r[$key]['desktop']!=='' && $r[$key]['desktop']!==null)$baseRules[]=$prop.':'.$this->escCss((string)$r[$key]['desktop']).';';
        }
        if(isset($r['backgroundImage']) && is_array($r['backgroundImage']) && isset($r['backgroundImage']['desktop']) && $r['backgroundImage']['desktop']!=='') {
            $bg=$r['backgroundImage']['desktop'];
            if(strpos($bg,'url(')!==0)$bg='url("'.$this->escCss($this->imageUrl($bg)).'")';
            $baseRules[]='background-image:'.$bg.';';
        }
        if(!empty($baseRules))$css.='.ng-rendered-widget.ng-node-'.$id.' > .ng-widget,.ng-rendered-widget.ng-node-'.$id.' > .ng-widget h1,.ng-rendered-widget.ng-node-'.$id.' > .ng-widget h2,.ng-rendered-widget.ng-node-'.$id.' > .ng-widget h3,.ng-rendered-widget.ng-node-'.$id.' > .ng-widget h4,.ng-rendered-widget.ng-node-'.$id.' > .ng-widget h5,.ng-rendered-widget.ng-node-'.$id.' > .ng-widget h6,.ng-rendered-widget.ng-node-'.$id.' > .ng-widget p,.ng-rendered-widget.ng-node-'.$id.' > .ng-widget a,.ng-rendered-widget.ng-node-'.$id.' > .ng-widget button{'.str_replace(';',' !important;',implode('',$baseRules)).'}';
        if(!empty($settings['heroHeadingSize']))$css.='.ng-rendered-widget.ng-node-'.$id.' .ng-universal-hero__content h2{font-size:'.$this->escCss((string)$settings['heroHeadingSize']).';}';
        if(!empty($settings['heroHeadingWeight']))$css.='.ng-rendered-widget.ng-node-'.$id.' .ng-universal-hero__content h2{font-weight:'.$this->escCss((string)$settings['heroHeadingWeight']).';}';
        if(!empty($settings['heroBodySize']))$css.='.ng-rendered-widget.ng-node-'.$id.' .ng-universal-hero__content p{font-size:'.$this->escCss((string)$settings['heroBodySize']).';}';
        foreach(array('tablet'=>'900px','mobile'=>'600px') as $device=>$break){
            $rules=array();
            foreach($map as $key=>$prop){
                if(isset($r[$key]) && is_array($r[$key]) && isset($r[$key][$device]) && $r[$key][$device]!=='' && $r[$key][$device]!==null){
                    $v=(string)$r[$key][$device];
                    if($key==='backgroundImage' && strpos($v,'url(')!==0){
                        $v='url("'.$this->escCss($this->imageUrl($v)).'")';
                    }
                    $rules[]=$prop.':'.$this->escCss($v).';';
                }
            }
            if(isset($r['textShadowX']) && is_array($r['textShadowX']) && isset($r['textShadowX'][$device])) { $tx=(string)$r['textShadowX'][$device]; $ty=(string)($r['textShadowY'][$device]??'0px'); $tb=(string)($r['textShadowBlur'][$device]??'0px'); $tc=(string)($r['textShadowColor'][$device]??'rgba(0,0,0,.25)'); $rules[]='text-shadow:'.$this->escCss($tx.' '.$ty.' '.$tb.' '.$tc).';'; }
            if($type==='hero' || $type==='hero_slider') {
                $heroRules=array();
                if(isset($r['minHeight']) && is_array($r['minHeight']) && isset($r['minHeight'][$device]) && $r['minHeight'][$device]!=='') $heroRules[]='--ng-hero-min-height:'.$this->escCss((string)$r['minHeight'][$device]).';';
                if(isset($r['contentMaxWidth']) && is_array($r['contentMaxWidth']) && isset($r['contentMaxWidth'][$device]) && $r['contentMaxWidth'][$device]!=='') $heroRules[]='--ng-hero-content-max-width:'.$this->escCss((string)$r['contentMaxWidth'][$device]).';';
                if(isset($r['contentPadding']) && is_array($r['contentPadding']) && isset($r['contentPadding'][$device]) && $r['contentPadding'][$device]!=='') $heroRules[]='--ng-hero-content-padding:'.$this->escCss((string)$r['contentPadding'][$device]).';';
                if(isset($r['heroHeadingSize']) && is_array($r['heroHeadingSize']) && isset($r['heroHeadingSize'][$device]) && $r['heroHeadingSize'][$device]!=='') $heroRules[]='--ng-hero-heading-size:'.$this->escCss((string)$r['heroHeadingSize'][$device]).';';
                if(isset($r['heroBodySize']) && is_array($r['heroBodySize']) && isset($r['heroBodySize'][$device]) && $r['heroBodySize'][$device]!=='') $heroRules[]='--ng-hero-body-size:'.$this->escCss((string)$r['heroBodySize'][$device]).';';
                if(isset($r['heroHeadingColor']) && is_array($r['heroHeadingColor']) && isset($r['heroHeadingColor'][$device]) && $r['heroHeadingColor'][$device]!=='') $heroRules[]='--ng-hero-heading-color:'.$this->escCss((string)$r['heroHeadingColor'][$device]).';';
                if(isset($r['heroBodyColor']) && is_array($r['heroBodyColor']) && isset($r['heroBodyColor'][$device]) && $r['heroBodyColor'][$device]!=='') $heroRules[]='--ng-hero-body-color:'.$this->escCss((string)$r['heroBodyColor'][$device]).';';
                if(isset($r['contentGap']) && is_array($r['contentGap']) && isset($r['contentGap'][$device]) && $r['contentGap'][$device]!=='') $heroRules[]='--ng-hero-content-gap:'.$this->escCss((string)$r['contentGap'][$device]).';';
                foreach(array('backgroundPosition'=>'--ng-hero-bg-position','backgroundSize'=>'--ng-hero-bg-size','backgroundRepeat'=>'--ng-hero-bg-repeat','backgroundColor'=>'--ng-hero-background-color','overlayColor'=>'--ng-hero-overlay-color','overlayOpacity'=>'--ng-hero-overlay-opacity') as $hk=>$hv){ if(isset($r[$hk]) && is_array($r[$hk]) && isset($r[$hk][$device]) && $r[$hk][$device]!=='') $heroRules[]=$hv.':'.$this->escCss((string)$r[$hk][$device]).';'; }
                if(isset($r['textAlign']) && is_array($r['textAlign']) && isset($r['textAlign'][$device]) && $r['textAlign'][$device]!=='') $heroRules[]='--ng-hero-text-align:'.$this->escCss((string)$r['textAlign'][$device]).';';
                if(isset($r['heroTextAlign']) && is_array($r['heroTextAlign']) && isset($r['heroTextAlign'][$device]) && $r['heroTextAlign'][$device]!=='') $heroRules[]='--ng-hero-text-align:'.$this->escCss((string)$r['heroTextAlign'][$device]).';';
                if(isset($r['contentPosition']) && is_array($r['contentPosition']) && isset($r['contentPosition'][$device]) && $r['contentPosition'][$device]!=='') { $parts=preg_split('/\s+/',trim((string)$r['contentPosition'][$device])); $hh=$parts[0]??'left'; $vv=$parts[1]??'center'; $heroRules[]='--ng-hero-align-items:'.($hh==='right'?'flex-end':($hh==='center'?'center':'flex-start')).';'; $heroRules[]='--ng-hero-justify-content:'.($vv==='top'?'flex-start':($vv==='bottom'?'flex-end':'center')).';'; }
                if(!empty($heroRules)) $css.='@media (max-width:'.$break.'){.ng-rendered-widget.ng-node-'.$id.' > .ng-widget{'.implode('',$heroRules).'}}';
            }
            if(!empty($rules)) $css.='@media (max-width:'.$break.'){.ng-rendered-widget.ng-node-'.$id.' > .ng-widget,.ng-rendered-widget.ng-node-'.$id.' > .ng-widget h1,.ng-rendered-widget.ng-node-'.$id.' > .ng-widget h2,.ng-rendered-widget.ng-node-'.$id.' > .ng-widget h3,.ng-rendered-widget.ng-node-'.$id.' > .ng-widget h4,.ng-rendered-widget.ng-node-'.$id.' > .ng-widget h5,.ng-rendered-widget.ng-node-'.$id.' > .ng-widget h6,.ng-rendered-widget.ng-node-'.$id.' > .ng-widget p,.ng-rendered-widget.ng-node-'.$id.' > .ng-widget a,.ng-rendered-widget.ng-node-'.$id.' > .ng-widget button{'.str_replace(';',' !important;',implode('',$rules)).'}}';
        }
        if(isset($settings['states']['hover'])&&is_array($settings['states']['hover'])){
            $h=$settings['states']['hover'];$hrules=array();
            foreach(array('color'=>'color','backgroundColor'=>'background-color','opacity'=>'opacity','transform'=>'transform','borderColor'=>'border-color','shadow'=>'box-shadow') as $key=>$prop){if(isset($h[$key])&&$h[$key]!=='')$hrules[]=$prop.':'.$this->escCss((string)$h[$key]).';';}
            if(!empty($hrules))$css.='.ng-rendered-widget.ng-node-'.$id.' > .ng-widget:hover,.ng-rendered-widget.ng-node-'.$id.' > .ng-widget:hover h1,.ng-rendered-widget.ng-node-'.$id.' > .ng-widget:hover h2,.ng-rendered-widget.ng-node-'.$id.' > .ng-widget:hover h3,.ng-rendered-widget.ng-node-'.$id.' > .ng-widget:hover h4,.ng-rendered-widget.ng-node-'.$id.' > .ng-widget:hover h5,.ng-rendered-widget.ng-node-'.$id.' > .ng-widget:hover h6,.ng-rendered-widget.ng-node-'.$id.' > .ng-widget:hover p,.ng-rendered-widget.ng-node-'.$id.' > .ng-widget:hover a,.ng-rendered-widget.ng-node-'.$id.' > .ng-widget:hover button{'.str_replace(';',' !important;',implode('',$hrules)).'}';
        }
        return $css?'<style data-nextgen-node-style="'.$this->escCss($id).'">'.$css.'</style>':'';
    }

    private function escCss($value) {
        return htmlspecialchars((string)$value,ENT_QUOTES,'UTF-8');
    }

    private function imageUrl($value) { return NextGenMediaUrl::url($value); }

    private function fallbackWidget(array $node,array $context=array()) {
        $type=htmlspecialchars(isset($node['type'])?$node['type']:'unknown',ENT_QUOTES,'UTF-8');
        $childrenHtml='';
        if (!empty($node['children']) && is_array($node['children'])) {
            foreach ($node['children'] as $child) {
                if (is_array($child)) $childrenHtml .= $this->renderNode($child,$context);
            }
        }
        return '<div class="ng-widget ng-widget-missing" data-widget-type="'.$type.'"><span class="ng-widget-missing-label">'. $type .' widget</span>'.$childrenHtml.'</div>';
    }
}
