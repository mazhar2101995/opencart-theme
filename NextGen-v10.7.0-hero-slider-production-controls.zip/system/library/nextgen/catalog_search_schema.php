<?php
class NextGenCatalogSearchSchema {
    public static function widgets() {
        return [
            'category-title' => ['title'=>'Category Title','template'=>'builder/catalog/category-title','category'=>'catalog'],
            'category-description' => ['title'=>'Category Description','template'=>'builder/catalog/category-description','category'=>'catalog'],
            'category-image' => ['title'=>'Category Image','template'=>'builder/catalog/category-image','category'=>'catalog'],
            'category-children' => ['title'=>'Category Children','template'=>'builder/catalog/category-children','category'=>'catalog'],
            'category-grid' => ['title'=>'Category Grid','template'=>'builder/catalog/category-grid','category'=>'catalog'],
            'category-products' => ['title'=>'Category Products','template'=>'builder/catalog/category-products','category'=>'catalog'],
            'product-filter' => ['title'=>'Product Filter','template'=>'builder/catalog/product-filter','category'=>'catalog'],
            'filter-sidebar' => ['title'=>'Filter Sidebar','template'=>'builder/catalog/filter-sidebar','category'=>'catalog'],
            'active-filters' => ['title'=>'Active Filters','template'=>'builder/catalog/active-filters','category'=>'catalog'],
            'product-sort' => ['title'=>'Product Sort','template'=>'builder/catalog/product-sort','category'=>'catalog'],
            'product-pagination' => ['title'=>'Product Pagination','template'=>'builder/catalog/product-pagination','category'=>'catalog'],
            'search-query' => ['title'=>'Search Query','template'=>'builder/catalog/search-query','category'=>'search'],
            'search-suggestions' => ['title'=>'Search Suggestions','template'=>'builder/catalog/search-suggestions','category'=>'search'],
            'search-results' => ['title'=>'Search Results','template'=>'builder/catalog/search-results','category'=>'search'],
            'search-filters' => ['title'=>'Search Filters','template'=>'builder/catalog/search-filters','category'=>'search'],
            'manufacturer-title' => ['title'=>'Manufacturer Title','template'=>'builder/catalog/manufacturer-title','category'=>'manufacturer'],
            'manufacturer-logo' => ['title'=>'Manufacturer Logo','template'=>'builder/catalog/manufacturer-logo','category'=>'manufacturer'],
            'manufacturer-description' => ['title'=>'Manufacturer Description','template'=>'builder/catalog/manufacturer-description','category'=>'manufacturer'],
            'manufacturer-products' => ['title'=>'Manufacturer Products','template'=>'builder/catalog/manufacturer-products','category'=>'manufacturer'],
        ];
    }

    public static function controls($id) {
        $common = [
            ['id'=>'alignment','type'=>'select','label'=>'Alignment','options'=>['left'=>'Left','center'=>'Center','right'=>'Right'],'default'=>'left'],
            ['id'=>'visibility','type'=>'responsive','label'=>'Responsive Visibility'],
            ['id'=>'animation','type'=>'animation','label'=>'Animation'],
            ['id'=>'custom_class','type'=>'text','label'=>'Custom Class','default'=>''],
            ['id'=>'custom_id','type'=>'text','label'=>'Custom ID','default'=>''],
            ['id'=>'custom_css','type'=>'textarea','label'=>'Custom CSS','default'=>''],
        ];

        $specific = [
            'category-grid' => [
                ['id'=>'columns','type'=>'responsive','label'=>'Columns','default'=>['desktop'=>4,'tablet'=>3,'mobile'=>2]],
                ['id'=>'gap','type'=>'responsive','label'=>'Gap','default'=>['desktop'=>'24px','tablet'=>'18px','mobile'=>'12px']],
            ],
            'category-products' => [
                ['id'=>'layout','type'=>'select','label'=>'Layout','options'=>['grid'=>'Grid','list'=>'List'],'default'=>'grid'],
                ['id'=>'columns','type'=>'responsive','label'=>'Columns','default'=>['desktop'=>4,'tablet'=>3,'mobile'=>2]],
                ['id'=>'limit','type'=>'number','label'=>'Products Per Page','default'=>24,'min'=>1,'max'=>100],
            ],
            'product-filter' => [
                ['id'=>'style','type'=>'select','label'=>'Style','options'=>['sidebar'=>'Sidebar','drawer'=>'Drawer','inline'=>'Inline'],'default'=>'sidebar'],
                ['id'=>'ajax','type'=>'toggle','label'=>'AJAX Filtering','default'=>true],
            ],
            'product-sort' => [
                ['id'=>'show_label','type'=>'toggle','label'=>'Show Label','default'=>true],
                ['id'=>'style','type'=>'select','label'=>'Style','options'=>['select'=>'Select','buttons'=>'Buttons'],'default'=>'select'],
            ],
            'product-pagination' => [
                ['id'=>'style','type'=>'select','label'=>'Style','options'=>['numbers'=>'Numbers','load_more'=>'Load More','infinite'=>'Infinite Scroll'],'default'=>'numbers'],
            ],
            'search-results' => [
                ['id'=>'layout','type'=>'select','label'=>'Layout','options'=>['grid'=>'Grid','list'=>'List'],'default'=>'grid'],
                ['id'=>'columns','type'=>'responsive','label'=>'Columns','default'=>['desktop'=>4,'tablet'=>3,'mobile'=>2]],
            ],
            'search-suggestions' => [
                ['id'=>'minimum_chars','type'=>'number','label'=>'Minimum Characters','default'=>2,'min'=>1,'max'=>10],
                ['id'=>'limit','type'=>'number','label'=>'Suggestion Limit','default'=>8,'min'=>1,'max'=>20],
            ],
            'manufacturer-products' => [
                ['id'=>'columns','type'=>'responsive','label'=>'Columns','default'=>['desktop'=>4,'tablet'=>3,'mobile'=>2]],
                ['id'=>'limit','type'=>'number','label'=>'Products Per Page','default'=>24,'min'=>1,'max'=>100],
            ],
        ]
        ;
        return array_merge($common, $specific[$id] ?? []);
    }
}
