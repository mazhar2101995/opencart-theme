<?php
class NextGenUpdateOrchestrator {
    public function plan(array $package, array $state=array()) {
        return array(
            'status'=>'planned',
            'steps'=>array(
                'acquire_lock',
                'validate_package',
                'create_backup',
                'stage_files',
                'apply_migrations',
                'atomic_switch',
                'refresh_cache',
                'run_smoke_tests',
                'verify',
                'release_lock'
            ),
            'automatic_rollback_on_failure'=>true
        );
    }

    public function failureResult($reason) {
        return array(
            'status'=>'failed',
            'reason'=>$reason,
            'rollback'=>'required',
            'storefront_publish'=>'blocked'
        );
    }
}
