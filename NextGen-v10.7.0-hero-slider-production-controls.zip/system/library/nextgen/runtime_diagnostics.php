<?php
class NextGenRuntimeDiagnostics {
    public function inspect(array $result) {
        return array(
            'status'=>isset($result['status'])?$result['status']:'unknown',
            'stage'=>isset($result['runtime_stage'])?$result['runtime_stage']:null,
            'has_html'=>isset($result['html']) && trim($result['html'])!=='',
            'has_document'=>isset($result['document']) && is_array($result['document']),
            'asset_count'=>$this->assetCount(isset($result['assets'])?$result['assets']:array()),
            'error'=>isset($result['runtime_error'])?$result['runtime_error']:null
        );
    }

    private function assetCount($assets) {
        $count=0;
        foreach(array('css','js','preload') as $key) {
            if(isset($assets[$key]) && is_array($assets[$key])) $count+=count($assets[$key]);
        }
        return $count;
    }
}
