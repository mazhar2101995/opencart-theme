<?php
class NextGenTrialManager {
    public function start($package,$installationId,$days=15) {
        return array(
            'action'=>'trial_start',
            'package'=>$package,
            'installation_id'=>$installationId,
            'requested_days'=>max(1,(int)$days)
        );
    }

    public function canStart(array $state) {
        return empty($state['trial_used']) && empty($state['active']);
    }
}
