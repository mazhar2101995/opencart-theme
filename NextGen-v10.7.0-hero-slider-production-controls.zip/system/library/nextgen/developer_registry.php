<?php
/**
 * Runtime developer registry facade.
 */
class NextGenDeveloperRegistry {
    private static $api;

    public static function boot($registry = null) {
        if (!self::$api) {
            require_once(DIR_SYSTEM . 'library/nextgen/developer_api.php');
            self::$api = new NextGenDeveloperApi($registry);
        }
        return self::$api;
    }

    public static function api() {
        return self::$api;
    }
}
