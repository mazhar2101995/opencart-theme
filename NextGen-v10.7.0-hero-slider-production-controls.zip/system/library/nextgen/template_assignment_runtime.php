<?php
class NextGenTemplateAssignmentRuntime {
    public function resolve(array $assignments,array $context=array()) {
        $matches=array();
        foreach($assignments as $assignment) {
            if(!is_array($assignment) || empty($assignment['enabled'])) continue;
            if(isset($assignment['route']) && $assignment['route']!=='' &&
               isset($context['route']) && $assignment['route']!==$context['route']) continue;
            if(isset($assignment['template_type']) && $assignment['template_type']!=='' &&
               isset($context['template_type']) && $assignment['template_type']!==$context['template_type']) continue;
            if(isset($assignment['store_id']) && (int)$assignment['store_id']!==(int)(isset($context['store_id'])?$context['store_id']:0)) continue;
            if(isset($assignment['language_id']) && (int)$assignment['language_id']!==(int)(isset($context['language_id'])?$context['language_id']:0)) continue;
            $matches[]=$assignment;
        }

        usort($matches,function($a,$b){
            return (int)(isset($b['priority'])?$b['priority']:0) <=> (int)(isset($a['priority'])?$a['priority']:0);
        });

        return $matches ? $matches[0] : null;
    }
}
