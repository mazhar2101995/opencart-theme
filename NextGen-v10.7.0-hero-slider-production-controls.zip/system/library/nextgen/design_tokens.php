<?php
/**
 * NextGen Design Token System v2.6
 */
class NextGenDesignTokens {
    private $tokens = array();

    public function set($key, $value) {
        if (!$this->validKey($key)) return false;
        $this->tokens[$key] = $value;
        return true;
    }

    public function get($key, $fallback = null) {
        return array_key_exists($key, $this->tokens) ? $this->tokens[$key] : $fallback;
    }

    public function all() {
        return $this->tokens;
    }

    public function cssVariables() {
        $css = ':root{';
        foreach ($this->tokens as $key => $value) {
            if (is_scalar($value)) {
                $css .= '--' . $key . ':' . htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8') . ';';
            }
        }
        return $css . '}';
    }

    private function validKey($key) {
        return is_string($key) && preg_match('/^[a-z0-9][a-z0-9_-]*$/', $key);
    }
}
