<?php
class NextGenTemplateRuntimeResolver {
    private $assignmentEvaluator;
    private $documentResolver;

    public function __construct($assignmentEvaluator=null,$documentResolver=null) {
        $this->assignmentEvaluator=$assignmentEvaluator;
        $this->documentResolver=$documentResolver;
    }

    public function resolve(array $templates,array $context=array()) {
        if(!$this->assignmentEvaluator || !$this->documentResolver) {
            return array('status'=>'not_configured','document'=>null,'template'=>null);
        }

        $matches=array();

        foreach($templates as $template) {
            if(!is_array($template)) continue;

            $match=false;

            if(method_exists($this->assignmentEvaluator,'matches')) {
                $match=$this->assignmentEvaluator->matches($template,$context);
            } else {
                $match=$this->basicMatch($template,$context);
            }

            if($match) $matches[]=$template;
        }

        usort($matches,function($a,$b){
            return (int)(isset($b['priority'])?$b['priority']:0) -
                   (int)(isset($a['priority'])?$a['priority']:0);
        });

        if(!$matches) {
            return array('status'=>'not_found','document'=>null,'template'=>null);
        }

        foreach($matches as $template) {
            $result=$this->documentResolver->resolve($template,$context);
            if($result['status']==='ok') {
                return array(
                    'status'=>'ok',
                    'template'=>$template,
                    'document'=>$result['document']
                );
            }
        }

        return array('status'=>'not_published','document'=>null,'template'=>$matches[0]);
    }

    private function basicMatch(array $template,array $context) {
        if(isset($template['route']) && $template['route']!=='' &&
           $template['route']!==$context['route']) return false;

        if(isset($template['template_type']) && $template['template_type']!=='' &&
           $template['template_type']!==$context['template_type']) return false;

        if(isset($template['store_id']) && (int)$template['store_id']!==(int)$context['store_id']) return false;

        if(isset($template['language_id']) && (int)$template['language_id']!==(int)$context['language_id']) return false;

        return true;
    }
}
