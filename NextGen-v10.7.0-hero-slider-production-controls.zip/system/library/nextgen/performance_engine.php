<?php
/**
 * NextGen Theme Performance Engine v2.2
 * Conservative frontend performance helpers.
 */
class NextGenPerformanceEngine {
    public static function imageAttributes(array $image, array $options = array()) {
        $src = isset($image['src']) ? $image['src'] : '';
        $alt = isset($image['alt']) ? $image['alt'] : '';
        $attrs = array(
            'src' => $src,
            'alt' => $alt,
            'loading' => !empty($options['eager']) ? 'eager' : 'lazy',
            'decoding' => 'async'
        );

        if (!empty($image['width'])) $attrs['width'] = (int)$image['width'];
        if (!empty($image['height'])) $attrs['height'] = (int)$image['height'];
        if (!empty($image['srcset'])) $attrs['srcset'] = $image['srcset'];
        if (!empty($image['sizes'])) $attrs['sizes'] = $image['sizes'];

        return $attrs;
    }

    public static function preload(array $resources) {
        $html = '';
        foreach ($resources as $resource) {
            if (empty($resource['href'])) continue;
            $href = htmlspecialchars($resource['href'], ENT_QUOTES, 'UTF-8');
            $as = !empty($resource['as']) ? $resource['as'] : 'fetch';
            $type = !empty($resource['type'])
                ? ' type="' . htmlspecialchars($resource['type'], ENT_QUOTES, 'UTF-8') . '"'
                : '';
            $html .= '<link rel="preload" href="' . $href . '" as="' . $as . '"' . $type . '>' . "\n";
        }
        return $html;
    }

    public static function cacheKey(array $context) {
        return 'nextgen_perf_' . sha1(json_encode(array(
            'route' => isset($context['route']) ? $context['route'] : '',
            'store_id' => isset($context['store_id']) ? $context['store_id'] : 0,
            'language_id' => isset($context['language_id']) ? $context['language_id'] : 0,
            'document_version' => isset($context['document_version']) ? $context['document_version'] : 0,
            'device' => isset($context['device']) ? $context['device'] : 'desktop'
        )));
    }
}
