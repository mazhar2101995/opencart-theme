<?php
// Integration helper for the existing NextGen widget registry.
// Include this file from the central registry bootstrap.
// It intentionally does not modify OpenCart controllers via OCMOD/VQMOD.
function nextgen_register_product_page_widgets(&$registry) {
    if (!class_exists('NextGenProductPageSchema')) {
        require_once DIR_SYSTEM . 'library/nextgen/product_page_schema.php';
    }
    foreach (NextGenProductPageSchema::widgets() as $id => $definition) {
        $registry[$id] = $definition;
        $registry[$id]['controls'] = NextGenProductPageSchema::controls($id);
    }
}
