<?php
/**
 * Release validation for NextGen theme packages.
 */
class NextGenReleaseValidator {
    public static function validate(array $packageFiles) {
        $required = array(
            'README.md',
            'docs/CHANGELOG-v2.4.0.md',
            'docs/87-testing-release-quality-v2.4.md'
        );

        $missing = array();
        foreach ($required as $file) {
            if (!in_array($file, $packageFiles, true)) $missing[] = $file;
        }

        return array(
            'passed' => empty($missing),
            'missing' => $missing,
            'file_count' => count($packageFiles)
        );
    }
}
