<?php
class NextGenRuntimeRenderer {
    public function renderDocument(array $document,array $context=array()) {
        if (empty($document['root']) || !is_array($document['root'])) {
            return array('status'=>'failed','runtime_error'=>'Invalid builder document root.');
        }

        return array(
            'status'=>'ok',
            'document'=>$document,
            'context'=>$context,
            'html'=>'',
            'assets'=>array('css'=>array(),'js'=>array(),'preload'=>array())
        );
    }

    public function renderWidget(array $node,array $context=array()) {
        if (empty($node['type'])) {
            return array('status'=>'failed','runtime_error'=>'Widget type missing.');
        }

        return array(
            'status'=>'ok',
            'widget_type'=>$node['type'],
            'html'=>'',
            'assets'=>array('css'=>array(),'js'=>array())
        );
    }
}
