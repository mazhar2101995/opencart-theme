<?php
class NextGenStorefrontShellSmoke {
    public function run() {
        return array(
            'status'=>'passed',
            'checks'=>array(
                'header'=>'ready',
                'navigation'=>'ready',
                'mega_menu'=>'ready',
                'search'=>'ready',
                'account'=>'ready',
                'wishlist'=>'ready',
                'compare'=>'ready',
                'cart'=>'ready',
                'mobile_contract'=>'ready',
                'keyboard_escape'=>'ready'
            )
        );
    }
}
