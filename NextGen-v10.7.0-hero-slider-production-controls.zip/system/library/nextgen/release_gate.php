<?php
class NextGenReleaseGate {
    public function evaluate(array $checks) {
        $failed=array();
        foreach($checks as $name=>$result) {
            if(is_array($result) && isset($result['status']) && $result['status']==='failed') $failed[]=$name;
            elseif($result===false) $failed[]=$name;
        }

        return array(
            'status'=>$failed?'failed':'passed',
            'failed'=>$failed,
            'ready'=>!$failed
        );
    }
}
