<?php
/**
 * NextGen Interaction Engine v2.8
 * Declarative frontend interaction definitions.
 */
class NextGenInteractionEngine {
    public static function normalize(array $definition) {
        $defaults = array(
            'trigger' => 'click',
            'target' => '',
            'animation' => 'fade',
            'duration' => 250,
            'delay' => 0,
            'once' => false,
            'close_on_escape' => true,
            'close_on_outside' => true,
            'prevent_scroll' => false
        );

        return array_merge($defaults, $definition);
    }

    public static function validTrigger($trigger) {
        return in_array($trigger, array(
            'click',
            'hover',
            'focus',
            'scroll',
            'load',
            'exit_intent'
        ), true);
    }
}
