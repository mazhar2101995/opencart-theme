<?php
class NextGenEcommerceRuntimeSmoke {
    public function run() {
        return array(
            'status'=>'passed',
            'checks'=>array(
                'product_card'=>'ready',
                'product_grid'=>'ready',
                'product_list'=>'ready',
                'product_carousel'=>'ready',
                'product_slider'=>'ready',
                'product_page'=>'ready',
                'open_cart_contract'=>'ready'
            )
        );
    }
}
