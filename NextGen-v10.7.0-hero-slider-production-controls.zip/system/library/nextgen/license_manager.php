<?php
class NextGenLicenseManager {
    public function activationPayload($package,$version,$domain,$installationId) {
        return array(
            'package'=>$package,
            'version'=>$version,
            'domain'=>$domain,
            'installation_id'=>$installationId,
            'timestamp'=>time()
        );
    }

    public function validateResponse(array $response) {
        if (empty($response['status'])) {
            return array('valid'=>false,'error'=>'License response is missing status.');
        }

        $allowed=array('active','trial','expired','suspended','revoked');
        if (!in_array($response['status'],$allowed,true)) {
            return array('valid'=>false,'error'=>'Unknown license status.');
        }

        return array(
            'valid'=>in_array($response['status'],array('active','trial'),true),
            'status'=>$response['status']
        );
    }
}
