<?php
require_once(DIR_SYSTEM . 'library/nextgen/media_url.php');

class NextGenEcommerceWidgetRenderers {
    private $adapter;
    private function imageUrl($value) { return NextGenMediaUrl::url($value); }


    public function __construct($adapter=null) {
        $this->adapter=$adapter ?: new NextGenOpenCartProductAdapter();
    }

    public function register($registry) {
        $self=$this;

        $registry->registerWidget('product_card',function($node,$context) use ($self){
            return $self->productCard($node,$context);
        });

        $registry->registerWidget('product_grid',function($node,$context) use ($self){
            return $self->productGrid($node,$context);
        });

        $registry->registerWidget('product_list',function($node,$context) use ($self){
            return $self->productList($node,$context);
        });

        $registry->registerWidget('product_carousel',function($node,$context) use ($self){
            return $self->productCarousel($node,$context);
        });
    }

    private function value($node,$key,$default=null) {
        if(isset($node['settings'][$key])) return $node['settings'][$key];
        if(isset($node['content'][$key])) return $node['content'][$key];
        return $default;
    }

    private function products($node,$context) {
        $products=array();
        if(isset($node['products']) && is_array($node['products'])) {
            $products=$node['products'];
        } elseif(isset($context['products']) && is_array($context['products'])) {
            $products=$context['products'];
        }
        $limit=(int)$this->value($node,'limit',0);
        if($limit>0) $products=array_slice($products,0,$limit);
        return $this->adapter->normalizeList($products,$context);
    }

    public function productCard($node,$context=array()) {
        $p=$this->adapter->normalize(
            isset($node['product']) && is_array($node['product']) ? $node['product'] : array(),
            $context
        );

        $name=htmlspecialchars($p['name'],ENT_QUOTES,'UTF-8');
        $href=htmlspecialchars($p['href'],ENT_QUOTES,'UTF-8');
        $image=htmlspecialchars($this->imageUrl($p['image']),ENT_QUOTES,'UTF-8'); $hoverImage=htmlspecialchars($this->imageUrl((string)$this->value($node,'hoverImage','')),ENT_QUOTES,'UTF-8'); if(!$hoverImage && !empty($p['additional_images'][0])) $hoverImage=htmlspecialchars((string)$p['additional_images'][0],ENT_QUOTES,'UTF-8');

        $showImage=$this->value($node,'showImage',true)!==false; $showBrand=$this->value($node,'showBrand',true)!==false; $showRating=$this->value($node,'showRating',true)!==false; $showPrice=$this->value($node,'showPrice',true)!==false; $showActions=$this->value($node,'showActions',true)!==false; $html='<article class="ng-product-card" data-product-id="'.(int)$p['product_id'].'">';
        if($image && $showImage) {
            $html.='<a class="ng-product-card-media" href="'.$href.'"><img class="ng-product-image-primary" src="'.$image.'" alt="'.$name.'" loading="lazy">'.($hoverImage && $this->value($node,'showHoverImage',false)?'<img class="ng-product-image-hover" src="'.$hoverImage.'" alt="" loading="lazy">':'').'</a>';
        }
        $html.='<div class="ng-product-card-body">';
        if($p['manufacturer'] && $showBrand) $html.='<div class="ng-product-card-brand">'.htmlspecialchars($p['manufacturer'],ENT_QUOTES,'UTF-8').'</div>';
        $html.='<h3 class="ng-product-card-title"><a href="'.$href.'">'.$name.'</a></h3>';

        if($showRating && $p['rating']>0) {
            $html.='<div class="ng-product-card-rating" aria-label="Rating '.(float)$p['rating'].' out of 5">';
            $html.=str_repeat('★',(int)round($p['rating']));
            $html.='</div>';
        }

        if($showPrice) { $html.='<div class="ng-product-card-price">';
            if($p['special']!==null) {
                $html.='<del>'.htmlspecialchars((string)$p['price'],ENT_QUOTES,'UTF-8').'</del> ';
                $html.='<strong>'.htmlspecialchars((string)$p['special'],ENT_QUOTES,'UTF-8').'</strong>';
            } else {
                $html.='<strong>'.htmlspecialchars((string)$p['price'],ENT_QUOTES,'UTF-8').'</strong>';
            }
            $html.='</div>'; }
        if($showActions) $html.='<button type="button" class="ng-product-add-cart" data-product-id="'.(int)$p['product_id'].'">Add to Cart</button>';
        $html.='</div></article>';

        return $html;
    }

    public function productGrid($node,$context=array()) {
        $products=$this->products($node,$context);
        $columns=(int)$this->value($node,'columns',4);
        $columns=max(1,min($columns,8));

        $gap=(int)$this->value($node,'gap',22);$tablet=(int)$this->value($node,'columnsTablet',3);$mobile=(int)$this->value($node,'columnsMobile',2);$html='<div class="ng-product-grid ng-product-grid-cols-'.$columns.'" style="--ng-grid-gap:'.$gap.'px;--ng-grid-tablet:'.$tablet.';--ng-grid-mobile:'.$mobile.';">';
        foreach($products as $p) {
            $html.=$this->productCard(array('product'=>$p),$context);
        }
        return $html.'</div>';
    }

    public function productList($node,$context=array()) {
        $products=$this->products($node,$context);
        $html='<div class="ng-product-list">';
        foreach($products as $p) {
            $html.=$this->productCard(array('product'=>$p),$context);
        }
        return $html.'</div>';
    }

    public function productCarousel($node,$context=array()) {
        $products=$this->products($node,$context);
        $html='<div class="ng-product-carousel" data-ng-carousel="1"><div class="ng-product-carousel__track">';
        foreach($products as $p) {
            $html.='<div class="ng-product-carousel-item">';
            $html.=$this->productCard(array('product'=>$p),$context);
            $html.='</div>';
        }
        return $html.'</div></div>';
    }
}
