<?php
class NextGenRuntimeRegistry {
    private $widgets=array();
    private $providers=array();

    public function registerWidget($type,$renderer) {
        $this->widgets[$type]=$renderer;
    }

    public function registerProvider($key,$provider) {
        $this->providers[$key]=$provider;
    }

    public function hasWidget($type) {
        return isset($this->widgets[$type]);
    }

    public function getWidget($type) {
        return isset($this->widgets[$type]) ? $this->widgets[$type] : null;
    }

    public function getProvider($key) {
        return isset($this->providers[$key]) ? $this->providers[$key] : null;
    }
}
