<?php
class NextGenLicenseLifecycle {
    public function actions() {
        return array(
            'activate',
            'deactivate',
            'renew',
            'refresh',
            'transfer',
            'trial_start',
            'trial_extend'
        );
    }

    public function allowedTransition($current,$action) {
        $map=array(
            'trial'=>array('renew','refresh','deactivate','trial_extend'),
            'active'=>array('renew','refresh','deactivate','transfer'),
            'expired'=>array('renew','refresh','activate'),
            'suspended'=>array('refresh','renew'),
            'revoked'=>array('refresh')
        );

        return isset($map[$current]) && in_array($action,$map[$current],true);
    }
}
