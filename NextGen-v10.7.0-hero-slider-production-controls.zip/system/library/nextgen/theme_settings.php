<?php
/**
 * NextGen Global Theme Settings v2.6
 */
class NextGenThemeSettings {
    private $config;
    private $settings = array();

    public function __construct($config = null) {
        $this->config = $config;
    }

    public function set($key, $value) {
        if (!is_string($key) || $key === '') return false;
        $this->settings[$key] = $value;
        return true;
    }

    public function get($key, $fallback = null) {
        return array_key_exists($key, $this->settings)
            ? $this->settings[$key]
            : $fallback;
    }

    public function all() {
        return $this->settings;
    }
}
