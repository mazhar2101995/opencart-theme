<?php
class NextGenCriticalCss {
    public static function inline($css) {
        if (!is_string($css) || $css === '') return '';
        // Conservative sanitization: this is intended for trusted theme CSS only.
        return '<style data-nextgen-critical-css>' . $css . '</style>';
    }

    public static function preloadNonCritical($href) {
        if (!$href) return '';
        $href = htmlspecialchars($href, ENT_QUOTES, 'UTF-8');
        return '<link rel="preload" href="' . $href . '" as="style" onload="this.onload=null;this.rel=\'stylesheet\'">'
            . '<noscript><link rel="stylesheet" href="' . $href . '"></noscript>';
    }
}
