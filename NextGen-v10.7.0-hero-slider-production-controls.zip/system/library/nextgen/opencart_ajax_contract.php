<?php
class NextGenOpenCartAjaxContract {
    public function endpoint($route) {
        return 'index.php?route='.rawurlencode($route);
    }

    public function addToCart($productId,$quantity=1,array $options=array()) {
        $data=array(
            'product_id'=>(int)$productId,
            'quantity'=>max(1,(int)$quantity)
        );

        foreach($options as $key=>$value) {
            $data['option['.(int)$key.']']=$value;
        }

        return array(
            'url'=>$this->endpoint('checkout/cart/add'),
            'method'=>'POST',
            'data'=>$data
        );
    }

    public function wishlist($productId) {
        return array(
            'url'=>$this->endpoint('account/wishlist/add'),
            'method'=>'POST',
            'data'=>array('product_id'=>(int)$productId)
        );
    }

    public function compare($productId) {
        return array(
            'url'=>$this->endpoint('product/compare/add'),
            'method'=>'POST',
            'data'=>array('product_id'=>(int)$productId)
        );
    }

    public function quickView($productId) {
        return array(
            'url'=>$this->endpoint('product/product/quickview'),
            'method'=>'GET',
            'data'=>array('product_id'=>(int)$productId)
        );
    }
}
