<?php
class NextGenProductionWidgetPipeline {
    protected $renderer;
    protected $responsive;
    protected $assets;

    public function __construct($renderer,$responsive,$assets) {
        $this->renderer=$renderer;
        $this->responsive=$responsive;
        $this->assets=$assets;
    }

    public function execute(array $document,array $context=array()) {
        $device=isset($context['device'])?$context['device']:'desktop';
        $resolved=$this->resolveNode($document,$device);
        $assetSet=$this->assets->collectForDocument($resolved);

        return array(
            'html'=>$this->renderer->render($resolved,$context),
            'assets'=>$this->assets->normalize($assetSet),
            'device'=>$device
        );
    }

    protected function resolveNode($node,$device) {
        if(!is_array($node)) return $node;
        if(isset($node['settings']) && is_array($node['settings'])) {
            $node['settings']=$this->responsive->resolve($node['settings'],$device);
        }
        if(isset($node['children']) && is_array($node['children'])) {
            foreach($node['children'] as $i=>$child) $node['children'][$i]=$this->resolveNode($child,$device);
        }
        return $node;
    }
}
