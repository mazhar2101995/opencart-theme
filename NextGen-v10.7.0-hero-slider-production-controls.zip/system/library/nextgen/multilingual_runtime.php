<?php
class NextGenMultilingualRuntime {
    public function languageContext($languageId,$code,$locale='') {
        return array(
            'language_id'=>(int)$languageId,
            'code'=>(string)$code,
            'locale'=>(string)$locale
        );
    }

    public function field(array $values,$languageId,$fallbackLanguageId=0) {
        if(isset($values[$languageId])) return $values[$languageId];
        if($fallbackLanguageId && isset($values[$fallbackLanguageId])) return $values[$fallbackLanguageId];
        return '';
    }

    public function hreflang(array $urls) {
        $result=array();
        foreach($urls as $code=>$url) {
            if($url==='') continue;
            $result[]=array('code'=>$code,'url'=>$url);
        }
        return $result;
    }
}
