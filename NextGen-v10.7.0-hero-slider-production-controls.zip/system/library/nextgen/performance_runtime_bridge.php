<?php
class NextGenPerformanceRuntimeBridge {
    private $engine;
    public function __construct($engine) { $this->engine=$engine; }

    public function image(array $image=array()) {
        if(!$this->engine || !method_exists($this->engine,'imageAttributes')) return $image;
        return array_merge($image,$this->engine->imageAttributes($image));
    }

    public function preload($url,$as='image') {
        if(!$this->engine || !method_exists($this->engine,'preload')) return array('url'=>$url,'as'=>$as);
        return $this->engine->preload($url,$as);
    }
}
