<?php
class NextGenFinalQaRunner {
    public function run(array $checks=array()) {
        $results=array();
        foreach($checks as $name=>$callback) {
            try {
                $results[$name]=is_callable($callback)?$callback():array('status'=>'passed');
            } catch(Exception $e) {
                $results[$name]=array('status'=>'failed','error'=>$e->getMessage());
            }
        }

        $failed=array();
        foreach($results as $name=>$result) {
            if(is_array($result) && isset($result['status']) && $result['status']==='failed') $failed[]=$name;
        }

        return array(
            'status'=>$failed?'failed':'passed',
            'results'=>$results,
            'failed'=>$failed
        );
    }
}
