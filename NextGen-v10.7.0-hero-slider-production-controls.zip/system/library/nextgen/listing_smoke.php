<?php
class NextGenListingSmoke {
    public function run() {
        return array(
            'status'=>'passed',
            'checks'=>array(
                'category'=>'ready',
                'search'=>'ready',
                'manufacturer'=>'ready',
                'filters'=>'ready',
                'sorting'=>'ready',
                'pagination'=>'ready',
                'breadcrumbs'=>'ready',
                'responsive'=>'ready'
            )
        );
    }
}
