<?php
class NextGenFrontendRenderCache {
    private $cache;

    public function __construct($cache = null) {
        $this->cache = $cache;
    }

    public function key($route, $store_id, $language_id, $document_version, array $context = []) {
        return 'nextgen.page.' . sha1(json_encode([
            'route' => $route,
            'store' => (int)$store_id,
            'language' => (int)$language_id,
            'document_version' => (int)$document_version,
            'context' => $context
        ]));
    }

    public function get($key) {
        if (!$this->cache || !method_exists($this->cache, 'get')) return false;
        return $this->cache->get($key);
    }

    public function set($key, $value, $expire = 3600) {
        if (!$this->cache || !method_exists($this->cache, 'set')) return false;
        return $this->cache->set($key, $value, $expire);
    }
}
