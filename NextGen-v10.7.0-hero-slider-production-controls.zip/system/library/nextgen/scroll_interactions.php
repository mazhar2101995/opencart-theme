<?php
class NextGenScrollInteractions {
    public static function normalize(array $options = array()) {
        return array(
            'animation' => isset($options['animation']) ? $options['animation'] : 'fade-up',
            'duration' => isset($options['duration']) ? (int)$options['duration'] : 500,
            'delay' => isset($options['delay']) ? (int)$options['delay'] : 0,
            'threshold' => isset($options['threshold']) ? (float)$options['threshold'] : 0.15,
            'once' => isset($options['once']) ? (bool)$options['once'] : true,
            'distance' => isset($options['distance']) ? $options['distance'] : '24px'
        );
    }
}
