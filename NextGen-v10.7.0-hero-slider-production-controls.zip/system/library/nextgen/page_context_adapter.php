<?php
class NextGenPageContextAdapter {
    public function build($route,array $data=array()) {
        $type=$this->typeForRoute($route);

        return array(
            'route'=>$route,
            'template_type'=>$type,
            'store_id'=>isset($data['store_id'])?(int)$data['store_id']:0,
            'language_id'=>isset($data['language_id'])?(int)$data['language_id']:0,
            'device'=>isset($data['device'])?$data['device']:'desktop',
            'product'=>isset($data['product'])?$data['product']:null,
            'products'=>isset($data['products'])?$data['products']:array(),
            'category'=>isset($data['category'])?$data['category']:null,
            'search'=>isset($data['search'])?$data['search']:array(),
            'header'=>isset($data['header'])?$data['header']:array(),
            'footer'=>isset($data['footer'])?$data['footer']:array()
        );
    }

    public function typeForRoute($route) {
        $map=array(
            'common/home'=>'homepage',
            'product/product'=>'product',
            'product/category'=>'category',
            'product/search'=>'search',
            'product/manufacturer'=>'manufacturer',
            'common/header'=>'header',
            'common/footer'=>'footer'
        );
        return isset($map[$route])?$map[$route]:'custom';
    }
}
