<?php
class NextGenGlobalStorefrontRuntime {
    public function normalize(array $data=array()) {
        return array(
            'announcement'=>isset($data['announcement'])&&is_array($data['announcement'])?$data['announcement']:array(),
            'footer'=>isset($data['footer'])&&is_array($data['footer'])?$data['footer']:array(),
            'newsletter'=>isset($data['newsletter'])&&is_array($data['newsletter'])?$data['newsletter']:array(),
            'social'=>isset($data['social'])&&is_array($data['social'])?$data['social']:array(),
            'payments'=>isset($data['payments'])&&is_array($data['payments'])?$data['payments']:array(),
            'trust_badges'=>isset($data['trust_badges'])&&is_array($data['trust_badges'])?$data['trust_badges']:array()
        );
    }
}
