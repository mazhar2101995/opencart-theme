<?php
class NextGenRuntimeAssets {
    private $css=array();
    private $js=array();
    private $preload=array();

    public function addCss($url) {
        if ($url) $this->css[$url]=true;
    }

    public function addJs($url) {
        if ($url) $this->js[$url]=true;
    }

    public function addPreload($url,$as='') {
        if ($url) $this->preload[$url]=array('url'=>$url,'as'=>$as);
    }

    public function output() {
        return array(
            'css'=>array_keys($this->css),
            'js'=>array_keys($this->js),
            'preload'=>array_values($this->preload)
        );
    }
}
