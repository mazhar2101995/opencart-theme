<?php
/**
 * NextGen Theme Engine v6.5
 * Contextual widget control metadata.
 * The browser editor may render these controls client-side; this class is intentionally
 * provider-neutral so custom widgets can register the same control vocabulary.
 */
class NextGenWidgetControlEngine {
    public function schema() {
        return array(
            'content'=>array('text','textarea','richtext','url','select','toggle','number','repeater','dynamic'),
            'media'=>array('image','gallery','video','icon','svg','image_position','image_fit'),
            'layout'=>array('display','width','height','minWidth','maxWidth','minHeight','margin','padding','gap','position','zIndex','overflow','columns','alignment'),
            'typography'=>array('fontFamily','fontSize','fontWeight','lineHeight','letterSpacing','wordSpacing','textTransform','textAlign','direction','fontStyle','textDecoration','color','textShadow','textShadowColor','textShadowX','textShadowY','textShadowBlur','textStrokeWidth','textStrokeColor'),
            'background'=>array('backgroundColor','backgroundImage','backgroundPosition','backgroundSize','backgroundRepeat','gradient','overlay','videoBackground'),
            'border'=>array('borderWidth','borderStyle','borderColor','radius'),
            'effects'=>array('shadow','opacity','transform','transition','filter','blendMode'),
            'responsive'=>array('desktop','tablet','mobile','visibility'),
            'states'=>array('normal','hover','focus','active','sticky'),
            'motion'=>array('entrance','duration','delay','easing','scrollReveal','parallax'),
            'advanced'=>array('cssClass','cssId','customAttributes','customCss','visibility','conditions','customData'),
            'interaction'=>array('link','lightbox','popup','tooltip','scrollTo','cursor'),
            'structure'=>array('childSlots','allowedChildren','maxDepth','repeaters','globalWidget')
        );
    }

    public function widgetProfiles() {
        return array(
            'heading'=>array('content'=>array('text','tag','align'),'style'=>array('typography','color','spacing')),
            'text'=>array('content'=>array('richtext'),'style'=>array('typography','color','spacing')),
            'button'=>array('content'=>array('text','url','target','icon','iconPosition'),'style'=>array('typography','colors','border','shadow','spacing'),'interaction'=>array('link','hover')),
            'image'=>array('content'=>array('image','alt','caption','link'),'style'=>array('fit','position','width','height','radius','overlay'),'interaction'=>array('lightbox','hover','link'),'responsive'=>array('desktop','tablet','mobile')),
            'icon'=>array('content'=>array('icon','svg'),'style'=>array('size','color','spacing')),
            'icon_box'=>array('content'=>array('icon','title','text','link'),'style'=>array('icon','typography','colors','spacing')),
            'gallery'=>array('content'=>array('repeater'),'layout'=>array('columns','gap'),'style'=>array('image','overlay')),
            'image_carousel'=>array('content'=>array('repeater','autoplay','loop','arrows','dots'),'layout'=>array('columns','gap')),
            'hero'=>array('content'=>array('eyebrow','heading','text','button','url','image'),'background'=>array('image','overlay','overlayOpacity','position','size','repeat','color'),'typography'=>array('heading','body','button'),'layout'=>array('height','minHeight','alignment','contentPosition','contentMaxWidth','contentPadding','contentGap','textAlign'),'responsive'=>array('desktop','tablet','mobile'),'advanced'=>array('cssClass','cssId','customAttributes','customCss')), 
            'hero_slider'=>array('content'=>array('slidesRepeater'),'background'=>array('image','overlay','position','size'),'typography'=>array('heading','body','button'),'layout'=>array('height','contentPosition'),'interaction'=>array('autoplay','interval','arrows','dots','swipe','pauseOnHover','loop'),'responsive'=>array('desktop','tablet','mobile')),
            'products'=>array('content'=>array('source','category','products','limit','displayMode','tabs'),'layout'=>array('columns','gap','slidesPerView'),'card'=>array('image','hoverImage','brand','rating','price','actions','wishlist','compare','quickView'),'interaction'=>array('arrows','dots','autoplay','loop'),'responsive'=>array('columns','gap')),
            'product_grid'=>array('content'=>array('source','category','products','limit'),'layout'=>array('columns','gap','cardWidth'),'card'=>array('image','hoverImage','brand','rating','price','badges','actions','wishlist','compare','quickView','quantity'),'responsive'=>array('columns','gap')),
            'product_carousel'=>array('content'=>array('source','category','products','limit'),'layout'=>array('slidesPerView','gap'),'interaction'=>array('arrows','dots','autoplay','loop')),
            'button_group'=>array('content'=>array('repeater'),'layout'=>array('alignment','gap')),
            'video'=>array('content'=>array('video'),'interaction'=>array('autoplay','loop','muted','controls')),
            'section'=>array('structure'=>array('columns','childSlots'),'layout'=>array('container','width','gap','padding','margin','minHeight','alignment','position','zIndex','contentMaxWidth','contentAlign','verticalAlign'),'background'=>array('color','image','overlay','video','gradient','position','size','repeat'),'effects'=>array('shadow','radius','shapeDivider','sticky','stickyOffset','motion'),'responsive'=>array('desktop','tablet','mobile'),'advanced'=>array('cssClass','cssId','customAttributes','customCss','visibility')), 
            'container'=>array('structure'=>array('childSlots'),'layout'=>array('direction','wrap','justify','align','gap')),
            'column'=>array('structure'=>array('childSlots'),'layout'=>array('width','minHeight','alignment','gap'))
        );
    }

    public function profile($type) {
        $profiles=$this->widgetProfiles();
        return isset($profiles[$type]) ? $profiles[$type] : array('content'=>array(),'layout'=>array(),'style'=>array(),'advanced'=>array('cssClass','cssId'));
    }
}
