# Modern Fashion — Journal-inspired reference demo

This demo is designed from the supplied Modern Fashion / Journal-style reference screenshot.

## Scope
- Full editorial fashion homepage structure: utility bar, dark header, hero, category rail, product edit, marquee, sale, editorial stories, inspiration grid, testimonials, blog, newsletter and footer.
- Uses NextGen Builder documents and presentation widgets only.
- Does not modify OpenCart products, customers, orders, stock, checkout, payment or shipping data.

## Asset storage
All demo images are packaged in the OpenCart media directory:

`image/catalog/nextgen/demos/fashion/`

They are intentionally **not** stored in `catalog/view/theme/nextgen/`.

## Import behavior
Importing **Modern Fashion** writes only NextGen builder/runtime state. The image files are already part of the theme package at the OpenCart `image/catalog/nextgen/demos/fashion/` path, so the demo does not depend on external image URLs.

## Note
The visual composition follows the supplied reference screenshot. The demo uses packaged local image assets so it remains self-contained after installation.
