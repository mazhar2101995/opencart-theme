# NextGen v4.0 Demo Storefronts

Five ready-to-import starter storefront documents are included:

1. Electronics Store
2. Fashion Store
3. Yoga Products Store
4. RC Car Store
5. Fruit & Vegetable Market

Each demo is presentation-only. Importing a demo must not alter:
- products
- orders
- customers
- checkout
- payment
- shipping
- stock

The demo document is the starter design. Real product/category data comes from OpenCart at runtime.
