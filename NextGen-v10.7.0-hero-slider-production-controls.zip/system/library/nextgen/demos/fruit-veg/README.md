# Fruit & Vegetable Market

Starter demo for the OpenCart NextGen Theme.

## Included
- Homepage
- Product template
- Category template
- Search template
- Manufacturer template
- Information template
- 404 template
- Global header/footer
- Product card
- Responsive design tokens

## Sections
- announcement
- header
- hero
- categories
- fresh-deals
- featured-products
- quality
- delivery
- newsletter
- footer

This demo is built as editable NextGen builder content, not a separate theme.
