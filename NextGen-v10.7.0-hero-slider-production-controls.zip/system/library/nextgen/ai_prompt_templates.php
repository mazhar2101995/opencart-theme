<?php
class NextGenAiPromptTemplates {
    public static function layout($prompt, array $context = array()) {
        return self::base(
            'Generate a structured page-builder layout using only registered NextGen widgets.',
            $prompt,
            $context
        );
    }

    public static function content($prompt, array $context = array()) {
        return self::base(
            'Generate editable ecommerce/content copy. Do not invent product facts.',
            $prompt,
            $context
        );
    }

    public static function design($prompt, array $context = array()) {
        return self::base(
            'Suggest design tokens, spacing, typography and component styling.',
            $prompt,
            $context
        );
    }

    public static function explain($prompt, array $context = array()) {
        return self::base(
            'Explain how the requested NextGen builder configuration should be implemented.',
            $prompt,
            $context
        );
    }

    private static function base($instruction, $prompt, array $context) {
        return array(
            'system_instruction' => $instruction,
            'user_prompt' => $prompt,
            'context' => $context,
            'constraints' => array(
                'Use only registered widgets.',
                'Do not execute PHP.',
                'Do not bypass permissions.',
                'Do not expose private customer data.',
                'Return editable structured output.',
                'Preserve OpenCart commerce logic.'
            )
        );
    }
}
