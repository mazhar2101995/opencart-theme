<?php
/**
 * NextGen Theme - JSON-LD Structured Data helpers.
 */
class NextGenStructuredData {
    public static function product(array $product) {
        $schema = array(
            '@context' => 'https://schema.org',
            '@type' => 'Product',
            'name' => isset($product['name']) ? $product['name'] : '',
            'url' => isset($product['url']) ? $product['url'] : '',
        );
        foreach (array('image','sku','mpn','brand','description') as $key) {
            if (!empty($product[$key])) $schema[$key] = $product[$key];
        }
        if (isset($product['price']) && $product['price'] !== '') {
            $schema['offers'] = array(
                '@type' => 'Offer',
                'url' => isset($product['url']) ? $product['url'] : '',
                'priceCurrency' => isset($product['currency']) ? $product['currency'] : '',
                'price' => (string)$product['price'],
                'availability' => !empty($product['in_stock'])
                    ? 'https://schema.org/InStock'
                    : 'https://schema.org/OutOfStock'
            );
        }
        if (isset($product['rating']) && $product['rating'] !== '') {
            $schema['aggregateRating'] = array(
                '@type' => 'AggregateRating',
                'ratingValue' => (string)$product['rating'],
                'reviewCount' => isset($product['review_count']) ? (string)$product['review_count'] : '0'
            );
        }
        return $schema;
    }

    public static function organization(array $store) {
        $schema = array(
            '@context' => 'https://schema.org',
            '@type' => 'Organization',
            'name' => isset($store['name']) ? $store['name'] : ''
        );
        foreach (array('url','logo','telephone') as $key) {
            if (!empty($store[$key])) $schema[$key] = $store[$key];
        }
        return $schema;
    }

    public static function breadcrumb(array $items) {
        $list = array();
        $position = 1;
        foreach ($items as $item) {
            if (!is_array($item) || empty($item['name'])) continue;
            $entry = array('@type'=>'ListItem','position'=>$position++,'name'=>$item['name']);
            if (!empty($item['url'])) $entry['item'] = $item['url'];
            $list[] = $entry;
        }
        return array(
            '@context'=>'https://schema.org',
            '@type'=>'BreadcrumbList',
            'itemListElement'=>$list
        );
    }

    public static function article(array $article) {
        return array(
            '@context'=>'https://schema.org',
            '@type'=>'Article',
            'headline'=>isset($article['headline']) ? $article['headline'] : '',
            'description'=>isset($article['description']) ? $article['description'] : '',
            'datePublished'=>isset($article['datePublished']) ? $article['datePublished'] : '',
            'dateModified'=>isset($article['dateModified']) ? $article['dateModified'] : ''
        );
    }

    public static function faq(array $questions) {
        $main = array();
        foreach ($questions as $q) {
            if (!is_array($q) || empty($q['question'])) continue;
            $main[] = array(
                '@type'=>'Question',
                'name'=>$q['question'],
                'acceptedAnswer'=>array(
                    '@type'=>'Answer',
                    'text'=>isset($q['answer']) ? $q['answer'] : ''
                )
            );
        }
        return array(
            '@context'=>'https://schema.org',
            '@type'=>'FAQPage',
            'mainEntity'=>$main
        );
    }

    public static function scriptTags(array $schemas) {
        $html = '';
        foreach ($schemas as $schema) {
            if (!is_array($schema) || empty($schema['@type'])) continue;
            $json = json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
            $html .= '<script type="application/ld+json">' . $json . '</script>' . "\n";
        }
        return $html;
    }
}
