<?php
class NextGenMigrationRunner {
    public function validate(array $migration) {
        return !empty($migration['version']) && !empty($migration['id']);
    }

    public function plan(array $migrations, $currentVersion, $targetVersion) {
        $result=array();
        foreach ($migrations as $migration) {
            if (!$this->validate($migration)) continue;
            if (version_compare($migration['version'],$currentVersion,'>') &&
                version_compare($migration['version'],$targetVersion,'<=')) {
                $result[]=$migration;
            }
        }
        usort($result,function($a,$b){ return version_compare($a['version'],$b['version']); });
        return $result;
    }

    public function executionContract(array $migration) {
        return array(
            'id'=>$migration['id'],
            'version'=>$migration['version'],
            'transaction_required'=>true,
            'backup_required'=>true,
            'reversible'=>!empty($migration['reversible'])
        );
    }
}
