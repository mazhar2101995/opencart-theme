<?php
class NextGenDemoManifest {
    public function validate(array $manifest) {
        foreach (array('slug','name','version','theme','pages','tokens') as $key) {
            if (!isset($manifest[$key])) {
                return array('valid'=>false,'error'=>"Missing demo field: {$key}");
            }
        }

        if (!is_array($manifest['pages']) || !is_array($manifest['tokens'])) {
            return array('valid'=>false,'error'=>'Pages and tokens must be arrays.');
        }

        return array('valid'=>true);
    }
}
