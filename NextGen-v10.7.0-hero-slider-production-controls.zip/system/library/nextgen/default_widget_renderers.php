<?php
require_once(DIR_SYSTEM . 'library/nextgen/media_url.php');

class NextGenDefaultWidgetRenderers {
    private function imageUrl($value) { return NextGenMediaUrl::url($value); }

    public function register($registry,$assets=null) {
        $self=$this;

        $registry->registerWidget('heading',function($node,$context) use ($self) {
            return $self->heading($node);
        });

        $registry->registerWidget('text',function($node,$context) use ($self) {
            return $self->text($node);
        });

        $registry->registerWidget('text_editor',function($node,$context) use ($self) {
            return $self->textEditor($node);
        });

        $registry->registerWidget('button',function($node,$context) use ($self) {
            return $self->button($node);
        });

        $registry->registerWidget('image',function($node,$context) use ($self) {
            return $self->image($node);
        });

        $registry->registerWidget('icon',function($node,$context) use ($self) {
            return $self->icon($node);
        });

        $registry->registerWidget('spacer',function($node,$context) use ($self) {
            return $self->spacer($node);
        });

        $registry->registerWidget('divider',function($node,$context) use ($self) {
            return $self->divider($node);
        });
    }

    private function setting($node,$key,$default='') {
        if (isset($node['settings'][$key])) return $node['settings'][$key];
        if (isset($node['content'][$key])) return $node['content'][$key];
        return $default;
    }

    public function heading($node) {
        $tag=$this->setting($node,'tag','h2');
        if (!in_array($tag,array('h1','h2','h3','h4','h5','h6'))) $tag='h2';

        $textValue=$this->setting($node,'text','');
        if ($textValue === '' && isset($node['settings']['content'])) $textValue=$node['settings']['content'];
        $text=htmlspecialchars((string)$textValue,ENT_QUOTES,'UTF-8');
        $url=(string)$this->setting($node,'url','');
        $level=(int)substr($tag,1);
        if($url!=='') $text='<a class="ng-widget-heading__link" href="'.htmlspecialchars($url,ENT_QUOTES,'UTF-8').'">'.$text.'</a>';
        return '<'.$tag.' class="ng-widget ng-widget-heading ng-heading-'.$level.'" data-ng-heading-level="'.$level.'">'.$text.'</'.$tag.'>';
    }

    public function text($node) {
        $text=(string)$this->setting($node,'text',$this->setting($node,'content',''));
        $tag=$this->safeTag($this->setting($node,'tag','div'),'div');
        return '<'.$tag.' class="ng-widget ng-widget-text">'.$text.'</'.$tag.'>';
    }

    public function textEditor($node) {
        $html=(string)$this->setting($node,'html',$this->setting($node,'text',$this->setting($node,'content','')));
        $tag=$this->safeTag($this->setting($node,'tag','div'),'div');
        return '<'.$tag.' class="ng-widget ng-widget-text-editor">'.$html.'</'.$tag.'>';
    }

    public function button($node) {
        $text=htmlspecialchars((string)$this->setting($node,'text','Button'),ENT_QUOTES,'UTF-8');
        $url=htmlspecialchars((string)$this->setting($node,'url','#'),ENT_QUOTES,'UTF-8');
        $target=(string)$this->setting($node,'target','_self');
        if(!in_array($target,array('_self','_blank','_parent','_top'),true))$target='_self';
        $icon=htmlspecialchars((string)$this->setting($node,'icon',''),ENT_QUOTES,'UTF-8');
        $position=(string)$this->setting($node,'iconPosition','left');
        if(!in_array($position,array('left','right','none'),true))$position='left';
        $iconHtml=$icon!==''&&$position!=='none'?'<span class="ng-widget-button__icon ng-widget-button__icon--'.$position.'" aria-hidden="true">'.$icon.'</span>':'';
        $label='<span class="ng-widget-button__label">'.$text.'</span>';
        $content=$position==='right'?$label.$iconHtml:$iconHtml.$label;
        $rel=$target==='_blank'?' rel="noopener noreferrer"':'';
        return '<a class="ng-widget ng-widget-button" href="'.$url.'" target="'.$target.'"'.$rel.'>'.$content.'</a>';
    }

    private function safeTag($tag,$fallback='div') {
        $tag=strtolower((string)$tag);
        return in_array($tag,array('h1','h2','h3','h4','h5','h6','div','span','p','section','article'),true)?$tag:$fallback;
    }

    public function image($node) {
        $src=htmlspecialchars($this->imageUrl($this->setting($node,'src','')),ENT_QUOTES,'UTF-8');
        $alt=htmlspecialchars((string)$this->setting($node,'alt',''),ENT_QUOTES,'UTF-8');
        $caption=htmlspecialchars((string)$this->setting($node,'caption',''),ENT_QUOTES,'UTF-8');
        if (!$src) return '';
        $fit=htmlspecialchars((string)$this->setting($node,'objectFit','cover'),ENT_QUOTES,'UTF-8');
        $pos=htmlspecialchars((string)$this->setting($node,'objectPosition','center center'),ENT_QUOTES,'UTF-8');
        $style='object-fit:'.$fit.';object-position:'.$pos.';';
        $hover=$this->setting($node,'hoverZoom',false)?' ng-image-hover-zoom':'';
        $overlay=htmlspecialchars((string)$this->setting($node,'overlayColor',''),ENT_QUOTES,'UTF-8');
        $img='<img class="ng-widget ng-widget-image'.$hover.'" src="'.$src.'" alt="'.$alt.'" loading="lazy" style="'.$style.'">';
        $linkType=(string)$this->setting($node,'linkType','none');
        if($linkType==='lightbox') $img='<a href="'.$src.'" class="ng-image-lightbox" data-ng-lightbox="1">'.$img.'</a>';
        elseif($linkType==='url') $img='<a href="'.htmlspecialchars((string)$this->setting($node,'url','#'),ENT_QUOTES,'UTF-8').'">'.$img.'</a>';
        $html='<figure class="ng-premium-image"'.($overlay?' style="--ng-image-overlay:'.$overlay.'"':'').'>'.$img.($overlay?'<span class="ng-image-overlay"></span>':'').($caption?'<figcaption>'.$caption.'</figcaption>':'').'</figure>';
        return $html;
    }

    public function icon($node) {
        $name=htmlspecialchars((string)$this->setting($node,'name','star'),ENT_QUOTES,'UTF-8');
        return '<span class="ng-widget ng-widget-icon" aria-hidden="true">'.$name.'</span>';
    }

    public function spacer($node) {
        $height=(int)$this->setting($node,'height',24);
        $height=max(0,min($height,1000));
        return '<div class="ng-widget ng-widget-spacer" style="height:'.$height.'px"></div>';
    }

    public function divider($node) {
        return '<hr class="ng-widget ng-widget-divider">';
    }
}
