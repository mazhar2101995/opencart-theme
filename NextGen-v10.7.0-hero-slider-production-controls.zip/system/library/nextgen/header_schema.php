<?php
class NextGenHeaderSchema {
    public static function widgets() {
        return [
            'announcement-bar' => ['title'=>'Announcement Bar','template'=>'builder/header/announcement-bar','category'=>'header'],
            'header-container' => ['title'=>'Header Container','template'=>'builder/header/header-container','category'=>'header'],
            'logo' => ['title'=>'Logo','template'=>'builder/header/logo','category'=>'header'],
            'main-navigation' => ['title'=>'Main Navigation','template'=>'builder/header/main-navigation','category'=>'header'],
            'mega-menu' => ['title'=>'Mega Menu','template'=>'builder/header/mega-menu','category'=>'header'],
            'search' => ['title'=>'Search','template'=>'builder/header/search','category'=>'header'],
            'search-suggestions' => ['title'=>'Search Suggestions','template'=>'builder/header/search-suggestions','category'=>'header'],
            'account' => ['title'=>'Account','template'=>'builder/header/account','category'=>'header'],
            'login-register' => ['title'=>'Login / Register','template'=>'builder/header/login-register','category'=>'header'],
            'wishlist' => ['title'=>'Wishlist','template'=>'builder/header/wishlist','category'=>'header'],
            'compare' => ['title'=>'Compare','template'=>'builder/header/compare','category'=>'header'],
            'cart' => ['title'=>'Cart','template'=>'builder/header/cart','category'=>'header'],
            'mini-cart' => ['title'=>'Mini Cart','template'=>'builder/header/mini-cart','category'=>'header'],
            'currency' => ['title'=>'Currency','template'=>'builder/header/currency','category'=>'header'],
            'language' => ['title'=>'Language','template'=>'builder/header/language','category'=>'header'],
            'store-selector' => ['title'=>'Store Selector','template'=>'builder/header/store-selector','category'=>'header'],
            'contact-info' => ['title'=>'Contact Info','template'=>'builder/header/contact-info','category'=>'header'],
            'social-links' => ['title'=>'Social Links','template'=>'builder/header/social-links','category'=>'header'],
            'mobile-menu' => ['title'=>'Mobile Menu','template'=>'builder/header/mobile-menu','category'=>'header'],
            'sticky-header' => ['title'=>'Sticky Header','template'=>'builder/header/sticky-header','category'=>'header'],
        ];
    }

    public static function controls($id) {
        $common = [
            ['id'=>'alignment','type'=>'select','label'=>'Alignment','options'=>['left'=>'Left','center'=>'Center','right'=>'Right'],'default'=>'left'],
            ['id'=>'visibility','type'=>'responsive','label'=>'Responsive Visibility'],
            ['id'=>'animation','type'=>'animation','label'=>'Animation'],
            ['id'=>'custom_class','type'=>'text','label'=>'Custom Class','default'=>''],
            ['id'=>'custom_id','type'=>'text','label'=>'Custom ID','default'=>''],
            ['id'=>'custom_css','type'=>'textarea','label'=>'Custom CSS','default'=>''],
        ];
        $specific = [
            'announcement-bar' => [
                ['id'=>'text','type'=>'text','label'=>'Announcement Text','default'=>''],
                ['id'=>'link','type'=>'url','label'=>'Link','default'=>''],
                ['id'=>'dismissible','type'=>'toggle','label'=>'Dismissible','default'=>false],
            ],
            'logo' => [
                ['id'=>'image','type'=>'image','label'=>'Logo Image','default'=>''],
                ['id'=>'mobile_image','type'=>'image','label'=>'Mobile Logo','default'=>''],
                ['id'=>'width','type'=>'responsive','label'=>'Logo Width','default'=>['desktop'=>'160px','tablet'=>'140px','mobile'=>'120px']],
            ],
            'main-navigation' => [
                ['id'=>'menu_source','type'=>'select','label'=>'Menu Source','options'=>['category'=>'OpenCart Categories','custom'=>'Custom Menu'],'default'=>'category'],
                ['id'=>'dropdown','type'=>'select','label'=>'Dropdown Style','options'=>['simple'=>'Simple','mega'=>'Mega Menu'],'default'=>'simple'],
                ['id'=>'hover_open','type'=>'toggle','label'=>'Open on Hover','default'=>true],
            ],
            'mega-menu' => [
                ['id'=>'columns','type'=>'number','label'=>'Columns','default'=>4,'min'=>1,'max'=>8],
                ['id'=>'width','type'=>'select','label'=>'Width','options'=>['container'=>'Container','full'=>'Full Width'],'default'=>'container'],
                ['id'=>'trigger','type'=>'select','label'=>'Trigger','options'=>['hover'=>'Hover','click'=>'Click'],'default'=>'hover'],
            ],
            'search' => [
                ['id'=>'placeholder','type'=>'text','label'=>'Placeholder','default'=>'Search'],
                ['id'=>'button','type'=>'toggle','label'=>'Show Search Button','default'=>true],
                ['id'=>'mobile_fullscreen','type'=>'toggle','label'=>'Mobile Fullscreen','default'=>true],
            ],
            'cart' => [
                ['id'=>'show_count','type'=>'toggle','label'=>'Show Item Count','default'=>true],
                ['id'=>'show_total','type'=>'toggle','label'=>'Show Total','default'=>true],
            ],
            'sticky-header' => [
                ['id'=>'enabled','type'=>'toggle','label'=>'Enabled','default'=>true],
                ['id'=>'hide_on_scroll_down','type'=>'toggle','label'=>'Hide on Scroll Down','default'=>false],
                ['id'=>'offset','type'=>'number','label'=>'Offset','default'=>0,'min'=>0,'max'=>500],
            ],
            'mobile-menu' => [
                ['id'=>'breakpoint','type'=>'number','label'=>'Breakpoint','default'=>991,'min'=>480,'max'=>1600],
                ['id'=>'drawer','type'=>'select','label'=>'Drawer Position','options'=>['left'=>'Left','right'=>'Right'],'default'=>'left'],
            ],
        ];
        return array_merge($common, $specific[$id] ?? []);
    }
}
