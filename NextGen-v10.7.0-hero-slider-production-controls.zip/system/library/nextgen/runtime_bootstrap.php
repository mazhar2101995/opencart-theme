<?php
class NextGenRuntimeBootstrap {
    public function stages() {
        return array(
            'context',
            'template_assignment',
            'document_validation',
            'conditions',
            'dynamic_data',
            'widget_resolution',
            'widget_rendering',
            'asset_collection',
            'seo',
            'performance',
            'finalize'
        );
    }

    public function architecture() {
        return array(
            'core_untouched'=>true,
            'event_based'=>true,
            'ocmod'=>false,
            'vqmod'=>false
        );
    }
}
