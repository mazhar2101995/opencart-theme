<?php
class NextGenAtomicDeployer {
    public function createDeploymentPlan(array $files) {
        $safe=array();
        foreach ($files as $file) {
            if ($this->safePath($file)) $safe[]=$file;
        }
        return array(
            'files'=>$safe,
            'staging_required'=>true,
            'atomic_switch'=>true,
            'verification_required'=>true
        );
    }

    private function safePath($path) {
        return strpos($path, '..') === false
            && strpos($path, '\\') !== 0
            && !preg_match('/^[A-Za-z]:/', $path);
    }
}
