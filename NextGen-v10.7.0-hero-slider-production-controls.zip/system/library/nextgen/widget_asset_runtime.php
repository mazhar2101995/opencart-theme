<?php
class NextGenWidgetAssetRuntime {
    protected $manifest=array();

    public function __construct(array $manifest=array()) {
        $this->manifest=$manifest;
    }

    public function collectForDocument(array $document) {
        $found=array('css'=>array(),'js'=>array());
        $this->walk($document,$found);
        return $found;
    }

    protected function walk($node,&$found) {
        if(!is_array($node)) return;
        if(isset($node['type']) && isset($this->manifest[$node['type']])) {
            $asset=$this->manifest[$node['type']];
            if(isset($asset['css'])) foreach((array)$asset['css'] as $v) $found['css'][$v]=true;
            if(isset($asset['js'])) foreach((array)$asset['js'] as $v) $found['js'][$v]=true;
        }
        if(isset($node['children']) && is_array($node['children'])) {
            foreach($node['children'] as $child) $this->walk($child,$found);
        }
    }

    public function normalize(array $assets) {
        return array(
            'css'=>array_keys(isset($assets['css'])?$assets['css']:array()),
            'js'=>array_keys(isset($assets['js'])?$assets['js']:array())
        );
    }
}
