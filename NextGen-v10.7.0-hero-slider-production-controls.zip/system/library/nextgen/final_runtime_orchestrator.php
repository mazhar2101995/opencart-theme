<?php
class NextGenFinalRuntimeOrchestrator {
    private $routeRuntime;
    private $assignmentRuntime;
    private $publishedRuntime;
    private $storefrontRuntime;
    private $fallback;

    public function __construct($routeRuntime,$assignmentRuntime,$publishedRuntime,$storefrontRuntime,$fallback=null) {
        $this->routeRuntime=$routeRuntime;
        $this->assignmentRuntime=$assignmentRuntime;
        $this->publishedRuntime=$publishedRuntime;
        $this->storefrontRuntime=$storefrontRuntime;
        $this->fallback=$fallback;
    }

    public function prepare(array $context,array $assignments,array $documents=array()) {
        $route=isset($context['route'])?$context['route']:'common/home';
        $type=$this->routeRuntime->map($route);
        $context['template_type']=$type;

        $assignment=$this->assignmentRuntime->resolve($assignments,$context);
        if(!$assignment) return $this->fallback('assignment_missing',$context);

        $document=null;
        $documentId=isset($assignment['document_id'])?(int)$assignment['document_id']:0;
        if($documentId && isset($documents[$documentId])) $document=$documents[$documentId];
        $document=$this->publishedRuntime->normalize($document);

        if(!$this->publishedRuntime->isRenderable($document)) {
            return $this->fallback('published_document_missing',$context);
        }

        $context['published_document']=true;
        return array(
            'status'=>'ready',
            'route'=>$route,
            'template_type'=>$type,
            'assignment'=>$assignment,
            'document'=>$document,
            'context'=>$context
        );
    }

    private function fallback($reason,array $context) {
        return array(
            'status'=>'fallback',
            'reason'=>$reason,
            'context'=>$context
        );
    }
}
