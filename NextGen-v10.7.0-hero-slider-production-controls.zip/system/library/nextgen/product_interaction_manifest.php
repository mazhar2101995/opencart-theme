<?php
return array(
    'product_card'=>array(
        'actions'=>array('cart','wishlist','compare','quick-view'),
        'assets'=>array('product-interactions.css','product-interactions.js')
    ),
    'product_page'=>array(
        'actions'=>array('cart','wishlist','compare','quick-view'),
        'assets'=>array('product-interactions.css','product-interactions.js')
    ),
    'product_gallery'=>array(
        'actions'=>array('gallery'),
        'assets'=>array('product-interactions.css','product-interactions.js')
    )
);
