<?php
class NextGenBuilderDocumentRenderer {
    public function render(array $document,array $context=array()) {
        $root=isset($document['root'])?$document['root']:$document;
        if (!is_array($root)) return '';

        return $this->renderNode($root,$context);
    }

    protected function renderNode($node,array $context=array()) {
        if (!is_array($node)) return '';
        $type=isset($node['type'])?$node['type']:'';
        $settings=isset($node['settings'])&&is_array($node['settings'])?$node['settings']:array();

        if ($type==='root') {
            return $this->renderChildren($node,$context);
        }

        if (in_array($type,array('section','container','inner-container','row','column','flex','grid'),true)) {
            $tag=isset($settings['tag'])?$settings['tag']:'div';
            $class='ng-node ng-'.$type;
            if (isset($settings['class'])) $class.=' '.preg_replace('/[^A-Za-z0-9 _-]/','',$settings['class']);
            $style=$this->inlineStyle($settings);
            return '<'.htmlspecialchars($tag,ENT_QUOTES,'UTF-8').' class="'.htmlspecialchars($class,ENT_QUOTES,'UTF-8').'"'.$style.'>'.
                $this->renderChildren($node,$context).'</'.htmlspecialchars($tag,ENT_QUOTES,'UTF-8').'>';
        }

        return $this->renderWidget($type,$settings,$node,$context);
    }

    protected function renderChildren($node,array $context) {
        $children=isset($node['children'])&&is_array($node['children'])?$node['children']:array();
        $html='';
        foreach($children as $child) $html.=$this->renderNode($child,$context);
        return $html;
    }

    protected function renderWidget($type,$settings,$node,array $context) {
        $content=isset($settings['content'])?$settings['content']:'';
        if ($type==='heading') {
            $tag=isset($settings['tag'])?$settings['tag']:'h2';
            return '<'.htmlspecialchars($tag,ENT_QUOTES,'UTF-8').' class="ng-widget ng-heading">'.
                htmlspecialchars($content,ENT_QUOTES,'UTF-8').'</'.htmlspecialchars($tag,ENT_QUOTES,'UTF-8').'>';
        }
        if ($type==='text') {
            return '<div class="ng-widget ng-text">'.$content.'</div>';
        }
        if ($type==='button') {
            $url=isset($settings['url'])?$settings['url']:'#';
            return '<a class="ng-widget ng-button" href="'.htmlspecialchars($url,ENT_QUOTES,'UTF-8').'">'.
                htmlspecialchars($content,ENT_QUOTES,'UTF-8').'</a>';
        }
        if ($type==='image') {
            $src=isset($settings['src'])?$settings['src']:'';
            $alt=isset($settings['alt'])?$settings['alt']:'';
            return '<img class="ng-widget ng-image" src="'.htmlspecialchars($src,ENT_QUOTES,'UTF-8').'" alt="'.htmlspecialchars($alt,ENT_QUOTES,'UTF-8').'">';
        }
        if ($type==='spacer') {
            $height=isset($settings['height'])?(int)$settings['height']:24;
            return '<div class="ng-widget ng-spacer" style="height:'.$height.'px"></div>';
        }
        return '<div class="ng-widget ng-unsupported" data-widget="'.htmlspecialchars($type,ENT_QUOTES,'UTF-8').'"></div>';
    }

    protected function inlineStyle($settings) {
        $style=array();
        if(isset($settings['background'])) $style[]='background:'.preg_replace('/[^A-Za-z0-9#(),.% _-]/','',$settings['background']);
        if(isset($settings['padding'])) $style[]='padding:'.preg_replace('/[^A-Za-z0-9.,% _-]/','',$settings['padding']);
        return $style?' style="'.htmlspecialchars(implode(';',$style),ENT_QUOTES,'UTF-8').'"':'';
    }
}
