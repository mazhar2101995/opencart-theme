<?php
/**
 * NextGen Advanced Builder UX v2.7
 */
class NextGenBuilderUx {
    public static function deviceList() {
        return array(
            'desktop' => array('label'=>'Desktop', 'width'=>1440),
            'tablet' => array('label'=>'Tablet', 'width'=>768),
            'mobile' => array('label'=>'Mobile', 'width'=>390)
        );
    }

    public static function resolveStyle($local, $global, $default = null) {
        if ($local !== null && $local !== '') return $local;
        if ($global !== null && $global !== '') return $global;
        return $default;
    }

    public static function tokenReference($token) {
        if (!is_string($token) || !preg_match('/^[a-z0-9_-]+$/', $token)) return null;
        return 'var(--ng-' . $token . ')';
    }

    public static function responsiveState(array $settings, $property, $device, $fallback = null) {
        if (isset($settings['responsive'][$property]) &&
            is_array($settings['responsive'][$property])) {
            $values = $settings['responsive'][$property];
            if (isset($values[$device]) && $values[$device] !== '') {
                return $values[$device];
            }
            foreach (array('tablet','desktop','mobile') as $candidate) {
                if ($candidate !== $device &&
                    isset($values[$candidate]) &&
                    $values[$candidate] !== '') {
                    return $values[$candidate];
                }
            }
        }
        return $fallback;
    }
}
