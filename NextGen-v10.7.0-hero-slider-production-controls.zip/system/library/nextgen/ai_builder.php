<?php
/**
 * NextGen AI-Assisted Builder v2.9
 *
 * Provider-neutral foundation. No external AI API is called here.
 * AI output is treated as untrusted input and must pass validation.
 */
class NextGenAiBuilder {
    public static function requestSchema() {
        return array(
            'prompt' => 'string',
            'mode' => array(
                'layout',
                'content',
                'design',
                'explain',
                'json'
            ),
            'context' => 'object'
        );
    }

    public static function sanitizeRequest(array $request) {
        $mode = isset($request['mode']) ? $request['mode'] : 'layout';

        if (!in_array($mode, array('layout','content','design','explain','json'), true)) {
            $mode = 'layout';
        }

        return array(
            'prompt' => isset($request['prompt'])
                ? trim((string)$request['prompt'])
                : '',
            'mode' => $mode,
            'context' => isset($request['context']) && is_array($request['context'])
                ? $request['context']
                : array()
        );
    }

    public static function outputEnvelope($mode, $content, array $meta = array()) {
        return array(
            'version' => '2.9',
            'mode' => $mode,
            'content' => $content,
            'meta' => $meta
        );
    }

    /**
     * Never trust AI-generated builder JSON.
     * The caller should pass the result through the existing document validator.
     */
    public static function requiresValidation() {
        return true;
    }
}
