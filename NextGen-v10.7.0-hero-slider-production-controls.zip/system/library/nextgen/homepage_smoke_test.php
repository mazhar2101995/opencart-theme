<?php
class NextGenHomepageSmokeTest {
    public function run(array $result,array $context=array()) {
        $checks=array();

        $checks['route']=isset($context['route']) && $context['route']==='common/home';
        $checks['document']=isset($result['document']) && is_array($result['document']);
        $checks['html']=isset($result['html']) && trim($result['html'])!=='';
        $checks['fallback_safe']=!isset($result['runtime_error']);

        $passed=true;
        foreach($checks as $value) {
            if(!$value) {$passed=false; break;}
        }

        return array(
            'status'=>$passed?'passed':'failed',
            'checks'=>$checks,
            'context'=>$context,
            'result_status'=>isset($result['status'])?$result['status']:'unknown'
        );
    }
}
