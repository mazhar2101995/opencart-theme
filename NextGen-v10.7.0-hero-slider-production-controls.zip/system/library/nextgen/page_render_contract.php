<?php
class NextGenPageRenderContract {
    public function product(array $context) {
        return array('type'=>'product','context'=>$context);
    }

    public function category(array $context) {
        return array('type'=>'category','context'=>$context);
    }

    public function search(array $context) {
        return array('type'=>'search','context'=>$context);
    }

    public function header(array $context) {
        return array('type'=>'header','context'=>$context);
    }

    public function footer(array $context) {
        return array('type'=>'footer','context'=>$context);
    }
}
