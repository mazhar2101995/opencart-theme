<?php
/**
 * Shared admin settings helpers.
 * UI remains module-specific; this file only provides safe common helpers.
 */
if (!function_exists('nextgen_admin_settings_flash')) {
    function nextgen_admin_settings_flash($session, $success = '', $error = '') {
        if ($success !== '') $session->data['nextgen_settings_success'] = $success;
        if ($error !== '') $session->data['nextgen_settings_error'] = $error;
    }
}
if (!function_exists('nextgen_admin_settings_token')) {
    function nextgen_admin_settings_token($session) {
        return 'user_token=' . (isset($session->data['user_token']) ? $session->data['user_token'] : '');
    }
}
