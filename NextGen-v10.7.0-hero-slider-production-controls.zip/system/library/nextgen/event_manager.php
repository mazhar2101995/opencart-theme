<?php
class NextGenEventManager {
    private $events=array();

    public function register($code,$trigger,$action,$status=1,$sortOrder=0) {
        $this->events[$code]=array(
            'code'=>$code,
            'trigger'=>$trigger,
            'action'=>$action,
            'status'=>(int)$status,
            'sort_order'=>(int)$sortOrder
        );
        return $this->events[$code];
    }

    public function all() { return $this->events; }
}
