<?php
class NextGenFrontendRenderEngine {
    private $loader;
    private $registry;

    public function __construct($loader = null, $registry = null) {
        $this->loader = $loader;
        $this->registry = $registry;
    }

    public function renderDocument(array $document, array $context = []) {
        $root = $document['root'] ?? $document;
        return $this->renderNode($root, $context);
    }

    public function renderNode($node, array $context = []) {
        if (!is_array($node)) return '';

        $type = $node['type'] ?? '';
        $settings = is_array($node['settings'] ?? null) ? $node['settings'] : [];
        $children = is_array($node['children'] ?? null) ? $node['children'] : [];

        if (!$this->isVisible($node, $context)) {
            return '';
        }

        $child_html = '';
        foreach ($children as $child) {
            $child_html .= $this->renderNode($child, $context);
        }

        if ($type === 'section') {
            return '<section class="ng-section">' . $child_html . '</section>';
        }

        if ($type === 'container') {
            return '<div class="ng-container">' . $child_html . '</div>';
        }

        if ($type === 'column') {
            return '<div class="ng-column">' . $child_html . '</div>';
        }

        if ($type === 'widget') {
            return $this->renderWidget($node, $context);
        }

        return $child_html;
    }

    private function renderWidget(array $node, array $context) {
        $widget_id = $node['widget'] ?? ($node['id'] ?? '');
        if (!$widget_id) return '';

        $settings = is_array($node['settings'] ?? null) ? $node['settings'] : [];

        // Central widget renderer contract.
        if (isset($this->registry['widgets'][$widget_id])) {
            $definition = $this->registry['widgets'][$widget_id];

            if (isset($definition['renderer']) && is_callable($definition['renderer'])) {
                return (string)call_user_func($definition['renderer'], $context, $settings, $node);
            }

            if (isset($definition['template']) && $this->loader) {
                $data = array_merge($context, [
                    'settings' => $settings,
                    'node' => $node,
                    'widget_id' => $widget_id
                ]);
                return (string)$this->loader->view($definition['template'], $data);
            }
        }

        return '';
    }

    private function isVisible(array $node, array $context) {
        if (isset($node['enabled']) && !$node['enabled']) return false;

        // Conditions remain presentation-only.
        if (isset($node['conditions']) && is_array($node['conditions'])) {
            return $this->evaluateConditions($node['conditions'], $context);
        }

        return true;
    }

    private function evaluateConditions(array $conditions, array $context) {
        foreach ($conditions as $condition) {
            $key = $condition['key'] ?? '';
            $operator = $condition['operator'] ?? 'equals';
            $expected = $condition['value'] ?? null;
            $actual = $this->readPath($context, $key);

            if (!$this->compare($actual, $operator, $expected)) {
                return false;
            }
        }

        return true;
    }

    private function compare($actual, $operator, $expected) {
        switch ($operator) {
            case 'not_equals': return $actual != $expected;
            case 'contains': return is_string($actual) && strpos($actual, (string)$expected) !== false;
            case 'greater': return $actual > $expected;
            case 'less': return $actual < $expected;
            case 'exists': return $actual !== null;
            default: return $actual == $expected;
        }
    }

    private function readPath(array $context, $path) {
        if (!$path) return null;
        $parts = explode('.', $path);
        $value = $context;

        foreach ($parts as $part) {
            if (is_array($value) && array_key_exists($part, $value)) {
                $value = $value[$part];
            } else {
                return null;
            }
        }

        return $value;
    }
}
