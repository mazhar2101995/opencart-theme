<?php
class NextGenOverlayManager {
    public static function definition($type, array $options = array()) {
        $allowed = array('popup','modal','drawer','offcanvas','lightbox');
        if (!in_array($type, $allowed, true)) return null;

        return array(
            'type' => $type,
            'placement' => isset($options['placement']) ? $options['placement'] : 'center',
            'backdrop' => isset($options['backdrop']) ? (bool)$options['backdrop'] : true,
            'close_escape' => isset($options['close_escape']) ? (bool)$options['close_escape'] : true,
            'close_outside' => isset($options['close_outside']) ? (bool)$options['close_outside'] : true,
            'lock_scroll' => isset($options['lock_scroll']) ? (bool)$options['lock_scroll'] : true
        );
    }
}
