<?php
class NextGenUpdateStateRepository {
    private $db;
    public function __construct($db) { $this->db=$db; }

    public function installSchema() {
        $sql="CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "nextgen_package_state` (
            `state_id` INT(11) NOT NULL AUTO_INCREMENT,
            `package_name` VARCHAR(128) NOT NULL,
            `installed_version` VARCHAR(32) NOT NULL,
            `migration_version` VARCHAR(32) DEFAULT NULL,
            `status` VARCHAR(32) NOT NULL DEFAULT 'active',
            `date_modified` DATETIME NOT NULL,
            PRIMARY KEY (`state_id`),
            UNIQUE KEY `package_name` (`package_name`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
        $this->db->query($sql);
    }

    public function get($package) {
        $q=$this->db->query("SELECT * FROM `" . DB_PREFIX . "nextgen_package_state` WHERE package_name='" . $this->db->escape($package) . "' LIMIT 1");
        return $q->row;
    }

    public function save($package,$version,$migration='',$status='active') {
        $exists=$this->get($package);
        $data=array(
            'package_name'=>$package,
            'installed_version'=>$version,
            'migration_version'=>$migration,
            'status'=>$status,
            'date_modified'=>date('Y-m-d H:i:s')
        );
        if ($exists) {
            $this->db->query("UPDATE `" . DB_PREFIX . "nextgen_package_state`
                SET installed_version='" . $this->db->escape($version) . "',
                    migration_version='" . $this->db->escape($migration) . "',
                    status='" . $this->db->escape($status) . "',
                    date_modified=NOW()
                WHERE package_name='" . $this->db->escape($package) . "'");
        } else {
            $this->db->query("INSERT INTO `" . DB_PREFIX . "nextgen_package_state`
                SET package_name='" . $this->db->escape($package) . "',
                    installed_version='" . $this->db->escape($version) . "',
                    migration_version='" . $this->db->escape($migration) . "',
                    status='" . $this->db->escape($status) . "',
                    date_modified=NOW()");
        }
        return true;
    }
}
