<?php
class NextGenCanonicalManager {
    public static function resolve($canonical, array $options = array()) {
        if (!empty($canonical)) return $canonical;

        $url = '';
        if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') $url .= 'https://';
        else $url .= 'http://';
        $url .= isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '';
        $url .= isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '/';

        if (!empty($options['strip_query'])) {
            $url = preg_replace('/\?.*$/', '', $url);
        }
        return $url;
    }
}
