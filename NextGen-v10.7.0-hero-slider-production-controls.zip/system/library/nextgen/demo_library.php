<?php
class NextGenDemoLibrary {
    public function all() {
        return array(
            'electronics'=>array('name'=>'Electronics Store','slug'=>'electronics'),
            'fashion'=>array('name'=>'Fashion Store','slug'=>'fashion'),
            'yoga'=>array('name'=>'Yoga Products Store','slug'=>'yoga'),
            'rc-car'=>array('name'=>'RC Car Store','slug'=>'rc-car'),
            'fruit-veg'=>array('name'=>'Fruit & Vegetable Market','slug'=>'fruit-veg')
        );
    }

    public function get($slug) {
        $all=$this->all();
        return isset($all[$slug]) ? $all[$slug] : null;
    }
}
