<?php
class NextGenMigrationState {
    public function plan(array $available, array $applied, $from, $to) {
        $pending=array();
        foreach ($available as $migration) {
            if (empty($migration['version'])) continue;
            if (in_array($migration['version'], $applied, true)) continue;
            if (version_compare($migration['version'],$from,'>') &&
                version_compare($migration['version'],$to,'<=')) {
                $pending[]=$migration['version'];
            }
        }
        usort($pending,'version_compare');
        return $pending;
    }
}
