<?php
class NextGenLicenseApiClient {
    private $endpoint;

    public function __construct($endpoint='') {
        $this->endpoint=rtrim($endpoint,'/');
    }

    public function requestPayload($action,array $data=array()) {
        return array(
            'action'=>$action,
            'payload'=>$data,
            'timestamp'=>time()
        );
    }

    public function validateServerResponse(array $response) {
        $required=array('status','package','installation_id');
        foreach ($required as $key) {
            if (!isset($response[$key])) {
                return array('valid'=>false,'error'=>"Missing response field: {$key}");
            }
        }

        return array(
            'valid'=>true,
            'status'=>$response['status'],
            'package'=>$response['package'],
            'installation_id'=>$response['installation_id']
        );
    }
}
