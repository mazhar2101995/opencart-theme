<?php
class NextGenDocumentRepositoryAdapter {
    private $repository;

    public function __construct($repository=null) {
        $this->repository=$repository;
    }

    public function getPublished($documentId) {
        if(!$this->repository || !$documentId) return null;

        if(method_exists($this->repository,'getPublished')) {
            return $this->repository->getPublished((int)$documentId);
        }

        if(method_exists($this->repository,'get')) {
            $document=$this->repository->get((int)$documentId);
            if(is_array($document) && isset($document['status']) && $document['status']==='published') {
                return $document;
            }
        }

        return null;
    }
}
