<?php
class NextGenStorefrontFallback {
    public function shouldFallback(array $result) {
        return empty($result['html']) || isset($result['runtime_error']);
    }

    public function response(array $result) {
        return array(
            'status'=>'fallback',
            'html'=>'',
            'reason'=>isset($result['reason'])?$result['reason']:'runtime_unavailable'
        );
    }
}
