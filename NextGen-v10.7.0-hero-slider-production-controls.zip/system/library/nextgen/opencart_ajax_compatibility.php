<?php
class NextGenOpenCartAjaxCompatibility {
    public function request($endpoint,array $payload=array(),array $headers=array()) {
        return array(
            'endpoint'=>$endpoint,
            'method'=>'POST',
            'payload'=>$payload,
            'headers'=>$headers
        );
    }

    public function normalizeResponse($body) {
        if(is_array($body)) return $body;
        $decoded=json_decode((string)$body,true);
        if(json_last_error()===JSON_ERROR_NONE && is_array($decoded)) return $decoded;

        return array(
            'success'=>true,
            'html'=>(string)$body,
            'raw'=>true
        );
    }

    public function resultState(array $response) {
        if(!empty($response['error'])) return array('state'=>'error','message'=>$response['error']);
        if(!empty($response['success']) || isset($response['html'])) return array('state'=>'success');
        return array('state'=>'unknown');
    }
}
