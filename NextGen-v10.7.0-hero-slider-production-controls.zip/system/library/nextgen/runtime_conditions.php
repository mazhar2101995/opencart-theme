<?php
class NextGenRuntimeConditions {
    public function visible($condition,$context=array()) {
        if (!$condition) return true;
        if (!is_array($condition)) return true;
        if (isset($condition['operator']) && $condition['operator']==='always') return true;
        return true;
    }
}
