<?php
class NextGenGlobalComponentSchema {
    public static function components() {
        return [
            'announcement-bar' => ['title'=>'Announcement Bar','type'=>'global','template'=>'builder/global/announcement-bar'],
            'product-card' => ['title'=>'Product Card','type'=>'global','template'=>'builder/global/product-card'],
            'cta' => ['title'=>'CTA','type'=>'global','template'=>'builder/global/cta'],
            'newsletter' => ['title'=>'Newsletter','type'=>'global','template'=>'builder/global/newsletter'],
            'trust-badges' => ['title'=>'Trust Badges','type'=>'global','template'=>'builder/global/trust-badges'],
            'footer-columns' => ['title'=>'Footer Columns','type'=>'global','template'=>'builder/global/footer-columns'],
            'footer-menu' => ['title'=>'Footer Menu','type'=>'global','template'=>'builder/global/footer-menu'],
            'footer-logo' => ['title'=>'Footer Logo','type'=>'global','template'=>'builder/global/footer-logo'],
            'footer-contact' => ['title'=>'Footer Contact','type'=>'global','template'=>'builder/global/footer-contact'],
            'footer-social' => ['title'=>'Footer Social','type'=>'global','template'=>'builder/global/footer-social'],
            'payment-icons' => ['title'=>'Payment Icons','type'=>'global','template'=>'builder/global/payment-icons'],
            'store-info' => ['title'=>'Store Info','type'=>'global','template'=>'builder/global/store-info'],
            'copyright' => ['title'=>'Copyright','type'=>'global','template'=>'builder/global/copyright'],
        ];
    }

    public static function controls($id) {
        $common = [
            ['id'=>'alignment','type'=>'select','label'=>'Alignment','options'=>['left'=>'Left','center'=>'Center','right'=>'Right'],'default'=>'left'],
            ['id'=>'visibility','type'=>'responsive','label'=>'Responsive Visibility'],
            ['id'=>'animation','type'=>'animation','label'=>'Animation'],
            ['id'=>'custom_class','type'=>'text','label'=>'Custom Class','default'=>''],
            ['id'=>'custom_id','type'=>'text','label'=>'Custom ID','default'=>''],
            ['id'=>'custom_css','type'=>'textarea','label'=>'Custom CSS','default'=>''],
        ];

        $specific = [
            'announcement-bar' => [
                ['id'=>'text','type'=>'text','label'=>'Text','default'=>''],
                ['id'=>'link','type'=>'url','label'=>'Link','default'=>''],
            ],
            'product-card' => [
                ['id'=>'show_brand','type'=>'toggle','label'=>'Show Brand','default'=>true],
                ['id'=>'show_rating','type'=>'toggle','label'=>'Show Rating','default'=>true],
                ['id'=>'show_price','type'=>'toggle','label'=>'Show Price','default'=>true],
                ['id'=>'show_actions','type'=>'toggle','label'=>'Show Actions','default'=>true],
            ],
            'cta' => [
                ['id'=>'heading','type'=>'text','label'=>'Heading','default'=>''],
                ['id'=>'text','type'=>'textarea','label'=>'Text','default'=>''],
                ['id'=>'button_text','type'=>'text','label'=>'Button Text','default'=>''],
                ['id'=>'button_link','type'=>'url','label'=>'Button Link','default'=>''],
            ],
            'newsletter' => [
                ['id'=>'heading','type'=>'text','label'=>'Heading','default'=>'Newsletter'],
                ['id'=>'placeholder','type'=>'text','label'=>'Email Placeholder','default'=>'Your email address'],
                ['id'=>'button_text','type'=>'text','label'=>'Button Text','default'=>'Subscribe'],
            ],
            'trust-badges' => [
                ['id'=>'items','type'=>'repeater','label'=>'Trust Badges','default'=>[]],
            ],
            'footer-columns' => [
                ['id'=>'columns','type'=>'number','label'=>'Columns','default'=>4,'min'=>1,'max'=>6],
            ],
        ];

        return array_merge($common, $specific[$id] ?? []);
    }
}
