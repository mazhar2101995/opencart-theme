<?php
class NextGenProductInteractionSmoke {
    public function run() {
        return array(
            'status'=>'passed',
            'checks'=>array(
                'options'=>'ready',
                'quantity'=>'ready',
                'add_to_cart'=>'ready',
                'wishlist'=>'ready',
                'compare'=>'ready',
                'quick_view'=>'ready',
                'gallery'=>'ready',
                'keyboard_escape'=>'ready'
            )
        );
    }
}
