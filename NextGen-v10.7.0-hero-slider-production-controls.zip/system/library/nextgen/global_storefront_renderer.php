<?php
class NextGenGlobalStorefrontRenderer {
    public function renderAnnouncement(array $data=array()) {
        if(empty($data['enabled'])) return '';
        $text=isset($data['text'])?$data['text']:'';
        $href=isset($data['href'])?$data['href']:'';
        $html='<div class="ng-announcement-bar">';
        if($href) $html.='<a href="'.htmlspecialchars($href,ENT_QUOTES,'UTF-8').'">'.htmlspecialchars($text,ENT_QUOTES,'UTF-8').'</a>';
        else $html.=htmlspecialchars($text,ENT_QUOTES,'UTF-8');
        return $html.'</div>';
    }

    public function renderNewsletter(array $data=array()) {
        $title=isset($data['title'])?$data['title']:'Newsletter';
        $action=isset($data['action'])?$data['action']:'#';
        $name=isset($data['email_name'])?$data['email_name']:'email';
        return '<section class="ng-newsletter"><h2>'.htmlspecialchars($title,ENT_QUOTES,'UTF-8').
            '</h2><form method="post" action="'.htmlspecialchars($action,ENT_QUOTES,'UTF-8').'">'.
            '<input type="email" name="'.htmlspecialchars($name,ENT_QUOTES,'UTF-8').'" required>'.
            '<button type="submit">Subscribe</button></form></section>';
    }

    public function renderSocial(array $items=array()) {
        $html='<div class="ng-social-links">';
        foreach($items as $item) {
            if(!is_array($item)) continue;
            $label=isset($item['label'])?$item['label']:'';
            $href=isset($item['href'])?$item['href']:'#';
            $html.='<a href="'.htmlspecialchars($href,ENT_QUOTES,'UTF-8').'" rel="noopener noreferrer">'.htmlspecialchars($label,ENT_QUOTES,'UTF-8').'</a>';
        }
        return $html.'</div>';
    }

    public function renderPayments(array $items=array()) {
        $html='<div class="ng-payment-icons">';
        foreach($items as $item) {
            if(!is_array($item)) continue;
            if(isset($item['src']) && $item['src']) {
                $html.='<img src="'.htmlspecialchars($item['src'],ENT_QUOTES,'UTF-8').'" alt="'.htmlspecialchars(isset($item['alt'])?$item['alt']:'Payment',ENT_QUOTES,'UTF-8').'">';
            }
        }
        return $html.'</div>';
    }

    public function renderTrustBadges(array $items=array()) {
        $html='<div class="ng-trust-badges">';
        foreach($items as $item) {
            if(!is_array($item)) continue;
            $title=isset($item['title'])?$item['title']:'';
            $description=isset($item['description'])?$item['description']:'';
            $html.='<div class="ng-trust-badge"><strong>'.htmlspecialchars($title,ENT_QUOTES,'UTF-8').
                '</strong><span>'.htmlspecialchars($description,ENT_QUOTES,'UTF-8').'</span></div>';
        }
        return $html.'</div>';
    }

    public function renderFooter(array $data=array()) {
        $html='<footer class="ng-global-footer">';
        $html.='<div class="ng-global-footer__columns">';
        foreach(isset($data['columns'])?$data['columns']:array() as $column) {
            if(!is_array($column)) continue;
            $html.='<div class="ng-footer-column"><h3>'.htmlspecialchars(isset($column['title'])?$column['title']:'',ENT_QUOTES,'UTF-8').'</h3>';
            foreach(isset($column['links'])?$column['links']:array() as $link) {
                if(!is_array($link)) continue;
                $html.='<a href="'.htmlspecialchars(isset($link['href'])?$link['href']:'#',ENT_QUOTES,'UTF-8').'">'.htmlspecialchars(isset($link['name'])?$link['name']:'',ENT_QUOTES,'UTF-8').'</a>';
            }
            $html.='</div>';
        }
        $html.='</div>';
        if(isset($data['copyright'])) $html.='<div class="ng-footer-copyright">'.htmlspecialchars($data['copyright'],ENT_QUOTES,'UTF-8').'</div>';
        return $html.'</footer>';
    }
}
