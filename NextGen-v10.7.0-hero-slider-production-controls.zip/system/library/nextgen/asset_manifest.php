<?php
function nextgen_asset_manifest() {
    return [
        'core' => [
            'css' => [
                'catalog/view/theme/nextgen/assets/css/frontend-core.css'
            ],
            'js' => [
                'catalog/view/theme/nextgen/assets/js/frontend-assets.js'
            ]
        ],
        'product-page' => [
            'css' => [
                'catalog/view/theme/nextgen/assets/css/product-page-builder.css'
            ],
            'js' => [
                'catalog/view/theme/nextgen/assets/js/product-page-builder.js'
            ]
        ],
        'catalog-search' => [
            'css' => [
                'catalog/view/theme/nextgen/assets/css/catalog-search-builder.css'
            ],
            'js' => [
                'catalog/view/theme/nextgen/assets/js/catalog-search-builder.js'
            ]
        ],
        'header' => [
            'css' => [
                'catalog/view/theme/nextgen/assets/css/header-builder.css'
            ],
            'js' => [
                'catalog/view/theme/nextgen/assets/js/header-builder.js'
            ]
        ],
        'global' => [
            'css' => [
                'catalog/view/theme/nextgen/assets/css/global-components.css'
            ],
            'js' => [
                'catalog/view/theme/nextgen/assets/js/global-components.js'
            ]
        ]
    ];
}
