<?php
class NextGenPackageValidator {
    public function validate(array $manifest, array $files = array()) {
        $errors = array();
        if (empty($files)) $errors[] = 'Package contains no declared files.';
        foreach ($files as $file) {
            if (strpos($file, '..') !== false || strpos($file, '\\') === 0 || preg_match('/^[A-Za-z]:/', $file)) {
                $errors[] = 'Unsafe package path: ' . $file;
            }
        }
        return array('valid'=>empty($errors),'errors'=>$errors);
    }
}
