<?php
class NextGenProductInteractionRuntime {
    public function endpoints() {
        return array(
            'cart'=>'index.php?route=checkout/cart/add',
            'wishlist'=>'index.php?route=account/wishlist/add',
            'compare'=>'index.php?route=product/compare/add',
            'quick_view'=>'index.php?route=product/product/quickview'
        );
    }

    public function normalizeOptions(array $options=array()) {
        $result=array();
        foreach($options as $option) {
            if(!is_array($option) || !isset($option['product_option_id'])) continue;
            $result[(int)$option['product_option_id']]=isset($option['value'])?$option['value']:null;
        }
        return $result;
    }

    public function normalizeQuantity($quantity) {
        $quantity=(int)$quantity;
        return $quantity>0?$quantity:1;
    }

    public function interactionState(array $state=array()) {
        return array(
            'loading'=>!empty($state['loading']),
            'added'=>!empty($state['added']),
            'wishlist'=>!empty($state['wishlist']),
            'compare'=>!empty($state['compare']),
            'quick_view'=>!empty($state['quick_view'])
        );
    }
}
