<?php
/**
 * One-click NextGen demo installer.
 * Stores demo state only inside NextGen tables; never mutates catalog, orders,
 * customers, checkout, payment or shipping data.
 */
class NextGenDemoInstaller {
    private $db;
    private $registry;

    public function __construct($db, $registry = null) {
        $this->db = $db;
        $this->registry = $registry;
    }

    public function listDemos() {
        $base = DIR_SYSTEM . 'library/nextgen/demos/';
        $items = array();
        foreach (glob($base . '*/manifest.json') ?: array() as $file) {
            $manifest = json_decode((string)file_get_contents($file), true);
            if (!is_array($manifest) || empty($manifest['slug'])) continue;
            $items[$manifest['slug']] = $manifest;
        }
        return $items;
    }

    public function import($slug, $store_id = 0, $language_id = 0) {
        $this->ensureOpenCartThemeSettings($store_id);
        $slug = preg_replace('/[^a-z0-9_-]/', '', strtolower((string)$slug));
        $base = DIR_SYSTEM . 'library/nextgen/demos/' . $slug . '/';
        if (!$slug || !is_dir($base)) return array('success'=>false,'error'=>'Demo not found.');

        $manifest_file = $base . 'manifest.json';
        $document_file = $base . 'document.json';
        if (!is_file($manifest_file) || !is_file($document_file)) {
            return array('success'=>false,'error'=>'Demo package is incomplete.');
        }

        $manifest_error = '';
        $document_error = '';
        $manifest = $this->decodeJsonFile($manifest_file, $manifest_error);
        $document = $this->decodeJsonFile($document_file, $document_error);
        if (!is_array($manifest)) {
            return array('success'=>false,'error'=>'Demo manifest JSON is invalid: ' . ($manifest_error ? $manifest_error : 'invalid object') . '.');
        }
        if (!is_array($document)) {
            return array('success'=>false,'error'=>'Demo document JSON is invalid: ' . ($document_error ? $document_error : 'invalid object') . '.');
        }
        // Accept both the packaged {root:{...}} document format and a direct root document.
        if (isset($document['root'])) {
            if (!is_array($document['root'])) {
                return array('success'=>false,'error'=>'Demo document root must be a JSON object.');
            }
        } elseif (isset($document['type']) && $document['type'] === 'root') {
            $document = array('root' => $document);
        } else {
            return array('success'=>false,'error'=>'Demo document JSON is valid, but no root document was found.');
        }
        if (!empty($manifest['mutates_opencart_catalog']) || !empty($manifest['mutates_orders']) || !empty($manifest['mutates_customers']) || !empty($manifest['mutates_checkout'])) {
            return array('success'=>false,'error'=>'Unsafe demo scope.');
        }

        $now = date('Y-m-d H:i:s');
        $root_document = isset($document['root']) && is_array($document['root']) ? $document['root'] : $document;
        if (!isset($root_document['type']) || $root_document['type'] !== 'root') return array('success'=>false,'error'=>'Demo document root is invalid.');
        $root_document = $this->normalizeDocument($root_document);
        $json = $this->db->escape(json_encode($root_document, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
        $name = $this->db->escape(isset($manifest['name']) ? $manifest['name'] : ucfirst($slug));

        // Homepage document: replace the existing demo document for this route.
        $existing = $this->db->query("SELECT document_id FROM `" . DB_PREFIX . "nextgen_builder_document` WHERE route='common/home' AND template_type='homepage' AND store_id='" . (int)$store_id . "' LIMIT 1");
        if ($existing->num_rows) {
            $document_id = (int)$existing->row['document_id'];
            $this->db->query("UPDATE `" . DB_PREFIX . "nextgen_builder_document` SET name='" . $name . "', status='1', version=version+1, document_json='" . $json . "', date_modified='" . $now . "' WHERE document_id='" . $document_id . "'");
        } else {
            $this->db->query("INSERT INTO `" . DB_PREFIX . "nextgen_builder_document` SET store_id='" . (int)$store_id . "', name='" . $name . "', route='common/home', template_type='homepage', status='1', version='1', document_json='" . $json . "', date_added='" . $now . "', date_modified='" . $now . "'");
            $document_id = (int)$this->db->getLastId();
        }

        $this->db->query("INSERT INTO `" . DB_PREFIX . "nextgen_template_assignment` SET store_id='" . (int)$store_id . "', language_id='" . (int)$language_id . "', route='common/home', template_type='homepage', document_id='" . $document_id . "', priority='100', status='1', source='demo:" . $this->db->escape($slug) . "', date_modified='" . $now . "' ON DUPLICATE KEY UPDATE document_id=VALUES(document_id), priority=VALUES(priority), status=VALUES(status), source=VALUES(source), date_modified=VALUES(date_modified)");

        // Install all advertised starter routes, not just the homepage. Each
        // route gets its own NextGen document + assignment so the active demo
        // does not fall back to the OpenCart default theme when navigating.
        $this->installRouteDocuments($slug, $manifest, $store_id, $language_id, $root_document, $now);

        // Persist the complete demo skin in NextGen runtime storage. A demo import
        // should feel like a real theme preset: visual tokens, typography, branding,
        // theme-level options and demo-specific CSS state are all restored together.
        $tokens = isset($manifest['tokens']) && is_array($manifest['tokens']) ? $manifest['tokens'] : array();
        $this->upsertRuntime($store_id, 'enabled', '1');
        $this->upsertRuntime($store_id, 'active_demo', $slug);
        $this->upsertRuntime($store_id, 'demo_tokens', json_encode($tokens, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
        $this->upsertRuntime($store_id, 'demo_version', isset($manifest['version']) ? $manifest['version'] : '1.0.0');
        if (!empty($manifest['tokens']) && is_array($manifest['tokens'])) {
            $tokenMap = array(
                'primary'=>'primary_color','accent'=>'accent_color','background'=>'background_color','surface'=>'surface_color',
                'container_width'=>'container_width','radius'=>'radius','spacing'=>'spacing','font_family'=>'font_family','brand_name'=>'brand_name'
            );
            foreach ($tokenMap as $from=>$to) {
                if (array_key_exists($from, $manifest['tokens'])) {
                    $this->upsertRuntime($store_id, $to, (string)$manifest['tokens'][$from]);
                }
            }
        }
        if (!empty($manifest['typography']) && is_array($manifest['typography'])) {
            $this->upsertRuntime($store_id, 'typography', json_encode($manifest['typography'], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
        }
        if (!empty($manifest['global_settings']) && is_array($manifest['global_settings'])) {
            foreach ($manifest['global_settings'] as $key=>$value) {
                if (is_scalar($value)) $this->upsertRuntime($store_id, preg_replace('/[^a-z0-9_]/i','_', (string)$key), (string)$value);
            }
        }
        if (!empty($manifest['branding']) && is_array($manifest['branding'])) {
            foreach ($manifest['branding'] as $key=>$value) {
                if (is_scalar($value)) $this->upsertRuntime($store_id, preg_replace('/[^a-z0-9_]/i','_', (string)$key), (string)$value);
            }
        }

        // Seed reusable Template Library entries and Global Components so a demo
        // is immediately usable from the complete NextGen admin workflow.
        $this->seedTemplateLibrary($slug, $manifest, $root_document, $store_id);
        $this->seedGlobalComponents($slug, $manifest, $root_document);

        // Mark package state for diagnostics.
        $meta = $this->db->escape(json_encode(array('demo'=>$slug,'document_id'=>$document_id), JSON_UNESCAPED_SLASHES));
        $this->db->query("INSERT INTO `" . DB_PREFIX . "nextgen_package_state` SET package_name='nextgen-demo-" . $this->db->escape($slug) . "', version='" . $this->db->escape(isset($manifest['version']) ? $manifest['version'] : '1.0.0') . "', status='active', metadata='" . $meta . "', date_modified='" . $now . "' ON DUPLICATE KEY UPDATE version=VALUES(version), status='active', metadata=VALUES(metadata), date_modified=VALUES(date_modified)");

        return array('success'=>true,'demo'=>$slug,'name'=>isset($manifest['name'])?$manifest['name']:$slug,'document_id'=>$document_id,'message'=>'Demo imported successfully. Your NextGen storefront is ready.');
    }


    private function decodeJsonFile($file, &$error) {
        $error = '';
        $raw = @file_get_contents($file);
        if ($raw === false) {
            $error = 'Could not read ' . basename($file);
            return null;
        }
        // Remove UTF-8 BOMs that can be introduced by desktop editors.
        if (substr($raw, 0, 3) === "\xEF\xBB\xBF") $raw = substr($raw, 3);
        $raw = trim($raw);
        $decoded = json_decode($raw, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            $error = json_last_error_msg();
            // PHP 7.2+ can substitute malformed UTF-8 rather than rejecting an otherwise valid structure.
            if (defined('JSON_INVALID_UTF8_SUBSTITUTE')) {
                $decoded = json_decode($raw, true, 512, JSON_INVALID_UTF8_SUBSTITUTE);
                if (json_last_error() === JSON_ERROR_NONE) return $decoded;
            }
            return null;
        }
        return $decoded;
    }



    private function ensureOpenCartThemeSettings($store_id) {
        $store_id=(int)$store_id;
        $settings=array(
            'theme_nextgen_directory'=>'nextgen',
            'theme_nextgen_status'=>'1',
            'theme_nextgen_product_limit'=>'15'
        );
        $this->upsertOpenCartSetting($store_id,'config','config_theme','nextgen');
        foreach($settings as $key=>$value) $this->upsertOpenCartSetting($store_id,'theme_nextgen',$key,$value);
    }

    private function upsertOpenCartSetting($store_id,$code,$key,$value) {
        $q=$this->db->query("SELECT setting_id FROM `".DB_PREFIX."setting` WHERE store_id='".(int)$store_id."' AND code='".$this->db->escape($code)."' AND `key`='".$this->db->escape($key)."' LIMIT 1");
        if($q->num_rows) {
            $this->db->query("UPDATE `".DB_PREFIX."setting` SET value='".$this->db->escape($value)."', serialized='0' WHERE setting_id='".(int)$q->row['setting_id']."'");
        } else {
            $this->db->query("INSERT INTO `".DB_PREFIX."setting` SET store_id='".(int)$store_id."', code='".$this->db->escape($code)."', `key`='".$this->db->escape($key)."', value='".$this->db->escape($value)."', serialized='0'");
        }
    }

    private function normalizeDocument($document) {
        $used=array();
        $walk=function(&$node) use (&$walk,&$used) {
            if(!is_array($node)) return;
            $type=isset($node['type'])?(string)$node['type']:'node';
            if(empty($node['id']) || isset($used[$node['id']])) {
                do { $node['id']=$type.'_'.substr(md5(uniqid('',true)),0,10); } while(isset($used[$node['id']]));
            }
            $used[$node['id']]=true;
            if(!isset($node['settings']) || !is_array($node['settings'])) $node['settings']=array();
            if(in_array($type,array('heading','text','button'),true) && !isset($node['settings']['text']) && isset($node['settings']['content'])) $node['settings']['text']=$node['settings']['content'];
            if(!isset($node['children']) || !is_array($node['children'])) $node['children']=array();
            foreach($node['children'] as &$child) $walk($child);
            unset($child);
        };
        $walk($document);
        return $document;
    }

    private function installRouteDocuments($slug, $manifest, $store_id, $language_id, $home_document, $now) {
        $routes=array(
            'product'=>'product/product',
            'category'=>'product/category',
            'search'=>'product/search',
            'manufacturer'=>'product/manufacturer',
            'information'=>'information/information',
            'cart'=>'checkout/cart',
            'account'=>'account/account',
            '404'=>'error/not_found'
        );
        foreach($routes as $page=>$route) {
            $type=$page==='404'?'404':$page;
            $doc=$this->pageDocument($page,$manifest,$home_document);
            $json=$this->db->escape(json_encode($doc,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE));
            $name=$this->db->escape((isset($manifest['name'])?$manifest['name']:'NextGen').' - '.ucfirst($page));
            $q=$this->db->query("SELECT document_id FROM `".DB_PREFIX."nextgen_builder_document` WHERE route='".$this->db->escape($route)."' AND template_type='".$this->db->escape($type)."' AND store_id='".(int)$store_id."' LIMIT 1");
            if($q->num_rows) {
                $id=(int)$q->row['document_id'];
                $this->db->query("UPDATE `".DB_PREFIX."nextgen_builder_document` SET name='".$name."',status='1',version=version+1,document_json='".$json."',date_modified='".$now."' WHERE document_id='".$id."'");
            } else {
                $this->db->query("INSERT INTO `".DB_PREFIX."nextgen_builder_document` SET store_id='".(int)$store_id."',name='".$name."',route='".$this->db->escape($route)."',template_type='".$this->db->escape($type)."',status='1',version='1',document_json='".$json."',date_added='".$now."',date_modified='".$now."'");
                $id=(int)$this->db->getLastId();
            }
            $this->db->query("INSERT INTO `".DB_PREFIX."nextgen_template_assignment` SET store_id='".(int)$store_id."',language_id='".(int)$language_id."',route='".$this->db->escape($route)."',template_type='".$this->db->escape($type)."',document_id='".$id."',priority='100',status='1',source='demo:".$this->db->escape($slug)."',date_modified='".$now."' ON DUPLICATE KEY UPDATE document_id=VALUES(document_id),priority=VALUES(priority),status=VALUES(status),source=VALUES(source),date_modified=VALUES(date_modified)");
        }
    }

    private function pageDocument($page,$manifest,$home_document) {
        $title=isset($manifest['name'])?$manifest['name']:'NextGen Store';
        $labels=array(
            'product'=>'Product',
            'category'=>'Shop by Category',
            'search'=>'Search Results',
            'manufacturer'=>'Brands',
            'information'=>'Information',
            'cart'=>'Your Cart',
            'account'=>'My Account',
            '404'=>'Page Not Found'
        );
        $heading=isset($labels[$page])?$labels[$page]:ucfirst($page);
        $section=array(
            'type'=>'section',
            'settings'=>array('padding'=>'56px 24px'),
            'children'=>array(
                array(
                    'type'=>'container',
                    'settings'=>array(),
                    'children'=>array(
                        array(
                            'type'=>'column',
                            'settings'=>array(),
                            'children'=>array(
                                array('type'=>'heading','settings'=>array('tag'=>'h1','text'=>$heading),'children'=>array()),
                                array('type'=>'text','settings'=>array('text'=>$title.' — NextGen storefront template.'),'children'=>array())
                            )
                        )
                    )
                )
            )
        );
        if(in_array($page,array('category','search','manufacturer'),true)) {
            $section['children'][0]['children'][0]['children'][]=array('type'=>'product_grid','settings'=>array('limit'=>12,'columns'=>4),'children'=>array());
        } elseif($page==='product') {
            $section['children'][0]['children'][0]['children'][]=array('type'=>'product','settings'=>array(),'children'=>array());
        } elseif($page==='404') {
            $section['children'][0]['children'][0]['children'][]=array('type'=>'button','settings'=>array('text'=>'Back to Store','url'=>'index.php?route=common/home'),'children'=>array());
        }
        return array('type'=>'root','version'=>1,'children'=>array($section));
    }

    private function seedTemplateLibrary($slug, $manifest, $home_document, $store_id = 0) {
        require_once DIR_SYSTEM . 'library/nextgen/template_library.php';
        $library = new NextGenTemplateLibrary($this->db);
        $library->install();
        $pages = isset($manifest['pages']) && is_array($manifest['pages']) ? $manifest['pages'] : array('home');
        foreach ($pages as $page) {
            $page = preg_replace('/[^a-z0-9_-]/', '', strtolower((string)$page));
            if (!$page) continue;
            $document = ($page === 'home') ? $home_document : array('type'=>'root','version'=>1,'children'=>array());
            $template_id=$library->save(
                'demo-' . $slug . '-' . $page,
                (isset($manifest['name']) ? $manifest['name'] . ' - ' : ucfirst($slug) . ' - ') . ucfirst($page),
                'page',
                'demo',
                $document,
                'published',
                '',
                0,
                'Seeded by demo import'
            );
            // Link reusable template to the actual published Builder document so
            // editing the template immediately changes the storefront assignment.
            $route_map=array('home'=>array('common/home','homepage'),'product'=>array('product/product','product'),'category'=>array('product/category','category'),'search'=>array('product/search','search'),'manufacturer'=>array('product/manufacturer','manufacturer'),'information'=>array('information/information','information'),'cart'=>array('checkout/cart','cart'),'account'=>array('account/account','account'),'404'=>array('error/not_found','404'));
            if(isset($route_map[$page])){
                $rm=$route_map[$page];
                $q=$this->db->query("SELECT document_id FROM `".DB_PREFIX."nextgen_builder_document` WHERE route='".$this->db->escape($rm[0])."' AND template_type='".$this->db->escape($rm[1])."' AND store_id='".(int)$store_id."' LIMIT 1");
                if($q->num_rows){ $library->linkBuilderDocument($template_id,(int)$q->row['document_id'],$rm[0],$rm[1],$store_id); }
            }
        }
    }

    private function seedGlobalComponents($slug, $manifest, $home_document) {
        require_once DIR_SYSTEM . 'library/nextgen/global_component_repository.php';
        $repository = new NextGenGlobalComponentRepository($this->db);
        $repository->install();
        $parts = isset($manifest['global_parts']) && is_array($manifest['global_parts']) ? $manifest['global_parts'] : array('header','footer','product-card');
        $definitions = array(
            'announcement' => array('name'=>'Announcement Bar','type'=>'announcement','document'=>array('type'=>'root','version'=>1,'children'=>array())),
            'header' => array('name'=>'Global Header','type'=>'header','document'=>array('type'=>'root','version'=>1,'children'=>array())),
            'footer' => array('name'=>'Global Footer','type'=>'footer','document'=>array('type'=>'root','version'=>1,'children'=>array())),
            'product-card' => array('name'=>'Product Card','type'=>'product-card','document'=>array('type'=>'root','version'=>1,'children'=>array())),
            'newsletter' => array('name'=>'Newsletter','type'=>'newsletter','document'=>array('type'=>'root','version'=>1,'children'=>array())),
            'trust-badges' => array('name'=>'Trust Badges','type'=>'trust-badges','document'=>array('type'=>'root','version'=>1,'children'=>array()))
        );
        foreach ($parts as $part) {
            $part = preg_replace('/[^a-z0-9_-]/', '', strtolower((string)$part));
            if (!$part || !isset($definitions[$part])) continue;
            $d = $definitions[$part];
            $repository->save('demo-' . $slug . '-' . $part, $d['name'], $d['type'], $d['document'], 0);
        }
    }

    private function upsertRuntime($store_id, $key, $value) {
        $q=$this->db->query("SELECT setting_id FROM `" . DB_PREFIX . "nextgen_runtime_setting` WHERE store_id='" . (int)$store_id . "' AND `key`='" . $this->db->escape($key) . "' LIMIT 1");
        $value=$this->db->escape((string)$value);
        if ($q->num_rows) {
            $this->db->query("UPDATE `" . DB_PREFIX . "nextgen_runtime_setting` SET value='" . $value . "', date_modified='" . date('Y-m-d H:i:s') . "' WHERE setting_id='" . (int)$q->row['setting_id'] . "'");
        } else {
            $this->db->query("INSERT INTO `" . DB_PREFIX . "nextgen_runtime_setting` SET store_id='" . (int)$store_id . "', `key`='" . $this->db->escape($key) . "', value='" . $value . "', date_modified='" . date('Y-m-d H:i:s') . "'");
        }
    }
}
