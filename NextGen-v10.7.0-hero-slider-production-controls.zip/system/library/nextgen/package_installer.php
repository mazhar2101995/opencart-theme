<?php
class NextGenPackageInstaller {
    public function plan(array $manifest, array $environment = array()) {
        $actions = array();
        $actions[] = 'validate_manifest';
        $actions[] = 'validate_compatibility';
        $actions[] = 'validate_dependencies';
        $actions[] = 'create_backup';
        $actions[] = 'run_migrations';
        $actions[] = 'install_files';
        $actions[] = 'refresh_caches';
        return array(
            'safe_mode'=>true,
            'actions'=>$actions,
            'rollback_supported'=>true,
            'requires_confirmation'=>true
        );
    }

    public function install(array $manifest, array $environment = array()) {
        return array(
            'status'=>'planned',
            'message'=>'Installer execution is intentionally separated from the planning layer.',
            'manifest'=>$manifest,
            'next_step'=>'Execute only after manifest, compatibility, dependency, checksum and permission checks pass.'
        );
    }
}
