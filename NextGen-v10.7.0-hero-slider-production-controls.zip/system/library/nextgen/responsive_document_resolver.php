<?php
class NextGenResponsiveDocumentResolver {
    public function resolve(array $settings,$device='desktop') {
        if (!is_array($settings)) return $settings;
        if (!isset($settings['responsive']) || !is_array($settings['responsive'])) return $settings;

        $base=$settings;
        unset($base['responsive']);
        $responsive=$settings['responsive'];

        foreach(array('desktop','tablet','mobile') as $candidate) {
            if($candidate===$device && isset($responsive[$candidate]) && is_array($responsive[$candidate])) {
                $base=array_merge($base,$responsive[$candidate]);
            }
        }
        return $base;
    }
}
