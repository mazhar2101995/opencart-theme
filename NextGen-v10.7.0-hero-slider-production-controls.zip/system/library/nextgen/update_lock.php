<?php
class NextGenUpdateLock {
    public function acquire($key) {
        return array('locked'=>true,'key'=>hash('sha256',$key),'expires'=>time()+900);
    }

    public function isExpired(array $lock) {
        return empty($lock['expires']) || $lock['expires'] < time();
    }
}
