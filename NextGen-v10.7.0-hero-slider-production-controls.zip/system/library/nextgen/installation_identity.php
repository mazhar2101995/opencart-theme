<?php
class NextGenInstallationIdentity {
    public function create($domain,$storeId='0') {
        $normalized=strtolower(trim($domain));
        return hash('sha256',$normalized.'|'.$storeId);
    }

    public function validate($installationId,$domain,$storeId='0') {
        return hash_equals($this->create($domain,$storeId),$installationId);
    }
}
