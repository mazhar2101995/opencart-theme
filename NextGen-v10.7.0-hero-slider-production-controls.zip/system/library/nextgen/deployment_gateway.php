<?php
class NextGenDeploymentGateway {
    public function validate(array $plan) {
        $required=array('backup','migration','deployment','verification');
        foreach ($required as $key) {
            if (empty($plan[$key])) return array('valid'=>false,'error'=>"Missing deployment stage: {$key}");
        }
        return array('valid'=>true,'error'=>null);
    }

    public function commitPlan(array $plan) {
        $check=$this->validate($plan);
        if (!$check['valid']) return array('status'=>'blocked','error'=>$check['error']);
        return array('status'=>'ready','requires_confirmation'=>true);
    }
}
