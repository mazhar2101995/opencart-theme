<?php
class NextGenRollbackManager {
    public function createPlan($packageName, $fromVersion, $toVersion) {
        return array(
            'package'=>$packageName,
            'from'=>$fromVersion,
            'to'=>$toVersion,
            'backup_required'=>true,
            'database_snapshot_required'=>true,
            'file_manifest_required'=>true,
            'status'=>'ready_for_review'
        );
    }

    public function canRollback(array $plan) {
        return !empty($plan['backup_required'])
            && !empty($plan['database_snapshot_required'])
            && !empty($plan['file_manifest_required']);
    }
}
