<?php
class NextGenCartRefreshContract {
    public function eventName() {
        return 'nextgen:cart-refresh';
    }

    public function responseShape(array $response) {
        return array(
            'success'=>!empty($response['success']),
            'total'=>isset($response['total'])?$response['total']:null,
            'items'=>isset($response['items'])?$response['items']:null,
            'redirect'=>isset($response['redirect'])?$response['redirect']:null
        );
    }
}
