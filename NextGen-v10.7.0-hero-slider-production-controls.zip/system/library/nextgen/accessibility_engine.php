<?php
/**
 * NextGen Theme Accessibility Engine v2.3
 * Safe server-side helpers for accessible frontend markup.
 */
class NextGenAccessibilityEngine {
    public static function attributes(array $options = array()) {
        $attrs = array();

        if (!empty($options['role'])) {
            $attrs['role'] = $options['role'];
        }

        if (isset($options['label']) && $options['label'] !== '') {
            $attrs['aria-label'] = $options['label'];
        }

        if (isset($options['labelledby']) && $options['labelledby'] !== '') {
            $attrs['aria-labelledby'] = $options['labelledby'];
        }

        if (isset($options['describedby']) && $options['describedby'] !== '') {
            $attrs['aria-describedby'] = $options['describedby'];
        }

        if (isset($options['expanded'])) {
            $attrs['aria-expanded'] = $options['expanded'] ? 'true' : 'false';
        }

        if (isset($options['controls']) && $options['controls'] !== '') {
            $attrs['aria-controls'] = $options['controls'];
        }

        if (isset($options['current']) && $options['current'] !== '') {
            $attrs['aria-current'] = $options['current'];
        }

        if (!empty($options['hidden'])) {
            $attrs['aria-hidden'] = 'true';
        }

        return $attrs;
    }

    public static function renderAttributes(array $attrs) {
        $html = '';
        foreach ($attrs as $key => $value) {
            $html .= ' ' . htmlspecialchars($key, ENT_QUOTES, 'UTF-8')
                . '="' . htmlspecialchars($value, ENT_QUOTES, 'UTF-8') . '"';
        }
        return $html;
    }
}
