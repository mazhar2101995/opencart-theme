<?php
class NextGenRuntimePipeline {
    private $stages=array();

    public function addStage($name,$callable) {
        $this->stages[$name]=$callable;
    }

    public function stages() {
        return array_keys($this->stages);
    }

    public function run(array $payload) {
        $result=$payload;

        foreach ($this->stages as $name=>$callable) {
            if (!is_callable($callable)) {
                return array('status'=>'failed','stage'=>$name,'error'=>'Runtime stage is not callable.');
            }

            $result=call_user_func($callable,$result);

            if (!is_array($result)) {
                return array('status'=>'failed','stage'=>$name,'error'=>'Runtime stage must return an array.');
            }

            if (isset($result['runtime_error'])) {
                return array('status'=>'failed','stage'=>$name,'error'=>$result['runtime_error']);
            }
        }

        $result['status']='render_ready';
        return $result;
    }
}
