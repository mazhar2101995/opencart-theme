<?php
function nextgen_register_header_widgets(&$registry) {
    if (!class_exists('NextGenHeaderSchema')) {
        require_once DIR_SYSTEM . 'library/nextgen/header_schema.php';
    }
    foreach (NextGenHeaderSchema::widgets() as $id => $definition) {
        $registry[$id] = $definition;
        $registry[$id]['controls'] = NextGenHeaderSchema::controls($id);
    }
}
