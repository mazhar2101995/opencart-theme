<?php
/**
 * NextGen Theme - SEO Engine v2.1
 * Server-side SEO metadata and structured-data foundation.
 * OpenCart event-compatible; does not replace OpenCart controllers.
 */
class NextGenSeoEngine {
    private $config;
    private $url;

    public function __construct($registry) {
        $this->config = $registry->get('config');
        $this->url = $registry->get('url');
    }

    public function build(array $context = array()) {
        $route = isset($context['route']) ? $context['route'] : '';
        $data = isset($context['seo']) && is_array($context['seo']) ? $context['seo'] : array();

        $title = $this->renderTemplate(
            isset($data['title_template']) ? $data['title_template'] : '',
            $context
        );
        $description = $this->renderTemplate(
            isset($data['description_template']) ? $data['description_template'] : '',
            $context
        );

        if ($title === '' && isset($data['title'])) $title = $data['title'];
        if ($description === '' && isset($data['description'])) $description = $data['description'];

        $canonical = isset($data['canonical']) && $data['canonical']
            ? $data['canonical']
            : $this->currentUrl();

        $robots = $this->robots($data);
        $og = $this->openGraph($context, $title, $description, $canonical);
        $twitter = $this->twitter($context, $title, $description);
        $structured = $this->structuredData($context);

        return array(
            'route' => $route,
            'title' => $title,
            'description' => $description,
            'canonical' => $canonical,
            'robots' => $robots,
            'og' => $og,
            'twitter' => $twitter,
            'structured_data' => $structured
        );
    }

    private function renderTemplate($template, array $context) {
        if (!$template) return '';
        $flat = $this->flatten($context);
        return preg_replace_callback('/\{\{\s*([a-zA-Z0-9_.-]+)\s*\}\}/', function($m) use ($flat) {
            $key = $m[1];
            return isset($flat[$key]) ? trim(strip_tags((string)$flat[$key])) : '';
        }, $template);
    }

    private function flatten(array $data, $prefix = '') {
        $out = array();
        foreach ($data as $key => $value) {
            $name = $prefix ? $prefix . '.' . $key : $key;
            if (is_array($value)) {
                $out = array_merge($out, $this->flatten($value, $name));
            } else {
                $out[$name] = $value;
            }
        }
        return $out;
    }

    private function robots(array $data) {
        if (isset($data['robots']) && is_string($data['robots']) && $data['robots'] !== '') {
            return $data['robots'];
        }
        if (isset($data['noindex']) && $data['noindex']) {
            return 'noindex,follow';
        }
        return 'index,follow';
    }

    private function currentUrl() {
        if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
            $scheme = 'https://';
        } else {
            $scheme = 'http://';
        }
        $host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '';
        $uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '/';
        return $scheme . $host . $uri;
    }

    private function openGraph(array $context, $title, $description, $canonical) {
        return array(
            'og:type' => isset($context['seo']['og_type']) ? $context['seo']['og_type'] : 'website',
            'og:title' => $title,
            'og:description' => $description,
            'og:url' => $canonical,
            'og:site_name' => isset($context['store']['name']) ? $context['store']['name'] : ''
        );
    }

    private function twitter(array $context, $title, $description) {
        return array(
            'twitter:card' => isset($context['seo']['twitter_card']) ? $context['seo']['twitter_card'] : 'summary_large_image',
            'twitter:title' => $title,
            'twitter:description' => $description
        );
    }

    private function structuredData(array $context) {
        $items = array();
        if (isset($context['structured_data']) && is_array($context['structured_data'])) {
            foreach ($context['structured_data'] as $item) {
                if (is_array($item) && isset($item['@type'])) $items[] = $item;
            }
        }
        return $items;
    }
}
