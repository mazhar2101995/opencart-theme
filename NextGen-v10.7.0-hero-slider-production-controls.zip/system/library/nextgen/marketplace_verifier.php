<?php
class NextGenMarketplaceVerifier {
    public function verify(array $manifest,array $license=array(),array $signature=array()) {
        $errors=array();

        if (empty($manifest['name']) || empty($manifest['version'])) {
            $errors[]='Manifest identity missing.';
        }

        if (!empty($signature) && empty($signature['valid'])) {
            $errors[]='Package signature is invalid.';
        }

        if (!empty($license) && empty($license['valid'])) {
            $errors[]='License is not active for this installation.';
        }

        return array(
            'verified'=>empty($errors),
            'errors'=>$errors
        );
    }
}
