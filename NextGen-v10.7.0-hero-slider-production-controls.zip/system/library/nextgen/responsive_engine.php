<?php
/**
 * Responsive value resolver.
 */
class NextGenResponsiveEngine {
    public static function resolve($value, $device = 'desktop', $fallback = null) {
        if (!is_array($value)) {
            return $value !== null ? $value : $fallback;
        }

        if (isset($value[$device]) && $value[$device] !== '') {
            return $value[$device];
        }

        $fallbackOrder = array(
            'mobile' => array('tablet', 'desktop'),
            'tablet' => array('desktop', 'mobile'),
            'desktop' => array('tablet', 'mobile')
        );

        foreach ($fallbackOrder[$device] as $candidate) {
            if (isset($value[$candidate]) && $value[$candidate] !== '') {
                return $value[$candidate];
            }
        }

        return $fallback;
    }
}
