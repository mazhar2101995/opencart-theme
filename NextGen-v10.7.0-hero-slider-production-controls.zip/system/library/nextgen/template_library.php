<?php
class NextGenTemplateLibrary {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function install() {
        $this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "nextgen_template` (
            `template_id` INT(11) NOT NULL AUTO_INCREMENT,
            `template_key` VARCHAR(120) NOT NULL,
            `name` VARCHAR(255) NOT NULL,
            `type` VARCHAR(50) NOT NULL DEFAULT 'page',
            `category` VARCHAR(100) NOT NULL DEFAULT 'general',
            `status` VARCHAR(30) NOT NULL DEFAULT 'draft',
            `version` INT(11) NOT NULL DEFAULT 1,
            `preview_image` VARCHAR(500) NOT NULL DEFAULT '',
            `route` VARCHAR(191) NOT NULL DEFAULT '',
            `template_type` VARCHAR(64) NOT NULL DEFAULT 'page',
            `store_id` INT(11) NOT NULL DEFAULT 0,
            `builder_document_id` INT(11) NOT NULL DEFAULT 0,
            `document_json` LONGTEXT NOT NULL,
            `date_added` DATETIME NOT NULL,
            `date_modified` DATETIME NOT NULL,
            PRIMARY KEY (`template_id`),
            UNIQUE KEY `template_key` (`template_key`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $this->ensureColumns();

        $this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "nextgen_template_revision` (
            `revision_id` INT(11) NOT NULL AUTO_INCREMENT,
            `template_id` INT(11) NOT NULL,
            `version` INT(11) NOT NULL,
            `document_json` LONGTEXT NOT NULL,
            `created_by` INT(11) NOT NULL DEFAULT 0,
            `note` VARCHAR(500) NOT NULL DEFAULT '',
            `date_added` DATETIME NOT NULL,
            PRIMARY KEY (`revision_id`),
            KEY `template_id` (`template_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $this->repairBuilderLinks();
    }

    private function ensureColumns() {
        $columns = array(
            'route' => "ALTER TABLE `" . DB_PREFIX . "nextgen_template` ADD `route` VARCHAR(191) NOT NULL DEFAULT '' AFTER `preview_image`",
            'template_type' => "ALTER TABLE `" . DB_PREFIX . "nextgen_template` ADD `template_type` VARCHAR(64) NOT NULL DEFAULT 'page' AFTER `route`",
            'store_id' => "ALTER TABLE `" . DB_PREFIX . "nextgen_template` ADD `store_id` INT(11) NOT NULL DEFAULT 0 AFTER `template_type`",
            'builder_document_id' => "ALTER TABLE `" . DB_PREFIX . "nextgen_template` ADD `builder_document_id` INT(11) NOT NULL DEFAULT 0 AFTER `store_id`"
        );
        foreach ($columns as $name => $sql) {
            $q = $this->db->query("SHOW COLUMNS FROM `" . DB_PREFIX . "nextgen_template` LIKE '" . $this->db->escape($name) . "'");
            if (!$q->num_rows) $this->db->query($sql);
        }
    }

    private function repairBuilderLinks() {
        $q=$this->db->query("SELECT template_id, template_key, route, template_type, store_id FROM `".DB_PREFIX."nextgen_template` WHERE builder_document_id='0' OR builder_document_id IS NULL");
        $map=array('home'=>array('common/home','homepage'),'product'=>array('product/product','product'),'category'=>array('product/category','category'),'search'=>array('product/search','search'),'manufacturer'=>array('product/manufacturer','manufacturer'),'information'=>array('information/information','information'),'cart'=>array('checkout/cart','cart'),'account'=>array('account/account','account'),'404'=>array('error/not_found','404'));
        foreach($q->rows as $row){
            $key=(string)$row['template_key']; $page='';
            foreach(array_keys($map) as $candidate){ if(preg_match('/-'.preg_quote($candidate,'/').'$/',$key)){ $page=$candidate; break; } }
            if(!$page) continue; $rm=$map[$page];
            $b=$this->db->query("SELECT document_id FROM `".DB_PREFIX."nextgen_builder_document` WHERE route='".$this->db->escape($rm[0])."' AND template_type='".$this->db->escape($rm[1])."' AND store_id='".(int)$row['store_id']."' ORDER BY document_id DESC LIMIT 1");
            if($b->num_rows) $this->linkBuilderDocument((int)$row['template_id'],(int)$b->row['document_id'],$rm[0],$rm[1],(int)$row['store_id']);
        }
    }

    public function getById($template_id) {
        $q = $this->db->query("SELECT * FROM `" . DB_PREFIX . "nextgen_template` WHERE template_id='" . (int)$template_id . "' LIMIT 1");
        if (!$q->num_rows) return null;
        $row = $q->row;
        $row['document'] = json_decode($row['document_json'], true);
        return $row;
    }

    public function saveById($template_id, $document, $user_id = 0, $note = '') {
        $current = $this->getById($template_id);
        if (!$current) return array('success'=>false,'error'=>'Template not found.');
        $id = $this->save($current['template_key'], $current['name'], $current['type'], $current['category'], $document, $current['status'], $current['preview_image'], $user_id, $note);
        $this->syncBuilderDocument($id);
        return array('success'=>true,'template_id'=>(int)$id,'version'=>(int)$this->getById($id)['version']);
    }

    public function setStatus($template_id, $status) {
        $status = in_array($status, array('draft','published','archived'), true) ? $status : 'draft';
        $this->db->query("UPDATE `" . DB_PREFIX . "nextgen_template` SET status='" . $this->db->escape($status) . "', date_modified='" . date('Y-m-d H:i:s') . "' WHERE template_id='" . (int)$template_id . "'");
        return true;
    }

    public function duplicate($template_id, $user_id = 0) {
        $row=$this->getById($template_id);
        if (!$row) return 0;
        $key=$row['template_key'].'-copy-'.substr(md5(uniqid('',true)),0,6);
        return $this->save($key, $row['name'].' Copy', $row['type'], $row['category'], $row['document'], 'draft', $row['preview_image'], $user_id, 'Duplicated template');
    }

    public function delete($template_id) {
        $row=$this->getById($template_id);
        if (!$row) return false;
        $this->db->query("DELETE FROM `" . DB_PREFIX . "nextgen_template_revision` WHERE template_id='" . (int)$template_id . "'");
        $this->db->query("DELETE FROM `" . DB_PREFIX . "nextgen_template` WHERE template_id='" . (int)$template_id . "'");
        return true;
    }

    public function linkBuilderDocument($template_id, $document_id, $route='', $template_type='page', $store_id=0) {
        $this->db->query("UPDATE `" . DB_PREFIX . "nextgen_template` SET builder_document_id='" . (int)$document_id . "', route='" . $this->db->escape($route) . "', template_type='" . $this->db->escape($template_type) . "', store_id='" . (int)$store_id . "', date_modified='" . date('Y-m-d H:i:s') . "' WHERE template_id='" . (int)$template_id . "'");
        return true;
    }

    private function syncBuilderDocument($template_id) {
        $row=$this->getById($template_id);
        if (!$row || empty($row['builder_document_id'])) return;
        $json=$this->db->escape(json_encode($row['document'], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE));
        $this->db->query("UPDATE `" . DB_PREFIX . "nextgen_builder_document` SET document_json='" . $json . "', version=version+1, status='1', date_modified='" . date('Y-m-d H:i:s') . "' WHERE document_id='" . (int)$row['builder_document_id'] . "'");
    }

    public function save($key, $name, $type, $category, $document, $status = 'draft', $preview = '', $user_id = 0, $note = '') {
        $now = date('Y-m-d H:i:s');
        $json = is_string($document) ? $document : json_encode($document, JSON_UNESCAPED_SLASHES);

        $query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "nextgen_template`
            WHERE `template_key`='" . $this->db->escape($key) . "' LIMIT 1");

        if ($query->num_rows) {
            $template_id = (int)$query->row['template_id'];
            $version = (int)$query->row['version'] + 1;

            $this->db->query("UPDATE `" . DB_PREFIX . "nextgen_template`
                SET `name`='" . $this->db->escape($name) . "',
                    `type`='" . $this->db->escape($type) . "',
                    `category`='" . $this->db->escape($category) . "',
                    `status`='" . $this->db->escape($status) . "',
                    `version`='" . $version . "',
                    `preview_image`='" . $this->db->escape($preview) . "',
                    `document_json`='" . $this->db->escape($json) . "',
                    `date_modified`='" . $now . "'
                WHERE `template_id`='" . $template_id . "'");

            $this->db->query("INSERT INTO `" . DB_PREFIX . "nextgen_template_revision`
                SET `template_id`='" . $template_id . "',
                    `version`='" . $version . "',
                    `document_json`='" . $this->db->escape($json) . "',
                    `created_by`='" . (int)$user_id . "',
                    `note`='" . $this->db->escape($note) . "',
                    `date_added`='" . $now . "'");

            return $template_id;
        }

        $this->db->query("INSERT INTO `" . DB_PREFIX . "nextgen_template`
            SET `template_key`='" . $this->db->escape($key) . "',
                `name`='" . $this->db->escape($name) . "',
                `type`='" . $this->db->escape($type) . "',
                `category`='" . $this->db->escape($category) . "',
                `status`='" . $this->db->escape($status) . "',
                `version`='1',
                `preview_image`='" . $this->db->escape($preview) . "',
                `document_json`='" . $this->db->escape($json) . "',
                `date_added`='" . $now . "',
                `date_modified`='" . $now . "'");

        $template_id = $this->db->getLastId();

        $this->db->query("INSERT INTO `" . DB_PREFIX . "nextgen_template_revision`
            SET `template_id`='" . $template_id . "',
                `version`='1',
                `document_json`='" . $this->db->escape($json) . "',
                `created_by`='" . (int)$user_id . "',
                `note`='" . $this->db->escape($note) . "',
                `date_added`='" . $now . "'");

        return $template_id;
    }

    public function get($key) {
        $query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "nextgen_template`
            WHERE `template_key`='" . $this->db->escape($key) . "' LIMIT 1");

        if (!$query->num_rows) return null;

        $row = $query->row;
        $row['document'] = json_decode($row['document_json'], true);
        return $row;
    }

    public function list($type = '', $category = '', $status = '') {
        $where = [];

        if ($type !== '') $where[] = "`type`='" . $this->db->escape($type) . "'";
        if ($category !== '') $where[] = "`category`='" . $this->db->escape($category) . "'";
        if ($status !== '') $where[] = "`status`='" . $this->db->escape($status) . "'";

        $sql = "SELECT * FROM `" . DB_PREFIX . "nextgen_template`";
        if ($where) $sql .= " WHERE " . implode(' AND ', $where);
        $sql .= " ORDER BY `date_modified` DESC";

        return $this->db->query($sql)->rows;
    }

    public function revisions($template_id) {
        return $this->db->query("SELECT * FROM `" . DB_PREFIX . "nextgen_template_revision`
            WHERE `template_id`='" . (int)$template_id . "'
            ORDER BY `version` DESC")->rows;
    }

    public function restore($template_id, $revision_id, $user_id = 0) {
        $revision = $this->db->query("SELECT * FROM `" . DB_PREFIX . "nextgen_template_revision`
            WHERE `revision_id`='" . (int)$revision_id . "'
            AND `template_id`='" . (int)$template_id . "' LIMIT 1");

        if (!$revision->num_rows) return false;

        $current = $this->db->query("SELECT * FROM `" . DB_PREFIX . "nextgen_template`
            WHERE `template_id`='" . (int)$template_id . "' LIMIT 1");

        if (!$current->num_rows) return false;

        $version = (int)$current->row['version'] + 1;
        $now = date('Y-m-d H:i:s');
        $json = $revision->row['document_json'];

        $this->db->query("UPDATE `" . DB_PREFIX . "nextgen_template`
            SET `version`='" . $version . "',
                `document_json`='" . $this->db->escape($json) . "',
                `status`='draft',
                `date_modified`='" . $now . "'
            WHERE `template_id`='" . (int)$template_id . "'");

        $this->db->query("INSERT INTO `" . DB_PREFIX . "nextgen_template_revision`
            SET `template_id`='" . (int)$template_id . "',
                `version`='" . $version . "',
                `document_json`='" . $this->db->escape($json) . "',
                `created_by`='" . (int)$user_id . "',
                `note`='Restored from revision " . (int)$revision->row['version'] . "',
                `date_added`='" . $now . "'");

        return true;
    }
}
