<?php
class NextGenHreflangManager {
    public static function render(array $alternates) {
        $html = '';
        foreach ($alternates as $alternate) {
            if (!is_array($alternate) || empty($alternate['hreflang']) || empty($alternate['href'])) continue;
            $lang = htmlspecialchars($alternate['hreflang'], ENT_QUOTES, 'UTF-8');
            $href = htmlspecialchars($alternate['href'], ENT_QUOTES, 'UTF-8');
            $html .= '<link rel="alternate" hreflang="' . $lang . '" href="' . $href . '">' . "\n";
        }
        return $html;
    }
}
