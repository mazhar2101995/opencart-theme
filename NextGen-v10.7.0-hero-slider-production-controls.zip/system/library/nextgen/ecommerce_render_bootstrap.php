<?php
class NextGenEcommerceRenderBootstrap {
    public function register($registry,$adapter=null) {
        $renderer=new NextGenEcommerceWidgetRenderers($adapter);
        $renderer->register($registry);
        return $registry;
    }
}
