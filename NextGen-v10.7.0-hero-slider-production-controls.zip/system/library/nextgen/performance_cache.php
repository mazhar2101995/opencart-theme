<?php
/**
 * Lightweight file-cache adapter for public, context-safe rendered fragments.
 * Do not cache customer-specific or session-specific output.
 */
class NextGenPerformanceCache {
    private $directory;

    public function __construct($directory) {
        $this->directory = rtrim($directory, '/\\');
        if (!is_dir($this->directory)) @mkdir($this->directory, 0755, true);
    }

    public function get($key, $ttl = 300) {
        $file = $this->file($key);
        if (!is_file($file)) return false;
        if ((time() - filemtime($file)) > $ttl) return false;
        return file_get_contents($file);
    }

    public function set($key, $value) {
        $file = $this->file($key);
        return (bool)file_put_contents($file, $value, LOCK_EX);
    }

    public function delete($key) {
        $file = $this->file($key);
        return is_file($file) ? @unlink($file) : true;
    }

    private function file($key) {
        return $this->directory . '/' . preg_replace('/[^a-zA-Z0-9_.-]/', '_', $key) . '.cache';
    }
}
