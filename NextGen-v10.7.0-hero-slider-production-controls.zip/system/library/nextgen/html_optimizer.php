<?php
class NextGenHtmlOptimizer {
    public function optimize($html) {
        if (!is_string($html) || $html === '') return $html;

        // Conservative production optimization:
        // remove HTML comments except conditional comments and normalize repeated whitespace.
        $html = preg_replace('/<!--(?!\[if).*?-->/s', '', $html);
        $html = preg_replace('/>\s+</', '><', $html);

        return trim($html);
    }
}
