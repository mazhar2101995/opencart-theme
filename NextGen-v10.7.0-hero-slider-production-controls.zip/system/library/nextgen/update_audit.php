<?php
class NextGenUpdateAudit {
    private $db;

    public function __construct($db) { $this->db=$db; }

    public function installSchema() {
        $this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "nextgen_update_audit` (
            `audit_id` INT(11) NOT NULL AUTO_INCREMENT,
            `package_name` VARCHAR(128) NOT NULL,
            `from_version` VARCHAR(32) DEFAULT NULL,
            `to_version` VARCHAR(32) DEFAULT NULL,
            `action` VARCHAR(64) NOT NULL,
            `status` VARCHAR(32) NOT NULL,
            `message` TEXT,
            `user_id` INT(11) DEFAULT NULL,
            `date_added` DATETIME NOT NULL,
            PRIMARY KEY (`audit_id`),
            KEY `package_name` (`package_name`),
            KEY `date_added` (`date_added`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    }

    public function record($package,$from,$to,$action,$status,$message='',$userId=null) {
        $this->db->query("INSERT INTO `" . DB_PREFIX . "nextgen_update_audit`
            SET package_name='" . $this->db->escape($package) . "',
                from_version='" . $this->db->escape($from) . "',
                to_version='" . $this->db->escape($to) . "',
                action='" . $this->db->escape($action) . "',
                status='" . $this->db->escape($status) . "',
                message='" . $this->db->escape($message) . "',
                user_id=" . ($userId === null ? "NULL" : (int)$userId) . ",
                date_added=NOW()");
    }
}
