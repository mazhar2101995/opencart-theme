<?php
class NextGenStorefrontShellRenderer {
    public function render(array $data=array()) {
        $name=isset($data['store_name'])?$data['store_name']:'Store';
        $home=isset($data['home'])?$data['home']:'/';
        $logo=isset($data['logo'])?$data['logo']:'';

        $html='<header class="ng-storefront-header">';
        $html.='<div class="ng-storefront-header__inner">';
        $html.='<a class="ng-storefront-logo" href="'.htmlspecialchars($home,ENT_QUOTES,'UTF-8').'">';
        if($logo) $html.='<img src="'.htmlspecialchars($logo,ENT_QUOTES,'UTF-8').'" alt="'.htmlspecialchars($name,ENT_QUOTES,'UTF-8').'">';
        else $html.=htmlspecialchars($name,ENT_QUOTES,'UTF-8');
        $html.='</a>';

        $html.='<nav class="ng-storefront-nav" aria-label="Main navigation">';
        $html.='<ul>';
        foreach(isset($data['menu'])?$data['menu']:array() as $item) {
            if(!is_array($item)) continue;
            $html.=$this->renderItem($item);
        }
        $html.='</ul></nav>';

        $html.='<div class="ng-storefront-actions">';
        $html.='<a href="'.htmlspecialchars(isset($data['account']['href'])?$data['account']['href']:'#',ENT_QUOTES,'UTF-8').'">Account</a>';
        $html.='<a href="'.htmlspecialchars(isset($data['wishlist'])?$data['wishlist']:'#',ENT_QUOTES,'UTF-8').'">Wishlist</a>';
        $html.='<a href="'.htmlspecialchars(isset($data['compare'])?$data['compare']:'#',ENT_QUOTES,'UTF-8').'">Compare</a>';
        $html.='<a href="'.htmlspecialchars(isset($data['cart']['href'])?$data['cart']['href']:'#',ENT_QUOTES,'UTF-8').'">Cart';
        if(isset($data['cart']['total'])) $html.=' <span>'.htmlspecialchars($data['cart']['total'],ENT_QUOTES,'UTF-8').'</span>';
        $html.='</a></div>';

        $html.='</div></header>';
        return $html;
    }

    protected function renderItem(array $item) {
        $name=isset($item['name'])?$item['name']:'';
        $href=isset($item['href'])?$item['href']:'#';
        $children=isset($item['children'])&&is_array($item['children'])?$item['children']:array();
        $class=$children?' class="has-children"':'';

        $html='<li'.$class.'><a href="'.htmlspecialchars($href,ENT_QUOTES,'UTF-8').'">'.htmlspecialchars($name,ENT_QUOTES,'UTF-8').'</a>';
        if($children) {
            $html.='<div class="ng-mega-menu"><div class="ng-mega-menu__grid">';
            foreach($children as $child) {
                if(!is_array($child)) continue;
                $html.='<a href="'.htmlspecialchars(isset($child['href'])?$child['href']:'#',ENT_QUOTES,'UTF-8').'">'.htmlspecialchars(isset($child['name'])?$child['name']:'',ENT_QUOTES,'UTF-8').'</a>';
            }
            $html.='</div></div>';
        }
        return $html.'</li>';
    }
}
