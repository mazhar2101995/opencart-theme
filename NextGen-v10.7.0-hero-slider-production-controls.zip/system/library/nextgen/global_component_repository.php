<?php
class NextGenGlobalComponentRepository {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function install() {
        $this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "nextgen_global_component` (
            `component_id` INT(11) NOT NULL AUTO_INCREMENT,
            `component_key` VARCHAR(100) NOT NULL,
            `name` VARCHAR(255) NOT NULL,
            `type` VARCHAR(50) NOT NULL DEFAULT 'global',
            `status` TINYINT(1) NOT NULL DEFAULT 1,
            `version` INT(11) NOT NULL DEFAULT 1,
            `document_json` LONGTEXT NOT NULL,
            `date_added` DATETIME NOT NULL,
            `date_modified` DATETIME NOT NULL,
            PRIMARY KEY (`component_id`),
            UNIQUE KEY `component_key` (`component_key`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "nextgen_global_component_revision` (
            `revision_id` INT(11) NOT NULL AUTO_INCREMENT,
            `component_id` INT(11) NOT NULL,
            `version` INT(11) NOT NULL,
            `document_json` LONGTEXT NOT NULL,
            `created_by` INT(11) NOT NULL DEFAULT 0,
            `date_added` DATETIME NOT NULL,
            PRIMARY KEY (`revision_id`),
            KEY `component_id` (`component_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    }

    public function getById($id) {
        $q=$this->db->query("SELECT * FROM `".DB_PREFIX."nextgen_global_component` WHERE component_id='".(int)$id."' LIMIT 1");
        if(!$q->num_rows) return null;
        $row=$q->row; $row['document']=json_decode($row['document_json'],true); return $row;
    }

    public function saveById($id,$document,$user_id=0) {
        $row=$this->getById($id); if(!$row) return array('success'=>false,'error'=>'Global component not found.');
        $new=$this->save($row['component_key'],$row['name'],$row['type'],$document,$user_id);
        return array('success'=>true,'component_id'=>(int)$new,'version'=>(int)$this->getById($new)['version']);
    }

    public function save($key, $name, $type, $document_json, $user_id = 0) {
        $now = date('Y-m-d H:i:s');
        $encoded = is_string($document_json) ? $document_json : json_encode($document_json);

        $existing = $this->db->query("SELECT * FROM `" . DB_PREFIX . "nextgen_global_component`
            WHERE `component_key` = '" . $this->db->escape($key) . "' LIMIT 1");

        if ($existing->num_rows) {
            $component_id = (int)$existing->row['component_id'];
            $version = (int)$existing->row['version'] + 1;

            $this->db->query("UPDATE `" . DB_PREFIX . "nextgen_global_component`
                SET `name`='" . $this->db->escape($name) . "',
                    `type`='" . $this->db->escape($type) . "',
                    `version`='" . $version . "',
                    `document_json`='" . $this->db->escape($encoded) . "',
                    `date_modified`='" . $now . "'
                WHERE `component_id`='" . $component_id . "'");

            $this->db->query("INSERT INTO `" . DB_PREFIX . "nextgen_global_component_revision`
                SET `component_id`='" . $component_id . "',
                    `version`='" . $version . "',
                    `document_json`='" . $this->db->escape($encoded) . "',
                    `created_by`='" . (int)$user_id . "',
                    `date_added`='" . $now . "'");

            return $component_id;
        }

        $this->db->query("INSERT INTO `" . DB_PREFIX . "nextgen_global_component`
            SET `component_key`='" . $this->db->escape($key) . "',
                `name`='" . $this->db->escape($name) . "',
                `type`='" . $this->db->escape($type) . "',
                `document_json`='" . $this->db->escape($encoded) . "',
                `date_added`='" . $now . "',
                `date_modified`='" . $now . "'");

        return $this->db->getLastId();
    }

    public function get($key) {
        $query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "nextgen_global_component`
            WHERE `component_key`='" . $this->db->escape($key) . "'
            AND `status`=1 LIMIT 1");

        if (!$query->num_rows) {
            return null;
        }

        $row = $query->row;
        $row['document'] = json_decode($row['document_json'], true);
        return $row;
    }

    public function list() {
        $query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "nextgen_global_component`
            ORDER BY `name` ASC");
        return $query->rows;
    }
}
