<?php
class NextGenSeoRuntimeBridge {
    private $seo;

    public function __construct($seo) { $this->seo=$seo; }

    public function build(array $context=array()) {
        if(!$this->seo || !method_exists($this->seo,'build')) return array();
        return $this->seo->build($context);
    }
}
