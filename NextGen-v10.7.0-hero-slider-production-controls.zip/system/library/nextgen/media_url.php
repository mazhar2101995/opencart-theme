<?php
/** Normalize OpenCart Image Manager values to public /image/ URLs. */
class NextGenMediaUrl {
    public static function url($value, $base = '') {
        $value = trim((string)$value);
        if ($value === '') return '';
        if (strpos($value, 'data:') === 0) return $value;

        if ($base === '') {
            if (defined('HTTPS_SERVER') && HTTPS_SERVER !== '') $base = HTTPS_SERVER;
            elseif (defined('HTTP_SERVER') && HTTP_SERVER !== '') $base = HTTP_SERVER;
        }
        $base = rtrim((string)$base, '/');

        // Already-correct absolute or root-relative image URL.
        if (preg_match('#^(https?:)?//#i', $value)) {
            if (preg_match('#^(.+?)/image/catalog/(.+)$#i', $value, $m)) return $m[1].'/image/catalog/'.$m[2];
            if (preg_match('#^(.+?)/catalog/(?!view/)(.+)$#i', $value, $m)) return $m[1].'/image/catalog/'.$m[2];
            return $value;
        }
        if (preg_match('#^/image/catalog/#i', $value)) return $base.$value;
        if (preg_match('#^image/catalog/#i', $value)) return $base.'/'.$value;
        if (preg_match('#^/catalog/view/theme/#i', $value)) return $base.$value;
        if (preg_match('#^catalog/view/theme/#i', $value)) return $base.'/'.$value;
        if (preg_match('#^/?catalog/(.+)$#i', $value, $m)) return $base.'/image/catalog/'.$m[1];
        if (preg_match('#^/?theme/(.+)$#i', $value, $m)) return $base.'/image/catalog/'.$m[1];
        if (preg_match('#^/?cache/(.+)$#i', $value, $m)) return $base.'/image/cache/'.$m[1];
        if (strpos($value, '/') === 0) return $base.'/image/'.ltrim($value,'/');
        return $base.'/image/catalog/'.ltrim($value,'/');
    }
}
