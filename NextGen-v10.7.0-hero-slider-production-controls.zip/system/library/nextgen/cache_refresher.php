<?php
class NextGenCacheRefresher {
    public function plan(array $areas) {
        $allowed=array('theme','template','modification','twig','image','nextgen');
        $refresh=array();

        foreach ($areas as $area) {
            if (in_array($area,$allowed,true)) $refresh[]=$area;
        }

        return array(
            'status'=>'planned',
            'areas'=>array_values(array_unique($refresh))
        );
    }

    public function result(array $areas,$success=true) {
        return array(
            'status'=>$success ? 'refreshed' : 'failed',
            'areas'=>$areas
        );
    }
}
