<?php
class NextGenTestReport {
    public static function toHtml(array $report) {
        $status = htmlspecialchars(
            isset($report['status']) ? $report['status'] : 'unknown',
            ENT_QUOTES,
            'UTF-8'
        );

        $html = '<div class="nextgen-test-report">';
        $html .= '<h2>NextGen Test Report: ' . $status . '</h2>';

        if (!empty($report['summary'])) {
            $html .= '<p>Passed: ' . (int)$report['summary']['passed']
                . ' | Warnings: ' . (int)$report['summary']['warnings']
                . ' | Failed: ' . (int)$report['summary']['failed'] . '</p>';
        }

        if (!empty($report['tests'])) {
            $html .= '<ul>';
            foreach ($report['tests'] as $test) {
                $html .= '<li><strong>' .
                    htmlspecialchars($test['status'], ENT_QUOTES, 'UTF-8') .
                    '</strong> ' .
                    htmlspecialchars($test['name'], ENT_QUOTES, 'UTF-8') .
                    ': ' .
                    htmlspecialchars($test['message'], ENT_QUOTES, 'UTF-8') .
                    '</li>';
            }
            $html .= '</ul>';
        }

        return $html . '</div>';
    }
}
