<?php
class NextGenProductionAssetBridge {
    private $collector;

    public function __construct($collector) {
        $this->collector=$collector;
    }

    public function collectFromResult(array $result) {
        if (!$this->collector) return;

        if (!empty($result['assets']['css'])) {
            foreach ($result['assets']['css'] as $url) $this->collector->addCss($url);
        }
        if (!empty($result['assets']['js'])) {
            foreach ($result['assets']['js'] as $url) $this->collector->addJs($url);
        }
        if (!empty($result['assets']['preload'])) {
            foreach ($result['assets']['preload'] as $item) {
                if (is_array($item)) {
                    $this->collector->addPreload(
                        isset($item['url']) ? $item['url'] : '',
                        isset($item['as']) ? $item['as'] : ''
                    );
                }
            }
        }
    }
}
