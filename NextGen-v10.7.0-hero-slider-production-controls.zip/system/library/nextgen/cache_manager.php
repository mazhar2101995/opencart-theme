<?php
class NextGenCacheManager {
    public function planRefresh(array $areas=array()) {
        $allowed=array('theme','template','modification','twig','image','nextgen');
        $refresh=array();
        foreach ($areas as $area) {
            if (in_array($area,$allowed,true)) $refresh[]=$area;
        }
        return array(
            'areas'=>array_values(array_unique($refresh)),
            'required'=>!empty($refresh)
        );
    }
}
