<?php
/**
 * Event-based presentation bridge.
 * Does not modify OpenCart core files and does not use OCMOD/VQMOD.
 */
class NextGenEventPresentationBridge {
    protected $runtime;
    protected $assignment;
    protected $fallback;

    public function __construct($runtime=null,$assignment=null,$fallback=null) {
        $this->runtime=$runtime;
        $this->assignment=$assignment;
        $this->fallback=$fallback;
    }

    public function register(array $events=array()) {
        $registered=array();
        foreach($events as $event) {
            if(!$event) continue;
            $registered[$event]=true;
        }
        return array_keys($registered);
    }

    public function presentationBoundary(array $context=array()) {
        return array(
            'route'=>isset($context['route'])?$context['route']:'',
            'template_type'=>isset($context['template_type'])?$context['template_type']:'',
            'nextgen_enabled'=>!empty($context['nextgen_enabled']),
            'fallback_allowed'=>true
        );
    }
}
