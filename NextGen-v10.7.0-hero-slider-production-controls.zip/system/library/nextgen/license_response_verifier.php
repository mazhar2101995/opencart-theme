<?php
class NextGenLicenseResponseVerifier {
    public function verify(array $response,$signature,$publicKey) {
        if (!$signature || !$publicKey) {
            return array('valid'=>false,'error'=>'Signed server response required.');
        }

        $payload=json_encode($response,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
        $result=openssl_verify($payload,base64_decode($signature),$publicKey,OPENSSL_ALGO_SHA256);

        return array(
            'valid'=>$result === 1,
            'error'=>$result === 1 ? null : 'License server response signature invalid.'
        );
    }
}
