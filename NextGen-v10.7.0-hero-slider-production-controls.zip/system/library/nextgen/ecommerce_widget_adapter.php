<?php
class NextGenEcommerceWidgetAdapter {
    protected $renderer;

    public function __construct($renderer) {
        $this->renderer=$renderer;
    }

    public function render($type,array $context,array $settings=array()) {
        if($type==='product_card') {
            return $this->renderer->renderProductCard(isset($context['product'])?$context['product']:array(),$settings);
        }
        if(in_array($type,array('product_grid','product_list','product_carousel','product_slider'),true)) {
            return $this->renderer->renderCollection(isset($context['products'])?$context['products']:array(),$settings);
        }
        if($type==='product_page') {
            return $this->renderer->renderProductPage(isset($context['product'])?$context['product']:array(),$settings);
        }
        return '';
    }
}
