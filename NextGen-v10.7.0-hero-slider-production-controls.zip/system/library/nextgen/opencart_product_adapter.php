<?php
class NextGenOpenCartProductAdapter {
    public function normalize(array $product,array $context=array()) {
        $price=isset($product['price']) ? (float)$product['price'] : 0;
        $special=isset($product['special']) && $product['special'] !== null ? (float)$product['special'] : null;

        return array(
            'product_id'=>(int)(isset($product['product_id'])?$product['product_id']:0),
            'name'=>isset($product['name'])?$product['name']:'',
            'model'=>isset($product['model'])?$product['model']:'',
            'image'=>isset($product['thumb'])?$product['thumb']:(isset($product['image'])?$product['image']:''),
            'price'=>$price,
            'special'=>$special,
            'tax'=>isset($product['tax'])?(float)$product['tax']:null,
            'rating'=>isset($product['rating'])?(float)$product['rating']:0,
            'reviews'=>isset($product['reviews'])?(int)$product['reviews']:0,
            'href'=>isset($product['href'])?$product['href']:'',
            'quantity'=>isset($product['quantity'])?(int)$product['quantity']:null,
            'stock_status'=>isset($product['stock_status'])?$product['stock_status']:'',
            'manufacturer'=>isset($product['manufacturer'])?$product['manufacturer']:'',
            'description'=>isset($product['description'])?$product['description']:'',
            'raw'=>$product
        );
    }

    public function normalizeList(array $products,array $context=array()) {
        $result=array();
        foreach($products as $product) {
            if(is_array($product)) $result[]=$this->normalize($product,$context);
        }
        return $result;
    }
}
