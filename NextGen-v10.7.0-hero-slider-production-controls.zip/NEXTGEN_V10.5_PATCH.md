# NextGen Theme Builder — V10.5 Inspector / Runtime Patch

## Fixed
- Inspector tab no longer jumps back to Content after every setting change.
- Inspector UI state is remembered per selected node.
- Normal/Hover state is remembered while editing.
- Open/closed inspector accordions are remembered per tab/node.
- Hero hover state can consume shared state values.
- New server-created sections no longer contain a physical Column node.
- Structure is `Section -> Container -> Widgets`.
- Grid columns remain CSS/grid tracks rather than navigator nodes.
- Added defensive `$attrs` initialization in the layout renderer.
- Builder version/assets bumped to 10.5.0 to avoid stale cached JS.
- Inspector errors now show the actual JS exception message in the panel.

## Architecture
Universal inspector controls remain centralized in:
`admin/view/javascript/nextgen-builder/inspector-schema.js`

Widgets reuse these controls instead of implementing separate control UIs.

## Compatibility
No OCMOD/VQMOD is introduced. OpenCart commerce/session/cart/checkout/payment/shipping
logic remains outside the builder presentation layer.


## V10.5.4 — Hero Color & Hover Pass

- Added/verified Elementor-style color controls for Hero eyebrow, heading and description text.
- Added Hero button text, background and border color controls.
- Added Hero button border width/style, radius, padding, shadow and typography controls.
- Added Hero button hover background, text and border colors plus radius/shadow/transform.
- Builder preview now reflects Hero button normal/hover styles.
- Storefront renderer now reads Hero hover values from the shared `states.hover` structure and responsive overrides.
- Increased builder asset cache-buster to `10.5.4.0` so browsers cannot keep serving the previous inspector JS/CSS.
