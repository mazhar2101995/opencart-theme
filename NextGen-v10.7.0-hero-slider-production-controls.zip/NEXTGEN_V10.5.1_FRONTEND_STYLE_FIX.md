# NextGen V10.5.1 — Frontend Style Scope Fix

## Root cause
The builder preview applied Hero typography/layout settings correctly, but the storefront wrapper did not include the node-scoped class expected by the universal Hero runtime CSS:
`ng-rendered-widget ng-node-<nodeId>`

The Hero renderer generated selectors such as `.ng-rendered-widget.ng-node-<nodeId> > .ng-universal-hero`, but the wrapper only had `ng-rendered-widget`. The CSS therefore matched nothing on the storefront.

## Fix
`system/library/nextgen/widget_render_engine.php` now adds the stable `ng-node-<nodeId>` class to every rendered widget wrapper. This fixes the same scope problem for Hero/Slider and other universal widgets without hard-coding widget-specific behavior.

## Inspector
Hero Heading/Description typography Text Color is kept next to the core typography controls instead of being buried after the other typography fields.

## Verification
- PHP source patched without changing document schema.
- Existing renderer architecture preserved.
- No widget files deleted.
