# NextGen v10.5.23 — Category Name Height Fix

## Fix
- Category name overlay now has a fixed height instead of growing/stretching unexpectedly.
- Default category-name height: `48px`.
- `box-sizing: border-box` is enforced so padding is included inside the fixed height.
- Long names remain on one line and use ellipsis when needed.
- Existing category name padding, colors, font, radius, position, and alignment remain supported.

## New Builder Control
Category Grid → Style → Category Name → **Height**

Supported units: px, rem, em, vh, vw.

## Responsive
The name height can be configured independently for desktop/tablet/mobile.

## Important
No category selection, slider window, image, or arrow logic was removed in this patch.
