# NextGen v10.6.5 — Products Widget Control/Application Fix

## Main fixes
- Slider arrows can be positioned `middle-outside`, `middle-inside`, `top`, or `bottom`.
- Default slider arrows are now vertically centered beside the product cards, outside the viewport.
- Added horizontal and vertical arrow offsets.
- Arrow icon, size, color, hover color/background, border, radius, shadow and position settings are applied by the frontend renderer.
- Removed hard-coded product action hover colors that previously overrode admin settings.
- Add-to-cart normal/hover colors, border, radius, padding, font and spacing now remain driven by inspector settings.
- Product card border style now respects the selected admin border style.
- Product image fit now respects `contain`/`cover`.
- Product image hover scale and transition duration are applied.
- Responsive inspector values for common card/action/arrow dimensions are emitted into device media queries.
- Added dot position control in the inspector.

## Testing
1. Select Products widget and set Display = Slider.
2. Set Arrow Position = Middle — Left / Right of Cards.
3. Change arrow icon, size, color and hover values.
4. Change action icon settings and card design settings.
5. Verify frontend after cache refresh.
6. Test Desktop, Tablet and Mobile builder values.
