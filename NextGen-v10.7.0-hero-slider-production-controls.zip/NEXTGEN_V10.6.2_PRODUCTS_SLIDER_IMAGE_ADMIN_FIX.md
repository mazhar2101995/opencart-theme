# NextGen v10.6.2 — Products Widget / Slider / Image / Admin Preview Fix

## Fixed

- Unified Products widget remains a single widget with three presentation modes:
  - Tabs
  - Slider
  - Grid
- Grid mode does not expose Tabs/Slider-specific settings.
- Slider mode exposes slider-only controls: interval, speed, autoplay, loop, arrows and dots.
- Latest Products uses the OpenCart latest-products API with an integer limit and is sliced to the configured widget limit.
- Product image pipeline keeps OpenCart's generated image URL, e.g. `/image/cache/catalog/...-600x600.jpg`.
- Product images now have an original-image fallback when a resized cache file is unavailable.
- Wishlist, Compare and Quick View use inline SVG icons so they do not depend on an icon font.
- Product action icons are visible by default instead of being hidden until hover.
- Slider runtime was moved to the ecommerce widget runtime and made responsive to desktop/tablet/mobile columns.
- Slider arrows, dots, loop and autoplay are initialized reliably after the storefront DOM is ready.
- Admin Products preview now uses real Fashion demo images instead of blank placeholder cards.
- Admin Products preview adapts to the actual builder-column width so cards do not become unusably narrow.
- Admin Slider preview has working previous/next controls.
- Frontend widget-slot dotted editor border is no longer applied to the published storefront.

## Validation

- PHP syntax checked for the modified Products renderer.
- JavaScript was updated as a standalone storefront runtime and builder preview runtime.
- Existing OpenCart image-manager paths remain supported.

## Cache refresh

After replacing the files:

1. OpenCart Admin → Extensions → Modifications → Refresh.
2. Refresh NextGen/theme cache if enabled.
3. Hard-refresh the browser (`Ctrl + F5`).
