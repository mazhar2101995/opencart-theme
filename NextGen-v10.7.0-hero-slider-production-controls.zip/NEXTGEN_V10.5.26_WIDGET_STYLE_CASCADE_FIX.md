# NextGen v10.5.26 — Widget Style Cascade Fix

## Problem
Admin inspector values were being serialized and appeared as inline styles on the storefront, but theme/demo CSS could override them. Heading controls were especially affected because the actual `<h1>`–`<h6>` element has its own theme rules. The previous renderer also had widget-state paths that could reference the widget type inconsistently.

## Root cause
1. Widget local styles were emitted without `!important`, so any stronger theme/demo declaration could win.
2. Heading typography was applied to the widget wrapper, but heading elements can have their own `font-*`, `color`, margin and line-height rules.
3. Responsive local widget styles used broad selectors and did not guarantee precedence over demo skin CSS.
4. Heading renderer did not expose a semantic `ng-heading-N` class/data attribute.

## Fix
- Local widget inline visual styles now use `!important` so inspector values are authoritative.
- Heading renderer now adds `ng-heading-1` … `ng-heading-6` and `data-ng-heading-level`.
- Responsive widget styles target the actual widget plus heading/text/button descendants and use `!important`.
- Hover/focus/active local states use stronger selectors and `!important`.
- Button hover declarations remain scoped to the actual button widget.
- Existing container, hero, category grid and slider logic is preserved.

## Files changed
- `system/library/nextgen/widget_render_engine.php`
- `system/library/nextgen/default_widget_renderers.php`

## QA
- PHP lint passed for both modified files.
