# NextGen V10.5.6 — Hero Stability & Style System

## Scope
This patch is intentionally limited to the Hero/ Hero Slider inspector and runtime styling path. Existing files and widgets are preserved.

## Fixed
- Removed duplicate generic Normal/State style controls from Hero inspector that were writing generic `color` / `backgroundColor` values instead of Hero-specific fields.
- Centralized Hero typography controls for eyebrow, heading, and description.
- Added Text Color to all three typography groups.
- Added complete typography controls: family, size, weight, line height, letter spacing, word spacing, transform, decoration, font style, text shadow.
- Added complete normal button controls: typography, text color, background, border style/width/color, radius, padding, shadow.
- Added complete button hover controls: text color, background, border style/width/color, radius, shadow, transform.
- Added Hero background image opacity as a dedicated control. It no longer relies on generic widget opacity.
- Added Hero image filter control.
- Added Hero hover background/overlay/opacity/filter/transform controls.
- Applied Hero image opacity/filter to storefront runtime, including responsive overrides.
- Applied button hover border width/style and all existing hover values to storefront runtime.
- Applied Hero hover values to storefront runtime.
- Builder asset cache version bumped to 10.5.6.

## Validation
- JavaScript syntax checked with Node.js.
- PHP syntax checked for modified PHP files.
