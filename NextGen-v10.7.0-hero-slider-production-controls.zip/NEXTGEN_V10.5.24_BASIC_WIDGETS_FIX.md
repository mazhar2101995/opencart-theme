# NextGen v10.5.24 — Heading / Text Editor / Button Widget Fix

## Scope
Production fix for the three core basic widgets:
- Heading
- Text Editor
- Button

## Frontend rendering fixes
- Heading settings now render on the actual heading element on the storefront.
- Heading link URL is supported.
- Text Editor now reads the `html` setting instead of incorrectly rendering only the `text` field.
- Text Editor preserves HTML content and supports semantic tag selection.
- Button now renders target, icon, icon position and label markup.
- Button visual settings are applied to the actual anchor element, not only the layout wrapper.
- Button normal and hover visual controls are scoped to the real button element.
- Generic widget typography/background/border/effects are propagated to the inner `.ng-widget` element.

## Inspector settings
### Heading
- Heading content
- HTML tag
- Link URL
- Typography
- Text color
- Background
- Border
- Text shadow/effects
- Layout
- Responsive controls

### Text Editor
- HTML content
- Semantic tag
- Typography
- Text color
- Background
- Border
- Effects
- Layout
- Responsive controls

### Button
- Button text
- URL
- Target
- Icon
- Icon position
- Font family/size/weight/style
- Line height / letter spacing
- Text transform / decoration
- Text color
- Background color
- Border color/style/width/radius
- Padding
- Box shadow
- Hover text/background/border/radius/shadow
- Layout and responsive controls

## Compatibility
OpenCart 3.x / NextGen Theme Engine runtime.

## Validation
- PHP syntax checked for modified PHP files.
- JavaScript syntax checked for modified inspector assets.
- Basic renderer output manually exercised for heading, text editor and button.
