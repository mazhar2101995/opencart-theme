(function () {
  'use strict';

  window.NextGenBuilderUX = {
    devices: {
      desktop: { width: 1440 },
      tablet: { width: 768 },
      mobile: { width: 390 }
    },

    setDevice: function (device) {
      if (!this.devices[device]) return;
      document.documentElement.setAttribute('data-nextgen-device', device);
      document.dispatchEvent(new CustomEvent('nextgen:device-change', {
        detail: { device: device }
      }));
    },

    resetProperty: function (element, property) {
      if (!element) return;
      element.dispatchEvent(new CustomEvent('nextgen:style-reset', {
        bubbles: true,
        detail: { property: property }
      }));
    }
  };
})();
