(function () {
  'use strict';
  document.querySelectorAll('[data-action]').forEach(function (button) {
    button.addEventListener('click', function () {
      var output = document.querySelector('[data-package-result]');
      output.textContent = button.textContent + ' selected. Review the generated plan before execution.';
    });
  });
}());
