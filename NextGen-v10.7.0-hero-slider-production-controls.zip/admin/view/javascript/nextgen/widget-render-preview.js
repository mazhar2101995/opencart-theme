(function(){
  'use strict';
  window.NextGenWidgetRenderPreview = {
    render: function(container, html) {
      if (!container) return;
      container.innerHTML = html || '';
    }
  };
})();
