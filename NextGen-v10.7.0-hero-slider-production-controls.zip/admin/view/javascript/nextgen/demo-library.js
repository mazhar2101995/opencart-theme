(function () {
  'use strict';

  document.querySelectorAll('[data-demo]').forEach(function (card) {
    card.addEventListener('click', function (event) {
      var action=event.target.textContent.trim();
      if (action === 'Import Demo') {
        if (!window.confirm('Import this demo? Existing theme content should be backed up first.')) return;
        card.setAttribute('data-import-requested','true');
      }
    });
  });
}());
