(function () {
  'use strict';
  var status=document.querySelector('[data-update-status]');
  if (!status) return;
  status.setAttribute('data-safe-update','true');
}());
