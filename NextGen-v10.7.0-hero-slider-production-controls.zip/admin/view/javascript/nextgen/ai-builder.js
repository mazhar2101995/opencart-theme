(function () {
  'use strict';

  window.NextGenAiBuilder = {
    modes: ['layout', 'content', 'design', 'explain', 'json'],

    buildRequest: function (prompt, mode, context) {
      return {
        prompt: String(prompt || ''),
        mode: this.modes.indexOf(mode) >= 0 ? mode : 'layout',
        context: context || {}
      };
    },

    /**
     * AI output must be reviewed and validated before save/publish.
     */
    requiresReview: true,
    requiresValidation: true
  };
})();
