(function(window,document){
'use strict';
 console.info('[NextGen Builder] UI 10.6.3 / UNIFIED PRODUCTS + MODE-AWARE INSPECTOR');
  window.__NEXTGEN_BUILDER_UI_VERSION='10.6.1.0';
var NG={};
if(!window.NextGenBuilderStore){
  window.NextGenBuilderStore=function(initial){this.state=JSON.parse(JSON.stringify(initial||{document:null,selectedId:null,device:'desktop',dirty:false}));this.history=[];this.future=[];this.listeners=[];this.clipboard=null;};
  window.NextGenBuilderStore.prototype.get=function(){return JSON.parse(JSON.stringify(this.state));};
  window.NextGenBuilderStore.prototype.emit=function(){var s=this.get();this.listeners.slice().forEach(function(fn){fn(s);});};
  window.NextGenBuilderStore.prototype.subscribe=function(fn){this.listeners.push(fn);fn(this.get());};
  window.NextGenBuilderStore.prototype.commit=function(next){this.history.push(this.get());this.future=[];this.state=JSON.parse(JSON.stringify(next));this.state.dirty=true;this.emit();};
  window.NextGenBuilderStore.prototype.update=function(fn){var n=this.get();fn(n);this.commit(n);};
  window.NextGenBuilderStore.prototype.setDocument=function(doc){this.state.document=JSON.parse(JSON.stringify(doc));this.state.dirty=false;this.history=[];this.future=[];this.emit();};
  window.NextGenBuilderStore.prototype.select=function(id){this.state.selectedId=id;this.emit();};
  window.NextGenBuilderStore.prototype.setDevice=function(d){this.state.device=d;this.emit();};
  window.NextGenBuilderStore.prototype.undo=function(){if(!this.history.length)return;this.future.push(this.get());this.state=this.history.pop();this.emit();};
  window.NextGenBuilderStore.prototype.redo=function(){if(!this.future.length)return;this.history.push(this.get());this.state=this.future.pop();this.emit();};
  window.NextGenBuilderStore.prototype.copy=function(node){this.clipboard=JSON.parse(JSON.stringify(node));};
  window.NextGenBuilderStore.prototype.paste=function(){return this.clipboard?JSON.parse(JSON.stringify(this.clipboard)):null;};
}

var WIDGETS=[
{id:'heading',name:'Heading',category:'Basic',icon:'T',settings:{text:'New Heading',tag:'h2',align:'left'}},
{id:'text',name:'Text Editor',category:'Basic',icon:'¶',settings:{text:'Start building your content here.'}},
{id:'button',name:'Button',category:'Basic',icon:'▣',settings:{text:'Button',url:'#',target:'_self'}},
{id:'button_group',name:'Button Group',category:'Basic',icon:'▦',settings:{}},
{id:'image',name:'Image',category:'Media',icon:'▧',settings:{src:'',alt:''}},
{id:'icon',name:'Icon',category:'Basic',icon:'★',settings:{icon:'star'}},
{id:'icon_box',name:'Icon Box',category:'Basic',icon:'✦',settings:{title:'Icon Box',text:'Description'}},
{id:'spacer',name:'Spacer',category:'Layout',icon:'↕',settings:{height:40}},
{id:'divider',name:'Divider',category:'Layout',icon:'—',settings:{}},
{id:'html',name:'HTML',category:'Basic',icon:'<>',settings:{html:''}},
{id:'video',name:'Video',category:'Media',icon:'▶',settings:{src:''}},
{id:'gallery',name:'Gallery',category:'Media',icon:'▦',settings:{images:[]}},
{id:'image_carousel',name:'Image Carousel',category:'Media',icon:'◀▶',settings:{images:[]}},
{id:'video_popup',name:'Video Popup',category:'Media',icon:'⏵',settings:{src:''}},
{id:'product',name:'Product',category:'OpenCart',icon:'🛒',settings:{productId:'',productName:'',layout:'image-left',showImage:true,showBrand:true,showModel:false,showDescription:true,showRating:true,showPrice:true,showSpecialPrice:true,showQuantity:false,showAddToCart:true,showBuyNow:false,addToCartText:'Add to Cart',buyNowText:'Buy Now',imageFit:'contain',imageWidth:'50%',imageRadius:'16px',imageBackground:'#f8fafc',gap:'40px',cardBackground:'#ffffff',cardBorderColor:'#e5e7eb',cardBorderWidth:'1px',cardBorderStyle:'solid',cardRadius:'18px',cardShadow:'0 12px 35px rgba(15,23,42,.08)',cardPadding:'28px',titleColor:'#111827',titleSize:'32px',titleWeight:'700',priceColor:'#111827',priceSize:'22px',descriptionColor:'#64748b',descriptionSize:'15px',buttonBackground:'#111827',buttonColor:'#ffffff',buttonHoverBackground:'#000000',buttonHoverColor:'#ffffff',buttonRadius:'8px',buttonPadding:'12px 20px'}} ,
{id:'products',name:'Products',category:'OpenCart',icon:'▦',settings:{source:'latest',displayMode:'grid',widgetWidthMode:'boxed',widgetWidth:'100%',widgetMaxWidth:'1400px',widgetAlign:'center',widgetPaddingX:'0px',limit:8,columns:4,columnsTablet:3,columnsMobile:2,gap:22,autoplay:true,interval:4500,speed:450,loop:true,arrows:true,dots:true,showBrand:true,showPrice:true,showRating:true,showActions:true,showWishlist:true,showCompare:true,showQuickView:true,showHoverImage:true,showModel:false,showLabels:true,newBadgeText:'NEW',saleBadgeText:'SALE',addToCartText:'Add to Cart',wishlistIcon:'heart',compareIcon:'swap',quickViewIcon:'eye',actionPosition:'overlay',actionSize:'40px',actionIconSize:'18px',actionGap:'8px',actionBackground:'#ffffff',actionColor:'#111827',actionHoverColor:'#ffffff',actionHoverBackground:'#111827',actionBorderColor:'rgba(17,24,39,.10)',actionBorderWidth:'1px',actionBorderStyle:'solid',actionRadius:'50%',actionShadow:'0 5px 18px rgba(0,0,0,.12)',arrowPrevIcon:'chevron-left',arrowNextIcon:'chevron-right',arrowPosition:'middle-outside',arrowOffsetX:'18px',arrowOffsetY:'0px',arrowSize:'42px',arrowIconSize:'18px',arrowBackground:'#ffffff',arrowColor:'#111827',arrowHoverBackground:'#111827',arrowHoverColor:'#ffffff',arrowBorderColor:'#e2e8f0',arrowBorderWidth:'1px',arrowBorderStyle:'solid',arrowRadius:'50%',arrowShadow:'0 5px 18px rgba(0,0,0,.10)',dotSize:'7px',dotColor:'#cbd5e1',dotActiveColor:'#111827',dotActiveScale:1.25,cardAnimation:'lift',tabs:[{label:'Latest Products',source:'latest',limit:8}]}},
{id:'product_categories',name:'Product Categories',category:'OpenCart',icon:'▤',settings:{}},
{id:'category_grid',name:'Category Grid',category:'OpenCart',icon:'▦',settings:{categories:[],columns:4,gap:20,showName:true,namePosition:'overlay',nameOverlayPosition:'bottom-center',nameAlign:'center',nameHeight:'48px',buttonDisplay:'hover',buttonText:'Shop Now',imageFit:'cover',imageHeight:'320px',displayMode:'grid',autoplay:true,interval:4000,arrows:true,arrowPrevIcon:'chevron-left',arrowNextIcon:'chevron-right',dots:true,loop:true}},
{id:'manufacturer',name:'Manufacturer / Brand',category:'OpenCart',icon:'™',settings:{}},
{id:'search',name:'Search',category:'OpenCart',icon:'⌕',settings:{}},
{id:'product_filter',name:'Product Filter',category:'OpenCart',icon:'☰',settings:{}},
{id:'pagination',name:'Pagination',category:'OpenCart',icon:'123',settings:{}},
{id:'hero',name:'Hero Banner',category:'Marketing',icon:'▰',settings:{heading:'Your headline',text:'Your supporting content',button:'Shop Now',widthMode:'contained',minHeight:'620px',backgroundSize:'cover',backgroundPosition:'center center',contentPosition:'left center',contentMaxWidth:'760px',contentPadding:''}},{id:'fashion_categories',name:'Fashion Collections',category:'Modern Fashion',icon:'▥',settings:{items:[]}},{id:'fashion_lookbook',name:'Fashion Lookbook',category:'Modern Fashion',icon:'▣',settings:{items:[]}},{id:'fashion_promo',name:'Fashion Promo',category:'Modern Fashion',icon:'◆',settings:{heading:'Private Sale',text:'Up to 30% off selected styles'}},{id:'fashion_marquee',name:'Fashion Marquee',category:'Modern Fashion',icon:'↔',settings:{text:'LIMITED EDITION · NEW SEASON'}},{id:'fashion_products',name:'Fashion Products',category:'Modern Fashion',icon:'▦',settings:{items:[]}},{id:'fashion_sale',name:'Fashion Sale',category:'Modern Fashion',icon:'%',settings:{heading:'SALE',text:'Up to 70% off'}},{id:'fashion_editorial',name:'Fashion Editorial',category:'Modern Fashion',icon:'◫',settings:{}},{id:'fashion_inspiration',name:'Fashion Inspiration',category:'Modern Fashion',icon:'✦',settings:{}},{id:'fashion_testimonials',name:'Fashion Testimonials',category:'Modern Fashion',icon:'❝',settings:{}},{id:'fashion_blog',name:'Fashion Blog',category:'Modern Fashion',icon:'▤',settings:{}},{id:'fashion_newsletter',name:'Fashion Newsletter',category:'Modern Fashion',icon:'@',settings:{}},
{id:'hero_slider',name:'Hero Slider',category:'Marketing',icon:'▤',settings:{slides:[{title:'Slide 1',eyebrow:'NEXTGEN HERO',mediaType:'image',heading:'Your headline',text:'Your supporting content',button:'Shop Now',url:'#',target:'_self',image:'',mobileImage:'',videoUrl:'',videoPoster:'',backgroundPosition:'center center',backgroundSize:'cover',backgroundRepeat:'no-repeat',contentPosition:'left center',textAlign:'left',overlayColor:'#000000',overlayOpacity:.25}],widthMode:'contained',customWidth:'100%',minHeight:'680px',contentPosition:'left center',contentMaxWidth:'760px',contentPadding:'70px 7vw',contentGap:'16px',textAlign:'left',backgroundColor:'#111827',backgroundSize:'cover',backgroundPosition:'center center',backgroundRepeat:'no-repeat',imageOpacity:1,imageFilter:'none',overlayColor:'#000000',overlayOpacity:.25,transition:'slide',easing:'ease',autoplay:true,interval:5000,speed:650,loop:true,pauseOnHover:true,pauseOnFocus:true,swipe:true,keyboard:true,arrows:true,arrowPrevIcon:'chevron-left',arrowNextIcon:'chevron-right',arrowPosition:'middle-inside',arrowOffsetX:'24px',arrowOffsetY:'0px',arrowSize:'48px',arrowIconSize:'22px',arrowBackground:'#ffffff',arrowColor:'#111827',arrowHoverBackground:'#111827',arrowHoverColor:'#ffffff',arrowBorderColor:'rgba(17,24,39,.12)',arrowBorderWidth:'1px',arrowBorderStyle:'solid',arrowRadius:'50%',arrowShadow:'0 8px 24px rgba(0,0,0,.18)',dots:true,dotPosition:'bottom-center',dotOffsetX:'0px',dotOffsetY:'22px',dotSize:'8px',dotGap:'8px',dotColor:'rgba(255,255,255,.55)',dotActiveColor:'#ffffff',dotActiveWidth:'26px',dotActiveRadius:'8px',progress:false,progressPosition:'bottom',progressColor:'#ffffff',progressHeight:'3px',showCounter:false,counterPosition:'top-right',counterColor:'#ffffff',counterBackground:'rgba(0,0,0,.35)',counterRadius:'999px',counterPadding:'6px 10px',containerBackground:'transparent',containerBorderColor:'transparent',containerBorderWidth:'0px',containerBorderStyle:'solid',containerRadius:'0px',containerShadow:'none',heroEyebrowFontFamily:'inherit',heroEyebrowSize:'12px',heroEyebrowWeight:'600',heroEyebrowLineHeight:'1.2',heroEyebrowLetterSpacing:'.16em',heroEyebrowWordSpacing:'0px',heroEyebrowTransform:'uppercase',heroEyebrowDecoration:'none',heroEyebrowStyle:'normal',heroEyebrowColor:'#ffffff',heroEyebrowShadow:'none',heroHeadingFontFamily:'inherit',heroHeadingSize:'clamp(40px,6vw,86px)',heroHeadingWeight:'700',heroHeadingLineHeight:'.98',heroHeadingLetterSpacing:'0px',heroHeadingWordSpacing:'0px',heroHeadingTransform:'none',heroHeadingDecoration:'none',heroHeadingStyle:'normal',heroHeadingColor:'#ffffff',heroHeadingShadow:'none',heroBodyFontFamily:'inherit',heroBodySize:'18px',heroBodyWeight:'400',heroBodyLineHeight:'1.7',heroBodyLetterSpacing:'0px',heroBodyWordSpacing:'0px',heroBodyTransform:'none',heroBodyDecoration:'none',heroBodyStyle:'normal',heroBodyColor:'#ffffff',heroBodyShadow:'none',buttonFontFamily:'inherit',buttonFontSize:'14px',buttonFontWeight:'700',buttonLineHeight:'1.2',buttonLetterSpacing:'.04em',buttonTransform:'uppercase',buttonDecoration:'none',buttonStyle:'normal',buttonBackground:'#111827',buttonColor:'#ffffff',buttonRadius:'8px',buttonPadding:'13px 22px',buttonBorderWidth:'0px',buttonBorderStyle:'solid',buttonBorderColor:'transparent',buttonShadow:'none',buttonHoverBackground:'#000000',buttonHoverColor:'#ffffff',buttonHoverBorderColor:'transparent',buttonHoverBorderWidth:'0px',buttonHoverBorderStyle:'solid',buttonHoverRadius:'8px',buttonHoverShadow:'0 8px 18px rgba(0,0,0,.18)',buttonHoverTransform:'lift'}},
{id:'announcement',name:'Announcement Bar',category:'Global',icon:'!',settings:{text:'Announcement'}},
{id:'newsletter',name:'Newsletter',category:'Global',icon:'✉',settings:{}},
{id:'trust_badges',name:'Trust Badges',category:'Global',icon:'✓',settings:{}},
{id:'social_links',name:'Social Links',category:'Global',icon:'●',settings:{}},
{id:'footer',name:'Footer',category:'Global',icon:'▰',settings:{}},
{id:'menu',name:'Navigation / Mega Menu',category:'Header',icon:'☰',settings:{}},
{id:'logo',name:'Logo',category:'Header',icon:'◉',settings:{}},
{id:'account',name:'Account',category:'Header',icon:'◯',settings:{}},
{id:'cart',name:'Cart',category:'Header',icon:'🛒',settings:{}},
{id:'conditions',name:'Conditional Section',category:'Advanced',icon:'?',settings:{}}];
var STRUCTURES=[{id:'section',name:'Section',icon:'▤'},{id:'container',name:'Container',icon:'□'}];
var WIDGET_TYPES=['heading','text','text_editor','button','button_group','image','icon','icon_box','spacer','divider','html','video','gallery','image_carousel','video_popup','youtube','vimeo','audio','lightbox','before_after','product','products','product_categories','category_grid','manufacturer','search','product_filter','pagination','hero','hero_slider','announcement','newsletter','trust_badges','social_links','footer','menu','logo','account','cart','conditions'];
var CONTAINER_TYPES={root:['section'],section:['container'],container:WIDGET_TYPES.concat(['container','section'])};
var MAX_WIDGET_NESTING=6;
function nodeDepth(root,id){function walk(n,d){if(!n)return -1;if(n.id===id)return d;var c=n.children||[];for(var i=0;i<c.length;i++){var r=walk(c[i],d+1);if(r>-1)return r;}return -1;}return walk(root,0);}
function isWidgetType(type){return WIDGET_TYPES.indexOf(type)>-1;}
function paletteWidgets(){return WIDGETS.filter(function(w){return WIDGET_TYPES.indexOf(w.id)>-1 && w.id.indexOf('fashion_')!==0;});}
function canNestWidget(parentType,childType){return isWidgetType(parentType)&&isWidgetType(childType);}
function clone(v){return JSON.parse(JSON.stringify(v));}
function getResponsive(n,key,device,fallback){
 var r=n.settings&&n.settings.responsive&&n.settings.responsive[key];
 if(r&&r[device]!==undefined&&r[device]!==null&&r[device]!=='')return r[device];
 if(r&&r.desktop!==undefined&&r.desktop!==null&&r.desktop!=='')return r.desktop;
 return n.settings&&n.settings[key]!==undefined?n.settings[key]:fallback;
}
function setResponsive(n,key,device,value){
 n.settings=n.settings||{};n.settings.responsive=n.settings.responsive||{};
 n.settings.responsive[key]=n.settings.responsive[key]||{};
 n.settings.responsive[key][device]=value;
 // Desktop is the canonical/base value. Keep the legacy/base key in sync so
 // renderers that consume direct settings and renderers that consume the
 // responsive map resolve to the same value. Tablet/mobile remain overrides.
 if(device==='desktop'){
   n.settings[key]=value;
 }
}
function num(v,f){var x=parseFloat(v);return isFinite(x)?x:f;}
function unit(v,def){if(v===undefined||v===null||v==='')return '';return typeof v==='number'?v+'px':String(v);}
function layoutStyle(n,device){
 var s=n.settings||{}, d={};
 var display=getResponsive(n,'display',device,'block');
 if(display)d.display=display;
 var direction=getResponsive(n,'direction',device,s.layout==='grid'?'row':'row');
 if(n.type==='container'||n.type==='section'||n.type==='root'){
   var layout=getResponsive(n,'layout',device,'flex');
   d.boxSizing='border-box';
   if(layout==='grid'){d.display='grid';d.gridTemplateColumns=getResponsive(n,'gridColumns',device,'1fr');d.gridAutoRows='minmax(0,auto)';}
   else {d.display='flex';d.flexDirection=direction;d.flexWrap=getResponsive(n,'wrap',device,'nowrap');d.justifyContent=getResponsive(n,'justify',device,'flex-start');d.alignItems=getResponsive(n,'align',device,'stretch');}
   var gap=getResponsive(n,'gap',device,'');if(gap!=='')d.gap=unit(gap,'');
   var width=getResponsive(n,'width',device,'');if(width!=='')d.width=unit(width,'');
   var maxWidth=getResponsive(n,'maxWidth',device,'');if(maxWidth!=='')d.maxWidth=unit(maxWidth,'');
   var minHeight=getResponsive(n,'minHeight',device,'');if(minHeight!=='')d.minHeight=unit(minHeight,'');
   var padding=getResponsive(n,'padding',device,'');if(padding!=='')d.padding=typeof padding==='string'?padding:unit(padding,'');
   var margin=getResponsive(n,'margin',device,'');if(margin!=='')d.margin=typeof margin==='string'?margin:unit(margin,'');
   var bg=getResponsive(n,'background',device,'');if(bg)d.background=bg;
   var radius=getResponsive(n,'radius',device,'');if(radius!=='')d.borderRadius=unit(radius,'');
   var shadow=getResponsive(n,'shadow',device,'');if(shadow)d.boxShadow=shadow;
   var overflow=getResponsive(n,'overflow',device,'');if(overflow)d.overflow=overflow;
   var position=getResponsive(n,'position',device,'');if(position)d.position=position;
   var z=getResponsive(n,'zIndex',device,'');if(z!=='')d.zIndex=z;
 }
 var fontSize=getResponsive(n,'fontSize',device,'');if(fontSize!=='')d.fontSize=unit(fontSize,'');
 var fontWeight=getResponsive(n,'fontWeight',device,'');if(fontWeight!=='')d.fontWeight=fontWeight;
 var color=getResponsive(n,'color',device,'');if(color!=='')d.color=color;
 var border=getResponsive(n,'border',device,'');if(border!=='')d.border=border;
 var textAlign=getResponsive(n,'textAlign',device,'');if(textAlign!=='')d.textAlign=textAlign;
 var backgroundColor=getResponsive(n,'backgroundColor',device,'');if(backgroundColor)d.backgroundColor=backgroundColor;
 var backgroundImage=getResponsive(n,'backgroundImage',device,'');if(backgroundImage)d.backgroundImage='url(\"'+builderAssetUrl(backgroundImage)+'\")';
 var fontFamily=getResponsive(n,'fontFamily',device,'');if(fontFamily)d.fontFamily=fontFamily;
 var lineHeight=getResponsive(n,'lineHeight',device,'');if(lineHeight)d.lineHeight=lineHeight;
 var letterSpacing=getResponsive(n,'letterSpacing',device,'');if(letterSpacing)d.letterSpacing=letterSpacing;
 var textTransform=getResponsive(n,'textTransform',device,'');if(textTransform)d.textTransform=textTransform;
 var borderWidth=getResponsive(n,'borderWidth',device,'');if(borderWidth)d.borderWidth=borderWidth;
 var borderStyle=getResponsive(n,'borderStyle',device,'');if(borderStyle)d.borderStyle=borderStyle;
 var borderColor=getResponsive(n,'borderColor',device,'');if(borderColor)d.borderColor=borderColor;
 var opacity=getResponsive(n,'opacity',device,'');if(opacity!=='')d.opacity=opacity;var justifySelf=getResponsive(n,'justifySelf',device,'');if(justifySelf!=='')d.justifySelf=justifySelf;var alignSelf=getResponsive(n,'alignSelf',device,'');if(alignSelf!=='')d.alignSelf=alignSelf;if(n.settings&&n.settings.gridColumnSpan)d.gridColumn='span '+Math.max(1,Math.min(12,parseInt(n.settings.gridColumnSpan,10)||1));
 return d;
}
function applyStyle(el,n,device){var d=layoutStyle(n,device);Object.keys(d).forEach(function(k){el.style[k]=d[k];});}
function uid(type){return type+'_'+Math.random().toString(36).slice(2,10);}
function byId(root,id){if(!root)return null;if(root.id===id)return root;var c=root.children||[];for(var i=0;i<c.length;i++){var r=byId(c[i],id);if(r)return r;}return null;}
function findParent(root,id){var c=root.children||[];for(var i=0;i<c.length;i++){if(c[i].id===id)return root;var r=findParent(c[i],id);if(r)return r;}return null;}
function contains(root,id){return !!byId(root,id);}
function normalizeBuilderStructure(doc){
  function normalize(n){
    if(!n||typeof n!=='object')return;
    n.children=Array.isArray(n.children)?n.children:[];
    n.settings=n.settings&&typeof n.settings==='object'?n.settings:{};
    if(n.type==='section'){
      n.settings.contentWidth=n.settings.contentWidth||'full';
      n.settings.maxWidth=n.settings.maxWidth||'1320px';
      n.settings.minHeight=n.settings.minHeight||'';
    }
    if(n.type==='container'){
      var flat=[];
      n.children.forEach(function(child){
        if(child&&child.type==='column'){
          var span=child.settings&&child.settings.gridColumnSpan?child.settings.gridColumnSpan:1;
          (child.children||[]).forEach(function(grand){
            if(grand&&span>1&&!grand.settings.gridColumnSpan){grand.settings=grand.settings||{};grand.settings.gridColumnSpan=span;}
            flat.push(grand);
          });
        }else flat.push(child);
      });
      n.children=flat;
      n.settings.layout=n.settings.layout||'flex';
      n.settings.widthMode=n.settings.widthMode||'boxed';
      n.settings.width=n.settings.width||'100%';
      n.settings.maxWidth=n.settings.maxWidth||'1320px';
      n.settings.gap=n.settings.gap||'24px';
      n.settings.gridColumnCount=n.settings.gridColumnCount||1;
      n.settings.gridColumns=n.settings.gridColumns||'repeat('+n.settings.gridColumnCount+',minmax(0,1fr))';
    }
    n.children.forEach(normalize);
  }
  normalize(doc);
  return doc;
}
function ensureDocument(doc){if(doc&&doc.root&&doc.root.type==='root')doc=doc.root;if(!doc||doc.type!=='root')doc={type:'root',version:1,children:[makeStructure('section')]};normalizeBuilderStructure(doc);(function ids(n){if(!n.id)n.id=uid(n.type||'node');if(!Array.isArray(n.children))n.children=[];n.children.forEach(ids);})(doc);return doc;}
function migrateLegacyHeroNodes(doc){(function walk(n){if(!n||typeof n!=='object')return;if(n.type==='fashion_hero'){var s=n.settings||{};n.type='hero';n.settings={eyebrow:s.eyebrow||'',heading:s.heading||'The New Edit',text:s.text||'Modern silhouettes. Quiet confidence.',button:s.button||'Shop New Arrivals',url:s.url||'index.php?route=product/category',image:s.image||'',mobileImage:s.mobileImage||s.mobile_image||'',backgroundPosition:s.backgroundPosition||s.background_position||'center center',backgroundSize:s.backgroundSize||s.background_size||'cover',overlayColor:s.overlayColor||s.overlay||'',backgroundColor:s.backgroundColor||'',widthMode:s.widthMode||'contained',contentPosition:s.contentPosition||'left center',contentMaxWidth:s.contentMaxWidth||'760px',contentPadding:s.contentPadding||'',minHeight:s.minHeight||'620px',headingTag:s.headingTag||'h1'};} (n.children||[]).forEach(walk);})(doc);return doc;}
function node(type,settings){return {id:uid(type),type:type,settings:clone(settings||{}),children:[]};}
function isAllowed(parentType,nodeType){var a=CONTAINER_TYPES[parentType]||[];if(a.indexOf(nodeType)>-1)return true;return canNestWidget(parentType,nodeType);}
function makeStructure(type){
 var actual=(type||'section');
 if(actual.indexOf('section_')===0)actual='section';
 var n=node(actual);
 if(actual==='section'){
   var count=type&&type.indexOf('section_')===0?Math.max(1,Math.min(12,parseInt(type.split('_')[1],10)||1)):1;
   n.settings={contentWidth:'full',maxWidth:'1320px',minHeight:''};
   var c=node('container');
   c.settings={layout:'flex',widthMode:'boxed',width:'100%',maxWidth:'1320px',minHeight:'',direction:'column',justify:'flex-start',align:'stretch',gap:'24px',wrap:'nowrap',padding:'0',margin:'0 auto',gridColumnCount:count,gridColumns:'repeat('+count+',minmax(0,1fr))',columnGap:'24px',rowGap:'24px'};
   n.children=[c];
 } else if(actual==='container'){
   n.settings={layout:'flex',widthMode:'boxed',width:'100%',maxWidth:'1320px',minHeight:'',direction:'column',justify:'flex-start',align:'stretch',gap:'24px',wrap:'nowrap',padding:'0',margin:'0 auto',gridColumnCount:1,gridColumns:'repeat(1,minmax(0,1fr))',columnGap:'24px',rowGap:'24px'};
 }
 return n;
}
function regenerateIds(n){n.id=uid(n.type);(n.children||[]).forEach(regenerateIds);return n;}
function findFirstByType(root,type){if(!root)return null;if(root.type===type)return root;var c=root.children||[];for(var i=0;i<c.length;i++){var f=findFirstByType(c[i],type);if(f)return f;}return null;}
function mount(selector){
 var root=document.querySelector(selector);if(!root)return;
 try{console.info('[NextGen Builder] UI '+(window.__NEXTGEN_BUILDER_UI_VERSION||'unknown')+' / Inspector '+(window.__NEXTGEN_INSPECTOR_SCHEMA_VERSION||'missing'));}catch(e){}
 var api=root.getAttribute('data-api-url'),canModify=root.getAttribute('data-can-modify')==='1';
 var catalogUrl=(root.getAttribute('data-catalog-url')||'').replace(/\/$/,'');var imageBaseUrl=(root.getAttribute('data-image-base-url')||'').replace(/\/$/,'')+'/';var frontEditorToken=root.getAttribute('data-front-editor-token')||'';var filemanagerUrl=root.getAttribute('data-filemanager-url')||'';var adminToken=root.getAttribute('data-token')||'';
 var store=new NextGenBuilderStore({document:ensureDocument(null),selectedId:null,device:'desktop',dirty:false});
 var els={canvas:root.querySelector('[data-ng-canvas]'),settings:root.querySelector('[data-ng-settings]'),widgets:root.querySelector('[data-ng-widget-list]'),path:root.querySelector('[data-ng-selection-path]'),settingsTitle:root.querySelector('[data-ng-settings-title]')};
 var templateId=parseInt(root.getAttribute('data-template-id')||'0',10)||0;var componentId=parseInt(root.getAttribute('data-component-id')||'0',10)||0;var templateMode=templateId>0;var componentMode=componentId>0;var meta={document_id:0,template_id:templateId,component_id:componentId,name:'Untitled Page',route:'',template_type:'page',version:0};
 var drag={nodeId:null,sourceType:null,dropTarget:null,position:null}; var frontSaveTimer=null; var frontSaveInFlight=false; var frontSaveQueued=false; ensureOpenCartImageBinding();
 function request(action,method,data,id,key){key=key||'document_id';var url=api+'&route=extension/theme/nextgen/builder/'+action+(id?'&'+key+'='+encodeURIComponent(id):'');var opts={method:method||'GET',headers:{'Content-Type':'application/json'}};if(data)opts.body=JSON.stringify(data);return fetch(url,opts).then(function(r){return r.text().then(function(t){var j;try{j=JSON.parse(t);}catch(e){throw new Error('Builder API returned non-JSON (HTTP '+r.status+'): '+t.slice(0,180));}if(!r.ok||j.success===false){throw new Error(j.error||('Builder API HTTP '+r.status));}return j;});});}
 function renderWidgets(filter){els.widgets.innerHTML='';var list=paletteWidgets().filter(function(w){return !filter||w.name.toLowerCase().indexOf(filter.toLowerCase())>-1;});list.forEach(function(w){els.widgets.appendChild(widgetButton(w,false));});STRUCTURES.forEach(function(w){var b=widgetButton(w,true);b.style.display='none';b.setAttribute('data-ng-structure','1');els.widgets.appendChild(b);});}
 function widgetButton(w,isStructure){var b=document.createElement('button');b.type='button';b.className='ng-widget';b.draggable=true;b.innerHTML='<span class="ng-widget-icon">'+w.icon+'</span><span class="ng-widget-name">'+w.name+'</span>';b.onclick=function(){isStructure?addStructure(w.id):addWidget(w.id);};b.addEventListener('dragstart',function(e){drag.nodeId=null;drag.sourceType=w.id;e.dataTransfer.effectAllowed='copy';e.dataTransfer.setData('text/nextgen-widget',w.id);b.classList.add('is-dragging');});b.addEventListener('dragend',clearDrop);return b;}
 function addStructure(type){store.update(function(s){var doc=s.document,n=makeStructure(type),p=doc;if(type==='container'){var target=byId(doc,s.selectedId);p=(target&&isAllowed(target.type,type))?target:findNearestContainer(doc,s.selectedId,type);if(!p)p=doc;}p.children=p.children||[];p.children.push(n);s.selectedId=n.id;});}
 function findWidgetDropTarget(doc,id){
   var n=id?byId(doc,id):null;
   if(!n)return findFirstByType(doc,'container');
   if(n.type==='container')return n;
   if(n.type==='section'||n.type==='root'){var direct=findFirstByType(n,'container');if(direct)return direct;}
   var p=findParent(doc,n.id);
   while(p){
     if(p.type==='container')return p;
     if(p.type==='section'||p.type==='root'){var c=findFirstByType(p,'container');if(c)return c;}
     p=findParent(doc,p.id);
   }
   return null;
 }
 function addWidget(id){var def=WIDGETS.find(function(w){return w.id===id;});store.update(function(s){var selected=byId(s.document,s.selectedId),p=selected;
   if(!p||!isAllowed(p.type,id)){p=findWidgetDropTarget(s.document,s.selectedId);}
   if(!p||!isAllowed(p.type,id)){setStatus('Select a container to add this widget.');return;}
   var depth=nodeDepth(s.document,p.id);if(isWidgetType(p.type)&&depth>=MAX_WIDGET_NESTING){setStatus('Maximum widget nesting depth reached');return;}
   p.children=p.children||[];var n=node(id,def?def.settings:{});p.children.push(n);s.selectedId=n.id;
 });}
 function duplicateNodeById(id){store.select(id);duplicateSelected();}
 function addDefaultChildWidget(id){var st=store.get(),p=byId(st.document,id);if(!p)return;var type='heading';if(!isAllowed(p.type,type)){type='text';}if(!isAllowed(p.type,type)){setStatus('This element does not accept child widgets. Use a Container.');return;}store.select(id);addWidget(type);}

 function findNearestContainer(doc,id,type){var n=id?byId(doc,id):null;while(n){if(isAllowed(n.type,type))return n;n=findParent(doc,n.id);}if(isAllowed(doc.type,type))return doc;return null;}
 function deleteSelected(){var id=store.get().selectedId;if(!id){setStatus('Nothing selected to delete');return;}store.update(function(s){var p=findParent(s.document,id);if(!p){setStatus('Cannot delete this element');return;}p.children=(p.children||[]).filter(function(n){return n.id!==id;});s.selectedId=p.type==='root'?null:p.id;});setStatus('Deleted');}
 function duplicateSelected(){var id=store.get().selectedId;store.update(function(s){var p=findParent(s.document,id),n=byId(s.document,id);if(!p||!n){setStatus('Nothing selected to duplicate');return;}var copy=regenerateIds(clone(n));var i=p.children.indexOf(n);p.children.splice(i+1,0,copy);s.selectedId=copy.id;});setStatus('Duplicated');}
 function copySelected(){var n=byId(store.get().document,store.get().selectedId);if(n){store.copy(n);setStatus('Copied '+n.type);return true;}setStatus('Nothing selected to copy');return false;}
 function pasteSelected(){var clip=store.paste();if(!clip){setStatus('Clipboard is empty');return false;}var ok=false;store.update(function(s){var target=byId(s.document,s.selectedId);var type=clip.type;var p=target&&isAllowed(target.type,type)?target:findNearestContainer(s.document,s.selectedId,type);if(!p){setStatus('Cannot paste '+type+' here');return;}var copy=regenerateIds(clip);p.children=p.children||[];p.children.push(copy);s.selectedId=copy.id;ok=true;});if(ok)setStatus('Pasted');return ok;}
 function moveNode(id,targetId,position){store.update(function(s){var doc=s.document,n=byId(doc,id),target=byId(doc,targetId);if(!n||!target||n.id===target.id||contains(n,target.id))return;var oldParent=findParent(doc,id);if(!oldParent)return;var oldIndex=oldParent.children.indexOf(n);if(oldIndex<0)return;var parent=target;var insertIndex=0;
   if(position==='inside'){if(!isAllowed(target.type,n.type))return;if(isWidgetType(parent.type)&&nodeDepth(doc,parent.id)>=MAX_WIDGET_NESTING)return;parent=target;insertIndex=(parent.children||[]).length;}
   else {parent=findParent(doc,target.id);if(!parent||!isAllowed(parent.type,n.type))return;insertIndex=parent.children.indexOf(target)+(position==='after'?1:0);}
   oldParent.children.splice(oldIndex,1);if(parent===oldParent&&oldIndex<insertIndex)insertIndex--;parent.children=parent.children||[];parent.children.splice(insertIndex,0,n);s.selectedId=n.id;});}
 function dropWidget(type,targetId,position){store.update(function(s){var target=byId(s.document,targetId);if(!target)return;var p=target;
   if(position==='inside' && isWidgetType(type) && (target.type==='section'||target.type==='container'||target.type==='root')) p=findWidgetDropTarget(s.document,targetId);
   else if(position!=='inside') p=findParent(s.document,targetId);
   if(!p)return;if(!isAllowed(p.type,type))return;var depth=nodeDepth(s.document,p.id);if(position==='inside'&&isWidgetType(p.type)&&depth>=MAX_WIDGET_NESTING){setStatus('Maximum widget nesting depth reached');return;}var def=WIDGETS.find(function(w){return w.id===type;});var n=def?node(type,def.settings):makeStructure(type);var idx=(position==='inside')?(p.children||[]).length:p.children.indexOf(target)+(position==='after'?1:0);p.children=p.children||[];p.children.splice(idx,0,n);s.selectedId=n.id;});}
 function validDrop(sourceType,targetId,position){var s=store.get(),target=byId(s.document,targetId);if(!target)return false;if(drag.nodeId){var n=byId(s.document,drag.nodeId);if(!n||n.id===target.id||contains(n,target.id))return false;if(position==='inside'){if(isWidgetType(n.type)&&(target.type==='section'||target.type==='container'||target.type==='root'))return !!findWidgetDropTarget(s.document,target.id);if(!isAllowed(target.type,n.type))return false;if(isWidgetType(target.type)&&nodeDepth(s.document,target.id)>=MAX_WIDGET_NESTING)return false;return true;}var p=findParent(s.document,target.id);return !!p&&isAllowed(p.type,n.type);}if(!sourceType)return false;if(position==='inside'){if(isWidgetType(sourceType)&&(target.type==='section'||target.type==='container'||target.type==='root'))return !!findWidgetDropTarget(s.document,target.id);if(!isAllowed(target.type,sourceType))return false;if(isWidgetType(target.type)&&nodeDepth(s.document,target.id)>=MAX_WIDGET_NESTING)return false;return true;}var p=findParent(s.document,target.id);return !!p&&isAllowed(p.type,sourceType);}
 function clearDrop(){root.querySelectorAll('.is-drop-target,.is-drop-before,.is-drop-after,.is-dragging').forEach(function(x){x.classList.remove('is-drop-target','is-drop-before','is-drop-after','is-dragging');});drag.dropTarget=null;drag.position=null;}
 function markDrop(el,position){clearDrop();el.classList.add(position==='inside'?'is-drop-target':position==='before'?'is-drop-before':'is-drop-after');drag.dropTarget=el.getAttribute('data-node-id');drag.position=position;}
 function dropPosition(el,e){var r=el.getBoundingClientRect(),y=e.clientY;var n=byId(store.get().document,el.getAttribute('data-node-id'));if(n&&(n.type==='section'||n.type==='container'||isWidgetType(n.type))&&y>r.top+r.height*.3&&y<r.bottom-r.height*.3)return 'inside';return y<r.top+r.height/2?'before':'after';}
 function attachDnD(el,n){el.draggable=true;el.addEventListener('dragstart',function(e){e.stopPropagation();drag.nodeId=n.id;drag.sourceType=n.type;drag.dropTarget=null;e.dataTransfer.effectAllowed='move';e.dataTransfer.setData('text/nextgen-node',n.id);el.classList.add('is-dragging');});el.addEventListener('dragend',clearDrop);el.addEventListener('dragover',function(e){e.preventDefault();e.stopPropagation();var p=dropPosition(el,e);if(validDrop(drag.nodeId?drag.sourceType:drag.sourceType, n.id,p)){e.dataTransfer.dropEffect=drag.nodeId?'move':'copy';markDrop(el,p);}else{clearDrop();e.dataTransfer.dropEffect='none';}});el.addEventListener('drop',function(e){e.preventDefault();e.stopPropagation();var p=drag.position,t=drag.dropTarget;if(!p||t!==n.id){clearDrop();return;}if(drag.nodeId)moveNode(drag.nodeId,n.id,p);else dropWidget(drag.sourceType,n.id,p);clearDrop();});}
 function renderWidgetPreview(el,n,state){
   var s=n.settings||{}, type=n.type;
   if(type==='heading'){var x=document.createElement(s.tag||'h2');x.className='ng-heading';x.style.textAlign=s.align||'left';x.textContent=s.text||s.content||'Heading';el.appendChild(x);return;}
   if(type==='text'||type==='text_editor'){var x=document.createElement('div');x.className='ng-text';x.innerHTML=s.text||s.content||'Start building your content here.';el.appendChild(x);return;}
   if(type==='button'){var x=document.createElement('a');x.className='ng-button';x.href=s.url||'#';x.textContent=s.text||s.content||'Button';el.appendChild(x);return;}
   if(type==='image'){if(s.src){var x=document.createElement('img');x.src=builderAssetUrl(s.src);x.alt=s.alt||'';x.className='ng-preview-image';el.appendChild(x);}else{var p=document.createElement('div');p.className='ng-placeholder';p.textContent='Image';el.appendChild(p);}return;}
   if(type==='icon'){var x=document.createElement('div');x.className='ng-preview-icon';x.textContent=s.icon||'★';el.appendChild(x);return;}
   if(type==='icon_box'){el.innerHTML='<div class="ng-preview-icon-box"><div class="ng-preview-icon">'+(s.icon||'✦')+'</div><h3>'+escapeHtml(s.title||'Icon Box')+'</h3><p>'+escapeHtml(s.text||'Description')+'</p></div>';return;}
   if(type==='spacer'){el.style.minHeight=(parseInt(s.height,10)||40)+'px';el.innerHTML='<span class="ng-widget-placeholder-label">Spacer · '+(parseInt(s.height,10)||40)+'px</span>';return;}
   if(type==='divider'){el.innerHTML='<hr class="ng-preview-divider">';return;}
   if(type==='hero'||type==='hero_slider'){
     var slides=(type==='hero_slider'&&Array.isArray(s.slides))?s.slides:[];
     var item=(slides.length?slides[0]:s)||{};
     var heroImage=builderAssetUrl(item.image||s.image||'');
     var heroMobile=builderAssetUrl(item.mobileImage||s.mobileImage||'');
     var device=state.device||'desktop';
     var responsive=s.responsive&&typeof s.responsive==='object'?s.responsive:{};
     function rv(key,fallback){var r=responsive[key];if(r&&typeof r==='object'&&r[device]!==undefined&&r[device]!=='')return r[device];if(device!=='desktop'&&r&&typeof r==='object'&&r.desktop!==undefined&&r.desktop!=='')return r.desktop;return s[key]!==undefined?s[key]:fallback;}
     var heroEyebrowSize=rv('heroEyebrowSize','');var heroEyebrowWeight=rv('heroEyebrowWeight','');var heroEyebrowColor=rv('heroEyebrowColor','');var heroEyebrowFontFamily=rv('heroEyebrowFontFamily','');var heroHeadingSize=rv('heroHeadingSize','');var heroHeadingWeight=rv('heroHeadingWeight','');var heroHeadingColor=rv('heroHeadingColor','');var heroHeadingFontFamily=rv('heroHeadingFontFamily','');var heroBodySize=rv('heroBodySize','');var heroBodyColor=rv('heroBodyColor','');var heroBodyFontFamily=rv('heroBodyFontFamily','');var buttonBackground=rv('buttonBackground','');var buttonColor=rv('buttonColor','');var buttonRadius=rv('buttonRadius','');var buttonPadding=rv('buttonPadding','');var buttonBorderColor=rv('buttonBorderColor','');var buttonBorderWidth=rv('buttonBorderWidth','');var buttonBorderStyle=rv('buttonBorderStyle','');var buttonShadow=rv('buttonShadow','');var buttonFontFamily=rv('buttonFontFamily','');var buttonFontSize=rv('buttonFontSize','');var buttonFontWeight=rv('buttonFontWeight','');var buttonLineHeight=rv('buttonLineHeight','');var buttonLetterSpacing=rv('buttonLetterSpacing','');var buttonTransform=rv('buttonTransform','');
     var hover=(s.states&&s.states.hover&&typeof s.states.hover==='object')?s.states.hover:{};var hoverResponsive=hover.responsive&&typeof hover.responsive==='object'?hover.responsive:{};
     function hv(key,fallback){var r=hoverResponsive[key];if(r&&typeof r==='object'&&r[device]!==undefined&&r[device]!=='')return r[device];if(device!=='desktop'&&r&&r.desktop!==undefined&&r.desktop!=='')return r.desktop;if(hover[key]!==undefined&&hover[key]!==null&&hover[key]!=='')return hover[key];var direct=s['buttonHover'+key.charAt(0).toUpperCase()+key.slice(1)];return direct!==undefined&&direct!==''?direct:fallback;}
     var buttonHoverBackground=hv('buttonHoverBackground','');var buttonHoverColor=hv('buttonHoverColor','');var buttonHoverBorderColor=hv('buttonHoverBorderColor','');var buttonHoverBorderWidth=hv('buttonHoverBorderWidth','');var buttonHoverBorderStyle=hv('buttonHoverBorderStyle','');var buttonHoverRadius=hv('buttonHoverRadius','');var buttonHoverShadow=hv('buttonHoverShadow','');var buttonHoverTransform=hv('buttonHoverTransform',''); var heroHoverBackground=hv('heroHoverBackground','');var heroHoverOverlayColor=hv('heroHoverOverlayColor','');var heroHoverOverlayOpacity=hv('heroHoverOverlayOpacity','');var heroHoverOpacity=hv('heroHoverOpacity','');var heroHoverFilter=hv('heroHoverFilter','');var heroHoverTransform=hv('heroHoverTransform','');
     var heroPos=item.backgroundPosition||s.backgroundPosition||'center center';
     var heroSize=item.backgroundSize||s.backgroundSize||'cover';
     var heroHeight=rv('minHeight',s.minHeight||'520px');var imageOpacity=rv('imageOpacity','1');var imageFilter=rv('imageFilter','');
     var heroWidth=s.widthMode||'contained';
     var heroAlign=(item.contentPosition||s.contentPosition||'left center').split(/\s+/);
     var h=heroAlign[0]||'left',v=heroAlign[1]||'center';
     var justify=v==='top'?'flex-start':(v==='bottom'?'flex-end':'center');
     var align=h==='right'?'flex-end':(h==='center'?'center':'flex-start');
     var heroStyle='min-height:'+escapeHtml(heroHeight)+';';
     if(heroWidth==='full_bleed')heroStyle+='width:100vw;max-width:100vw;margin-left:50%;transform:translateX(-50%);';
     else if(heroWidth==='full')heroStyle+='width:100%;max-width:100%;margin-left:0;margin-right:0;transform:none;';
     else if(heroWidth==='wide')heroStyle+='width:calc(100% + 4vw);max-width:none;margin-left:-2vw;';
     else if(heroWidth==='custom')heroStyle+='width:'+(s.customWidth||'100%')+';max-width:'+(s.customWidth||'100%')+';margin-left:auto;margin-right:auto;';
     var copyStyle='align-items:'+align+';justify-content:'+justify+';text-align:'+(rv('textAlign',s.textAlign||'left'))+';max-width:'+(rv('contentMaxWidth',s.contentMaxWidth||'760px'))+';padding:'+(rv('contentPadding',s.contentPadding||''))+';gap:'+(rv('contentGap',s.contentGap||'16px'))+';';
     var eyebrowStyle='';
     var heroEyebrowLineHeight=rv('heroEyebrowLineHeight','');var heroEyebrowLetterSpacing=rv('heroEyebrowLetterSpacing','');var heroEyebrowWordSpacing=rv('heroEyebrowWordSpacing','');var heroEyebrowTransform=rv('heroEyebrowTransform','');var heroEyebrowDecoration=rv('heroEyebrowDecoration','');var heroEyebrowStyle=rv('heroEyebrowStyle','');var heroEyebrowShadow=rv('heroEyebrowShadow','');
     if(heroEyebrowSize)eyebrowStyle+='font-size:'+escapeHtml(heroEyebrowSize)+';';
     if(heroEyebrowWeight)eyebrowStyle+='font-weight:'+escapeHtml(heroEyebrowWeight)+';';
     if(heroEyebrowColor)eyebrowStyle+='color:'+escapeHtml(heroEyebrowColor)+';';
     if(heroEyebrowFontFamily)eyebrowStyle+='font-family:'+escapeHtml(heroEyebrowFontFamily)+';';
     if(heroEyebrowLineHeight)eyebrowStyle+='line-height:'+escapeHtml(heroEyebrowLineHeight)+';';
     if(heroEyebrowLetterSpacing)eyebrowStyle+='letter-spacing:'+escapeHtml(heroEyebrowLetterSpacing)+';';
     if(heroEyebrowWordSpacing)eyebrowStyle+='word-spacing:'+escapeHtml(heroEyebrowWordSpacing)+';';
     if(heroEyebrowTransform)eyebrowStyle+='text-transform:'+escapeHtml(heroEyebrowTransform)+';';
     if(heroEyebrowDecoration)eyebrowStyle+='text-decoration:'+escapeHtml(heroEyebrowDecoration)+';';
     if(heroEyebrowStyle)eyebrowStyle+='font-style:'+escapeHtml(heroEyebrowStyle)+';';
     if(heroEyebrowShadow)eyebrowStyle+='text-shadow:'+escapeHtml(heroEyebrowShadow)+';';
     var headingStyle='';
     if(heroHeadingSize)headingStyle+='font-size:'+escapeHtml(heroHeadingSize)+';';
     if(heroHeadingWeight)headingStyle+='font-weight:'+escapeHtml(heroHeadingWeight)+';';
     if(heroHeadingColor)headingStyle+='color:'+escapeHtml(heroHeadingColor)+';';
     if(heroHeadingFontFamily)headingStyle+='font-family:'+escapeHtml(heroHeadingFontFamily)+';';
     var bodyStyle='';
     if(heroBodySize)bodyStyle+='font-size:'+escapeHtml(heroBodySize)+';';
     if(heroBodyColor)bodyStyle+='color:'+escapeHtml(heroBodyColor)+';';
     if(heroBodyFontFamily)bodyStyle+='font-family:'+escapeHtml(heroBodyFontFamily)+';';
     var buttonStyle='';
     if(buttonBackground)buttonStyle+='background:'+escapeHtml(buttonBackground)+';';
     if(buttonColor)buttonStyle+='color:'+escapeHtml(buttonColor)+';';
     if(buttonFontFamily)buttonStyle+='font-family:'+escapeHtml(buttonFontFamily)+';';
     if(buttonFontSize)buttonStyle+='font-size:'+escapeHtml(buttonFontSize)+';';
     if(buttonFontWeight)buttonStyle+='font-weight:'+escapeHtml(buttonFontWeight)+';';
     if(buttonLineHeight)buttonStyle+='line-height:'+escapeHtml(buttonLineHeight)+';';
     if(buttonLetterSpacing)buttonStyle+='letter-spacing:'+escapeHtml(buttonLetterSpacing)+';';
     if(buttonTransform)buttonStyle+='text-transform:'+escapeHtml(buttonTransform)+';';
     if(buttonRadius)buttonStyle+='border-radius:'+escapeHtml(buttonRadius)+';';
     if(buttonPadding)buttonStyle+='padding:'+escapeHtml(buttonPadding)+';';
     if(buttonBorderWidth)buttonStyle+='border-width:'+escapeHtml(buttonBorderWidth)+';';
     if(buttonBorderStyle)buttonStyle+='border-style:'+escapeHtml(buttonBorderStyle)+';';
     if(buttonBorderColor)buttonStyle+='border-color:'+escapeHtml(buttonBorderColor)+';';
     if(buttonShadow)buttonStyle+='box-shadow:'+escapeHtml(buttonShadow)+';';
     var overlay=s.overlayColor||'';
     var slideCount=slides.length;
     var tag=s.headingTag||'h2';if(!/^h[1-6]$/.test(tag))tag='h2';
     var media=heroImage?'<img class="ng-preview-hero-media" style="opacity:' + escapeHtml(imageOpacity||'1') + ';' + (imageFilter?'filter:'+escapeHtml(imageFilter)+';':'') + '" src="'+escapeHtml(device==='mobile'&&heroMobile?heroMobile:heroImage)+'" alt="" />':'';
     var hoverCss='';if(buttonHoverBackground||buttonHoverColor||buttonHoverBorderColor||buttonHoverBorderWidth||buttonHoverBorderStyle||buttonHoverRadius||buttonHoverShadow||buttonHoverTransform){hoverCss+='.ng-preview-hero-live .ng-button:hover{'+(buttonHoverBackground?'background:'+escapeHtml(buttonHoverBackground)+' !important;':'')+(buttonHoverColor?'color:'+escapeHtml(buttonHoverColor)+' !important;':'')+(buttonHoverBorderColor?'border-color:'+escapeHtml(buttonHoverBorderColor)+' !important;':'')+(buttonHoverBorderWidth?'border-width:'+escapeHtml(buttonHoverBorderWidth)+' !important;':'')+(buttonHoverBorderStyle?'border-style:'+escapeHtml(buttonHoverBorderStyle)+' !important;':'')+(buttonHoverRadius?'border-radius:'+escapeHtml(buttonHoverRadius)+' !important;':'')+(buttonHoverShadow?'box-shadow:'+escapeHtml(buttonHoverShadow)+' !important;':'')+(buttonHoverTransform==='lift'?'transform:translateY(-2px) !important;':(buttonHoverTransform==='scale'?'transform:scale(1.03) !important;':(buttonHoverTransform&&buttonHoverTransform!=='none'?'transform:'+escapeHtml(buttonHoverTransform)+' !important;':'')))+'}';}if(heroHoverBackground||heroHoverOverlayColor||heroHoverOverlayOpacity||heroHoverOpacity||heroHoverFilter||heroHoverTransform){hoverCss+='.ng-preview-hero-live:hover{'+(heroHoverBackground?'background:'+escapeHtml(heroHoverBackground)+' !important;':'')+(heroHoverOpacity?'opacity:'+escapeHtml(heroHoverOpacity)+' !important;':'')+(heroHoverFilter?'filter:'+escapeHtml(heroHoverFilter)+' !important;':'')+(heroHoverTransform?'transform:'+escapeHtml(heroHoverTransform)+' !important;':'')+'}.ng-preview-hero-live:hover .ng-preview-hero-overlay{'+(heroHoverOverlayColor?'background:'+escapeHtml(heroHoverOverlayColor)+' !important;':'')+(heroHoverOverlayOpacity?'opacity:'+escapeHtml(heroHoverOverlayOpacity)+' !important;':'')+'}';}
     el.innerHTML='<div class="ng-preview-hero ng-preview-hero-live" style="'+heroStyle+'">'+(hoverCss?'<style>'+hoverCss+'</style>':'')+media+'<div class="ng-preview-hero-overlay" style="background:'+(overlay?escapeHtml(overlay):'transparent')+';"></div><div class="ng-preview-hero-copy" style="'+copyStyle+'"><span class="ng-preview-kicker" style="'+eyebrowStyle+'">'+escapeHtml(item.eyebrow||s.eyebrow||'NEXTGEN HERO')+'</span><'+tag+' style="'+headingStyle+'">'+escapeHtml(item.heading||s.heading||'Your headline')+'</'+tag+'><p style="'+bodyStyle+'">'+escapeHtml(item.text||s.text||'Build a conversion-focused hero section visually.')+'</p><a class="ng-button" style="'+buttonStyle+'">'+escapeHtml(item.button||s.button||'Shop Now')+'</a></div>'+(slideCount?'<span class="ng-preview-slide-count">'+slideCount+' slide'+(slideCount===1?'':'s')+'</span>':'')+'</div>';
     return;
   }
   if(type==='fashion_categories'){var cats=(s.items&&Array.isArray(s.items)&&s.items.length?s.items:[{title:'Women',image:'image/catalog/nextgen/demos/fashion/women.jpg'},{title:'Men',image:'image/catalog/nextgen/demos/fashion/men.jpg'},{title:'Accessories',image:'image/catalog/nextgen/demos/fashion/accessories.jpg'}]);el.innerHTML='<div class="ng-preview-fashion-categories">'+cats.map(function(it){var u=builderAssetUrl(it.image);return '<div class="ng-preview-fashion-card"><div class="ng-preview-fashion-card-media"><img src="'+escapeHtml(u)+'" alt="'+escapeHtml(it.title||'')+'"><span>'+escapeHtml(it.title||'')+'</span></div></div>';}).join('')+'</div>';return;}
   if(type==='fashion_lookbook'){var looks=(s.items&&Array.isArray(s.items)&&s.items.length?s.items:[{title:'Form',subtitle:'01 / Tailoring',image:'image/catalog/nextgen/demos/fashion/lookbook-01.jpg'},{title:'Texture',subtitle:'02 / Details',image:'image/catalog/nextgen/demos/fashion/lookbook-02.jpg'}]);el.innerHTML='<div class="ng-preview-fashion-lookbook">'+looks.map(function(it){return '<article><img src="'+escapeHtml(builderAssetUrl(it.image))+'" alt="'+escapeHtml(it.title||'')+'"><div><small>'+escapeHtml(it.subtitle||'')+'</small><h3>'+escapeHtml(it.title||'')+'</h3></div></article>';}).join('')+'</div>';return;}
   if(type==='fashion_promo'){var promoImg=builderAssetUrl(s.image||'image/catalog/nextgen/demos/fashion/promo.jpg');el.innerHTML='<div class="ng-preview-fashion-promo" style="background-image:url(&quot;'+escapeHtml(promoImg)+'&quot;)"><div><span class="ng-preview-kicker">MEMBERS</span><h2>'+escapeHtml(s.heading||'Private Sale')+'</h2><p>'+escapeHtml(s.text||'Up to 30% off selected styles')+'</p><a class="ng-button">Shop the edit</a></div></div>';return;}
   if(type==='fashion_marquee'){el.innerHTML='<div class="ng-fashion-marquee"><div>'+escapeHtml(s.text||'LIMITED EDITION · NEW SEASON · UP TO 70% OFF')+'</div></div>';return;}
   if(type==='fashion_products'){var imgs=['product-01.jpg','product-02.jpg','product-03.jpg','product-04.jpg'];el.innerHTML='<div class="ng-preview-products">'+imgs.map(function(im,i){return '<div class="ng-preview-product-card"><div class="ng-preview-product-image" style="background-image:url(\"'+escapeHtml(builderAssetUrl('image/catalog/nextgen/demos/fashion/'+im))+'\")"></div><div class="ng-preview-product-brand">MODERN FASHION</div><h4>'+['Nightfall Set','Soft Structure','Studio Edit','Evening Form'][i]+'</h4><div class="ng-preview-price">$'+[89,120,98,110][i]+'.00</div></div>';}).join('')+'</div>';return;}
   if(type==='fashion_sale'){el.innerHTML='<div class="ng-fashion-sale"><div class="ng-fashion-sale__media"><img src="'+escapeHtml(builderAssetUrl(s.image||'image/catalog/nextgen/demos/fashion/product-04.jpg'))+'"></div><div class="ng-fashion-sale__copy"><span>LIMITED EDIT</span><h2>'+escapeHtml(s.heading||'SALE')+'</h2><p>'+escapeHtml(s.text||'Up to 70% off selected styles.')+'</p></div></div>';return;}
   if(type==='fashion_editorial'){el.innerHTML='<div class="ng-fashion-editorial"><article><img src="'+escapeHtml(builderAssetUrl(s.image_a||'image/catalog/nextgen/demos/fashion/editorial-01.jpg'))+'"><div><span>NEW COLLECTION</span><h2>New Collection</h2><p>Editorial storytelling section.</p></div></article></div>';return;}
   if(type==='fashion_inspiration'){el.innerHTML='<div class="ng-fashion-inspiration"><div class="ng-fashion-inspiration__head"><span>INSPO / JOURNAL</span><h2>Inspiration</h2></div><div class="ng-fashion-inspiration__grid">'+[1,2,3,4,5,6].map(function(i){return '<div class="ng-fashion-inspiration__item"><img src="'+escapeHtml(builderAssetUrl('image/catalog/nextgen/demos/fashion/inspiration-0'+i+'.jpg'))+'"></div>';}).join('')+'</div></div>';return;}
   if(type==='fashion_testimonials'){el.innerHTML='<div class="ng-fashion-testimonials"><span>WORDS FROM OUR CUSTOMERS</span><blockquote>“The collection feels considered without ever feeling complicated.”</blockquote><strong>— CHARLOTTE M.</strong></div>';return;}
   if(type==='fashion_blog'){el.innerHTML='<div class="ng-fashion-blog"><div class="ng-fashion-blog__head"><span>JOURNAL</span><h2>From the Blog</h2></div><div class="ng-fashion-blog__grid">'+[1,2,3,4].map(function(i){return '<article><img src="'+escapeHtml(builderAssetUrl('image/catalog/nextgen/demos/fashion/blog-0'+i+'.jpg'))+'"><h3>Journal Story '+i+'</h3></article>';}).join('')+'</div></div>';return;}
   if(type==='fashion_newsletter'){el.innerHTML='<div class="ng-fashion-newsletter"><span>JOIN THE LIST</span><h2>Sign up now &amp; get 10% off</h2><p>Stay up to date with new arrivals and stories.</p></div>';return;}
   if(type==='category_grid'){
     var cats=Array.isArray(s.categories)?s.categories:[];
     var cols=Math.max(1,Math.min(8,parseInt(s.columns,10)||4)), gap=Math.max(0,parseInt(s.gap,10)||20);
     var mode=s.displayMode==='slider'?'slider':'grid';
     var wrap=document.createElement('div');
     wrap.className='ng-preview-category-grid ng-preview-category-'+mode;
     wrap.style.setProperty('--ng-preview-category-columns',cols);
     wrap.style.setProperty('--ng-preview-category-gap',gap+'px');
     if(mode==='slider'){wrap.style.display='block';wrap.style.overflow='hidden';}
     else {wrap.style.display='grid';wrap.style.gridTemplateColumns='repeat('+cols+',minmax(0,1fr))';wrap.style.gap=gap+'px';}
     var track=wrap;
     if(mode==='slider'){
       track=document.createElement('div');track.className='ng-preview-category-track';
       track.style.display='flex';track.style.gap=gap+'px';track.style.width='100%';track.style.transition='transform .35s ease';
       wrap.appendChild(track);
     }
     if(!cats.length){var ep=document.createElement('div');ep.className='ng-placeholder';ep.textContent='Select categories';(mode==='slider'?track:wrap).appendChild(ep);}
     else cats.forEach(function(c){
       var card=document.createElement('div');card.className='ng-preview-category-card';
       if(mode==='slider'){
         card.style.flex='0 0 100%';
         card.style.width='100%';
         card.style.maxWidth='100%';
         card.style.minWidth='100%';
       }
       var img=document.createElement('div');img.className='ng-preview-category-image';
       if(c.image){img.style.backgroundImage='url("'+builderAssetUrl(c.image)+'")';}else img.textContent='Category';
       var name=document.createElement('div');name.className='ng-preview-category-name';name.textContent=c.name||'Category';
       var placement=s.namePosition==='below'?'below':'overlay';
       if(placement==='overlay'){
         name.classList.add('is-overlay');
         name.classList.add('pos-'+(s.nameOverlayPosition||'bottom-center'));
         card.appendChild(img);
         if(s.showName!==false)card.appendChild(name);
       }else{
         card.appendChild(img);
         if(s.showName!==false){name.classList.add('is-below');name.style.textAlign=s.nameAlign||'center';card.appendChild(name);}
       }
       if(s.buttonDisplay!=='never'){
         var btn=document.createElement('span');btn.className='ng-preview-category-button';btn.textContent=s.buttonText||'Shop Now';
         if(s.buttonDisplay==='always')btn.classList.add('is-always');
         card.appendChild(btn);
       }
       (mode==='slider'?track:wrap).appendChild(card);
     });
     if(mode==='slider' && cats.length>1){
       var iconMap={
         'chevron-left':'‹','arrow-left':'←','angle-left':'❮','double-left':'«','caret-left':'‹',
         'chevron-right':'›','arrow-right':'→','angle-right':'❯','double-right':'»','caret-right':'›'
       };
       var prev=document.createElement('button');prev.type='button';prev.className='ng-preview-category-arrow prev';prev.setAttribute('aria-label','Previous');prev.textContent=iconMap[s.arrowPrevIcon||'chevron-left']||'‹';
       var next=document.createElement('button');next.type='button';next.className='ng-preview-category-arrow next';next.setAttribute('aria-label','Next');next.textContent=iconMap[s.arrowNextIcon||'chevron-right']||'›';
       wrap.appendChild(prev);wrap.appendChild(next);
       var previewIndex=0;
       function previewStep(){return (wrap.clientWidth||0)+gap;}
       function previewGo(i){previewIndex=Math.max(0,Math.min(cats.length-1,i));track.style.transform='translate3d(-'+(previewIndex*previewStep())+'px,0,0)';}
       prev.addEventListener('click',function(){previewGo(previewIndex-1);});
       next.addEventListener('click',function(){previewGo(previewIndex+1);});
       previewGo(0);
     }
     el.appendChild(wrap);return;}
   if(type==='product'){
     var pw=document.createElement('article');pw.className='ng-preview-product-widget';pw.style.display='grid';pw.style.gridTemplateColumns=(s.layout==='image-top'?'1fr':'1fr 1fr');pw.style.gap=s.gap||'24px';pw.style.padding=s.cardPadding||'24px';pw.style.background=s.cardBackground||'#fff';pw.style.border=(s.cardBorderWidth||'1px')+' '+(s.cardBorderStyle||'solid')+' '+(s.cardBorderColor||'#e5e7eb');pw.style.borderRadius=s.cardRadius||'16px';pw.style.boxShadow=s.cardShadow||'0 10px 30px rgba(0,0,0,.08)';
     var pm=document.createElement('div');pm.className='ng-preview-product-widget-media';pm.style.background=s.imageBackground||'#f8fafc';pm.style.borderRadius=s.imageRadius||'14px';pm.style.overflow='hidden';var pimg=document.createElement('img');pimg.src=builderAssetUrl('image/catalog/demo/samsung_tab_1-600x600.jpg');pimg.style.width='100%';pimg.style.height='100%';pimg.style.minHeight='260px';pimg.style.objectFit=s.imageFit||'contain';pm.appendChild(pimg);
     var pb=document.createElement('div');pb.style.display='flex';pb.style.flexDirection='column';pb.style.justifyContent='center';if(s.showBrand!==false){var br=document.createElement('small');br.textContent='SAMSUNG';br.style.color=s.brandColor||'#94a3b8';br.style.letterSpacing='.12em';pb.appendChild(br);}var tt=document.createElement('h2');tt.textContent=s.productName||'Samsung Galaxy Tab 10.1';tt.style.color=s.titleColor||'#111827';tt.style.fontSize=s.titleSize||'30px';tt.style.fontWeight=s.titleWeight||'700';pb.appendChild(tt);if(s.showDescription!==false){var ds=document.createElement('p');ds.textContent='Product description preview. Select a product to load the real product content.';ds.style.color=s.descriptionColor||'#64748b';ds.style.fontSize=s.descriptionSize||'15px';pb.appendChild(ds);}if(s.showRating!==false){var rt=document.createElement('div');rt.textContent='★★★★★';rt.style.color=s.ratingColor||'#f59e0b';pb.appendChild(rt);}if(s.showPrice!==false){var pr=document.createElement('strong');pr.textContent='$199.99';pr.style.color=s.priceColor||'#111827';pr.style.fontSize=s.priceSize||'22px';pr.style.margin='12px 0';pb.appendChild(pr);}if(s.showAddToCart!==false){var cb=document.createElement('button');cb.type='button';cb.textContent=s.addToCartText||'Add to Cart';cb.style.background=s.buttonBackground||'#111827';cb.style.color=s.buttonColor||'#fff';cb.style.border=(s.buttonBorderWidth||'0')+' '+(s.buttonBorderStyle||'solid')+' '+(s.buttonBorderColor||'transparent');cb.style.borderRadius=s.buttonRadius||'8px';cb.style.padding=s.buttonPadding||'12px 20px';pb.appendChild(cb);}pw.appendChild(pm);pw.appendChild(pb);if(s.layout==='image-right'){pw.style.gridTemplateColumns='1fr 1fr';pw.insertBefore(pm,pb);}if(s.layout==='image-top'){pw.style.gridTemplateColumns='1fr';}el.appendChild(pw);return;
   }
   if(type==='products'){
     var mode=s.displayMode||'grid',cols=Math.max(1,parseInt(s.columns,10)||4),limit=Math.max(1,Math.min(12,parseInt(s.limit,10)||8));
     var demoImgs=['product-01.jpg','product-02.jpg','product-03.jpg','product-04.jpg','product-05.jpg','product-06.jpg','product-07.jpg','product-08.jpg'];
     var demoNames=['Nightfall Set','Soft Structure','Studio Edit','Evening Form','Modern Tailoring','Silk Structure','Weekend Edit','Signature Coat'];
     function iconSvg(kind){if(kind==='wishlist')return '<svg viewBox="0 0 24 24"><path d="M20.8 8.7c0 5-8.8 10.2-8.8 10.2S3.2 13.7 3.2 8.7A4.7 4.7 0 0 1 12 6.1a4.7 4.7 0 0 1 8.8 2.6Z"/></svg>';if(kind==='compare')return '<svg viewBox="0 0 24 24"><path d="M7 4v15M4 7l3-3 3 3M17 20V5M14 17l3 3 3-3"/></svg>';return '<svg viewBox="0 0 24 24"><path d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6Z"/><circle cx="12" cy="12" r="2.5"/></svg>';}
     function card(i){var img=builderAssetUrl('image/catalog/nextgen/demos/fashion/'+demoImgs[i%demoImgs.length]);return '<article class="ng-preview-product-card ng-preview-product-card-live"><div class="ng-preview-product-image"><img src="'+escapeHtml(img)+'" alt="" onerror="this.style.opacity=.15"><div class="ng-preview-product-actions"><button title="Wishlist">'+iconSvg('wishlist')+'</button><button title="Compare">'+iconSvg('compare')+'</button><button title="Quick View">'+iconSvg('quick')+'</button></div></div><div class="ng-preview-product-brand">MODERN FASHION</div><h4>'+demoNames[i%demoNames.length]+'</h4><strong class="ng-preview-price">$'+(99+i*25)+'.00</strong><button class="ng-preview-add-cart">Add to Cart</button></article>';}
     var count=mode==='slider'?Math.max(limit,cols+2):limit,cards=Array.from({length:count},function(_,i){return card(i);}).join('');
     if(mode==='tabs'){el.innerHTML='<div class="ng-products-preview-tabs"><div class="ng-products-preview-tab-head"><button class="active">Latest</button><button>Featured</button><button>Special</button></div><div class="ng-preview-products" style="grid-template-columns:repeat('+cols+',minmax(0,1fr))">'+cards+'</div></div>';}
     else if(mode==='slider'){
       el.innerHTML='<div class="ng-preview-slider"><div class="ng-preview-slider-viewport"><div class="ng-preview-slider-track" style="--preview-cols:'+cols+'">'+cards+'</div></div><div class="ng-preview-slider-controls"><button type="button" class="ng-preview-slider-prev">‹</button><span class="ng-preview-slider-status">1 / '+Math.max(1,count-cols+1)+'</span><button type="button" class="ng-preview-slider-next">›</button></div></div>';
       var pt=el.querySelector('.ng-preview-slider-track'),pc=Array.prototype.slice.call(pt.children),pi=0;
       function pstep(){return pc.length?pc[0].getBoundingClientRect().width+(parseFloat(getComputedStyle(pt).gap)||0):0;}
       function visiblePreviewCols(){var w=el.clientWidth||600;return Math.max(1,Math.min(cols,Math.floor((w+14)/(135+14))));} function pgo(x){var max=Math.max(0,pc.length-visiblePreviewCols());pi=Math.max(0,Math.min(max,x));pt.style.transform='translate3d(-'+(pi*pstep())+'px,0,0)';var st=el.querySelector('.ng-preview-slider-status');if(st)st.textContent=(pi+1)+' / '+(max+1);}
       el.querySelector('.ng-preview-slider-prev').onclick=function(){pgo(pi-1);};el.querySelector('.ng-preview-slider-next').onclick=function(){pgo(pi+1);};setTimeout(function(){pgo(0);},0);
     }else{el.innerHTML='<div class="ng-preview-products ng-preview-products-grid" style="grid-template-columns:repeat('+cols+',minmax(0,1fr))">'+cards+'</div>';}
     return;
   }
   if(type==='newsletter'){el.innerHTML='<div class="ng-preview-newsletter"><div><span class="ng-preview-kicker">STAY UPDATED</span><h2>Get the latest from your store</h2><p>News, launches and offers — straight to your customers.</p></div><div class="ng-preview-form"><span>Email address</span><button>Subscribe</button></div></div>';return;}
   if(type==='trust_badges'){el.innerHTML='<div class="ng-preview-trust"><span>✓ Secure checkout</span><span>✓ Fast delivery</span><span>✓ Easy returns</span></div>';return;}
   if(type==='social_links'){el.innerHTML='<div class="ng-preview-social"><span>f</span><span>◎</span><span>in</span><span>▶</span></div>';return;}
   if(type==='video'||type==='video_popup'){el.innerHTML='<div class="ng-preview-video"><span>▶</span><strong>Video</strong><small>Click to configure media</small></div>';return;}
   if(type==='gallery'||type==='image_carousel'){el.innerHTML='<div class="ng-preview-gallery"><div></div><div></div><div></div></div>';return;}
   if(type==='html'){el.innerHTML='<div class="ng-preview-generic">HTML / Custom Content</div>';return;}
   if(type==='search'){el.innerHTML='<div class="ng-preview-search">Search products <span>⌕</span></div>';return;}
   if(type==='menu'||type==='logo'||type==='account'||type==='cart'){el.innerHTML='<div class="ng-preview-header-item">'+escapeHtml(type.replace('_',' '))+'</div>';return;}
   if(type==='footer'){el.innerHTML='<div class="ng-preview-footer"><div>Footer columns</div><div>Menus</div><div>Contact</div></div>';return;}
   var generic=document.createElement('div');generic.className='ng-preview-generic';generic.textContent=(type||'Widget')+' widget';el.appendChild(generic);
 }
 function escapeHtml(v){return String(v==null?'':v).replace(/[&<>\"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','\\':'&#92;','"':'&quot;'}[c]||c;});}
 function builderAssetUrl(path){
  path=String(path||'').trim();
  if(!path)return '';
  if(/^(?:https?:)?\/\//i.test(path)){
    if(/\/catalog\//i.test(path)&&!/\/image\/catalog\//i.test(path))return path.replace(/\/catalog\//i,'/image/catalog/');
    return path;
  }
  if(path.indexOf('data:')===0)return path;
  // OpenCart Image Manager paths are stored without /image/.
  // Normalize every catalog/theme media path through the catalog image base.
  if(path.indexOf('/image/')===0 && catalogUrl)return catalogUrl+path;
  if(path.indexOf('image/')===0 && imageBaseUrl)return imageBaseUrl+path.substring(6);
  if(path.indexOf('catalog/')===0 && imageBaseUrl)return imageBaseUrl+path;
  if(path.indexOf('/catalog/')===0 && imageBaseUrl)return imageBaseUrl+path.substring(1);
  if(path.indexOf('theme/')===0 && imageBaseUrl)return imageBaseUrl+path;
  if(imageBaseUrl && !/^catalog\/view\//i.test(path) && !/^catalog\/javascript\//i.test(path))return imageBaseUrl+'catalog/'+path.replace(/^\/+/, '');
  try{return new URL('../'+path.replace(/^\/+/,''),window.location.href).href;}catch(e){return path;}
}
 function enableInlineEdit(el,n){
   if(!n||['heading','text','text_editor','button','fashion_promo','announcement'].indexOf(n.type)<0)return;
   el.addEventListener('dblclick',function(e){
     var target=el.querySelector('.ng-heading,.ng-text,.ng-button,h2,p,a');if(!target)return;e.preventDefault();e.stopPropagation();target.contentEditable='true';target.classList.add('ng-inline-editing');target.focus();
     var finish=function(){target.contentEditable='false';target.classList.remove('ng-inline-editing');var value=target.innerHTML;store.update(function(st){var x=byId(st.document,st.selectedId||n.id);if(!x)return;if(x.type==='heading')x.settings.text=target.textContent;if(x.type==='text'||x.type==='text_editor')x.settings.text=value;if(x.type==='button')x.settings.text=target.textContent;});target.removeEventListener('blur',finish);};target.addEventListener('blur',finish);target.addEventListener('keydown',function(ev){if(ev.key==='Enter'&&n.type!=='text'&&n.type!=='text_editor'){ev.preventDefault();target.blur();}});
   });
 }
 function renderNode(n,state){var el=document.createElement('div');el.className='ng-node ng-'+n.type+(state.selectedId===n.id?' is-selected':'');el.setAttribute('data-node-id',n.id);el.setAttribute('data-node-type',n.type);attachDnD(el,n);applyStyle(el,n,state.device);if(n.type==='container'){var wm=getResponsive(n,'widthMode',state.device,n.settings&&n.settings.widthMode||'boxed');el.classList.add('ng-container-mode-'+wm);if(wm==='full'){el.style.width='100vw';el.style.maxWidth='100vw';el.style.marginLeft='calc(50% - 50vw)';el.style.marginRight='calc(50% - 50vw)';}else if(wm==='wide'){el.style.width='calc(100% + 4vw)';el.style.maxWidth='none';el.style.marginLeft='-2vw';el.style.marginRight='0';}else if(wm==='custom'){var cw=getResponsive(n,'customWidth',state.device,n.settings&&n.settings.customWidth||'100%');el.style.width=cw;el.style.maxWidth=cw;el.style.marginLeft='auto';el.style.marginRight='auto';}else{el.style.width=getResponsive(n,'width',state.device,n.settings&&n.settings.width||'100%');el.style.maxWidth=getResponsive(n,'maxWidth',state.device,n.settings&&n.settings.maxWidth||'1320px');el.style.marginLeft='auto';el.style.marginRight='auto';}}var label=document.createElement('span');label.className='ng-node-label';label.textContent=n.type;el.appendChild(label);var nodeTools=document.createElement('span');nodeTools.className='ng-node-tools';nodeTools.setAttribute('draggable','false');var nodeActions=[['↕','Move',function(){store.select(n.id);setStatus('Selected '+n.type+' — drag to move');}],['✎','Edit',function(){store.select(n.id);}]];
   if(n.type==='section'){nodeActions.push(['＋','Add Container',function(){insertContainerIntoSection(n.id);}]);}
   else if(n.type==='container'){nodeActions.push(['＋','Add Container',function(){insertNestedContainer(n.id);}]);if(getResponsive(n,'layout',state.device,n.settings&&n.settings.layout||'flex')==='grid'){nodeActions.push(['▦','Add Grid Item',function(){insertGridItem(n.id);}]);}}
   nodeActions.push(['⧉','Duplicate',function(){store.select(n.id);duplicateSelected();}]);
   if(n.type!=='section' && n.type!=='root'){nodeActions.splice(2,0,['＋','Add',function(){store.select(n.id);addDefaultChildWidget(n.id);}]);nodeActions.splice(3,0,['□','Copy',function(){store.select(n.id);copySelected();}]);nodeActions.splice(4,0,['▣','Paste',function(){store.select(n.id);pasteSelected();}]);}nodeActions.push(['×','Delete',function(){store.select(n.id);deleteSelected();}]);nodeActions.forEach(function(a){var tb=document.createElement('button');tb.type='button';tb.className='ng-node-tool';tb.setAttribute('draggable','false');tb.title=a[1];tb.textContent=a[0];tb.addEventListener('pointerdown',function(ev){ev.preventDefault();ev.stopPropagation();});tb.addEventListener('click',function(ev){ev.preventDefault();ev.stopPropagation();a[2]();});nodeTools.appendChild(tb);});el.appendChild(nodeTools);el.onclick=function(e){e.stopPropagation();store.select(n.id);};
   el.ondblclick=function(e){if(n.type==='heading'||n.type==='text'||n.type==='text_editor'||n.type==='button'){e.stopPropagation();var current=(n.settings&&n.settings.text)||'';var v=window.prompt('Edit '+n.type,current);if(v!==null){store.update(function(st){var x=byId(st.document,n.id);x.settings=x.settings||{};x.settings.text=v;});}}};
   if(n.type==='section'||n.type==='container'||n.type==='root'){el.classList.add('ng-drop-zone');}
   if(n.type==='section'||n.type==='container'||isWidgetType(n.type)){if(!n.children||!n.children.length){var hint=document.createElement('div');hint.className='ng-empty-drop ng-inner-drop';hint.textContent=isWidgetType(n.type)?'Drop widget inside':(n.type==='container'?'+ Drop widget here':'');el.appendChild(hint);}}
   if(n.type!=='root'&&n.type!=='section'&&n.type!=='container'){renderWidgetPreview(el,n,state);enableInlineEdit(el,n);}
   if(n.children&&n.children.length){var slot=document.createElement('div');slot.className=(n.type==='container'?'ng-container-content':(isWidgetType(n.type)?'ng-inner-widget-slot':'ng-child-slot'));if(n.type==='container'){var containerLayout=getResponsive(n,'layout',state.device,n.settings&&n.settings.layout||'flex');slot.setAttribute('data-layout',containerLayout);slot.style.display=containerLayout==='grid'?'grid':'flex';if(containerLayout==='grid'){slot.style.gridTemplateColumns=getResponsive(n,'gridColumns',state.device,n.settings&&n.settings.gridColumns||'repeat(1,minmax(0,1fr))');slot.style.columnGap=getResponsive(n,'columnGap',state.device,n.settings&&n.settings.columnGap||getResponsive(n,'gap',state.device,'24px'));slot.style.rowGap=getResponsive(n,'rowGap',state.device,n.settings&&n.settings.rowGap||getResponsive(n,'gap',state.device,'24px'));}else{slot.style.flexDirection=getResponsive(n,'direction',state.device,n.settings&&n.settings.direction||'column');slot.style.flexWrap=getResponsive(n,'wrap',state.device,n.settings&&n.settings.wrap||'nowrap');slot.style.gap=getResponsive(n,'gap',state.device,'24px');slot.style.justifyContent=getResponsive(n,'justify',state.device,'flex-start');slot.style.alignItems=getResponsive(n,'align',state.device,'stretch');}}n.children.forEach(function(c){slot.appendChild(renderNode(c,state));});el.appendChild(slot);}
   return el;}
 function insertContainerIntoSection(sectionId){
   var ok=false;
   store.update(function(st){
     var section=byId(st.document,sectionId);
     if(!section||section.type!=='section')return;
     section.children=section.children||[];
     var c=makeStructure('container');
     section.children.push(c);st.selectedId=c.id;ok=true;
   });
   setStatus(ok?'Container added to section':'Could not add container');return ok;
 }
 function insertNestedContainer(containerId){
   var ok=false;
   store.update(function(st){
     var c=byId(st.document,containerId);
     if(!c||c.type!=='container')return;
     c.children=c.children||[];
     var child=makeStructure('container');
     c.children.push(child);st.selectedId=child.id;ok=true;
   });
   setStatus(ok?'Nested container added':'Could not add nested container');return ok;
 }
 function insertGridItem(containerId){var ok=false;store.update(function(st){var c=byId(st.document,containerId);if(!c||c.type!=='container')return;if(getResponsive(c,'layout','desktop',c.settings&&c.settings.layout||'flex')!=='grid')return;c.children=c.children||[];var item=makeStructure('container');item.settings={layout:'flex',widthMode:'boxed',width:'100%',maxWidth:'none',direction:'column',justify:'flex-start',align:'stretch',gap:'12px',wrap:'nowrap',padding:'0',margin:'0',gridColumnCount:1,gridColumns:'repeat(1,minmax(0,1fr))'};c.children.push(item);st.selectedId=item.id;ok=true;});setStatus(ok?'Grid item added — add multiple widgets inside it':'Select a grid container first');return ok;}
 function insertColumnIntoContainer(containerId){ return insertNestedContainer(containerId); }
 function insertSectionAt(index){
   var ok=false;
   store.update(function(s){
     if(!s.document||s.document.type!=='root')return;
     var n=makeStructure('section');s.document.children=s.document.children||[];
     var i=Math.max(0,Math.min(index,s.document.children.length));
     s.document.children.splice(i,0,n);s.selectedId=n.id;ok=true;
   });
   setStatus(ok?'Section added':'Could not add section');return ok;
 }
 function renderCanvas(state){els.canvas.innerHTML='';els.canvas.setAttribute('data-device',state.device);var rootNode=renderNode(state.document,state);rootNode.classList.add('ng-root');rootNode.style.minHeight='650px';var rootChildren=state.document.children||[];var rootWrap=document.createElement('div');rootWrap.className='ng-root-sections';rootChildren.forEach(function(child,index){var before=document.createElement('div');before.className='ng-section-insert';before.innerHTML='<button type="button" class="ng-section-plus" title="Add Section">+</button>';before.querySelector('button').onclick=function(e){e.stopPropagation();insertSectionAt(index);};rootWrap.appendChild(before);var rendered=rootNode.querySelector('[data-node-id="'+child.id+'"]');if(rendered){rendered.parentNode.removeChild(rendered);rootWrap.appendChild(rendered);}var after=document.createElement('div');after.className='ng-section-insert ng-section-insert-after';after.innerHTML='<button type="button" class="ng-section-plus" title="Add Section">+</button>';after.querySelector('button').onclick=function(e){e.stopPropagation();insertSectionAt(index+1);};rootWrap.appendChild(after);});if(!rootChildren.length){var emptyAdd=document.createElement('div');emptyAdd.className='ng-empty-canvas-add';emptyAdd.innerHTML='<div class="ng-elementor-add-section"><div class="ng-elementor-add-actions"><button type="button" class="ng-add-circle ng-add-section-primary" title="Add New Section">+</button><button type="button" class="ng-add-circle ng-template-circle" title="Templates">▰</button><button type="button" class="ng-add-circle ng-ai-circle" title="AI Builder">✦</button></div><div class="ng-add-section-label">Drag widget here</div></div>';emptyAdd.querySelector('.ng-add-section-primary').onclick=function(e){e.stopPropagation();insertSectionAt(0);};emptyAdd.querySelector('.ng-template-circle').onclick=function(e){e.stopPropagation();setStatus('Templates: choose a template from NextGen Theme Engine → Templates');};emptyAdd.querySelector('.ng-ai-circle').onclick=function(e){e.stopPropagation();setStatus('AI Builder is available from NextGen Theme Engine → AI Builder');};rootWrap.appendChild(emptyAdd);}els.canvas.appendChild(rootWrap);els.canvas.ondragover=function(e){e.preventDefault();};els.canvas.onclick=function(){store.select(null);};els.path.textContent=state.selectedId?(byId(state.document,state.selectedId)||{}).type||'Selected':'Nothing selected';renderSettings(state);renderNavigator(state);}
 function field(label,key,value,type,change){var wrap=document.createElement('div');wrap.className='ng-field';var l=document.createElement('label');l.textContent=label;wrap.appendChild(l);var input=document.createElement(type==='textarea'?'textarea':'input');var fieldId='ng-field-'+uid(String(key||'field'));input.id=fieldId;input.name=fieldId;input.setAttribute('data-ng-field-key',String(key||''));l.htmlFor=fieldId;if(type==='textarea')input.value=value==null?'':value;else{input.type=type||'text';input.value=value==null?'':value;}input.onchange=function(){store.update(function(s){var n=byId(s.document,s.selectedId);if(!n)return;n.settings=n.settings||{};if(key==='items_json'){try{n.settings.items=JSON.parse(input.value||'[]');delete n.settings.items_json;}catch(e){alert('Invalid items JSON.');}}else{n.settings[key]=type==='number'?Number(input.value):input.value;}if(change)change(n,input.value);});};wrap.appendChild(input);return wrap;}
 function setSettingValue(key,value){store.update(function(st){var x=byId(st.document,st.selectedId);if(!x)return;x.settings=x.settings||{};x.settings[key]=value;});}
 function openOpenCartImageManager(target,thumbId){
   var jq=window.jQuery;
   if(!jq){return false;}
   var base='';
   var raw='';
   try { raw=(new URL(window.location.href)).searchParams.get('user_token')||''; } catch(e) {}
   if(!raw){ raw=adminToken||''; raw=raw.replace(/^.*?[?&](?:user_token|token)=/i,'').split('&')[0]; }
   if(raw){ base='index.php?route=common/filemanager&user_token='+encodeURIComponent(raw); }
   else { base=filemanagerUrl||''; }
   var sep=base.indexOf('?')>-1?'&':'?';
   var url=base+sep+'target='+encodeURIComponent(target)+'&thumb='+encodeURIComponent(thumbId);
   jq('#modal-image').remove();
   jq('<div id="modal-image" class="modal fade" tabindex="-1" role="dialog"></div>').appendTo('body');
   var modal=jq('#modal-image');
   modal.load(url,function(response,status,xhr){
     if(status==='error'){
       modal.remove();
       setStatus('OpenCart Image Manager could not be loaded (HTTP '+(xhr&&xhr.status?xhr.status:'error')+').');
       return;
     }
     // OpenCart 3.x filemanager.twig supplies the selection handler through its target/thumb parameters.
     if(typeof modal.modal==='function') modal.modal('show');
     else { modal.addClass('in').show(); }
   });
   return true;
 }
 function ensureOpenCartImageBinding(){ return true; }
 function mediaPicker(parent,label,key,value){
   var wrap=document.createElement('div');wrap.className='ng-field ng-media-field ng-native-image-field';
   var l=document.createElement('label');l.textContent=label;wrap.appendChild(l);
   var target='ng-image-'+uid('field');var thumbId=target+'-thumb';var current=value||'';
   var link=document.createElement('a');link.href='#';link.id=thumbId;link.className='img-thumbnail ng-native-image-thumb';link.title='OpenCart Image Manager';
   var img=document.createElement('img');img.alt='';img.className='ng-native-image-preview';img.src=current?builderAssetUrl(current):builderAssetUrl('no_image.png');link.appendChild(img);
   var input=document.createElement('input');input.type='hidden';input.id=target;input.value=current;input.className='ng-native-image-input';
   var path=document.createElement('div');path.className='ng-media-path';path.textContent=current?('Stored: '+current):'No image selected';
   var actions=document.createElement('div');actions.className='ng-native-image-actions';
   var change=document.createElement('button');change.type='button';change.className='btn btn-primary ng-media-change';change.textContent='Choose Image';
   var clear=document.createElement('button');clear.type='button';clear.className='btn btn-light ng-media-clear';clear.textContent='Remove';
   function sync(v){v=v||'';current=v;input.value=v;path.textContent=v?('Stored: '+v):'No image selected';img.src=v?builderAssetUrl(v):builderAssetUrl('no_image.png');setSettingValue(key,v);}
   change.onclick=function(e){e.preventDefault();e.stopPropagation();openOpenCartImageManager(target,thumbId);};
   link.onclick=function(e){e.preventDefault();e.stopPropagation();openOpenCartImageManager(target,thumbId);};
   clear.onclick=function(e){e.preventDefault();e.stopPropagation();sync('');};
   actions.appendChild(change);actions.appendChild(clear);wrap.appendChild(link);wrap.appendChild(input);wrap.appendChild(actions);wrap.appendChild(path);
   if(window.jQuery){window.jQuery(document).off('change.nextgenImage', '#'+target).on('change.nextgenImage','#'+target,function(){sync(this.value);});}
   var observer=null;
   if(typeof MutationObserver!=='undefined'){try{observer=new MutationObserver(function(){var v=input.value||'';if(v!==current)sync(v);});observer.observe(input,{attributes:true,attributeFilter:['value']});}catch(e){observer=null;}}
   var poll=setInterval(function(){if(!document.body.contains(wrap)){clearInterval(poll);try{if(observer)observer.disconnect();}catch(e){}return;}var v=input.value||'';if(v!==current)sync(v);},500);
   parent.appendChild(wrap);return wrap;
 }
 function normalizeHex(v){v=(v||'').trim().toUpperCase();if(v&&v.charAt(0)!=='#')v='#'+v;if(/^#[0-9A-F]{3}$/.test(v))v='#'+v.substring(1).split('').map(function(x){return x+x;}).join('');return v;}
 function hexToRgb(v){v=normalizeHex(v);if(!/^#[0-9A-F]{6}$/.test(v))return null;return {r:parseInt(v.substr(1,2),16),g:parseInt(v.substr(3,2),16),b:parseInt(v.substr(5,2),16)};}
 function rgbToHex(r,g,b){function h(n){var x=Math.max(0,Math.min(255,Math.round(n))).toString(16).toUpperCase();return x.length===1?'0'+x:x;}return '#'+h(r)+h(g)+h(b);}
 function colorParts(v){v=(v||'').trim().toUpperCase();var hex=normalizeHex(v);if(/^#[0-9A-F]{8}$/.test(hex))return {hex:hex.substr(0,7),alpha:parseInt(hex.substr(7,2),16)/255};if(/^#[0-9A-F]{6}$/.test(hex))return {hex:hex,alpha:1};if(/^#[0-9A-F]{3}$/.test(hex))return {hex:normalizeHex(hex),alpha:1};var m=v.match(/^RGBA?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*([0-9.]+)\s*)?\)$/i);if(m)return {hex:rgbToHex(+m[1],+m[2],+m[3]),alpha:m[4]===undefined?1:Math.max(0,Math.min(1,parseFloat(m[4])))};return {hex:'#000000',alpha:1};}
 function advancedColorField(parent,label,key,value,device,responsive,state){
   var wrap=document.createElement('div');wrap.className='ng-field ng-advanced-color-field';var l=document.createElement('label');l.textContent=label;wrap.appendChild(l);
   var parts=colorParts(value||'');var row=document.createElement('div');row.className='ng-advanced-color-row';
   var picker=document.createElement('input');picker.type='color';picker.value=parts.hex;picker.className='ng-color-native';picker.title='Color picker';
   var text=document.createElement('input');text.type='text';text.value=parts.hex;text.className='ng-color-hex';text.placeholder='#000000';text.maxLength=9;
   var alpha=document.createElement('input');alpha.type='range';alpha.min='0';alpha.max='100';alpha.step='1';alpha.value=Math.round(parts.alpha*100);alpha.className='ng-color-alpha';alpha.title='Opacity';
   var alphaValue=document.createElement('span');alphaValue.className='ng-color-alpha-value';alphaValue.textContent=alpha.value+'%';
   var swatch=document.createElement('span');swatch.className='ng-color-swatch';
   var clear=document.createElement('button');clear.type='button';clear.className='btn btn-light ng-color-clear';clear.textContent='Clear';
   function emit(){var hex=normalizeHex(text.value);if(!/^#[0-9A-F]{6}$/.test(hex))return;var a=Math.round((+alpha.value/100)*255).toString(16).toUpperCase();if(a.length===1)a='0'+a;var out=(+alpha.value>=100)?hex:hex+a;swatch.style.backgroundColor=out;alphaValue.textContent=alpha.value+'%';store.update(function(st){var x=byId(st.document,st.selectedId);if(!x)return;x.settings=x.settings||{};if(state==='hover'){x.settings.states=x.settings.states||{};x.settings.states.hover=x.settings.states.hover||{};if(responsive){x.settings.states.hover.responsive=x.settings.states.hover.responsive||{};x.settings.states.hover.responsive[key]=x.settings.states.hover.responsive[key]||{};x.settings.states.hover.responsive[key][device]=out;}else{x.settings.states.hover[key]=out;}}else if(responsive){setResponsive(x,key,device,out);}else{x.settings[key]=out;}});}
   function setBase(hex){hex=normalizeHex(hex);if(/^#[0-9A-F]{6}$/.test(hex)){text.value=hex;picker.value=hex;swatch.style.backgroundColor=hex;emit();}}
   picker.oninput=function(){text.value=picker.value.toUpperCase();emit();};text.onchange=function(){var hex=normalizeHex(text.value);if(/^#[0-9A-F]{6}$/.test(hex)){text.value=hex;picker.value=hex;emit();}else{text.value=parts.hex;}};alpha.oninput=function(){alphaValue.textContent=alpha.value+'%';emit();};clear.onclick=function(){text.value='';alpha.value='100';alphaValue.textContent='100%';swatch.style.background='transparent';store.update(function(st){var x=byId(st.document,st.selectedId);if(!x)return;x.settings=x.settings||{};if(state==='hover'){x.settings.states=x.settings.states||{};x.settings.states.hover=x.settings.states.hover||{};if(responsive){x.settings.states.hover.responsive=x.settings.states.hover.responsive||{};if(x.settings.states.hover.responsive[key])delete x.settings.states.hover.responsive[key][device];}else delete x.settings.states.hover[key];}else if(responsive){setResponsive(x,key,device,'');}else delete x.settings[key];});};
   row.appendChild(swatch);row.appendChild(picker);row.appendChild(text);row.appendChild(alpha);row.appendChild(alphaValue);row.appendChild(clear);wrap.appendChild(row);
   var presets=document.createElement('div');presets.className='ng-color-presets';['#000000','#FFFFFF','#111827','#2563EB','#DC2626','#16A34A','#F59E0B','#8B5CF6'].forEach(function(c){var b=document.createElement('button');b.type='button';b.className='ng-color-preset';b.style.backgroundColor=c;b.title=c;b.onclick=function(){setBase(c);};presets.appendChild(b);});wrap.appendChild(presets);return wrap;
 }
 function commonStyleControls(parent,n,s,device){
   var g=group('Typography');
   selectField(g,'Font Family','fontFamily',getResponsive(n,'fontFamily',device,s.fontFamily||''),[['','Default'],['Inter','Inter'],['Arial','Arial'],['Helvetica','Helvetica'],['Georgia','Georgia'],['Times New Roman','Times New Roman'],['Verdana','Verdana'],['system-ui','System UI']],device,true);
   unitControl(g,'Font Size','fontSize',getResponsive(n,'fontSize',device,''),device,['px','rem','em','%','vw','vh']);
   selectField(g,'Font Weight','fontWeight',getResponsive(n,'fontWeight',device,''),[['','Default'],['100','100'],['200','200'],['300','300'],['400','400'],['500','500'],['600','600'],['700','700'],['800','800'],['900','900']],device,true);
   unitControl(g,'Line Height','lineHeight',getResponsive(n,'lineHeight',device,''),device,['px','rem','em','%']);
   unitControl(g,'Letter Spacing','letterSpacing',getResponsive(n,'letterSpacing',device,''),device,['px','rem','em']);
   unitControl(g,'Word Spacing','wordSpacing',getResponsive(n,'wordSpacing',device,''),device,['px','rem','em']);
   selectField(g,'Text Transform','textTransform',getResponsive(n,'textTransform',device,''),[['','Default'],['none','None'],['uppercase','Uppercase'],['lowercase','Lowercase'],['capitalize','Capitalize']],device,true);
   selectField(g,'Text Decoration','textDecoration',getResponsive(n,'textDecoration',device,''),[['','Default'],['none','None'],['underline','Underline'],['overline','Overline'],['line-through','Line Through']],device,true);
   selectField(g,'Font Style','fontStyle',getResponsive(n,'fontStyle',device,''),[['','Default'],['normal','Normal'],['italic','Italic'],['oblique','Oblique']],device,true);
   selectField(g,'Text Align','textAlign',getResponsive(n,'textAlign',device,''),[['','Default'],['left','Left'],['center','Center'],['right','Right'],['justify','Justify']],device,true);
   selectField(g,'Text Direction','direction',getResponsive(n,'direction',device,''),[['','Default'],['ltr','LTR'],['rtl','RTL']],device,true);
   g.appendChild(advancedColorField(g,'Text Color','color',getResponsive(n,'color',device,''),device,true));
   var shadow=group('Text Shadow');shadow.appendChild(advancedColorField(shadow,'Shadow Color','textShadowColor',getResponsive(n,'textShadowColor',device,''),device,true));unitControl(shadow,'Horizontal','textShadowX',getResponsive(n,'textShadowX',device,''),device,['px','em']);unitControl(shadow,'Vertical','textShadowY',getResponsive(n,'textShadowY',device,''),device,['px','em']);unitControl(shadow,'Blur','textShadowBlur',getResponsive(n,'textShadowBlur',device,''),device,['px','em']);
   var stroke=group('Text Stroke');unitControl(stroke,'Stroke Width','textStrokeWidth',getResponsive(n,'textStrokeWidth',device,''),device,['px']);stroke.appendChild(advancedColorField(stroke,'Stroke Color','textStrokeColor',getResponsive(n,'textStrokeColor',device,''),device,true));
   var bg=group('Background');bg.appendChild(advancedColorField(bg,'Background Color','backgroundColor',getResponsive(n,'backgroundColor',device,''),device,true));mediaPicker(bg,'Background Image','backgroundImage',getResponsive(n,'backgroundImage',device,''));
   var spacing=group('Spacing');responsiveField(spacing,'Margin','margin',getResponsive(n,'margin',device,''),device,'text');responsiveField(spacing,'Padding','padding',getResponsive(n,'padding',device,''),device,'text');responsiveField(spacing,'Width','width',getResponsive(n,'width',device,''),device,'text');responsiveField(spacing,'Max Width','maxWidth',getResponsive(n,'maxWidth',device,''),device,'text');
   var border=group('Border');responsiveField(border,'Border Width','borderWidth',getResponsive(n,'borderWidth',device,''),device,'text');selectField(border,'Border Style','borderStyle',getResponsive(n,'borderStyle',device,''),[['','Default'],['none','None'],['solid','Solid'],['dashed','Dashed'],['dotted','Dotted']],device,true);border.appendChild(advancedColorField(border,'Border Color','borderColor',getResponsive(n,'borderColor',device,''),device,true));responsiveField(border,'Radius','radius',getResponsive(n,'radius',device,''),device,'text');
   var effects=group('Effects');responsiveField(effects,'Box Shadow','shadow',getResponsive(n,'shadow',device,''),device,'text');responsiveField(effects,'Opacity','opacity',getResponsive(n,'opacity',device,''),device,'text');
 }
 function advancedControls(parent,s,device){
   var g=group('CSS & Attributes');
   g.appendChild(field('CSS Class','class',s.class||'','text'));
   g.appendChild(field('CSS ID','id',s.id||'','text'));
   g.appendChild(field('Custom Attributes','customAttributes',s.customAttributes||'','text'));
   g.appendChild(field('Custom CSS','customCss',s.customCss||'','textarea'));
   var vis=group('Responsive Visibility');
   ['desktop','tablet','mobile'].forEach(function(d){
     var row=document.createElement('label');row.className='ng-check';var cb=document.createElement('input');cb.type='checkbox';cb.checked=!!(s.visibility&&s.visibility[d]===false);
     cb.onchange=function(){store.update(function(st){var x=byId(st.document,st.selectedId);if(!x)return;x.settings=x.settings||{};x.settings.visibility=x.settings.visibility||{};x.settings.visibility[d]=!cb.checked;});};
     row.appendChild(cb);row.appendChild(document.createTextNode(' Hide on '+d));vis.appendChild(row);
   });
   var motion=group('Motion & Interaction');
   selectField(motion,'Entrance Animation','animation',s.animation||'none',[['none','None'],['fade','Fade'],['fade-up','Fade Up'],['fade-down','Fade Down'],['zoom-in','Zoom In'],['slide-left','Slide Left'],['slide-right','Slide Right']],device,false);
   unitControl(motion,'Duration','animationDuration',s.animationDuration||500,device,['ms']);
   unitControl(motion,'Delay','animationDelay',s.animationDelay||0,device,['ms']);
   selectField(motion,'Easing','animationEasing',s.animationEasing||'ease',[['ease','Ease'],['linear','Linear'],['ease-in','Ease In'],['ease-out','Ease Out'],['ease-in-out','Ease In Out']],device,false);
   var inter=group('Interactions');
   selectField(inter,'Cursor','cursor',s.cursor||'default',[['default','Default'],['pointer','Pointer'],['grab','Grab'],['zoom-in','Zoom In']],device,false);
   field(inter,'Scroll To ID','scrollTo',s.scrollTo||'','text');
   var cond=group('Visibility Conditions');
   field(cond,'Condition Key','conditionKey',s.conditionKey||'','text');
   selectField(cond,'Condition','conditionOperator',s.conditionOperator||'exists',[['exists','Exists'],['equals','Equals'],['not_equals','Not Equals'],['contains','Contains']],device,false);
   field(cond,'Condition Value','conditionValue',s.conditionValue||'','text');
 }
 function stateKey(s,state){return state==='hover'?(s.states&&s.states.hover)||{}:s;}
 function ensureStateStyle(n,state){n.settings=n.settings||{};if(state==='hover'){n.settings.states=n.settings.states||{};n.settings.states.hover=n.settings.states.hover||{};return n.settings.states.hover;}return n.settings;}
 function stateField(parent,label,key,value,device,type,state){
   var wrap=document.createElement('div');wrap.className='ng-field';var l=document.createElement('label');l.textContent=label;wrap.appendChild(l);
   var input=document.createElement(type==='textarea'?'textarea':'input');if(type!=='textarea')input.type=type||'text';input.value=value==null?'':value;
   input.onchange=function(){store.update(function(st){var x=byId(st.document,st.selectedId);if(!x)return;var target=ensureStateStyle(x,state);if(device){target.responsive=target.responsive||{};target.responsive[key]=target.responsive[key]||{};target.responsive[key][device]=input.value;}else target[key]=input.value;});};wrap.appendChild(input);parent.appendChild(wrap);return wrap;
 }
 function navigatorNode(n,body,depth,state){
   var row=document.createElement('button');row.type='button';row.className='ng-nav-item'+(state.selectedId===n.id?' active':'');row.style.paddingLeft=(10+depth*14)+'px';row.textContent=(n.type||'node').replace(/_/g,' ');row.onclick=function(e){e.stopPropagation();store.select(n.id);};body.appendChild(row);(n.children||[]).forEach(function(c){navigatorNode(c,body,depth+1,state);});
 }
 function renderNavigator(state){var body=root.querySelector('[data-ng-navigator-body]');if(!body)return;body.innerHTML='';if(state.document)navigatorNode(state.document,body,0,state);}
 function inspectorAccordion(parent,title,icon,open){
  var box=document.createElement('div');
  box.className='ng-inspector-accordion'+(open===false?'':' is-open');
  var head=document.createElement('button');
  head.type='button';
  head.className='ng-inspector-accordion-head';
  var ic=document.createElement('span');
  ic.className='ng-inspector-accordion-icon';
  ic.textContent=icon||'•';
  var ttl=document.createElement('span');
  ttl.className='ng-inspector-accordion-title';
  ttl.textContent=title||'Settings';
  var chev=document.createElement('span');
  chev.className='ng-inspector-accordion-chevron';
  chev.textContent='⌄';
  head.appendChild(ic);head.appendChild(ttl);head.appendChild(chev);
  var content=document.createElement('div');
  content.className='ng-inspector-accordion-content';
  head.addEventListener('click',function(e){
    e.preventDefault();
    box.classList.toggle('is-open');
  });
  box.appendChild(head);box.appendChild(content);parent.appendChild(box);
  return content;
}

  // Shared inspector control primitives. Keep these centralized so every widget
  // uses the same Elementor-style controls instead of implementing its own.
  function group(title){
    return inspectorAccordion(body,title,'',true);
  }
  function stateWrite(key,value,device,responsive,stateName){
    var st=store.get();
    var x=byId(st.document,st.selectedId);
    if(!x)return;
    x.settings=x.settings||{};
    var target=x.settings;
    if(stateName&&stateName!=='normal'){
      x.settings.states=x.settings.states||{};
      x.settings.states[stateName]=x.settings.states[stateName]||{};
      target=x.settings.states[stateName];
    }
    if(responsive){
      target.responsive=target.responsive||{};
      target.responsive[key]=target.responsive[key]||{};
      target.responsive[key][device]=value;
      if(stateName==='normal' && device==='desktop')x.settings[key]=value;
    }else{
      target[key]=value;
    }
    store.commit(st);
  }
  function selectField(parent,label,key,value,options,device,responsive,stateName){
    var wrap=document.createElement('div');wrap.className='ng-field';
    var l=document.createElement('label');l.textContent=label;wrap.appendChild(l);
    var input=document.createElement('select');
    var fieldId='ng-select-'+uid(String(key||'select'));input.id=fieldId;input.name=fieldId;input.setAttribute('data-ng-field-key',String(key||''));l.htmlFor=fieldId;
    (options||[]).forEach(function(o){
      var op=document.createElement('option');op.value=o[0];op.textContent=o[1];
      if(String(o[0])===String(value==null?'':value))op.selected=true;
      input.appendChild(op);
    });
    input.onchange=function(e){if(e){e.stopPropagation();}stateWrite(key,input.value,device,responsive!==false,stateName||'normal');};
    input.onclick=function(e){e.stopPropagation();};
    wrap.appendChild(input);parent.appendChild(wrap);return wrap;
  }
  function responsiveField(parent,label,key,value,device,type,stateName){
    var wrap=document.createElement('div');wrap.className='ng-field';
    var l=document.createElement('label');l.textContent=label;wrap.appendChild(l);
    var input=document.createElement('input');input.type=type||'text';var fieldId='ng-responsive-'+uid(String(key||'field'));input.id=fieldId;input.name=fieldId;input.setAttribute('data-ng-field-key',String(key||''));l.htmlFor=fieldId;
    input.value=value==null?'':value;input.placeholder='Desktop default / '+device;
    input.onchange=function(){
      var v=type==='number'?(input.value===''?'':Number(input.value)):input.value;
      stateWrite(key,v,device,true,stateName||'normal');
    };
    wrap.appendChild(input);parent.appendChild(wrap);return wrap;
  }
  function unitControl(parent,label,key,value,device,units,stateName){
    var wrap=document.createElement('div');wrap.className='ng-unit-control ng-field';
    var l=document.createElement('label');l.textContent=label;wrap.appendChild(l);
    var row=document.createElement('div');row.className='ng-unit-row';
    var input=document.createElement('input');input.type='text';var inputId='ng-unit-'+uid(String(key||'unit'));input.id=inputId;input.name=inputId;input.setAttribute('data-ng-field-key',String(key||''));l.htmlFor=inputId;input.value=value==null?'':value;
    var select=document.createElement('select');var selectId=inputId+'-unit';select.id=selectId;select.name=selectId;
    var raw=String(value==null?'':value),detected='';
    (units||['px','%','em','rem','vh','vw','auto']).forEach(function(u){
      var o=document.createElement('option');o.value=u;o.textContent=u;
      if(u!=='auto' && raw.slice(-u.length)===u)detected=u;
      select.appendChild(o);
    });
    if(detected)select.value=detected;else if(select.options.length)select.value=select.options[0].value;
    function save(){
      var v=input.value.trim();if(v===''){stateWrite(key,'',device,true,stateName||'normal');return;}
      var unit=select.value;if(/^[-+]?\d*\.?\d+$/.test(v)&&unit!=='auto')v+=unit;
      stateWrite(key,v,device,true,stateName||'normal');
    }
    input.onchange=save;select.onchange=save;row.appendChild(input);row.appendChild(select);wrap.appendChild(row);parent.appendChild(wrap);return wrap;
  }

// Persist inspector UI state per selected node. Store updates re-render the
// inspector, but the user must stay on the tab/accordion they are editing.
var inspectorUiMemory={};
function getInspectorUi(nodeId,defaultTab){
  var key=nodeId||'__none__';
  if(!inspectorUiMemory[key]) inspectorUiMemory[key]={tab:defaultTab,state:'normal',accordions:{}};
  var ui=inspectorUiMemory[key];
  ui.tab=ui.tab||defaultTab;
  ui.state=ui.state||'normal';
  ui.accordions=ui.accordions||{};
  return ui;
}

function renderSettings(state){
  els.settings.innerHTML='';
  var n=state.selectedId?byId(state.document,state.selectedId):null;
  if(!n){els.settingsTitle.textContent='Settings';var empty=document.createElement('div');empty.className='ng-empty';empty.textContent='Select an element to edit its settings.';els.settings.appendChild(empty);return;}
  var prettyType=(n.type||'element').replace(/_/g,' ').replace(/\b\w/g,function(c){return c.toUpperCase();});
  els.settingsTitle.textContent='Edit '+prettyType;
  var schemas=window.NextGenInspectorSchemas&&window.NextGenInspectorSchemas.schema?window.NextGenInspectorSchemas.schema(n.type):null;
  if(!schemas){schemas={content:[],layout:[],style:[],advanced:[]};}
  var tabNames=(n.type==='root')?['Layout','Style','Advanced']:['Content','Layout','Style','Advanced'];
  var ui=getInspectorUi(n.id,tabNames[0].toLowerCase());
  var activeTab=tabNames.indexOf((ui.tab||'').replace(/^./,function(c){return c.toUpperCase();}));
  if(activeTab<0) activeTab=0;
  var tabs=document.createElement('div');tabs.className='ng-inspector-tabs ng-inspector-tabs-'+((n.type==='section'||n.type==='container'||n.type==='root')?'structural':'widget');
  tabNames.forEach(function(name,i){var b=document.createElement('button');b.type='button';b.textContent=name;b.className=i===activeTab?'active':'';b.setAttribute('data-inspector-tab',name.toLowerCase());tabs.appendChild(b);});
  els.settings.appendChild(tabs);
  var body=document.createElement('div');body.className='ng-inspector-body';els.settings.appendChild(body);
  var inspectorState=ui.state||'normal';
  var currentTab=tabNames[activeTab].toLowerCase();
  var device=state.device||'desktop';

  function currentSettings(){var x=byId(store.get().document,store.get().selectedId);return x&&x.settings?x.settings:{};}
  function readValue(node,key,fallback,responsive,stateName){
    var s=node.settings||{};var target=s;
    if(stateName&&stateName!=='normal') target=(s.states&&s.states[stateName])||{};
    if(responsive){
      var rr=target.responsive&&target.responsive[key];
      if(rr&&rr[device]!==undefined&&rr[device]!=='')return rr[device];
      if(rr&&rr.desktop!==undefined&&rr.desktop!=='')return rr.desktop;
    }
    if(target[key]!==undefined&&target[key]!==null&&target[key]!=='')return target[key];
    return fallback===undefined?'':fallback;
  }
  function writeValue(key,value,responsive,stateName){
    store.update(function(st){var x=byId(st.document,st.selectedId);if(!x)return;x.settings=x.settings||{};var target=x.settings;if(stateName&&stateName!=='normal'){x.settings.states=x.settings.states||{};x.settings.states[stateName]=x.settings.states[stateName]||{};target=x.settings.states[stateName];}
      if(responsive){target.responsive=target.responsive||{};target.responsive[key]=target.responsive[key]||{};target.responsive[key][device]=value;if(stateName==='normal'&&device==='desktop')x.settings[key]=value;}
      else target[key]=value;
    });
  }
  function simpleField(parent,def){
    var value=readValue(n,def.id,def.default,def.responsive!==false,inspectorState);
    if(def.type==='image'){mediaPicker(parent,def.label,def.id,value);return;}
    if(def.type==='color'){parent.appendChild(advancedColorField(parent,def.label,def.id,value,device,def.responsive!==false,inspectorState));return;}
    if(def.type==='hero-color'){parent.appendChild(advancedColorField(parent,def.label,def.id,readValue(n,def.id,'',true,inspectorState),device,true,inspectorState));return;}
    if(def.type==='unit'){unitControl(parent,def.label,def.id,value,device,def.units||['px','%','em','rem','vw','vh','auto'],inspectorState);return;}
    if(def.type==='select'){
      selectField(parent,def.label,def.id,value,def.options||[],device,def.responsive!==false,inspectorState);return;
    }
    if(def.type==='toggle'){
      var row=document.createElement('label');row.className='ng-check ng-switch-row';var cb=document.createElement('input');cb.type='checkbox';cb.checked=value!==''?(value===true||value==='1'||value==='true'):!!def.default;
      cb.onchange=function(){
        if(def.id==='hideDesktop'||def.id==='hideTablet'||def.id==='hideMobile'){
          var map={hideDesktop:'desktop',hideTablet:'tablet',hideMobile:'mobile'};store.update(function(st){var x=byId(st.document,st.selectedId);if(!x)return;x.settings=x.settings||{};x.settings.visibility=x.settings.visibility||{};x.settings.visibility[map[def.id]]=!cb.checked;});
        }else writeValue(def.id,cb.checked,false,inspectorState);
      };
      row.appendChild(cb);row.appendChild(document.createTextNode(' '+def.label));parent.appendChild(row);return;
    }
    if(def.type==='range'){
      var rw=document.createElement('div');rw.className='ng-field';var rl=document.createElement('label');rl.textContent=def.label;rw.appendChild(rl);var rr=document.createElement('input');rr.type='range';rr.min=def.min;rr.max=def.max;rr.step=def.step||1;rr.value=value===''?(def.default!==undefined?def.default:def.min):value;var rv=document.createElement('span');rv.className='ng-range-value';rv.textContent=rr.value;rr.oninput=function(){rv.textContent=rr.value;};rr.onchange=function(){writeValue(def.id,rr.value,def.responsive!==false,inspectorState);};rw.appendChild(rr);rw.appendChild(rv);parent.appendChild(rw);return;
    }
    if(def.type==='number'){
      responsiveField(parent,def.label,def.id,value,device,'number',inspectorState);return;
    }
    if(def.type==='code'){
      var cg=document.createElement('div');cg.className='ng-field';var cl=document.createElement('label');cl.textContent=def.label;cg.appendChild(cl);var ta=document.createElement('textarea');ta.value=value||'';ta.rows=def.id==='customCss'?8:4;ta.placeholder=def.description||'';ta.onchange=function(){writeValue(def.id,ta.value,false,inspectorState);};cg.appendChild(ta);if(def.description){var hp=document.createElement('p');hp.className='ng-help';hp.textContent=def.description;cg.appendChild(hp);}parent.appendChild(cg);return;
    }
    var type=def.type==='textarea'?'textarea':'text';var f=field(def.label,def.id,value,type);var input=f.querySelector('input,textarea');if(input){input.onchange=function(){writeValue(def.id,type==='number'?Number(input.value):input.value,def.responsive!==false,inspectorState);};}parent.appendChild(f);
  }
  function accordion(parent,title,controls,open){
    var key=currentTab+':'+title;
    var initial=Object.prototype.hasOwnProperty.call(ui.accordions,key)?!!ui.accordions[key]:(open!==false);
    var content=inspectorAccordion(parent,title,'',initial);
    var box=content.parentNode;
    var head=box&&box.querySelector?box.querySelector('.ng-inspector-accordion-head'):null;
    if(head) head.addEventListener('click',function(){ui.accordions[key]=box.classList.contains('is-open');});
    (controls||[]).forEach(function(def){simpleField(content,def);});
    return content;
  }
  function heroSlidesRepeater(parent){
    var st=store.get(),node=byId(st.document,st.selectedId);if(!node)return;node.settings=node.settings||{};
    var slides=Array.isArray(node.settings.slides)?JSON.parse(JSON.stringify(node.settings.slides)):[];
    if(!slides.length)slides=[{title:'Slide 1',eyebrow:'NEXTGEN HERO',mediaType:'image',heading:'Your headline',text:'Your supporting content',button:'Shop Now',url:'#',target:'_self',image:'',mobileImage:'',videoUrl:'',videoPoster:'',backgroundPosition:'center center',backgroundSize:'cover',backgroundRepeat:'no-repeat',contentPosition:'left center',textAlign:'left',overlayColor:'#000000',overlayOpacity:.25}];
    var wrap=document.createElement('div');wrap.className='ng-hero-slides-builder';var help=document.createElement('p');help.className='ng-help';help.textContent='Create and fully configure each slide. Every slide can have its own image, text, button, position and overlay.';wrap.appendChild(help);
    function save(next){slides=next;store.update(function(st2){var n2=byId(st2.document,st2.selectedId);if(n2){n2.settings=n2.settings||{};n2.settings.slides=slides;}});renderContent();}
    function field(container,label,value,type,cb){var f=document.createElement('div');f.className='ng-field';var l=document.createElement('label');l.textContent=label;f.appendChild(l);var x=document.createElement(type==='textarea'?'textarea':'input');x.type=type==='number'?'number':'text';x.value=value==null?'':value;if(type==='textarea')x.rows=3;x.onchange=function(){cb(x.value)};f.appendChild(x);container.appendChild(f);return x;}
    function select(container,label,value,opts,cb){var f=document.createElement('div');f.className='ng-field';var l=document.createElement('label');l.textContent=label;f.appendChild(l);var x=document.createElement('select');opts.forEach(function(o){var q=document.createElement('option');q.value=o[0];q.textContent=o[1];if(String(value)===String(o[0]))q.selected=true;x.appendChild(q)});x.onchange=function(){cb(x.value)};f.appendChild(x);container.appendChild(f);}
    function toggle(container,label,value,cb){var f=document.createElement('label');f.className='ng-check ng-switch-row';var x=document.createElement('input');x.type='checkbox';x.checked=value===true||value==='1'||value==='true';x.onchange=function(){cb(x.checked)};f.appendChild(x);f.appendChild(document.createTextNode(' '+label));container.appendChild(f);}
    function slideCard(slide,index){var item=document.createElement('div');item.className='ng-hero-slide-builder-item';var head=document.createElement('div');head.className='ng-products-tab-builder-head';var title=document.createElement('strong');title.textContent=(index+1)+'. '+(slide.title||slide.heading||'Slide');head.appendChild(title);var tools=document.createElement('div');tools.className='ng-products-tab-builder-tools';[['↑','up'],['↓','down'],['⧉','dup'],['×','del']].forEach(function(a){var b=document.createElement('button');b.type='button';b.className='ng-mini-btn';b.textContent=a[0];b.onclick=function(){var n=JSON.parse(JSON.stringify(slides));if(a[1]==='del'){if(n.length===1)return;n.splice(index,1)}else if(a[1]==='dup')n.splice(index+1,0,Object.assign({},n[index],{title:(n[index].title||'Slide')+' Copy'}));else if(a[1]==='up'&&index)n.splice(index-1,0,n.splice(index,1)[0]);else if(a[1]==='down'&&index<n.length-1)n.splice(index+1,0,n.splice(index,1)[0]);else return;save(n)};tools.appendChild(b)});head.appendChild(tools);item.appendChild(head);
      var body=document.createElement('div');body.className='ng-products-tab-builder-body';
      field(body,'Slide Name',slide.title||('Slide '+(index+1)),'text',function(v){var n=JSON.parse(JSON.stringify(slides));n[index].title=v;save(n)});
      select(body,'Media Type',slide.mediaType||'image',[['image','Image'],['video','Video']],function(v){var n=JSON.parse(JSON.stringify(slides));n[index].mediaType=v;save(n)});
      mediaPicker(body,'Desktop Image','__hero_slide_image_'+index,slide.image||'');
      var imgHidden=body.querySelector('.ng-native-image-field:last-of-type input.ng-native-image-input');
      if(imgHidden){imgHidden.addEventListener('change',function(){var n=JSON.parse(JSON.stringify(slides));n[index].image=imgHidden.value;save(n)});}
      mediaPicker(body,'Mobile Image','__hero_slide_mobile_'+index,slide.mobileImage||'');
      var allInputs=body.querySelectorAll('.ng-native-image-input');if(allInputs.length){var ih=allInputs[allInputs.length-1];ih.addEventListener('change',function(){var n=JSON.parse(JSON.stringify(slides));n[index].mobileImage=ih.value;save(n)});}
      field(body,'Video URL',slide.videoUrl||'','text',function(v){var n=JSON.parse(JSON.stringify(slides));n[index].videoUrl=v;save(n)});
      mediaPicker(body,'Video Poster','__hero_slide_poster_'+index,slide.videoPoster||'');
      var hs=body.querySelectorAll('.ng-native-image-input');if(hs.length){var hp=hs[hs.length-1];hp.addEventListener('change',function(){var n=JSON.parse(JSON.stringify(slides));n[index].videoPoster=hp.value;save(n)});}
      field(body,'Eyebrow',slide.eyebrow||'','text',function(v){var n=JSON.parse(JSON.stringify(slides));n[index].eyebrow=v;save(n)});
      field(body,'Heading',slide.heading||'','text',function(v){var n=JSON.parse(JSON.stringify(slides));n[index].heading=v;save(n)});
      field(body,'Description',slide.text||'','textarea',function(v){var n=JSON.parse(JSON.stringify(slides));n[index].text=v;save(n)});
      field(body,'Button Text',slide.button||'','text',function(v){var n=JSON.parse(JSON.stringify(slides));n[index].button=v;save(n)});
      field(body,'Button URL',slide.url||'#','text',function(v){var n=JSON.parse(JSON.stringify(slides));n[index].url=v;save(n)});
      select(body,'Open In',slide.target||'_self',[['_self','Same Window'],['_blank','New Tab']],function(v){var n=JSON.parse(JSON.stringify(slides));n[index].target=v;save(n)});
      select(body,'Content Position',slide.contentPosition||'left center',[['left top','Left / Top'],['left center','Left / Center'],['left bottom','Left / Bottom'],['center top','Center / Top'],['center center','Center / Center'],['center bottom','Center / Bottom'],['right top','Right / Top'],['right center','Right / Center'],['right bottom','Right / Bottom']],function(v){var n=JSON.parse(JSON.stringify(slides));n[index].contentPosition=v;save(n)});
      select(body,'Text Alignment',slide.textAlign||'left',[['left','Left'],['center','Center'],['right','Right'],['justify','Justify']],function(v){var n=JSON.parse(JSON.stringify(slides));n[index].textAlign=v;save(n)});
      field(body,'Image Position',slide.backgroundPosition||'center center','text',function(v){var n=JSON.parse(JSON.stringify(slides));n[index].backgroundPosition=v;save(n)});
      select(body,'Image Size',slide.backgroundSize||'cover',[['cover','Cover'],['contain','Contain'],['auto','Auto'],['100% 100%','Stretch']],function(v){var n=JSON.parse(JSON.stringify(slides));n[index].backgroundSize=v;save(n)});
      select(body,'Image Repeat',slide.backgroundRepeat||'no-repeat',[['no-repeat','No Repeat'],['repeat','Repeat'],['repeat-x','Repeat X'],['repeat-y','Repeat Y']],function(v){var n=JSON.parse(JSON.stringify(slides));n[index].backgroundRepeat=v;save(n)});
      var cwrap=document.createElement('div');cwrap.className='ng-hero-slide-builder-subgroup';var ct=document.createElement('strong');ct.textContent='Slide Overlay';cwrap.appendChild(ct);var cf=document.createElement('div');cf.className='ng-field';var cl=document.createElement('label');cl.textContent='Overlay Color';cf.appendChild(cl);var ci=document.createElement('input');ci.type='text';ci.value=slide.overlayColor||'';ci.onchange=function(){var n=JSON.parse(JSON.stringify(slides));n[index].overlayColor=ci.value;save(n)};cf.appendChild(ci);cwrap.appendChild(cf);var of=document.createElement('div');of.className='ng-field';var ol=document.createElement('label');ol.textContent='Overlay Opacity';of.appendChild(ol);var oi=document.createElement('input');oi.type='range';oi.min='0';oi.max='1';oi.step='.01';oi.value=slide.overlayOpacity==null?.25:slide.overlayOpacity;var ov=document.createElement('span');ov.className='ng-range-value';ov.textContent=oi.value;oi.oninput=function(){ov.textContent=oi.value};oi.onchange=function(){var n=JSON.parse(JSON.stringify(slides));n[index].overlayOpacity=oi.value;save(n)};of.appendChild(oi);of.appendChild(ov);cwrap.appendChild(of);body.appendChild(cwrap);
      item.appendChild(body);wrap.appendChild(item);
    }
    slides.forEach(slideCard);var add=document.createElement('button');add.type='button';add.className='ng-btn ng-btn-primary ng-products-add-tab';add.textContent='+ Add Slide';add.onclick=function(){var n=JSON.parse(JSON.stringify(slides));n.push({title:'Slide '+(n.length+1),eyebrow:'',mediaType:'image',heading:'New headline',text:'',button:'Shop Now',url:'#',target:'_self',image:'',mobileImage:'',videoUrl:'',videoPoster:'',backgroundPosition:'center center',backgroundSize:'cover',backgroundRepeat:'no-repeat',contentPosition:'left center',textAlign:'left',overlayColor:'#000000',overlayOpacity:.25});save(n)};wrap.appendChild(add);parent.appendChild(wrap);
  }
  function productsTabsRepeater(parent){
    var st=store.get(),node=byId(st.document,st.selectedId);if(!node)return;node.settings=node.settings||{};
    var tabs=Array.isArray(node.settings.tabs)?node.settings.tabs.slice():[];if(!tabs.length)tabs=[{label:'Latest Products',source:'latest',limit:Number(node.settings.limit||8)}];
    var wrap=document.createElement('div');wrap.className='ng-products-tabs-builder';var help=document.createElement('p');help.className='ng-help';help.textContent='Create custom tabs. Each tab has its own source, category or product selection.';wrap.appendChild(help);
    function saveTabs(next){tabs=next.map(function(t){return {label:String(t.label||'Tab'),source:String(t.source||'latest'),categoryId:String(t.categoryId||''),categoryName:String(t.categoryName||''),productIds:String(t.productIds||''),productNames:String(t.productNames||''),limit:Math.max(1,Math.min(60,Number(t.limit||node.settings.limit||8)))}});store.update(function(st2){var n2=byId(st2.document,st2.selectedId);if(n2){n2.settings=n2.settings||{};n2.settings.tabs=tabs;}});renderContent();}
    function field(container,label,value,type,cb){var f=document.createElement('div');f.className='ng-field';var l=document.createElement('label');l.textContent=label;f.appendChild(l);var x=document.createElement(type==='textarea'?'textarea':'input');if(type==='number')x.type='number';x.value=value==null?'':value;if(type==='textarea')x.rows=3;x.onchange=function(){cb(x.value)};f.appendChild(x);container.appendChild(f);return x;}
    function select(container,label,value,opts,cb){var f=document.createElement('div');f.className='ng-field';var l=document.createElement('label');l.textContent=label;f.appendChild(l);var x=document.createElement('select');opts.forEach(function(o){var q=document.createElement('option');q.value=o[0];q.textContent=o[1];if(String(value)===String(o[0]))q.selected=true;x.appendChild(q)});x.onchange=function(){cb(x.value)};f.appendChild(x);container.appendChild(f);}
    function search(action,q){return fetch(api+'&route=extension/theme/nextgen/builder/'+action+'&q='+encodeURIComponent(q)+'&limit=15',{headers:{Accept:'application/json'}}).then(function(r){return r.json()})}
    function picker(container,label,value,placeholder,action,pick){var f=document.createElement('div');f.className='ng-field ng-products-autocomplete';var l=document.createElement('label');l.textContent=label;f.appendChild(l);var x=document.createElement('input');x.type='text';x.value=value||'';x.placeholder=placeholder;f.appendChild(x);var menu=document.createElement('div');menu.className='ng-autocomplete-menu';menu.hidden=true;f.appendChild(menu);container.appendChild(f);var timer=null;x.oninput=function(){clearTimeout(timer);var q=x.value.trim();if(!q){menu.hidden=true;return}timer=setTimeout(function(){search(action,q).then(function(d){menu.innerHTML='';var rows=action==='category_search'?(d.categories||[]):(d.products||[]);rows.forEach(function(row){var b=document.createElement('button');b.type='button';b.className='ng-autocomplete-option';b.textContent=action==='category_search'?row.name+' (#'+row.category_id+')':row.name+(row.model?' · '+row.model:'');b.onclick=function(){pick(row);x.value=action==='category_search'?row.name:row.name;menu.hidden=true};menu.appendChild(b)});if(!rows.length){menu.innerHTML='<div class="ng-autocomplete-empty">No matches</div>'}menu.hidden=false}).catch(function(){menu.hidden=true})},180)};document.addEventListener('click',function(e){if(!f.contains(e.target))menu.hidden=true});return f}
    function card(tab,index){var item=document.createElement('div');item.className='ng-products-tab-builder-item';var head=document.createElement('div');head.className='ng-products-tab-builder-head';var title=document.createElement('strong');title.textContent=(index+1)+'. '+(tab.label||'Untitled Tab');head.appendChild(title);var tools=document.createElement('div');tools.className='ng-products-tab-builder-tools';[['↑','up'],['↓','down'],['⧉','dup'],['×','del']].forEach(function(a){var b=document.createElement('button');b.type='button';b.className='ng-mini-btn';b.textContent=a[0];b.onclick=function(){var n=tabs.slice();if(a[1]==='del'){if(n.length===1)return;n.splice(index,1)}else if(a[1]==='dup')n.splice(index+1,0,Object.assign({},n[index],{label:(n[index].label||'Tab')+' Copy'}));else if(a[1]==='up'&&index)n.splice(index-1,0,n.splice(index,1)[0]);else if(a[1]==='down'&&index<n.length-1)n.splice(index+1,0,n.splice(index,1)[0]);else return;saveTabs(n)};tools.appendChild(b)});head.appendChild(tools);item.appendChild(head);var body=document.createElement('div');body.className='ng-products-tab-builder-body';
      field(body,'Tab Name',tab.label||'Tab','text',function(v){var n=tabs.slice();n[index].label=v;saveTabs(n)});
      select(body,'Product Condition / Source',tab.source||'latest',[['latest','Latest Products'],['featured','Featured Products'],['special','Special Products'],['bestseller','Best Sellers'],['category','Category Products'],['custom','Custom Product Selection']],function(v){var n=tabs.slice();n[index].source=v;saveTabs(n)});
      if(tab.source==='category'){picker(body,'Category',tab.categoryName||'','Search category...','category_search',function(r){var n=tabs.slice();n[index].categoryId=String(r.category_id);n[index].categoryName=String(r.name);saveTabs(n)});field(body,'Category ID',tab.categoryId||'','text',function(v){var n=tabs.slice();n[index].categoryId=v;saveTabs(n)})}
      if(tab.source==='custom'){picker(body,'Add Product','', 'Search product name, model or EAN...','product_search',function(r){var n=tabs.slice(),ids=String(n[index].productIds||'').split(/[,\s]+/).filter(Boolean);if(ids.indexOf(String(r.product_id))<0)ids.push(String(r.product_id));var names=String(n[index].productNames||'').split('||').filter(Boolean);if(!names.some(function(x){return x.split('::')[0]===String(r.product_id)}))names.push(String(r.product_id)+'::'+String(r.name));n[index].productIds=ids.join(',');n[index].productNames=names.join('||');saveTabs(n)});var chips=document.createElement('div');chips.className='ng-products-selected-chips';String(tab.productNames||'').split('||').filter(Boolean).forEach(function(v){var z=v.split('::'),id=z.shift(),name=z.join('::');var c=document.createElement('span');c.className='ng-products-selected-chip';c.textContent=name;var x=document.createElement('button');x.type='button';x.textContent='×';x.onclick=function(){var n=tabs.slice();n[index].productIds=String(n[index].productIds||'').split(/[,\s]+/).filter(function(q){return q&&q!==id}).join(',');n[index].productNames=String(n[index].productNames||'').split('||').filter(function(q){return q.split('::')[0]!==id}).join('||');saveTabs(n)};c.appendChild(x);chips.appendChild(c)});body.appendChild(chips);field(body,'Product IDs',tab.productIds||'','textarea',function(v){var n=tabs.slice();n[index].productIds=v;saveTabs(n)})}
      field(body,'Products in this Tab',tab.limit||node.settings.limit||8,'number',function(v){var n=tabs.slice();n[index].limit=v;saveTabs(n)});item.appendChild(body);wrap.appendChild(item)}
    tabs.forEach(card);var add=document.createElement('button');add.type='button';add.className='ng-btn ng-btn-primary ng-products-add-tab';add.textContent='+ Add Tab';add.onclick=function(){var n=tabs.slice();n.push({label:'New Tab',source:'latest',limit:Number(node.settings.limit||8)});saveTabs(n)};wrap.appendChild(add);parent.appendChild(wrap)
  }
  function renderContent(){
    var C=window.NextGenInspectorSchemas&&window.NextGenInspectorSchemas.control;
    var controls=(schemas.content||[]).slice();

    if(n.type==='product' && C){
      accordion(body,'Product',[],true);
      var pf=document.createElement('div');pf.className='ng-field ng-products-autocomplete';
      var pl=document.createElement('label');pl.textContent='Select Product';pf.appendChild(pl);
      var pi=document.createElement('input');pi.type='search';pi.autocomplete='off';pi.placeholder='Search product name, model or EAN...';pi.value=String(readValue(n,'productName','',false,'normal')||'');pf.appendChild(pi);
      var pm=document.createElement('div');pm.className='ng-autocomplete-menu';pm.hidden=true;pf.appendChild(pm);body.appendChild(pf);
      var psel=document.createElement('div');psel.className='ng-products-selected-chips';body.appendChild(psel);
      function showSelectedProduct(){psel.innerHTML='';var id=String(readValue(n,'productId','',false,'normal')||'');var name=String(readValue(n,'productName','',false,'normal')||'');if(!id)return;var chip=document.createElement('span');chip.className='ng-products-selected-chip';chip.textContent=name||('Product #'+id);var x=document.createElement('button');x.type='button';x.textContent='×';x.onclick=function(){writeValue('productId','',false,'normal');writeValue('productName','',false,'normal');pi.value='';showSelectedProduct();};chip.appendChild(x);psel.appendChild(chip);}
      showSelectedProduct();
      var ptimer=null;pi.oninput=function(){clearTimeout(ptimer);var q=pi.value.trim();if(!q){pm.hidden=true;return;}ptimer=setTimeout(function(){fetch(api+'&route=extension/theme/nextgen/builder/product_search&q='+encodeURIComponent(q)+'&limit=15',{headers:{Accept:'application/json'}}).then(function(r){return r.json();}).then(function(d){pm.innerHTML='';(d.products||[]).forEach(function(row){var b=document.createElement('button');b.type='button';b.className='ng-autocomplete-option';b.textContent=row.name+(row.model?' · '+row.model:'');b.onclick=function(){writeValue('productId',String(row.product_id),false,'normal');writeValue('productName',String(row.name),false,'normal');pi.value=String(row.name);pm.hidden=true;showSelectedProduct();};pm.appendChild(b);});if(!d.products||!d.products.length)pm.innerHTML='<div class="ng-autocomplete-empty">No products found</div>';pm.hidden=false;}).catch(function(){pm.hidden=true;});},180);};
      document.addEventListener('click',function(e){if(!pf.contains(e.target))pm.hidden=true;});
      accordion(body,'Content',[
        C.toggle('showImage','Show Image',{default:true}), C.toggle('showBrand','Show Brand',{default:true}), C.toggle('showModel','Show Model',{default:false}), C.toggle('showDescription','Show Description',{default:true}), C.toggle('showRating','Show Rating',{default:true}), C.toggle('showPrice','Show Price',{default:true}), C.toggle('showSpecialPrice','Show Special Price',{default:true}), C.toggle('showQuantity','Show Quantity',{default:false}), C.toggle('showAddToCart','Show Add to Cart',{default:true}), C.toggle('showBuyNow','Show Buy Now',{default:false}), C.text('addToCartText','Add to Cart Text'), C.text('buyNowText','Buy Now Text')
      ],true);
      accordion(body,'Layout',[
        C.select('layout','Product Layout',[['image-left','Image Left'],['image-right','Image Right'],['image-top','Image Top']]), C.unit('imageWidth','Image Width',['px','%','vw'],{responsive:true}), C.unit('gap','Content Gap',['px','rem','em'],{responsive:true}), C.select('imageFit','Image Fit',window.NextGenInspectorSchemas.options.objectFit,{responsive:true}), C.color('imageBackground','Image Background'), C.unit('imageRadius','Image Radius',['px','%','rem','em'],{responsive:true}), C.text('cardPadding','Card Padding',{responsive:true})
      ],true);
      accordion(body,'Card Design',[
        C.color('cardBackground','Background'), C.color('cardBorderColor','Border Color'), C.unit('cardBorderWidth','Border Width',['px','rem','em'],{responsive:true}), C.select('cardBorderStyle','Border Style',[['solid','Solid'],['none','None'],['dashed','Dashed'],['dotted','Dotted']]), C.unit('cardRadius','Radius',['px','%','rem','em'],{responsive:true}), C.text('cardShadow','Box Shadow',{responsive:true})
      ],true);
      accordion(body,'Typography',[
        C.color('titleColor','Title Color'), C.unit('titleSize','Title Size',['px','rem','em','vw'],{responsive:true}), C.select('titleWeight','Title Weight',window.NextGenInspectorSchemas.options.fontWeight,{responsive:true}), C.color('descriptionColor','Description Color'), C.unit('descriptionSize','Description Size',['px','rem','em'],{responsive:true}), C.color('priceColor','Price Color'), C.unit('priceSize','Price Size',['px','rem','em'],{responsive:true}), C.color('brandColor','Brand Color'), C.color('ratingColor','Rating Color')
      ],true);
      accordion(body,'Buttons',[
        C.color('buttonBackground','Background'), C.color('buttonColor','Text Color'), C.color('buttonHoverBackground','Hover Background'), C.color('buttonHoverColor','Hover Text Color'), C.unit('buttonRadius','Radius',['px','%','rem','em'],{responsive:true}), C.text('buttonPadding','Padding',{responsive:true}), C.unit('buttonFontSize','Font Size',['px','rem','em'],{responsive:true}), C.select('buttonFontWeight','Font Weight',window.NextGenInspectorSchemas.options.fontWeight,{responsive:true}), C.color('buttonBorderColor','Border Color'), C.unit('buttonBorderWidth','Border Width',['px','rem','em'],{responsive:true}), C.select('buttonBorderStyle','Border Style',[['solid','Solid'],['none','None'],['dashed','Dashed'],['dotted','Dotted']])
      ],false);
      return;
    }

    if(n.type==='hero_slider' && C){
      accordion(body,'Slides',[],true);
      heroSlidesRepeater(body);
      accordion(body,'Slider', [
        C.select('transition','Transition',[['slide','Slide'],['fade','Fade']]), C.select('easing','Easing',[['linear','Linear'],['ease','Ease'],['ease-in','Ease In'],['ease-out','Ease Out'],['ease-in-out','Ease In Out']]), C.toggle('autoplay','Autoplay',{default:true}), C.number('interval','Autoplay Interval (ms)',{responsive:false}), C.number('speed','Transition Speed (ms)',{responsive:false}), C.toggle('loop','Loop',{default:true}), C.toggle('pauseOnHover','Pause on Hover',{default:true}), C.toggle('pauseOnFocus','Pause on Focus',{default:true}), C.toggle('swipe','Touch Swipe',{default:true}), C.toggle('keyboard','Keyboard Navigation',{default:true})
      ],true);
      accordion(body,'Arrows', [
        C.toggle('arrows','Show Arrows',{default:true}), C.select('arrowPrevIcon','Previous Icon',[['chevron-left','Chevron Left'],['arrow-left','Arrow Left'],['angle-left','Angle Left'],['double-left','Double Left'],['caret-left','Caret Left']]), C.select('arrowNextIcon','Next Icon',[['chevron-right','Chevron Right'],['arrow-right','Arrow Right'],['angle-right','Angle Right'],['double-right','Double Right'],['caret-right','Caret Right']]), C.select('arrowPosition','Position',[['middle-inside','Middle / Inside'],['middle-outside','Middle / Outside'],['top-left','Top Left'],['top-right','Top Right'],['bottom-left','Bottom Left'],['bottom-right','Bottom Right']]), C.unit('arrowOffsetX','Horizontal Offset',['px','%','rem','em'],{responsive:true}), C.unit('arrowOffsetY','Vertical Offset',['px','%','rem','em'],{responsive:true}), C.unit('arrowSize','Button Size',['px','rem','em'],{responsive:true}), C.unit('arrowIconSize','Icon Size',['px','rem','em'],{responsive:true}), C.color('arrowBackground','Background'), C.color('arrowColor','Icon Color'), C.color('arrowHoverBackground','Hover Background'), C.color('arrowHoverColor','Hover Icon Color'), C.color('arrowBorderColor','Border Color'), C.unit('arrowBorderWidth','Border Width',['px','rem','em'],{responsive:true}), C.select('arrowBorderStyle','Border Style',[['none','None'],['solid','Solid'],['dashed','Dashed'],['dotted','Dotted']]), C.unit('arrowRadius','Radius',['px','%','rem','em'],{responsive:true}), C.text('arrowShadow','Box Shadow',{responsive:true})
      ],false);
      accordion(body,'Dots', [
        C.toggle('dots','Show Dots',{default:true}), C.select('dotPosition','Position',[['bottom-center','Bottom Center'],['bottom-left','Bottom Left'],['bottom-right','Bottom Right'],['top-center','Top Center'],['top-left','Top Left'],['top-right','Top Right']]), C.unit('dotOffsetX','Horizontal Offset',['px','%','rem','em'],{responsive:true}), C.unit('dotOffsetY','Vertical Offset',['px','%','rem','em'],{responsive:true}), C.unit('dotSize','Size',['px','rem','em'],{responsive:true}), C.unit('dotGap','Gap',['px','rem','em'],{responsive:true}), C.color('dotColor','Color'), C.color('dotActiveColor','Active Color'), C.unit('dotActiveWidth','Active Width',['px','rem','em'],{responsive:true}), C.unit('dotActiveRadius','Active Radius',['px','%','rem','em'],{responsive:true})
      ],false);
      accordion(body,'Progress & Counter', [
        C.toggle('progress','Show Progress Bar',{default:false}), C.select('progressPosition','Progress Position',[['top','Top'],['bottom','Bottom']]), C.color('progressColor','Progress Color'), C.unit('progressHeight','Progress Height',['px','rem','em'],{responsive:true}), C.toggle('showCounter','Show Slide Counter',{default:false}), C.select('counterPosition','Counter Position',[['top-left','Top Left'],['top-center','Top Center'],['top-right','Top Right'],['bottom-left','Bottom Left'],['bottom-center','Bottom Center'],['bottom-right','Bottom Right']]), C.color('counterColor','Counter Text Color'), C.color('counterBackground','Counter Background'), C.unit('counterRadius','Counter Radius',['px','%','rem','em'],{responsive:true}), C.text('counterPadding','Counter Padding',{responsive:true})
      ],false);
      return;
    }

    // Products is intentionally a single unified collection widget.
    // Keep the inspector mode-first and only expose controls that are relevant
    // to the selected presentation mode.
    if(n.type==='products' && C){
      var mode=String((n.settings&&n.settings.displayMode)||'grid');

      accordion(body,'Display',[
        C.select('displayMode','Display',[['tabs','Tabs'],['slider','Slider'],['grid','Grid']])
      ],true);

      if(mode==='tabs'){
        accordion(body,'Tabs',[],true);
        productsTabsRepeater(body);
      accordion(body,'Tabs Style',[
        C.select('tabsAlign','Alignment',[['left','Left'],['center','Center'],['right','Right']],{responsive:true}),
        C.color('tabsColor','Text Color'), C.color('tabsActiveColor','Active Text Color'), C.color('tabsHoverColor','Hover Text Color'),
        C.color('tabsBackground','Background'), C.color('tabsActiveBackground','Active Background'), C.color('tabsHoverBackground','Hover Background'),
        C.color('tabsBorderColor','Border Color'), C.color('tabsActiveBorderColor','Active Border Color'),
        C.unit('tabsBorderWidth','Border Width',['px'],{responsive:false}), C.unit('tabsRadius','Radius',['px','%'],{responsive:true}),
        C.unit('tabsPadding','Padding',['px','rem','em'],{responsive:true}), C.unit('tabsGap','Gap',['px','rem','em'],{responsive:true}),
        C.unit('tabsFontSize','Font Size',['px','rem','em'],{responsive:true}), C.select('tabsFontWeight','Font Weight',[['400','400'],['500','500'],['600','600'],['700','700'],['800','800']],{responsive:true}),
        C.select('tabsTextTransform','Text Transform',[['none','None'],['uppercase','Uppercase'],['lowercase','Lowercase'],['capitalize','Capitalize']],{responsive:true}),
        C.unit('tabsMarginBottom','Bottom Spacing',['px','rem','em'],{responsive:true})
      ],true);
      }else{
        accordion(body,'Product Source',[
          C.select('source','Product Source',[
            ['latest','Latest Products'],
            ['featured','Featured Products'],
            ['special','Special Products'],
            ['bestseller','Best Sellers'],
            ['category','Category Products'],
            ['custom','Custom Products']
          ]),
          C.text('categoryId','Category ID',{description:'Used when Product Source = Category.'}),
          C.textarea('productIds','Custom Product IDs',{description:'Comma-separated product IDs when Product Source = Custom.'})
        ],true);
      }

      accordion(body,'Widget Container',[
        C.select('widgetWidthMode','Widget Width',[['full','Full Width'],['boxed','Boxed / Container'],['custom','Custom Width']]),
        C.unit('widgetWidth','Widget Width',['px','%','vw','rem'],{responsive:true}),
        C.unit('widgetMaxWidth','Maximum Width',['px','%','vw','rem','none'],{responsive:true}),
        C.select('widgetAlign','Horizontal Alignment',[['left','Left'],['center','Center'],['right','Right']],{responsive:true}),
        C.unit('widgetPaddingX','Horizontal Outer Spacing',['px','%','rem','em'],{responsive:true})
      ],true);

      accordion(body,'Layout',[
        C.number('limit','Products',{responsive:false}),
        C.number('columns','Columns',{responsive:true}),
        C.number('gap','Gap',{responsive:true}),
        C.number('columnsTablet','Tablet Columns',{responsive:false}),
        C.number('columnsMobile','Mobile Columns',{responsive:false})
      ],true);

      if(mode==='slider'){
        accordion(body,'Slider',[
          C.number('interval','Slider Interval (ms)',{responsive:false}),
          C.number('speed','Animation Speed (ms)',{responsive:false}),
          C.toggle('autoplay','Autoplay',{default:true}),
          C.toggle('loop','Loop',{default:true}),
          C.toggle('arrows','Show Arrows',{default:true}),
          C.toggle('dots','Show Dots',{default:true})
        ],true);
      }

      accordion(body,'Product Card',[
        C.toggle('showBrand','Show Brand',{default:true}),
        C.toggle('showModel','Show Model',{default:false}),
        C.toggle('showPrice','Show Price',{default:true}),
        C.toggle('showRating','Show Rating',{default:true}),
        C.toggle('showActions','Show Add to Cart',{default:true}),
        C.toggle('showWishlist','Show Wishlist',{default:true}),
        C.toggle('showCompare','Show Compare',{default:true}),
        C.toggle('showQuickView','Show Quick View',{default:true}),
        C.toggle('showHoverImage','Show Hover Image',{default:true}),
        C.toggle('showLabels','Show Sale/New Badge',{default:true}),
        C.text('newBadgeText','New Badge Text'),
        C.text('saleBadgeText','Sale Badge Text'),
        C.text('addToCartText','Add to Cart Text')
      ],true);

      accordion(body,'Action Icons',[
        C.select('wishlistIcon','Wishlist Icon',[["heart","Heart"],["heart-filled","Heart Filled"],["bookmark","Bookmark"],["plus","Plus"]]),
        C.select('compareIcon','Compare Icon',[["swap","Swap"],["compare","Compare"],["plus","Plus"]]),
        C.select('quickViewIcon','Quick View Icon',[["eye","Eye"],["search","Search"],["bookmark","Bookmark"]]),
        C.select('actionPosition','Action Position',[["overlay","Image Overlay"],["below","Below Card"],["hover","Hover"],["always","Always Visible"]]),
        C.unit('actionSize','Icon Button Size',['px','rem','em'],{responsive:true}),
        C.unit('actionIconSize','Icon Size',['px','rem','em'],{responsive:true}),
        C.unit('actionGap','Icon Gap',['px','rem','em'],{responsive:true}),
        C.color('actionBackground','Icon Background'),
        C.color('actionColor','Icon Color'),
        C.color('actionHoverColor','Hover Icon Color'),
        C.color('actionHoverBackground','Hover Background'),
        C.color('actionBorderColor','Icon Border Color'),
        C.unit('actionBorderWidth','Icon Border Width',['px','rem','em'],{responsive:true}),
        C.select('actionBorderStyle','Icon Border Style',[["solid","Solid"],["none","None"],["dashed","Dashed"],["dotted","Dotted"]]),
        C.unit('actionRadius','Icon Radius',['px','%','rem','em'],{responsive:true}),
        C.text('actionShadow','Icon Shadow'),
        C.color('actionHoverBorderColor','Hover Border Color'),
        C.text('actionIconStroke','Icon Stroke Width'),
        C.unit('actionOffsetTop','Icon Top Offset',['px','rem','em'],{responsive:true}),
        C.unit('actionOffsetRight','Icon Right Offset',['px','rem','em'],{responsive:true})
      ],true);

      if(mode==='slider'){
        accordion(body,'Slider Arrows',[
          C.select('arrowPrevIcon','Previous Arrow Icon',[["chevron-left","Chevron Left"],["arrow-left","Arrow Left"],["caret-left","Caret Left"]]),
          C.select('arrowNextIcon','Next Arrow Icon',[["chevron-right","Chevron Right"],["arrow-right","Arrow Right"],["caret-right","Caret Right"]]),
          C.select('arrowPosition','Arrow Position',[["middle-outside","Middle — Left / Right of Cards"],["middle-inside","Middle — Inside Cards"],["top","Top"],["bottom","Bottom"]]),
          C.unit('arrowOffsetX','Arrow Horizontal Offset',['px','rem','em'],{responsive:true}),
          C.unit('arrowOffsetY','Arrow Vertical Offset',['px','rem','em'],{responsive:true}),
          C.unit('arrowSize','Arrow Button Size',['px','rem','em'],{responsive:true}),
          C.unit('arrowIconSize','Arrow Icon Size',['px','rem','em'],{responsive:true}),
          C.color('arrowBackground','Arrow Background'),
          C.color('arrowColor','Arrow Color'),
          C.color('arrowHoverBackground','Arrow Hover Background'),
          C.color('arrowHoverColor','Arrow Hover Color'),
          C.color('arrowBorderColor','Arrow Border Color'),
          C.unit('arrowBorderWidth','Arrow Border Width',['px','rem','em'],{responsive:true}),
          C.select('arrowBorderStyle','Arrow Border Style',[["solid","Solid"],["none","None"],["dashed","Dashed"],["dotted","Dotted"]]),
          C.unit('arrowRadius','Arrow Radius',['px','%','rem','em'],{responsive:true}),
          C.text('arrowShadow','Arrow Shadow')
        ],true);
        accordion(body,'Slider Dots',[
          C.toggle('dots','Show Dots',{default:true}),
          C.unit('dotSize','Dot Size',['px','rem','em'],{responsive:true}),
          C.color('dotColor','Dot Color'),
          C.color('dotActiveColor','Active Dot Color'),
          C.number('dotActiveScale','Active Dot Scale',{responsive:false}),
          C.select('dotPosition','Dot Position',[["below","Below Cards"],["above","Above Cards"]])
        ],false);
      }

      accordion(body,'Card Design',[
        C.color('cardBackground','Card Background'),
        C.color('cardBorderColor','Card Border Color'),
        C.unit('cardBorderWidth','Card Border Width',['px','rem','em'],{responsive:true}),
        C.select('cardBorderStyle','Card Border Style',[["solid","Solid"],["none","None"],["dashed","Dashed"],["dotted","Dotted"]]),
        C.unit('cardRadius','Card Radius',['px','%','rem','em'],{responsive:true}),
        C.text('cardShadow','Card Shadow'),
        C.select('cardAnimation','Card Hover Animation',[["none","None"],["lift","Lift"],["zoom","Zoom"]]),
        C.text('cardPadding','Card Vertical Padding'),
        C.text('cardPaddingX','Card Horizontal Padding'),
        C.text('cardPaddingBottom','Card Bottom Padding'),
        C.color('imageBackground','Image Background'),
        C.select('imageFit','Image Fit',[["contain","Contain"],["cover","Cover"]]),
        C.unit('imageHeight','Image Height',['px','rem','em','%','vw'],{responsive:true})
      ],true);

      accordion(body,'Typography',[
        C.color('brandColor','Brand Color'),
        C.unit('brandFontSize','Brand Font Size',['px','rem','em'],{responsive:true}),
        C.select('brandFontWeight','Brand Weight',window.NextGenInspectorSchemas.options.fontWeight,{responsive:true}),
        C.text('brandLetterSpacing','Brand Letter Spacing'),
        C.color('productTitleColor','Product Title Color'),
        C.unit('productTitleSize','Product Title Size',['px','rem','em'],{responsive:true}),
        C.select('productTitleWeight','Product Title Weight',window.NextGenInspectorSchemas.options.fontWeight,{responsive:true}),
        C.text('titleMarginBottom','Title Bottom Spacing'),
        C.color('ratingColor','Rating Color'),
        C.color('reviewCountColor','Review Count Color'),
        C.unit('ratingSize','Rating Size',['px','rem','em'],{responsive:true}),
        C.color('priceColor','Price Color'),
        C.color('oldPriceColor','Old Price Color'),
        C.unit('priceFontSize','Price Font Size',['px','rem','em'],{responsive:true}),
        C.select('priceFontWeight','Price Weight',window.NextGenInspectorSchemas.options.fontWeight,{responsive:true}),
        C.unit('priceMarginBottom','Price Bottom Spacing',['px','rem','em'],{responsive:true})
      ],false);

      accordion(body,'Add to Cart',[
        C.color('cartBackground','Button Background'),
        C.color('cartColor','Button Text Color'),
        C.color('cartHoverBackground','Hover Background'),
        C.color('cartHoverColor','Hover Text Color'),
        C.unit('cartRadius','Button Radius',['px','%','rem','em'],{responsive:true}),
        C.text('cartPadding','Button Padding'),
        C.unit('cartFontSize','Font Size',['px','rem','em'],{responsive:true}),
        C.select('cartFontWeight','Font Weight',window.NextGenInspectorSchemas.options.fontWeight,{responsive:true}),
        C.text('cartLetterSpacing','Letter Spacing'),
        C.unit('cartBorderWidth','Border Width',['px','rem','em'],{responsive:true}),
        C.color('cartBorderColor','Border Color'),
        C.select('cartBorderStyle','Border Style',[["solid","Solid"],["none","None"],["dashed","Dashed"],["dotted","Dotted"]])
      ],false);
      return;
    }
    if(n.type==='hero' && C){
      accordion(body,'Media',[C.image('image','Desktop Image'),C.image('mobileImage','Mobile Image'),C.select('mediaType','Media Type',[['image','Image'],['video','Video']]),C.text('videoUrl','Video URL'),C.image('videoPoster','Video Poster')],true);
      accordion(body,'Hero Content',[C.text('eyebrow','Eyebrow'),C.textarea('heading','Heading'),C.textarea('text','Description'),C.select('headingTag','Heading Tag',window.NextGenInspectorSchemas.options.tags),C.text('button','Button Text'),C.text('url','Button URL'),C.select('target','Open In',[['_self','Same Window'],['_blank','New Tab']])],true);
      return;
    }
    if(n.type==='category_grid' && C){
      var picker=document.createElement('div');picker.className='ng-category-picker';body.appendChild(picker);
      var title=document.createElement('div');title.className='ng-category-picker-title';title.textContent='Categories';picker.appendChild(title);

      var search=document.createElement('input');
      search.type='search';
      search.className='ng-category-search';
      search.id='ng-category-search-'+uid('categories');
      search.name=search.id;
      search.placeholder='Search categories...';
      search.autocomplete='off';
      search.spellcheck=false;
      search.setAttribute('aria-label','Search categories');
      search.setAttribute('data-ng-category-control','search');
      picker.appendChild(search);

      var actions=document.createElement('div');actions.className='ng-category-picker-actions';
      var selectAll=document.createElement('button');selectAll.type='button';selectAll.className='btn btn-light';selectAll.textContent='Select Visible';
      var clearAll=document.createElement('button');clearAll.type='button';clearAll.className='btn btn-light';clearAll.textContent='Clear Visible';
      actions.appendChild(selectAll);actions.appendChild(clearAll);picker.appendChild(actions);

      var list=document.createElement('div');list.className='ng-category-picker-list';picker.appendChild(list);
      var selected=(Array.isArray(n.settings.categories)?n.settings.categories:[]).map(function(v){
        return {category_id:Number(v.category_id||v.id),name:v.name||'',image:v.image||'',image_url:v.image_url||'',url:v.url||''};
      });

      function stopInspectorEvent(e){
        e.stopPropagation();
      }
      ['click','mousedown','pointerdown','keydown','keyup','keypress'].forEach(function(type){
        search.addEventListener(type,stopInspectorEvent,true);
      });

      function categoryImageUrl(c){
        var raw=String((c&&c.image_url)||((c&&c.image)||'')).trim();
        if(!raw)return '';
        return builderAssetUrl(raw);
      }
      function persist(){
        store.update(function(st){
          var x=byId(st.document,st.selectedId);if(!x)return;
          x.settings=x.settings||{};
          x.settings.categories=selected.map(function(v){
            return {category_id:Number(v.category_id),name:v.name||'',image:v.image||'',image_url:v.image_url||'',url:v.url||''};
          });
          x.settings.categoryIds=x.settings.categories.map(function(v){return v.category_id;});
        });
      }
      function visibleItems(items){
        var q=(search.value||'').trim().toLowerCase();
        return (items||[]).filter(function(c){
          return !q||(String(c.name||'').toLowerCase().indexOf(q)>-1);
        });
      }
      function toggleCategory(c,checked){
        var id=String(c.category_id||c.id);
        if(!id||id==='0')return;
        if(checked){
          if(!selected.some(function(x){return String(x.category_id)===id;})){
            selected.push({category_id:Number(c.category_id||c.id),name:c.name||'',image:c.image||'',image_url:c.image_url||'',url:c.url||''});
          }
        }else{
          selected=selected.filter(function(x){return String(x.category_id)!==id;});
        }
        persist();
      }
      function draw(items){
        list.innerHTML='';
        var visible=visibleItems(items);
        if(!visible.length){
          var empty=document.createElement('div');empty.className='ng-help';empty.textContent='No categories found.';list.appendChild(empty);return;
        }
        visible.forEach(function(c){
          var id=String(c.category_id||c.id);
          var row=document.createElement('div');row.className='ng-category-picker-item';row.tabIndex=0;row.setAttribute('role','checkbox');
          row.setAttribute('aria-checked',selected.some(function(x){return String(x.category_id)===id;})?'true':'false');
          var cb=document.createElement('input');cb.type='checkbox';var cbId='ng-category-'+uid(id);cb.id=cbId;cb.name=cbId;
          cb.checked=selected.some(function(x){return String(x.category_id)===id;});
          cb.setAttribute('aria-label',c.name||'Category');
          var im=document.createElement('img');im.src=categoryImageUrl(c);im.alt='';im.loading='lazy';
          var nm=document.createElement('span');nm.textContent=c.name||'Category';
          row.appendChild(cb);row.appendChild(im);row.appendChild(nm);

          function apply(checked,e){
            if(e){e.preventDefault();e.stopPropagation();}
            cb.checked=!!checked;
            row.setAttribute('aria-checked',cb.checked?'true':'false');
            toggleCategory(c,cb.checked);
          }
          cb.addEventListener('change',function(e){e.stopPropagation();toggleCategory(c,cb.checked);row.setAttribute('aria-checked',cb.checked?'true':'false');});
          row.addEventListener('click',function(e){
            if(e.target===cb)return;
            apply(!cb.checked,e);
          });
          row.addEventListener('keydown',function(e){
            if(e.key==='Enter'||e.key===' '){apply(!cb.checked,e);}
            else e.stopPropagation();
          });
          ['click','mousedown','pointerdown','keydown','keyup','keypress'].forEach(function(type){
            cb.addEventListener(type,stopInspectorEvent,true);
          });
          list.appendChild(row);
        });
      }
      function getCats(){return Array.isArray(window.__NG_CATEGORIES)?window.__NG_CATEGORIES:[];}
      search.addEventListener('input',function(e){e.stopPropagation();draw(getCats());});
      search.addEventListener('change',function(e){e.stopPropagation();draw(getCats());});
      selectAll.addEventListener('click',function(e){
        e.preventDefault();e.stopPropagation();
        visibleItems(getCats()).forEach(function(c){
          var id=String(c.category_id||c.id);
          if(!selected.some(function(x){return String(x.category_id)===id;}))
            selected.push({category_id:Number(c.category_id||c.id),name:c.name||'',image:c.image||'',image_url:c.image_url||'',url:c.url||''});
        });
        persist();draw(getCats());
      });
      clearAll.addEventListener('click',function(e){
        e.preventDefault();e.stopPropagation();
        var ids=visibleItems(getCats()).map(function(c){return String(c.category_id||c.id);});
        selected=selected.filter(function(x){return ids.indexOf(String(x.category_id))===-1;});
        persist();draw(getCats());
      });

      if(window.__NG_CATEGORIES){draw(window.__NG_CATEGORIES);}
      else{
        var loading=document.createElement('div');loading.className='ng-help';loading.textContent='Loading categories...';list.appendChild(loading);
        request('categories').then(function(res){
          window.__NG_CATEGORIES=Array.isArray(res.categories)?res.categories:[];
          draw(window.__NG_CATEGORIES);
        }).catch(function(err){
          list.innerHTML='<div class="ng-inspector-error">Unable to load categories: '+escapeHtml(err.message||'Unknown error')+'</div>';
        });
      }
      accordion(body,'Grid',[
        C.select('displayMode','Display Mode',[['grid','Grid'],['slider','Slider']]),
        C.number('columns','Columns',{responsive:true}),
        C.number('gap','Gap',{responsive:true}),
        C.toggle('showName','Show Category Name',{default:true}),
        C.select('namePosition','Name Display',[['overlay','Overlay on Image'],['below','Below Image']]),
        C.select('nameOverlayPosition','Name Position',[['top-left','Top Left'],['top-center','Top Center'],['top-right','Top Right'],['center-left','Center Left'],['center','Center'],['center-right','Center Right'],['bottom-left','Bottom Left'],['bottom-center','Bottom Center'],['bottom-right','Bottom Right']]),
        C.select('nameAlign','Name Alignment',[['left','Left'],['center','Center'],['right','Right']]),
        C.select('buttonDisplay','Button Display',[['hover','On Hover'],['always','Always'],['never','Never']],{responsive:true}),
        C.text('buttonText','Button Text'),
        C.select('imageFit','Image Fit',window.NextGenInspectorSchemas.options.objectFit,{responsive:true}),
        C.unit('imageHeight','Image Height',['px','rem','vh','vw','auto'],{responsive:true}),
        C.toggle('autoplay','Autoplay',{default:true}),
        C.number('interval','Slide Interval (ms)',{responsive:false}),
        C.toggle('arrows','Show Arrows',{default:true}),
        C.select('arrowPrevIcon','Previous Arrow Icon',[['chevron-left','‹ Chevron'],['arrow-left','← Arrow'],['angle-left','❮ Angle'],['double-left','« Double'],['caret-left','‹ Caret']]),
        C.select('arrowNextIcon','Next Arrow Icon',[['chevron-right','› Chevron'],['arrow-right','→ Arrow'],['angle-right','❯ Angle'],['double-right','» Double'],['caret-right','› Caret']]),
        C.toggle('dots','Show Dots',{default:true}),
        C.toggle('loop','Loop',{default:true})
      ],true);
      return;
    }
    if(controls.length) accordion(body,'Content',controls,true);
    else {var info=document.createElement('p');info.className='ng-help';info.textContent='This element has no content controls.';body.appendChild(info);}
  }
  function renderLayout(){
    if(n.type==='container'){
      accordion(body,'Container',[window.NextGenInspectorSchemas.control.select('layout','Container Layout',[["flex","Flexbox"],["grid","Grid"]],{responsive:true}),window.NextGenInspectorSchemas.control.select('widthMode','Content Width',window.NextGenInspectorSchemas.options.widthMode,{responsive:true}),window.NextGenInspectorSchemas.control.unit('width','Width',['px','%','vw','auto'],{responsive:true}),window.NextGenInspectorSchemas.control.unit('maxWidth','Max Width',['px','%','vw','none','auto'],{responsive:true}),window.NextGenInspectorSchemas.control.unit('minHeight','Min Height',['px','%','vh','vw','auto'],{responsive:true})],true);
      var layout=readValue(n,'layout','flex',true,'normal');
      if(layout==='flex') accordion(body,'Items',[window.NextGenInspectorSchemas.control.select('direction','Direction',window.NextGenInspectorSchemas.options.direction,{responsive:true}),window.NextGenInspectorSchemas.control.select('justify','Justify Content',window.NextGenInspectorSchemas.options.justify,{responsive:true}),window.NextGenInspectorSchemas.control.select('align','Align Items',window.NextGenInspectorSchemas.options.alignItems,{responsive:true}),window.NextGenInspectorSchemas.control.text('gap','Gap',{responsive:true}),window.NextGenInspectorSchemas.control.select('wrap','Wrap',[["nowrap","No Wrap"],["wrap","Wrap"],["wrap-reverse","Wrap Reverse"]],{responsive:true})],true);
      if(layout==='grid'){
        var cg=inspectorAccordion(body,'Grid','▦',true);
        var count=readValue(n,'gridColumnCount',1,true,'normal');
        var wrap=document.createElement('div');wrap.className='ng-field';var lab=document.createElement('label');lab.textContent='Columns';wrap.appendChild(lab);
        var inp=document.createElement('input');inp.type='number';inp.min=1;inp.max=12;inp.value=count||1;
        inp.onchange=function(){var c=Math.max(1,Math.min(12,parseInt(inp.value,10)||1));writeValue('gridColumnCount',c,true,'normal');writeValue('gridColumns','repeat('+c+',minmax(0,1fr))',true,'normal');};wrap.appendChild(inp);cg.appendChild(wrap);
        simpleField(cg,window.NextGenInspectorSchemas.control.text('columnGap','Column Gap',{responsive:true}));
        simpleField(cg,window.NextGenInspectorSchemas.control.text('rowGap','Row Gap',{responsive:true}));
        simpleField(cg,window.NextGenInspectorSchemas.control.select('justifyItems','Justify Items',[["stretch","Stretch"],["start","Start"],["center","Center"],["end","End"]],{responsive:true}));
        simpleField(cg,window.NextGenInspectorSchemas.control.select('alignItems','Align Items',[["stretch","Stretch"],["start","Start"],["center","Center"],["end","End"]],{responsive:true}));
        var note=document.createElement('p');note.className='ng-help';note.textContent='Grid tracks are created automatically. Widgets are the grid items — no separate columns are required.';cg.appendChild(note);
      }
    } else if(n.type==='section'||n.type==='root'){
      accordion(body,'Section',[window.NextGenInspectorSchemas.control.select('contentWidth','Content Width',[["boxed","Boxed"],["full","Full Width"]],{responsive:true}),window.NextGenInspectorSchemas.control.unit('maxWidth','Max Width',['px','%','vw','none'],{responsive:true}),window.NextGenInspectorSchemas.control.unit('minHeight','Min Height',['px','%','vh','vw','auto'],{responsive:true})],true);
    }
    if(n.type==='hero'){
      accordion(body,'Hero Layout',[window.NextGenInspectorSchemas.control.select('widthMode','Width Mode',window.NextGenInspectorSchemas.options.widthMode,{responsive:true}),window.NextGenInspectorSchemas.control.select('contentPosition','Content Position',[["left top","Left Top"],["center top","Center Top"],["right top","Right Top"],["left center","Left Center"],["center center","Center"],["right center","Right Center"],["left bottom","Left Bottom"],["center bottom","Center Bottom"],["right bottom","Right Bottom"]],{responsive:true}),window.NextGenInspectorSchemas.control.unit('contentMaxWidth','Content Max Width',['px','%','vw'],{responsive:true}),window.NextGenInspectorSchemas.control.text('contentPadding','Content Padding',{responsive:true}),window.NextGenInspectorSchemas.control.select('textAlign','Text Alignment',window.NextGenInspectorSchemas.options.align,{responsive:true}),window.NextGenInspectorSchemas.control.unit('minHeight','Min Height',['px','vh','vw'],{responsive:true}),window.NextGenInspectorSchemas.control.unit('contentGap','Content Gap',['px','rem','em'],{responsive:true})],true);
    }
    if(n.type!=='container'&&n.type!=='hero'&&n.type!=='section'&&n.type!=='root') accordion(body,'Layout',window.NextGenInspectorSchemas.groups.layout,false);
  }
  function renderStyle(){
    var stateBar=document.createElement('div');
    stateBar.className='ng-state-bar';
    ['normal','hover'].forEach(function(st){
      var b=document.createElement('button');
      b.type='button'; b.textContent=st==='normal'?'Normal':'Hover';
      b.className=(st===inspectorState?'active':''); b.setAttribute('data-ng-state',st);
      b.onclick=function(){
        inspectorState=st; ui.state=st;
        stateBar.querySelectorAll('button').forEach(function(x){x.classList.toggle('active',x===b);});
        renderStyleBody();
      };
      stateBar.appendChild(b);
    });
    body.appendChild(stateBar);

    function heroColor(id,label){ return {id:id,type:'hero-color',label:label,responsive:true,states:true}; }

    function heroTypography(H,prefix,title){
      return {title:title,controls:[
        H.select(prefix+'FontFamily','Font Family',[['','Default'],['inherit','Inherit'],['Inter','Inter'],['Roboto','Roboto'],['Arial','Arial'],['Helvetica','Helvetica'],['Georgia','Georgia'],['Times New Roman','Times New Roman'],['Verdana','Verdana'],['system-ui','System UI']],{responsive:true}),
        heroColor(prefix+'Color','Text Color'),
        H.unit(prefix+'Size','Font Size',['px','rem','em','%','vw','vh'],{responsive:true}),
        H.select(prefix+'Weight','Font Weight',window.NextGenInspectorSchemas.options.fontWeight,{responsive:true}),
        H.unit(prefix+'LineHeight','Line Height',['px','rem','em','%'],{responsive:true}),
        H.unit(prefix+'LetterSpacing','Letter Spacing',['px','rem','em'],{responsive:true}),
        H.unit(prefix+'WordSpacing','Word Spacing',['px','rem','em'],{responsive:true}),
        H.select(prefix+'Transform','Text Transform',[['','Default'],['none','None'],['uppercase','Uppercase'],['lowercase','Lowercase'],['capitalize','Capitalize']],{responsive:true}),
        H.select(prefix+'Decoration','Text Decoration',[['','Default'],['none','None'],['underline','Underline'],['overline','Overline'],['line-through','Line Through']],{responsive:true}),
        H.select(prefix+'Style','Font Style',[['','Default'],['normal','Normal'],['italic','Italic'],['oblique','Oblique']],{responsive:true}),
        H.text(prefix+'Shadow','Text Shadow',{responsive:true})
      ]};
    }
    function heroButtonNormal(H){
      return {title:'Hero Button',controls:[
        H.select('buttonFontFamily','Font Family',[['','Default'],['inherit','Inherit'],['Inter','Inter'],['Roboto','Roboto'],['Arial','Arial'],['Helvetica','Helvetica'],['Georgia','Georgia'],['Times New Roman','Times New Roman'],['Verdana','Verdana'],['system-ui','System UI']],{responsive:true}),
        heroColor('buttonColor','Text Color'),
        heroColor('buttonBackground','Background Color'),
        heroColor('buttonBorderColor','Border Color'),
        H.unit('buttonFontSize','Font Size',['px','rem','em','%','vw'],{responsive:true}),
        H.select('buttonFontWeight','Font Weight',window.NextGenInspectorSchemas.options.fontWeight,{responsive:true}),
        H.unit('buttonLineHeight','Line Height',['px','rem','em','%'],{responsive:true}),
        H.unit('buttonLetterSpacing','Letter Spacing',['px','rem','em'],{responsive:true}),
        H.select('buttonTransform','Text Transform',[['','Default'],['none','None'],['uppercase','Uppercase'],['lowercase','Lowercase'],['capitalize','Capitalize']],{responsive:true}),
        H.select('buttonDecoration','Text Decoration',[['','Default'],['none','None'],['underline','Underline'],['line-through','Line Through']],{responsive:true}),
        H.select('buttonStyle','Font Style',[['','Default'],['normal','Normal'],['italic','Italic'],['oblique','Oblique']],{responsive:true}),
        H.select('buttonBorderStyle','Border Style',[['','Default'],['none','None'],['solid','Solid'],['dashed','Dashed'],['dotted','Dotted'],['double','Double']],{responsive:true}),
        H.unit('buttonBorderWidth','Border Width',['px','rem','em'],{responsive:true}),
        H.unit('buttonRadius','Border Radius',['px','%','rem','em'],{responsive:true}),
        H.text('buttonPadding','Padding',{responsive:true}),
        H.text('buttonShadow','Box Shadow',{responsive:true})
      ]};
    }
    function heroButtonHover(H){
      return {title:'Hero Button Hover',controls:[
        heroColor('buttonHoverColor','Text Color'),
        heroColor('buttonHoverBackground','Background Color'),
        heroColor('buttonHoverBorderColor','Border Color'),
        H.select('buttonHoverBorderStyle','Border Style',[['','Keep Normal'],['none','None'],['solid','Solid'],['dashed','Dashed'],['dotted','Dotted'],['double','Double']],{responsive:true}),
        H.unit('buttonHoverBorderWidth','Border Width',['px','rem','em'],{responsive:true}),
        H.unit('buttonHoverRadius','Border Radius',['px','%','rem','em'],{responsive:true}),
        H.text('buttonHoverShadow','Box Shadow',{responsive:true}),
        H.select('buttonHoverTransform','Transform',[['none','None'],['lift','Lift'],['scale','Scale']],{responsive:true})
      ]};
    }
    function renderStyleBody(){
      Array.prototype.slice.call(body.querySelectorAll('.ng-style-generated')).forEach(function(x){x.remove();});
      var holder=document.createElement('div'); holder.className='ng-style-generated'; body.appendChild(holder);
      if(n.type==='hero'||n.type==='hero_slider'){ var diag=document.createElement('div'); diag.className='ng-hero-style-version'; diag.textContent='Hero Style Controls · 10.5.16'; holder.appendChild(diag); }
      var H=window.NextGenInspectorSchemas.control;
      if(n.type==='hero'||n.type==='hero_slider'){
        if(inspectorState==='normal'){
          accordion(holder,'Background',[ 
            heroColor('backgroundColor','Background Color'),
            H.image('image','Background Image'),
            H.range('imageOpacity','Image Opacity',0,1,.01,{responsive:true}),
            H.text('imageFilter','Image Filter',{responsive:true}),
            H.select('backgroundSize','Background Size',window.NextGenInspectorSchemas.options.backgroundSize,{responsive:true}),
            H.text('backgroundPosition','Background Position',{responsive:true}),
            H.select('backgroundRepeat','Background Repeat',window.NextGenInspectorSchemas.options.backgroundRepeat,{responsive:true}),
            heroColor('overlayColor','Overlay Color'),
            H.range('overlayOpacity','Overlay Opacity',0,1,.01,{responsive:true})
          ],true);
          accordion(holder,'Eyebrow Typography',heroTypography(H,'heroEyebrow','Eyebrow Typography').controls,true);
          accordion(holder,'Heading Typography',heroTypography(H,'heroHeading','Heading Typography').controls,true);
          accordion(holder,'Description Typography',heroTypography(H,'heroBody','Description Typography').controls,true);
          accordion(holder,'Hero Button',heroButtonNormal(H).controls,true);
          accordion(holder,'Hero Effects',[
            H.range('opacity','Hero Opacity',0,1,.01,{responsive:true}),
            H.text('filter','Hero Filter',{responsive:true}),
            H.text('transition','Transition',{responsive:true})
          ],false);
        }else{
          accordion(holder,'Hero Button Hover',heroButtonHover(H).controls,true);
          accordion(holder,'Hero Hover',[
            heroColor('heroHoverBackground','Background Color'),
            heroColor('heroHoverOverlayColor','Overlay Color'),
            H.range('heroHoverOverlayOpacity','Overlay Opacity',0,1,.01,{responsive:true}),
            H.range('heroHoverOpacity','Opacity',0,1,.01,{responsive:true}),
            H.text('heroHoverFilter','Filter',{responsive:true}),
            H.text('heroHoverTransform','Transform',{responsive:true})
          ],false);
        }
        return;
      }
      if(n.type==='category_grid'){
        if(inspectorState==='normal'){
          accordion(holder,'Card',[heroColor('cardBackground','Card Background'),heroColor('cardBorderColor','Border Color'),H.unit('cardBorderWidth','Border Width',['px','rem','em'],{responsive:true}),H.unit('cardRadius','Border Radius',['px','%','rem','em'],{responsive:true}),H.text('cardShadow','Box Shadow',{responsive:true})],true);
          accordion(holder,'Category Name',[heroColor('nameColor','Text Color'),heroColor('nameBackground','Background Color'),H.text('namePadding','Padding',{responsive:true}),H.unit('nameHeight','Height',['px','rem','em','vh','vw'],{responsive:true}),H.unit('nameRadius','Border Radius',['px','%','rem','em'],{responsive:true}),H.select('nameFontFamily','Font Family',[['','Default'],['inherit','Inherit'],['Inter','Inter'],['Roboto','Roboto'],['Arial','Arial'],['Helvetica','Helvetica'],['Georgia','Georgia'],['Times New Roman','Times New Roman'],['Verdana','Verdana'],['system-ui','System UI']],{responsive:true}),H.unit('nameFontSize','Font Size',['px','rem','em','vw'],{responsive:true}),H.select('nameFontWeight','Font Weight',window.NextGenInspectorSchemas.options.fontWeight,{responsive:true}),H.unit('nameLetterSpacing','Letter Spacing',['px','rem','em'],{responsive:true}),H.select('nameTransform','Text Transform',[['','Default'],['none','None'],['uppercase','Uppercase'],['lowercase','Lowercase'],['capitalize','Capitalize']],{responsive:true}),H.text('nameShadow','Text Shadow',{responsive:true})],true);
          accordion(holder,'Button',[heroColor('buttonColor','Text Color'),heroColor('buttonBackground','Background Color'),heroColor('buttonBorderColor','Border Color'),H.unit('buttonBorderWidth','Border Width',['px','rem','em'],{responsive:true}),H.select('buttonBorderStyle','Border Style',[['','Default'],['none','None'],['solid','Solid'],['dashed','Dashed'],['dotted','Dotted'],['double','Double']],{responsive:true}),H.unit('buttonRadius','Border Radius',['px','%','rem','em'],{responsive:true}),H.text('buttonPadding','Padding',{responsive:true}),H.unit('buttonFontSize','Font Size',['px','rem','em','vw'],{responsive:true}),H.select('buttonFontWeight','Font Weight',window.NextGenInspectorSchemas.options.fontWeight,{responsive:true})],true);
          accordion(holder,'Overlay',[heroColor('overlayColor','Overlay Color'),H.range('overlayOpacity','Overlay Opacity',0,1,.01,{responsive:true})],true);
        }else{
          accordion(holder,'Category Hover',[heroColor('buttonHoverColor','Button Text Color'),heroColor('buttonHoverBackground','Button Background Color'),heroColor('buttonHoverBorderColor','Button Border Color'),H.text('hoverFilter','Image Filter',{responsive:true}),H.text('hoverTransform','Image Transform',{responsive:true})],true);
        }
        return;
      }
      var styleGroups=schemas.style||[];
      styleGroups.forEach(function(g){accordion(holder,g.title,g.controls,g.open!==false);});
    }
    renderStyleBody();
  }
  function renderAdvanced(){
    var groups=schemas.advanced||[];groups.forEach(function(g){accordion(body,g.title,g.controls,g.open!==false);});
  }
  function show(tab){
    currentTab=tab;
    ui.tab=tab;
    body.innerHTML='';
    try{
      if(tab==='content')renderContent();
      else if(tab==='layout')renderLayout();
      else if(tab==='style')renderStyle();
      else renderAdvanced();
    }catch(err){
      console.error('[NextGen Inspector] render failed for '+n.type+' / '+tab,err);
      var box=document.createElement('div');box.className='ng-inspector-error';
      var strong=document.createElement('strong');strong.textContent='Inspector could not render this panel.';
      var span=document.createElement('span');span.textContent=(err&&err.message)?err.message:'The panel could not be rendered. Your document data is safe.';
      box.appendChild(strong);box.appendChild(span);body.appendChild(box);
    }
  }
  tabs.querySelectorAll('button').forEach(function(btn){
    btn.onclick=function(){
      var tab=btn.getAttribute('data-inspector-tab');
      ui.tab=tab;
      tabs.querySelectorAll('button').forEach(function(x){x.classList.remove('active');});
      btn.classList.add('active');
      show(tab);
    };
  });
  show(currentTab);
  // Browser accessibility/autofill hardening: every inspector form control gets
  // a stable DOM id/name. This also prevents browser Issues from treating
  // dynamically-created controls as anonymous fields.
  (function normalizeInspectorFields(){
    var used={};
    Array.prototype.slice.call(body.querySelectorAll('input,select,textarea')).forEach(function(field,index){
      var key=field.getAttribute('data-ng-field-key')||field.getAttribute('aria-label')||field.name||field.id||('field-'+index);
      key=String(key).replace(/[^a-zA-Z0-9_-]/g,'-').replace(/^-+|-+$/g,'')||('field-'+index);
      var id=field.id||('ng-inspector-'+String(n.id||'node').replace(/[^a-zA-Z0-9_-]/g,'-')+'-'+key);
      if(used[id]||document.getElementById(id)&&document.getElementById(id)!==field){id+='-'+index;}
      used[id]=true;field.id=id;if(!field.name)field.name=id;
      var label=field.parentNode&&field.parentNode.querySelector?field.parentNode.querySelector(':scope > label'):null;
      if(label&&!label.htmlFor)label.htmlFor=id;
    });
  })();
  var actions=document.createElement('div');actions.className='ng-actions';[['Copy',copySelected],['Paste',pasteSelected],['Duplicate',duplicateSelected],['Delete',deleteSelected]].forEach(function(a){var btn=document.createElement('button');btn.type='button';btn.className=a[0]==='Delete'?'btn btn-danger':'btn btn-default';btn.textContent=a[0];btn.onclick=a[1];actions.appendChild(btn);});els.settings.appendChild(actions);
 }
 function setStatus(text){var x=root.querySelector('[data-ng-status]');if(x)x.textContent=text;}
 function save(silent){if(!canModify){if(!silent)alert('You do not have modify permission.');return Promise.reject(new Error('No modify permission.'));}var st=store.get();setStatus('Saving…');var action,payload;if(templateMode){action='save_template';payload={template_id:meta.template_id,document:st.document};}else if(componentMode){action='save_component';payload={component_id:meta.component_id,document:st.document};}else{action='save';payload={document_id:meta.document_id,name:meta.name,route:meta.route,template_type:meta.template_type,status:1,store_id:meta.store_id||0,document:st.document};}return request(action,'POST',payload).then(function(r){if(!r.success){throw new Error(r.error||'Save failed.');}meta.version=r.version||meta.version;if(!templateMode&&!componentMode)meta.document_id=r.document_id;store.state.dirty=false;store.emit();setStatus('Saved');return r;}).catch(function(err){setStatus('Save failed');if(!silent)alert(err&&err.message?err.message:'Could not connect to builder API.');throw err;});}
 function preview(){var s=store.get();if(meta.route){var u=new URL(window.location.href);u.search='';u.pathname=u.pathname.replace(/admin\/index\.php$/,'');var base=u.origin+u.pathname;window.open(base+'index.php?route='+encodeURIComponent(meta.route),'_blank');}else{alert('Set a route for this document before previewing.');}}
 var frontOverlay=null,frontFrame=null,frontRight=null,frontCloseHandler=null,frontRefreshing=false;
 function frontEditorUrl(){
   if(!meta.route||!catalogUrl||!frontEditorToken)return '';
   return catalogUrl+'/index.php?route='+encodeURIComponent(meta.route)+'&nextgen_editor=1&nextgen_edit_token='+encodeURIComponent(frontEditorToken)+'&_ng='+Date.now();
 }
 function refreshFrontEditor(){
   if(!frontFrame||!frontFrame.contentWindow)return;
   try{frontFrame.contentWindow.postMessage({source:'nextgen-front-editor-parent',type:'refresh'},'*');}catch(e){}
 }
 function frontMessage(e){
   var d=e.data||{};if(d.source!=='nextgen-front-editor'||!frontOverlay)return;
   if(d.type==='select'&&d.id){store.select(d.id);return;}
   if(d.type==='duplicate-node'&&d.id){store.select(d.id);duplicateSelected();return;}
   if(d.type==='copy-node'&&d.id){store.select(d.id);copySelected();return;}
   if(d.type==='paste-node'&&d.id){store.select(d.id);pasteSelected();return;}
   if(d.type==='add-container'&&d.id){insertContainerIntoSection(d.id);return;}
   if(d.type==='add-column'&&d.id){insertNestedContainer(d.id);return;}
   if(d.type==='delete-node'&&d.id){store.select(d.id);deleteSelected();return;}
   if(d.type==='add-child'&&d.id){store.select(d.id);addDefaultChildWidget(d.id);return;}
   if((d.type==='add-section-before'||d.type==='add-section-after')&&d.id){store.update(function(st){var p=findParent(st.document,d.id);var n=byId(st.document,d.id);if(!n||n.type!=='section')return;var target=p||st.document;target.children=target.children||[];var idx=target.children.indexOf(n);if(idx<0)return;if(d.type==='add-section-after')idx++;var added=makeStructure('section');target.children.splice(idx,0,added);st.selectedId=added.id;});return;}
   if(d.type==='inline-change'&&d.id){store.update(function(st){var n=byId(st.document,d.id);if(!n)return;n.settings=n.settings||{};if(n.type==='heading'||n.type==='text'||n.type==='text_editor'||n.type==='button'){n.settings.text=d.text||'';n.settings.html=d.value||d.text||'';}});return;}
   if(d.type==='ready'){try{frontFrame.contentWindow.postMessage({source:'nextgen-front-editor-parent',type:'select',id:store.get().selectedId||''},'*');}catch(e){}}
 }
 function openFrontEditor(){
   if(frontOverlay){return;}
   var url=frontEditorUrl();if(!url){alert('Save the page and make sure a route is assigned before opening Frontend Editor.');return;}
   frontOverlay=document.createElement('div');frontOverlay.className='ng-front-editor';
   var top=document.createElement('div');top.className='ng-front-toolbar';
   var left=document.createElement('div');left.className='ng-front-toolbar-left';
   var close=document.createElement('button');close.type='button';close.className='ng-front-close';close.textContent='← Back to Builder';close.onclick=closeFrontEditor;
   var title=document.createElement('strong');title.textContent='NextGen Frontend Editor';left.appendChild(close);left.appendChild(title);
   var center=document.createElement('div');center.className='ng-front-toolbar-center';
   ['desktop','tablet','mobile'].forEach(function(d){var b=document.createElement('button');b.type='button';b.textContent=d.charAt(0).toUpperCase()+d.slice(1);b.className='ng-front-device'+(store.get().device===d?' active':'');b.onclick=function(){store.setDevice(d);center.querySelectorAll('button').forEach(function(x){x.classList.remove('active');});b.classList.add('active');if(frontFrame&&frontFrame.contentWindow)frontFrame.contentWindow.postMessage({source:'nextgen-front-editor-parent',type:'viewport',device:d},'*');};center.appendChild(b);});
   var rightTop=document.createElement('div');rightTop.className='ng-front-toolbar-right';var saveBtn=document.createElement('button');saveBtn.type='button';saveBtn.className='btn btn-primary';saveBtn.textContent='Save';saveBtn.onclick=save;rightTop.appendChild(saveBtn);top.appendChild(left);top.appendChild(center);top.appendChild(rightTop);frontOverlay.appendChild(top);
   var body=document.createElement('div');body.className='ng-front-body';
   var elementsDrawer=document.createElement('aside');elementsDrawer.className='ng-front-elements';
   var eh=document.createElement('div');eh.className='ng-front-elements-head';var et=document.createElement('strong');et.textContent='Elements';var ec=document.createElement('button');ec.type='button';ec.textContent='×';ec.onclick=function(){elementsDrawer.classList.remove('is-open');};eh.appendChild(et);eh.appendChild(ec);elementsDrawer.appendChild(eh);
   var es=document.createElement('input');es.type='search';es.placeholder='Search widgets...';es.className='ng-front-elements-search';elementsDrawer.appendChild(es);
   var elist=document.createElement('div');elist.className='ng-front-elements-list';elementsDrawer.appendChild(elist);
   function drawFrontWidgets(q){elist.innerHTML='';var needle=(q||'').toLowerCase();WIDGETS.filter(function(w){return !needle||w.name.toLowerCase().indexOf(needle)>-1;}).forEach(function(w){var b=document.createElement('button');b.type='button';b.className='ng-front-element';b.innerHTML='<span>'+escapeHtml(w.icon||'•')+'</span><span>'+escapeHtml(w.name)+'</span>';b.onclick=function(){addWidget(w.id);};elist.appendChild(b);});}
   es.oninput=function(){drawFrontWidgets(es.value);};drawFrontWidgets('');
   var elementToggle=document.createElement('button');elementToggle.type='button';elementToggle.className='ng-front-elements-toggle';elementToggle.textContent='☷ Elements';elementToggle.onclick=function(){elementsDrawer.classList.toggle('is-open');};
   frontOverlay.appendChild(elementsDrawer);frontOverlay.appendChild(elementToggle);
   var frameWrap=document.createElement('div');frameWrap.className='ng-front-frame-wrap';frontFrame=document.createElement('iframe');frontFrame.className='ng-front-frame';frontFrame.src=url;frontFrame.setAttribute('title','NextGen Frontend Editor');frontFrame.setAttribute('frameborder','0');frameWrap.appendChild(frontFrame);body.appendChild(frameWrap);
   frontRight=root.querySelector('.ng-right');var inspectorHost=document.createElement('aside');inspectorHost.className='ng-front-inspector';if(frontRight){inspectorHost.appendChild(frontRight);frontRight.style.display='flex';frontRight.style.height='100%';frontRight.style.borderLeft='0';}body.appendChild(inspectorHost);frontOverlay.appendChild(body);document.body.appendChild(frontOverlay);document.body.classList.add('ng-front-editor-open');window.addEventListener('message',frontMessage);renderSettings(store.get());
 }
 function closeFrontEditor(){if(!frontOverlay)return;window.removeEventListener('message',frontMessage);if(frontRight){frontRight.style.display='';frontRight.style.height='';frontRight.style.borderLeft='';root.appendChild(frontRight);}frontOverlay.remove();frontOverlay=null;frontFrame=null;document.body.classList.remove('ng-front-editor-open');renderCanvas(store.get());}
 function loadFirst(){if(templateMode||componentMode){var endpoint=templateMode?'load_template':'load_component';var id=templateMode?templateId:componentId;return request(endpoint,'GET',null,id,templateMode?'template_id':'component_id').then(function(r){if(r&&r.success){var t=templateMode?r.template:r.component;meta=Object.assign(meta,{template_id:templateMode?t.template_id:0,component_id:componentMode?t.component_id:0,name:t.name,template_type:t.template_type||t.type,route:t.route||'',version:t.version});var normalized=migrateLegacyHeroNodes(ensureDocument(t.document));store.setDocument(normalized);var firstContainer=findFirstByType(normalized,'container');if(firstContainer)store.select(firstContainer.id);setStatus((templateMode?'Template':'Global component')+' loaded');}}).catch(function(err){renderCanvas(store.get());setStatus('Editor API error');var box=document.createElement('div');box.className='ng-builder-error';box.textContent='Could not load: '+(err&&err.message?err.message:'Unknown error');els.canvas.prepend(box);});}return request('documents','GET').then(function(r){var docs=r.documents||[];var preferred=null;for(var i=0;i<docs.length;i++){if(docs[i].route==='common/home'&&docs[i].template_type==='homepage'&&String(docs[i].status)==='1'){preferred=docs[i];break;}}var chosen=preferred||docs[0];if(chosen){meta=Object.assign(meta,chosen);return request('load','GET',null,meta.document_id);}if(canModify){meta.route='common/home';meta.template_type='homepage';meta.name='Homepage';return request('create','POST',{name:meta.name,route:meta.route,store_id:0,template_type:meta.template_type}).then(function(x){if(x.success){meta.document_id=x.document_id;meta.version=x.version;return request('load','GET',null,meta.document_id);}throw new Error(x.error||'Could not create Homepage document.');});}return null;}).then(function(r){if(r&&r.success){meta=Object.assign(meta,r.document);var normalized=migrateLegacyHeroNodes(ensureDocument(r.document.document));store.setDocument(normalized);var firstContainer=findFirstByType(normalized,'container');if(firstContainer)store.select(firstContainer.id);}else{renderCanvas(store.get());}}).catch(function(err){renderCanvas(store.get());setStatus('Builder API error');var box=document.createElement('div');box.className='ng-builder-error';box.textContent='Builder could not load its document: '+(err&&err.message?err.message:'Unknown error');els.canvas.prepend(box);});}
 function bindAction(selector,handler,scope){var el=(scope||root).querySelector(selector);if(el)el.onclick=handler;return el;}
 var page=document;
 bindAction('[data-ng-action="save"]',save,page);
 bindAction('[data-ng-action="preview"]',preview,page);
 bindAction('[data-ng-action="front-edit"]',openFrontEditor,page);
 bindAction('[data-ng-action="undo"]',function(){store.undo();});
 bindAction('[data-ng-action="redo"]',function(){store.redo();});
 bindAction('[data-ng-action="copy"]',copySelected);
 bindAction('[data-ng-action="paste"]',pasteSelected);
 bindAction('[data-ng-action="toggle-left"]',function(){var x=root.querySelector('.ng-left');if(x)x.classList.toggle('is-open');});
 function centerNavigator(){var r=root.querySelector('.ng-navigator');if(!r)return;r.classList.add('is-open');r.classList.remove('is-positioned');r.style.left='50%';r.style.top='50%';r.style.right='auto';r.style.bottom='auto';r.style.transform='translate(-50%, -50%)';}
 function closeNavigatorPosition(){var r=root.querySelector('.ng-navigator');if(!r)return;r.classList.remove('is-open');r.classList.remove('is-positioned');r.style.left='';r.style.top='';r.style.right='';r.style.bottom='';r.style.transform='';}
 bindAction('[data-ng-action="navigator"]',function(){var r=root.querySelector('.ng-navigator');if(!r)return;if(r.classList.contains('is-open')){closeNavigatorPosition();}else{centerNavigator();}});
 function makeNavigatorDraggable(){var r=root.querySelector('.ng-navigator');var h=root.querySelector('[data-ng-navigator-drag-handle]');if(!r||!h)return;var dragState=null;h.addEventListener('pointerdown',function(e){if(e.target.closest('[data-ng-action="navigator"]'))return;if(e.button!==undefined&&e.button!==0)return;if(!r.classList.contains('is-open'))return;var rr=r.getBoundingClientRect(),br=root.getBoundingClientRect();dragState={pointerId:e.pointerId,offsetX:e.clientX-rr.left,offsetY:e.clientY-rr.top,maxX:br.width-rr.width,maxY:br.height-rr.height};r.classList.add('is-dragging');r.classList.add('is-positioned');r.style.transform='none';h.setPointerCapture(e.pointerId);e.preventDefault();});h.addEventListener('pointermove',function(e){if(!dragState||e.pointerId!==dragState.pointerId)return;var br=root.getBoundingClientRect();var x=e.clientX-br.left-dragState.offsetX;var y=e.clientY-br.top-dragState.offsetY;x=Math.max(0,Math.min(x,dragState.maxX));y=Math.max(0,Math.min(y,dragState.maxY));r.style.left=x+'px';r.style.top=y+'px';r.style.right='auto';r.style.bottom='auto';});function endDrag(e){if(!dragState||e.pointerId!==dragState.pointerId)return;try{h.releasePointerCapture(e.pointerId);}catch(_e){}dragState=null;r.classList.remove('is-dragging');}h.addEventListener('pointerup',endDrag);h.addEventListener('pointercancel',endDrag);}
 makeNavigatorDraggable();
 var zoom=root.querySelector('[data-ng-zoom]');if(zoom)zoom.onchange=function(){var c=els.canvas;if(c)c.style.setProperty('--ng-editor-zoom',zoom.value);};
 bindAction('[data-ng-action="history"]',function(){alert('Use Undo / Redo to navigate builder history.');});
 bindAction('[data-ng-action="toggle-right"]',function(){var x=root.querySelector('.ng-right');if(x)x.classList.toggle('is-open');});
 var search=root.querySelector('[data-ng-search]');if(search)search.oninput=function(){renderWidgets(this.value);};
 var activeCategory='all';function rebuildWidgets(){var q=(search&&search.value||'').toLowerCase();els.widgets.innerHTML='';paletteWidgets().filter(function(w){return (!q||w.name.toLowerCase().indexOf(q)>-1)&&(activeCategory==='all'||w.category===activeCategory);}).forEach(function(w){els.widgets.appendChild(widgetButton(w,false));});STRUCTURES.forEach(function(w){var b=widgetButton(w,true);b.style.display='none';b.setAttribute('data-ng-structure','1');els.widgets.appendChild(b);});}
 function renderCategories(){var c=root.querySelector('[data-ng-categories]');if(!c)return;c.innerHTML='';var cats=['all'];paletteWidgets().forEach(function(w){if(cats.indexOf(w.category)<0)cats.push(w.category);});cats.forEach(function(cat){var b=document.createElement('button');b.type='button';b.textContent=cat==='all'?'All':(cat.charAt(0).toUpperCase()+cat.slice(1));b.className=cat===activeCategory?'active':'';b.onclick=function(){activeCategory=cat;c.querySelectorAll('button').forEach(function(x){x.classList.remove('active');});b.classList.add('active');rebuildWidgets();};c.appendChild(b);});}
 if(search)search.oninput=function(){rebuildWidgets();};renderCategories();
 root.querySelectorAll('[data-ng-tab]').forEach(function(tab){tab.onclick=function(){root.querySelectorAll('[data-ng-tab]').forEach(function(x){x.classList.remove('active');});tab.classList.add('active');var structure=tab.getAttribute('data-ng-tab')==='structure';root.querySelectorAll('[data-ng-structure]').forEach(function(x){x.style.display=structure?'block':'none';});};});
 root.querySelectorAll('[data-ng-device]').forEach(function(b){b.onclick=function(){root.querySelectorAll('[data-ng-device]').forEach(function(x){x.classList.remove('active');});b.classList.add('active');store.setDevice(b.getAttribute('data-ng-device'));};});
 document.addEventListener('keydown',function(e){if(!root.contains(document.activeElement)&&document.activeElement!==document.body)return;if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='z'){e.preventDefault();e.shiftKey?store.redo():store.undo();}else if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='c'){if(store.get().selectedId){e.preventDefault();copySelected();}}else if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='v'){e.preventDefault();pasteSelected();}else if(e.key==='Delete'&&!/input|textarea/i.test(document.activeElement.tagName)){if(store.get().selectedId){e.preventDefault();deleteSelected();}}});
 function scheduleFrontAutosave(){if(!frontOverlay||!canModify)return;frontSaveQueued=true;if(frontSaveTimer)window.clearTimeout(frontSaveTimer);frontSaveTimer=window.setTimeout(function(){if(frontSaveInFlight)return;frontSaveQueued=false;frontSaveInFlight=true;save(true).then(function(){refreshFrontEditor();}).catch(function(){}).finally(function(){frontSaveInFlight=false;if(frontSaveQueued)scheduleFrontAutosave();});},350);}
 store.subscribe(function(st){renderCanvas(st);if(frontOverlay&&frontFrame&&frontFrame.contentWindow&&st.selectedId){try{frontFrame.contentWindow.postMessage({source:'nextgen-front-editor-parent',type:'select',id:st.selectedId},'*');}catch(e){}}if(frontOverlay&&st.dirty)scheduleFrontAutosave();});rebuildWidgets();loadFirst();
}
NG.mount=mount;window.NextGenBuilder=NG;
})(window,document);
