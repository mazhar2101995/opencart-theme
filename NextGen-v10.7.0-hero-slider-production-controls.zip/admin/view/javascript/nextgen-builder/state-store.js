(function(window){
  'use strict';
  function clone(v){return JSON.parse(JSON.stringify(v));}
  function Store(initial){this.state=clone(initial||{document:null,selectedId:null,device:'desktop',dirty:false});this.history=[];this.future=[];this.listeners=[];this.clipboard=null;}
  Store.prototype.subscribe=function(fn){this.listeners.push(fn);fn(this.get());return function(){var i=this.listeners.indexOf(fn);if(i>-1)this.listeners.splice(i,1);}.bind(this);};
  Store.prototype.get=function(){return clone(this.state);};
  Store.prototype.emit=function(){var s=this.get();this.listeners.forEach(function(fn){fn(s);});};
  Store.prototype.commit=function(next,track){if(track!==false)this.history.push(clone(this.state));if(track!==false)this.future=[];this.state=clone(next);this.state.dirty=true;this.emit();};
  Store.prototype.undo=function(){if(!this.history.length)return false;this.future.push(clone(this.state));this.state=this.history.pop();this.state.dirty=true;this.emit();return true;};
  Store.prototype.redo=function(){if(!this.future.length)return false;this.history.push(clone(this.state));this.state=this.future.pop();this.state.dirty=true;this.emit();return true;};
  Store.prototype.select=function(id){this.state.selectedId=id;this.emit();};
  Store.prototype.setDevice=function(device){this.state.device=device;this.emit();};
  Store.prototype.update=function(mutator){var next=this.get();mutator(next);this.commit(next,true);};
  Store.prototype.setDocument=function(doc){this.state.document=clone(doc);this.state.dirty=false;this.history=[];this.future=[];this.emit();};
  Store.prototype.copy=function(node){this.clipboard=clone(node);};
  Store.prototype.paste=function(){return this.clipboard?clone(this.clipboard):null;};
  window.NextGenBuilderStore=Store;
})(window);
