window.__NEXTGEN_INSPECTOR_SCHEMA_VERSION='10.6.1.0';
(function(window){
'use strict';
var C={
  text:function(id,label,extra){return Object.assign({id:id,type:'text',label:label},extra||{});},
  textarea:function(id,label,extra){return Object.assign({id:id,type:'textarea',label:label},extra||{});},
  select:function(id,label,options,extra){return Object.assign({id:id,type:'select',label:label,options:options},extra||{});},
  unit:function(id,label,units,extra){return Object.assign({id:id,type:'unit',label:label,units:units||['px','%','em','rem','vw','vh','auto'],responsive:true},extra||{});},
  color:function(id,label,extra){return Object.assign({id:id,type:'color',label:label,responsive:true,states:true},extra||{});},
  image:function(id,label,extra){return Object.assign({id:id,type:'image',label:label},extra||{});},
  toggle:function(id,label,extra){return Object.assign({id:id,type:'toggle',label:label},extra||{});},
  number:function(id,label,extra){return Object.assign({id:id,type:'number',label:label,responsive:true},extra||{});},
  range:function(id,label,min,max,step,extra){return Object.assign({id:id,type:'range',label:label,min:min,max:max,step:step,responsive:true},extra||{});},
  code:function(id,label,extra){return Object.assign({id:id,type:'code',label:label},extra||{});}
};
var O={
  tags:[['h1','H1'],['h2','H2'],['h3','H3'],['h4','H4'],['h5','H5'],['h6','H6'],['div','DIV'],['span','SPAN']],
  align:[['left','Left'],['center','Center'],['right','Right'],['justify','Justify']],
  direction:[['row','Row'],['column','Column'],['row-reverse','Row Reverse'],['column-reverse','Column Reverse']],
  justify:[['flex-start','Start'],['center','Center'],['flex-end','End'],['space-between','Space Between'],['space-around','Space Around'],['space-evenly','Space Evenly']],
  alignItems:[['stretch','Stretch'],['flex-start','Start'],['center','Center'],['flex-end','End'],['baseline','Baseline']],
  display:[['','Default'],['block','Block'],['inline-block','Inline Block'],['flex','Flex'],['grid','Grid'],['none','None']],
  position:[['','Default'],['relative','Relative'],['absolute','Absolute'],['fixed','Fixed'],['sticky','Sticky']],
  widthMode:[['boxed','Container'],['full','Full Container'],['full_bleed','Full Width / Viewport'],['wide','Wide'],['custom','Custom']],
  layout:[['flex','Flexbox'],['grid','Grid']],
  objectFit:[['cover','Cover'],['contain','Contain'],['fill','Fill'],['none','None'],['scale-down','Scale Down']],
  backgroundSize:[['cover','Cover'],['contain','Contain'],['auto','Auto'],['100% 100%','Stretch']],
  backgroundRepeat:[['no-repeat','No Repeat'],['repeat','Repeat'],['repeat-x','Repeat X'],['repeat-y','Repeat Y']],
  fontWeight:[['','Default'],['100','100'],['200','200'],['300','300'],['400','400'],['500','500'],['600','600'],['700','700'],['800','800'],['900','900']],
  fontStyle:[['','Default'],['normal','Normal'],['italic','Italic'],['oblique','Oblique']],
  transformOrigin:[['center center','Center'],['top left','Top Left'],['top center','Top Center'],['top right','Top Right'],['center left','Center Left'],['center right','Center Right'],['bottom left','Bottom Left'],['bottom center','Bottom Center'],['bottom right','Bottom Right']]
};
function controls(){
  return {
    typography:[
      C.select('fontFamily','Font Family',[['','Default'],['inherit','Inherit'],['Inter','Inter'],['Roboto','Roboto'],['Arial','Arial'],['Helvetica','Helvetica'],['Georgia','Georgia'],['Times New Roman','Times New Roman'],['Verdana','Verdana'],['system-ui','System UI']],{responsive:true}),
      C.unit('fontSize','Font Size',['px','rem','em','%','vw','vh'],{responsive:true}),
      C.select('fontWeight','Font Weight',O.fontWeight,{responsive:true}),
      C.select('fontStyle','Font Style',O.fontStyle,{responsive:true}),
      C.unit('lineHeight','Line Height',['px','rem','em','%'],{responsive:true}),
      C.unit('letterSpacing','Letter Spacing',['px','rem','em'],{responsive:true}),
      C.unit('wordSpacing','Word Spacing',['px','rem','em'],{responsive:true}),
      C.select('textTransform','Text Transform',[['','Default'],['none','None'],['uppercase','Uppercase'],['lowercase','Lowercase'],['capitalize','Capitalize']],{responsive:true}),
      C.select('textDecoration','Text Decoration',[['','Default'],['none','None'],['underline','Underline'],['overline','Overline'],['line-through','Line Through']],{responsive:true}),
      C.select('textAlign','Alignment',[['','Default'],['left','Left'],['center','Center'],['right','Right'],['justify','Justify']],{responsive:true}),
      C.select('direction','Direction',[['','Default'],['ltr','LTR'],['rtl','RTL']],{responsive:true}),
      C.color('color','Text Color')
    ],
    textShadow:[C.color('textShadowColor','Shadow Color'),C.unit('textShadowX','Horizontal',['px','em']),C.unit('textShadowY','Vertical',['px','em']),C.unit('textShadowBlur','Blur',['px','em'])],
    background:[
      C.color('backgroundColor','Background Color'),C.image('backgroundImage','Background Image'),
      C.select('backgroundSize','Size',O.backgroundSize,{responsive:true}),
      C.text('backgroundPosition','Position',{responsive:true}),
      C.select('backgroundRepeat','Repeat',O.backgroundRepeat,{responsive:true}),
      C.color('backgroundOverlay','Overlay Color'),C.range('backgroundOverlayOpacity','Overlay Opacity',0,1,.01,{responsive:true})
    ],
    border:[
      C.select('borderStyle','Border Type',[['','Default'],['none','None'],['solid','Solid'],['dashed','Dashed'],['dotted','Dotted'],['double','Double']],{responsive:true}),
      C.unit('borderWidth','Border Width',['px','rem','em'],{responsive:true}),
      C.color('borderColor','Border Color'),
      C.unit('borderRadius','Border Radius',['px','%','rem','em'],{responsive:true}),
      C.text('shadow','Box Shadow',{responsive:true})
    ],
    layout:[
      C.select('display','Display',O.display,{responsive:true}),
      C.unit('width','Width',['px','%','vw','vh','auto','fit-content','max-content'],{responsive:true}),
      C.unit('maxWidth','Max Width',['px','%','vw','none','auto'],{responsive:true}),
      C.unit('minWidth','Min Width',['px','%','vw','auto'],{responsive:true}),
      C.unit('height','Height',['px','%','vh','vw','auto'],{responsive:true}),
      C.unit('minHeight','Min Height',['px','%','vh','vw','auto'],{responsive:true}),
      C.unit('maxHeight','Max Height',['px','%','vh','vw','none'],{responsive:true}),
      C.text('margin','Margin',{responsive:true}),C.text('padding','Padding',{responsive:true}),
      C.select('position','Position',O.position,{responsive:true}),
      C.text('top','Top',{responsive:true}),C.text('right','Right',{responsive:true}),C.text('bottom','Bottom',{responsive:true}),C.text('left','Left',{responsive:true}),
      C.number('zIndex','Z-Index',{responsive:true}),C.select('overflow','Overflow',[['','Default'],['visible','Visible'],['hidden','Hidden'],['auto','Auto'],['scroll','Scroll']],{responsive:true})
    ],
    effects:[C.range('opacity','Opacity',0,1,.01,{responsive:true}),C.text('filter','CSS Filter',{responsive:true}),C.text('transition','Transition',{responsive:true})],
    transform:[C.text('transform','Transform',{responsive:true,description:'Example: translateX(10px) rotate(2deg) scale(1.02)'}),C.select('transformOrigin','Transform Origin',O.transformOrigin,{responsive:true}),C.text('transition','Transition',{responsive:true})],
    motion:[C.select('animation','Entrance Animation',[['none','None'],['fade','Fade'],['fade-up','Fade Up'],['fade-down','Fade Down'],['zoom-in','Zoom In'],['slide-left','Slide Left'],['slide-right','Slide Right']],{}),C.number('animationDuration','Duration',{responsive:false}),C.number('animationDelay','Delay',{responsive:false}),C.select('animationEasing','Easing',[['ease','Ease'],['linear','Linear'],['ease-in','Ease In'],['ease-out','Ease Out'],['ease-in-out','Ease In Out']],{}) ,C.select('sticky','Sticky',[['none','None'],['top','Top'],['bottom','Bottom']],{})],
    advanced:[C.text('class','CSS Classes'),C.text('id','CSS ID'),C.code('customAttributes','Custom Attributes'),C.code('customCss','Custom CSS')]
  };
}
var G=controls();
function content(type){
  var base={
    heading:[C.textarea('text','Heading'),C.select('tag','HTML Tag',O.tags),C.text('url','Link URL')],
    text:[C.textarea('text','Text Content'),C.select('tag','HTML Tag',O.tags)],
    text_editor:[C.textarea('html','HTML Content'),C.select('tag','HTML Tag',O.tags)],
    button:[C.text('text','Button Text'),C.text('url','Button URL'),C.select('target','Open In',[['_self','Same Window'],['_blank','New Tab']]),C.text('icon','Icon'),C.select('iconPosition','Icon Position',[['left','Left'],['right','Right'],['none','None']])],
    button_group:[C.text('text','Button Text'),C.text('url','Button URL')],
    image:[C.image('src','Image'),C.text('alt','Alt Text'),C.select('linkType','Link',[['none','None'],['url','URL'],['lightbox','Lightbox']]),C.text('url','Link URL')],
    icon:[C.text('icon','Icon'),C.text('label','Accessibility Label')],
    icon_box:[C.text('icon','Icon'),C.text('title','Title'),C.textarea('text','Description'),C.text('url','Link URL')],
    spacer:[C.unit('height','Height',['px','rem','em','vh'],{responsive:true})],
    divider:[C.select('style','Style',[['solid','Solid'],['dashed','Dashed'],['dotted','Dotted'],['double','Double']]),C.unit('width','Width',['px','%','vw'],{responsive:true})],
    html:[C.code('html','HTML')],
    video:[C.text('src','Video URL'),C.image('poster','Poster Image'),C.toggle('controls','Show Controls',{default:true}),C.toggle('autoplay','Autoplay'),C.toggle('loop','Loop'),C.toggle('muted','Muted')],
    video_popup:[C.text('src','Video URL'),C.text('text','Button Text')],
    gallery:[C.text('images_json','Images JSON',{description:'Use the OpenCart Image Manager for gallery items.'}),C.number('columns','Columns',{responsive:true}),C.select('objectFit','Image Fit',O.objectFit,{responsive:true})],
    image_carousel:[C.text('images_json','Images JSON'),C.number('columns','Columns',{responsive:true}),C.toggle('autoplay','Autoplay',{default:true}),C.number('interval','Interval (ms)',{responsive:false})],
    product:[C.text('productId','Product ID'),C.text('productName','Product Name'),C.toggle('showImage','Show Image',{default:true}),C.toggle('showBrand','Show Brand',{default:true}),C.toggle('showDescription','Show Description',{default:true}),C.toggle('showRating','Show Rating',{default:true}),C.toggle('showPrice','Show Price',{default:true}),C.toggle('showAddToCart','Show Add to Cart',{default:true})],
    products:[C.select('displayMode','Display',[['tabs','Tabs'],['slider','Slider'],['grid','Grid']]),C.select('source','Product Source',[['latest','Latest Products'],['featured','Featured Products'],['special','Special Products'],['bestseller','Best Sellers'],['category','Category Products'],['custom','Custom Products']]),C.text('categoryId','Category ID',{description:'Used when Product Source = Category.'}),C.textarea('productIds','Custom Product IDs',{description:'Comma-separated product IDs when Product Source = Custom.'}),C.textarea('tabs_json','Tabs JSON',{description:'Tabs only: [{\"label\":\"Latest\",\"source\":\"latest\"}]'}),C.number('limit','Products',{responsive:false}),C.number('columns','Columns',{responsive:true}),C.number('gap','Gap',{responsive:true}),C.number('columnsTablet','Tablet Columns',{responsive:false}),C.number('columnsMobile','Mobile Columns',{responsive:false}),C.number('interval','Slider Interval (ms)',{responsive:false}),C.number('speed','Animation Speed (ms)',{responsive:false}),C.toggle('autoplay','Autoplay',{default:true}),C.toggle('loop','Loop',{default:true}),C.toggle('arrows','Show Arrows',{default:true}),C.toggle('dots','Show Dots',{default:true}),C.toggle('showBrand','Show Brand',{default:true}),C.toggle('showPrice','Show Price',{default:true}),C.toggle('showRating','Show Rating',{default:true}),C.toggle('showActions','Show Add to Cart',{default:true}),C.toggle('showWishlist','Show Wishlist',{default:true}),C.toggle('showCompare','Show Compare',{default:true}),C.toggle('showQuickView','Show Quick View',{default:true}),C.toggle('showHoverImage','Show Hover Image',{default:true})],
    announcement:[C.text('text','Announcement'),C.text('url','Link URL')],
    newsletter:[C.text('heading','Heading'),C.textarea('text','Description')],
    trust_badges:[C.text('items_json','Badges JSON')],social_links:[C.text('items_json','Social Links JSON')],
    menu:[C.text('menu_id','Menu ID')],logo:[C.image('image','Logo Image'),C.text('alt','Alt Text'),C.text('url','Logo URL')],account:[],cart:[],footer:[],conditions:[C.text('conditionKey','Condition Key'),C.select('conditionOperator','Condition',[['exists','Exists'],['equals','Equals'],['not_equals','Not Equals'],['contains','Contains']]),C.text('conditionValue','Condition Value')]
  };
  if(type==='hero') return [C.text('eyebrow','Eyebrow'),C.text('heading','Heading'),C.textarea('text','Description'),C.select('headingTag','Heading Tag',O.tags),C.text('button','Button Text'),C.text('url','Button URL'),C.select('target','Open In',[['_self','Same Window'],['_blank','New Tab']]),C.image('image','Background Image'),C.image('mobileImage','Mobile Image')];
  if(type==='hero_slider') return [];
  return base[type]||[];
}
function schema(type){
  var style=[{title:'Typography',controls:G.typography},{title:'Text Shadow',controls:G.textShadow,open:false},{title:'Background',controls:G.background},{title:'Border',controls:G.border},{title:'Effects',controls:G.effects,open:false}];
  if(type==='products'){style=[{title:'Product Card',controls:[C.color('cardBackground','Card Background'),C.color('cardBorderColor','Card Border Color'),C.unit('cardRadius','Card Radius',['px','%','rem','em'],{responsive:true}),C.text('cardShadow','Card Shadow',{responsive:true})]},{title:'Product Typography',controls:[C.unit('productTitleSize','Title Size',['px','rem','em'],{responsive:true}),C.select('productTitleWeight','Title Weight',O.fontWeight,{responsive:true}),C.color('productTitleColor','Title Color'),C.color('priceColor','Price Color')]},{title:'Actions',controls:[C.select('actionPosition','Action Position',[['overlay','Image Overlay'],['below','Below Product'],['hover','On Hover']]),C.color('actionBackground','Action Background'),C.color('actionColor','Action Color'),C.unit('actionRadius','Action Radius',['px','%','rem','em'],{responsive:true})]},{title:'Animation',controls:[C.select('cardAnimation','Card Hover',[['none','None'],['lift','Lift'],['zoom','Zoom'],['fade','Fade']]),C.number('animationDuration','Duration (ms)',{responsive:false})]}];}
  if(type==='hero_slider'){style=[
    {title:'Container',controls:[C.select('widthMode','Width Mode',O.widthMode,{responsive:false}),C.unit('customWidth','Custom Width',['px','%','vw'],{responsive:true}),C.color('containerBackground','Background'),C.color('containerBorderColor','Border Color'),C.unit('containerBorderWidth','Border Width',['px','rem','em'],{responsive:true}),C.select('containerBorderStyle','Border Style',[['none','None'],['solid','Solid'],['dashed','Dashed'],['dotted','Dotted']],{responsive:true}),C.unit('containerRadius','Radius',['px','%','rem','em'],{responsive:true}),C.text('containerShadow','Box Shadow',{responsive:true})]},
    {title:'Layout',controls:[C.unit('minHeight','Min Height',['px','vh','vw','rem','em'],{responsive:true}),C.select('contentPosition','Content Position',[['left top','Left / Top'],['left center','Left / Center'],['left bottom','Left / Bottom'],['center top','Center / Top'],['center center','Center / Center'],['center bottom','Center / Bottom'],['right top','Right / Top'],['right center','Right / Center'],['right bottom','Right / Bottom']],{responsive:true}),C.unit('contentMaxWidth','Content Max Width',['px','%','vw','rem','em'],{responsive:true}),C.text('contentPadding','Content Padding',{responsive:true}),C.unit('contentGap','Content Gap',['px','rem','em'],{responsive:true}),C.select('textAlign','Text Alignment',[['left','Left'],['center','Center'],['right','Right'],['justify','Justify']],{responsive:true})]},
    {title:'Media',controls:[C.color('backgroundColor','Background Color'),C.select('backgroundSize','Image Fit',O.backgroundSize,{responsive:true}),C.text('backgroundPosition','Image Position',{responsive:true}),C.select('backgroundRepeat','Image Repeat',O.backgroundRepeat,{responsive:true}),C.range('imageOpacity','Image Opacity',0,1,.01,{responsive:true}),C.text('imageFilter','Image Filter',{responsive:true})]},
    {title:'Overlay',controls:[C.color('overlayColor','Overlay Color'),C.range('overlayOpacity','Overlay Opacity',0,1,.01,{responsive:true})]},
    {title:'Eyebrow Typography',controls:[C.select('heroEyebrowFontFamily','Font Family',[['','Default'],['inherit','Inherit'],['Inter','Inter'],['Arial','Arial'],['Helvetica','Helvetica'],['Georgia','Georgia'],['system-ui','System UI']],{responsive:true}),C.unit('heroEyebrowSize','Font Size',['px','rem','em','vw'],{responsive:true}),C.select('heroEyebrowWeight','Font Weight',O.fontWeight,{responsive:true}),C.unit('heroEyebrowLineHeight','Line Height',['px','rem','em'],{responsive:true}),C.unit('heroEyebrowLetterSpacing','Letter Spacing',['px','rem','em'],{responsive:true}),C.unit('heroEyebrowWordSpacing','Word Spacing',['px','rem','em'],{responsive:true}),C.select('heroEyebrowTransform','Text Transform',[['none','None'],['uppercase','Uppercase'],['lowercase','Lowercase'],['capitalize','Capitalize']],{responsive:true}),C.select('heroEyebrowDecoration','Decoration',[['none','None'],['underline','Underline'],['line-through','Line Through']],{responsive:true}),C.select('heroEyebrowStyle','Font Style',O.fontStyle,{responsive:true}),C.color('heroEyebrowColor','Color'),C.text('heroEyebrowShadow','Text Shadow',{responsive:true})]},
    {title:'Heading Typography',controls:[C.select('heroHeadingFontFamily','Font Family',[['','Default'],['inherit','Inherit'],['Inter','Inter'],['Arial','Arial'],['Helvetica','Helvetica'],['Georgia','Georgia'],['system-ui','System UI']],{responsive:true}),C.unit('heroHeadingSize','Font Size',['px','rem','em','vw'],{responsive:true}),C.select('heroHeadingWeight','Font Weight',O.fontWeight,{responsive:true}),C.unit('heroHeadingLineHeight','Line Height',['px','rem','em'],{responsive:true}),C.unit('heroHeadingLetterSpacing','Letter Spacing',['px','rem','em'],{responsive:true}),C.unit('heroHeadingWordSpacing','Word Spacing',['px','rem','em'],{responsive:true}),C.select('heroHeadingTransform','Text Transform',[['none','None'],['uppercase','Uppercase'],['lowercase','Lowercase'],['capitalize','Capitalize']],{responsive:true}),C.select('heroHeadingDecoration','Decoration',[['none','None'],['underline','Underline'],['line-through','Line Through']],{responsive:true}),C.select('heroHeadingStyle','Font Style',O.fontStyle,{responsive:true}),C.color('heroHeadingColor','Color'),C.text('heroHeadingShadow','Text Shadow',{responsive:true})]},
    {title:'Body Typography',controls:[C.select('heroBodyFontFamily','Font Family',[['','Default'],['inherit','Inherit'],['Inter','Inter'],['Arial','Arial'],['Helvetica','Helvetica'],['Georgia','Georgia'],['system-ui','System UI']],{responsive:true}),C.unit('heroBodySize','Font Size',['px','rem','em','vw'],{responsive:true}),C.select('heroBodyWeight','Font Weight',O.fontWeight,{responsive:true}),C.unit('heroBodyLineHeight','Line Height',['px','rem','em'],{responsive:true}),C.unit('heroBodyLetterSpacing','Letter Spacing',['px','rem','em'],{responsive:true}),C.unit('heroBodyWordSpacing','Word Spacing',['px','rem','em'],{responsive:true}),C.select('heroBodyTransform','Text Transform',[['none','None'],['uppercase','Uppercase'],['lowercase','Lowercase'],['capitalize','Capitalize']],{responsive:true}),C.select('heroBodyDecoration','Decoration',[['none','None'],['underline','Underline'],['line-through','Line Through']],{responsive:true}),C.select('heroBodyStyle','Font Style',O.fontStyle,{responsive:true}),C.color('heroBodyColor','Color'),C.text('heroBodyShadow','Text Shadow',{responsive:true})]},
    {title:'Button',controls:[C.select('buttonFontFamily','Font Family',[['','Default'],['inherit','Inherit'],['Inter','Inter'],['Arial','Arial'],['Helvetica','Helvetica'],['Georgia','Georgia'],['system-ui','System UI']],{responsive:true}),C.unit('buttonFontSize','Font Size',['px','rem','em','vw'],{responsive:true}),C.select('buttonFontWeight','Font Weight',O.fontWeight,{responsive:true}),C.unit('buttonLineHeight','Line Height',['px','rem','em'],{responsive:true}),C.unit('buttonLetterSpacing','Letter Spacing',['px','rem','em'],{responsive:true}),C.select('buttonTransform','Text Transform',[['none','None'],['uppercase','Uppercase'],['lowercase','Lowercase'],['capitalize','Capitalize']],{responsive:true}),C.select('buttonDecoration','Decoration',[['none','None'],['underline','Underline'],['line-through','Line Through']],{responsive:true}),C.select('buttonStyle','Font Style',O.fontStyle,{responsive:true}),C.color('buttonBackground','Background'),C.color('buttonColor','Text Color'),C.unit('buttonRadius','Radius',['px','%','rem','em'],{responsive:true}),C.text('buttonPadding','Padding',{responsive:true}),C.unit('buttonBorderWidth','Border Width',['px','rem','em'],{responsive:true}),C.select('buttonBorderStyle','Border Style',[['none','None'],['solid','Solid'],['dashed','Dashed'],['dotted','Dotted']],{responsive:true}),C.color('buttonBorderColor','Border Color'),C.text('buttonShadow','Box Shadow',{responsive:true}),C.color('buttonHoverBackground','Hover Background'),C.color('buttonHoverColor','Hover Text Color'),C.color('buttonHoverBorderColor','Hover Border Color'),C.unit('buttonHoverBorderWidth','Hover Border Width',['px','rem','em'],{responsive:true}),C.select('buttonHoverBorderStyle','Hover Border Style',[['none','None'],['solid','Solid'],['dashed','Dashed'],['dotted','Dotted']],{responsive:true}),C.unit('buttonHoverRadius','Hover Radius',['px','%','rem','em'],{responsive:true}),C.text('buttonHoverShadow','Hover Shadow',{responsive:true}),C.select('buttonHoverTransform','Hover Transform',[['none','None'],['lift','Lift'],['scale','Scale']],{responsive:true})]}
  ];}
  if(type==='category_grid'){style=[
    {title:'Card',controls:[C.color('cardBackground','Card Background'),C.color('cardBorderColor','Card Border Color'),C.unit('cardBorderWidth','Card Border Width',['px','rem','em'],{responsive:true}),C.unit('cardRadius','Card Radius',['px','%','rem','em'],{responsive:true}),C.text('cardShadow','Card Shadow',{responsive:true})]},
    {title:'Category Name',controls:[C.color('nameColor','Text Color'),C.color('nameBackground','Background Color'),C.text('namePadding','Padding',{responsive:true}),C.unit('nameHeight','Height',['px','rem','em','vh','vw'],{responsive:true}),C.unit('nameRadius','Border Radius',['px','%','rem','em'],{responsive:true}),C.select('nameFontFamily','Font Family',[['','Default'],['inherit','Inherit'],['Inter','Inter'],['Roboto','Roboto'],['Arial','Arial'],['Helvetica','Helvetica'],['Georgia','Georgia'],['Times New Roman','Times New Roman'],['Verdana','Verdana'],['system-ui','System UI']],{responsive:true}),C.unit('nameFontSize','Font Size',['px','rem','em','vw'],{responsive:true}),C.select('nameFontWeight','Font Weight',O.fontWeight,{responsive:true}),C.unit('nameLetterSpacing','Letter Spacing',['px','rem','em'],{responsive:true}),C.select('nameTransform','Text Transform',[['','Default'],['none','None'],['uppercase','Uppercase'],['lowercase','Lowercase'],['capitalize','Capitalize']],{responsive:true}),C.text('nameShadow','Text Shadow',{responsive:true})]},
    {title:'Button',controls:[C.color('buttonColor','Text Color'),C.color('buttonBackground','Background Color'),C.color('buttonBorderColor','Border Color'),C.unit('buttonBorderWidth','Border Width',['px','rem','em'],{responsive:true}),C.select('buttonBorderStyle','Border Style',[['','Default'],['none','None'],['solid','Solid'],['dashed','Dashed'],['dotted','Dotted'],['double','Double']],{responsive:true}),C.unit('buttonRadius','Border Radius',['px','%','rem','em'],{responsive:true}),C.text('buttonPadding','Padding',{responsive:true}),C.unit('buttonFontSize','Font Size',['px','rem','em','vw'],{responsive:true}),C.select('buttonFontWeight','Font Weight',O.fontWeight,{responsive:true}),C.color('buttonHoverColor','Hover Text Color'),C.color('buttonHoverBackground','Hover Background'),C.color('buttonHoverBorderColor','Hover Border Color')]},
    {title:'Overlay',controls:[C.color('overlayColor','Overlay Color'),C.range('overlayOpacity','Overlay Opacity',0,1,.01,{responsive:true})]}
  ];}
  // Basic widgets get explicit, Elementor-style control groups. The same
  // settings are also consumed by the storefront renderer so there is no
  // builder-only styling.
  if(type==='button'){
    style=[
      {title:'Typography',controls:[C.select('buttonFontFamily','Font Family',[['','Default'],['inherit','Inherit'],['Inter','Inter'],['Roboto','Roboto'],['Arial','Arial'],['Helvetica','Helvetica'],['Georgia','Georgia'],['Times New Roman','Times New Roman'],['Verdana','Verdana'],['system-ui','System UI']],{responsive:true}),C.color('buttonColor','Text Color'),C.unit('buttonFontSize','Font Size',['px','rem','em','%','vw'],{responsive:true}),C.select('buttonFontWeight','Font Weight',O.fontWeight,{responsive:true}),C.unit('buttonLineHeight','Line Height',['px','rem','em','%'],{responsive:true}),C.unit('buttonLetterSpacing','Letter Spacing',['px','rem','em'],{responsive:true}),C.select('buttonTransform','Text Transform',[['','Default'],['none','None'],['uppercase','Uppercase'],['lowercase','Lowercase'],['capitalize','Capitalize']],{responsive:true}),C.select('buttonDecoration','Text Decoration',[['','Default'],['none','None'],['underline','Underline'],['line-through','Line Through']],{responsive:true}),C.select('buttonStyle','Font Style',O.fontStyle,{responsive:true})]},
      {title:'Background',controls:[C.color('buttonBackground','Background Color')]},
      {title:'Border',controls:[C.color('buttonBorderColor','Border Color'),C.unit('buttonBorderWidth','Border Width',['px','rem','em'],{responsive:true}),C.select('buttonBorderStyle','Border Style',[['','Default'],['none','None'],['solid','Solid'],['dashed','Dashed'],['dotted','Dotted'],['double','Double']],{responsive:true}),C.unit('buttonRadius','Border Radius',['px','%','rem','em'],{responsive:true})]},
      {title:'Spacing & Shadow',controls:[C.text('buttonPadding','Padding',{responsive:true}),C.text('buttonShadow','Box Shadow',{responsive:true})]},
      {title:'Hover',controls:[C.color('buttonHoverColor','Text Color'),C.color('buttonHoverBackground','Background Color'),C.color('buttonHoverBorderColor','Border Color'),C.unit('buttonHoverBorderWidth','Border Width',['px','rem','em'],{responsive:true}),C.select('buttonHoverBorderStyle','Border Style',[['','Keep Normal'],['none','None'],['solid','Solid'],['dashed','Dashed'],['dotted','Dotted'],['double','Double']],{responsive:true}),C.unit('buttonHoverRadius','Border Radius',['px','%','rem','em'],{responsive:true}),C.text('buttonHoverShadow','Box Shadow',{responsive:true})]}
    ];
  }
  var advanced=[{title:'Layout',controls:G.layout},{title:'Transform',controls:G.transform,open:false},{title:'Motion Effects',controls:G.motion,open:false},{title:'Responsive',controls:[C.toggle('hideDesktop','Hide On Desktop'),C.toggle('hideTablet','Hide On Tablet'),C.toggle('hideMobile','Hide On Mobile')] ,open:false},{title:'Attributes',controls:[C.code('customAttributes','Custom Attributes')],open:false},{title:'Custom CSS',controls:[C.code('customCss','Custom CSS')],open:false}];
  return {content:content(type),layout:G.layout,style:style,advanced:advanced};
}
window.NextGenInspectorSchemas={control:C,options:O,groups:G,content:content,schema:schema};
})(window);
