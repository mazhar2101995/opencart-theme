<?php
$_['heading_title'] = 'NextGen Product Page Builder';
