<?php
$_['heading_title'] = 'NextGen SEO Engine';
