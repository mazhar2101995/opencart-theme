<?php
$_['heading_title'] = 'NextGen Package Manager';
$_['text_validate'] = 'Validate Package';
$_['text_compatibility'] = 'Compatibility';
$_['text_install'] = 'Install';
$_['text_update'] = 'Update';
$_['text_rollback'] = 'Rollback';
