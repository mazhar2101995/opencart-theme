<?php
$_['heading_title'] = 'NextGen Theme Builder';
$_['text_builder'] = 'Builder';
