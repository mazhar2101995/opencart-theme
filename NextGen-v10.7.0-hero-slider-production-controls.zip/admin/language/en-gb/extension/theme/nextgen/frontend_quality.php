<?php
$_['heading_title'] = 'NextGen Frontend Quality';
