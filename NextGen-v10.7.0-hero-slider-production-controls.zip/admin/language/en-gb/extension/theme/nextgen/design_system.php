<?php
$_['heading_title'] = 'NextGen Design System';
