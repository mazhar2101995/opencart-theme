<?php
$_['heading_title'] = 'NextGen AI Builder';
