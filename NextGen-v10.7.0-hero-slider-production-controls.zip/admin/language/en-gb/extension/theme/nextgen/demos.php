<?php
$_['heading_title'] = 'NextGen Demo Library';
