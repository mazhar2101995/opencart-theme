<?php
$_['heading_title'] = 'NextGen Marketplace Security';
$_['text_signature'] = 'Package Signature';
$_['text_license'] = 'License';
$_['text_identity'] = 'Installation Identity';
$_['text_verification'] = 'Marketplace Verification';
