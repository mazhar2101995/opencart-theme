<?php
$_['heading_title'] = 'NextGen Interactions';
