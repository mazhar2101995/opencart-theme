<?php
$_['heading_title'] = 'NextGen Template Library';
