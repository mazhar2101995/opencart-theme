<?php
$_['heading_title'] = 'NextGen Core Runtime';
$_['text_pipeline'] = 'Runtime Pipeline';
$_['text_status'] = 'Runtime Status';
