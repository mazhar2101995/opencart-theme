<?php
$_['heading_title'] = 'NextGen Theme Testing';
