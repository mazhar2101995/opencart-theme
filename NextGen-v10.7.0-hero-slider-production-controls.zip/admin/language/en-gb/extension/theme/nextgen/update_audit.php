<?php
$_['heading_title'] = 'NextGen Update Audit';
$_['text_install'] = 'Install';
$_['text_update'] = 'Update';
$_['text_migration'] = 'Migration';
$_['text_rollback'] = 'Rollback';
$_['text_cache'] = 'Cache Refresh';
