<?php
$_['heading_title'] = 'NextGen Frontend Render Engine';
