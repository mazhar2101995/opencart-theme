<?php
$_['heading_title'] = 'NextGen Theme Engine';
