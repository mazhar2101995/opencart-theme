<?php
$_['heading_title'] = 'NextGen License Manager';
$_['text_activate'] = 'Activate';
$_['text_deactivate'] = 'Deactivate';
$_['text_renew'] = 'Renew';
$_['text_transfer'] = 'Transfer Domain';
$_['text_trial'] = 'Trial';
