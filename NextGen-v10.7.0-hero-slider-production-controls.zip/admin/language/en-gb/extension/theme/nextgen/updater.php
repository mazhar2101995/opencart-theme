<?php
$_['heading_title'] = 'NextGen Production Updater';
$_['text_backup'] = 'Backup';
$_['text_stage'] = 'Stage Files';
$_['text_migrate'] = 'Migrations';
$_['text_verify'] = 'Verification';
$_['text_rollback'] = 'Automatic Rollback';
