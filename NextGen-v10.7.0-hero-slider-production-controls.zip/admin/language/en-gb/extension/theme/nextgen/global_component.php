<?php
$_['heading_title'] = 'NextGen Global Components';
