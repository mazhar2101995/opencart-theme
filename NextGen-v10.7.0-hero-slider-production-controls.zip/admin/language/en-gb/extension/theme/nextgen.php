<?php
$_['heading_title'] = 'NextGen Theme Builder';
$_['extension_heading_title'] = 'NextGen Theme Builder';
$_['text_home'] = 'Home';
$_['text_extension'] = 'Extensions';
$_['text_edit'] = 'Theme Settings';
$_['text_enabled'] = 'Enabled';
$_['text_disabled'] = 'Disabled';
$_['text_success'] = 'NextGen theme settings saved successfully.';
$_['text_nextgen_info'] = 'NextGen is an OpenCart 3 presentation layer with a visual builder, widgets, templates, design system, demos and responsive controls. OpenCart commerce logic remains authoritative.';
$_['text_builder'] = 'Open Builder';
$_['text_demos'] = 'Demo Library';
$_['text_engine'] = 'Theme Engine';
$_['entry_directory'] = 'Theme Directory';
$_['entry_status'] = 'Status';
$_['entry_product_limit'] = 'Default Product Limit';
$_['help_directory'] = 'This directory is fixed to nextgen for the NextGen theme.';
$_['error_permission'] = 'Warning: You do not have permission to modify the NextGen theme.';
