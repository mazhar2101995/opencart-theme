<?php
$_['heading_title'] = 'NextGen Marketplace Management';
$_['text_products'] = 'Products';
$_['text_plans'] = 'Plans';
$_['text_licenses'] = 'Licenses';
$_['text_activations'] = 'Activations';
$_['text_api_logs'] = 'API Logs';
$_['text_customer_orders'] = 'Customer / Orders';
