<?php
$_['heading_title'] = 'NextGen Marketplace Dashboard';
$_['text_products'] = 'Products';
$_['text_plans'] = 'Plans';
$_['text_licenses'] = 'Licenses';
$_['text_activations'] = 'Activations';
$_['text_api_audit'] = 'API Audit';
