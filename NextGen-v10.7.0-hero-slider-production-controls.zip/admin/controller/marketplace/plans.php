<?php
class ControllerMarketplacePlans extends Controller {
    public function index() {
        if (!$this->user->hasPermission('access','marketplace/plans')) {
            $this->response->setOutput(json_encode(array('error'=>'Permission denied')));
            return;
        }
        $this->response->setOutput(json_encode(array(
            'status'=>'ok',
            'section'=>'plans',
            'actions'=>array('list','create','edit','trial','activation_limit','status')
        )));
    }
}
