<?php
class ControllerMarketplaceApiLogs extends Controller {
    public function index() {
        if (!$this->user->hasPermission('access','marketplace/api_logs')) {
            $this->response->setOutput(json_encode(array('error'=>'Permission denied')));
            return;
        }
        $this->response->setOutput(json_encode(array(
            'status'=>'ok',
            'section'=>'api_logs',
            'filters'=>array('action','status','license_id','installation_id','date_from','date_to')
        )));
    }
}
