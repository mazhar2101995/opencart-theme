<?php
class ControllerMarketplaceProducts extends Controller {
    public function index() {
        if (!$this->user->hasPermission('access','marketplace/products')) {
            $this->response->setOutput(json_encode(array('error'=>'Permission denied')));
            return;
        }
        $this->response->setOutput(json_encode(array(
            'status'=>'ok',
            'section'=>'products',
            'actions'=>array('list','create','edit','version','status')
        )));
    }
}
