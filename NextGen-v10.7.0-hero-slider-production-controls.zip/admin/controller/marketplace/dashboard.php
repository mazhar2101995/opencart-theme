<?php
class ControllerMarketplaceDashboard extends Controller {
    public function index() {
        if (!$this->user->hasPermission('access', 'marketplace/dashboard')) {
            $this->response->setOutput(json_encode(array('error'=>'Permission denied')));
            return;
        }

        $this->response->setOutput(json_encode(array(
            'status'=>'ok',
            'dashboard'=>'NextGen Marketplace',
            'sections'=>array(
                'products',
                'plans',
                'licenses',
                'activations',
                'api_audit'
            )
        )));
    }
}
