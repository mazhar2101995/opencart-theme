<?php
class ControllerMarketplaceLicenses extends Controller {
    public function index() {
        if (!$this->user->hasPermission('access','marketplace/licenses')) {
            $this->response->setOutput(json_encode(array('error'=>'Permission denied')));
            return;
        }
        $this->response->setOutput(json_encode(array(
            'status'=>'ok',
            'section'=>'licenses',
            'actions'=>array('search','view','renew','suspend','revoke','reset_installation')
        )));
    }
}
