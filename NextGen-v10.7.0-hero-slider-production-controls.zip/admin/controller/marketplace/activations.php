<?php
class ControllerMarketplaceActivations extends Controller {
    public function index() {
        if (!$this->user->hasPermission('access','marketplace/activations')) {
            $this->response->setOutput(json_encode(array('error'=>'Permission denied')));
            return;
        }
        $this->response->setOutput(json_encode(array(
            'status'=>'ok',
            'section'=>'activations',
            'actions'=>array('list','view','deactivate','transfer','reset')
        )));
    }
}
