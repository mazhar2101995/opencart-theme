<?php
class ControllerExtensionThemeNextgen extends Controller {
    private $error = array();
    private $code = 'nextgen';
    private $directory = 'nextgen';

    public function index() {
        $this->load->language('extension/theme/nextgen');
        $this->document->setTitle($this->language->get('heading_title'));
        $this->load->model('setting/setting');
        // Self-heal the NextGen installation when the settings page is opened.
        $this->removeLegacyThemeController();
        $this->repairExtensionRecord();
        $this->installDatabase();
        $this->installEvents();
        $this->grantPermissions();
        $this->ensureThemeSettings();

        $store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
            $settings = array(
                'theme_nextgen_directory' => 'nextgen',
                'theme_nextgen_status' => isset($this->request->post['nextgen_status']) ? (int)$this->request->post['nextgen_status'] : 1,
                'theme_nextgen_product_limit' => isset($this->request->post['nextgen_product_limit']) ? (int)$this->request->post['nextgen_product_limit'] : 15
            );
            $this->model_setting_setting->editSetting('theme_nextgen', $settings, $store_id);
            $this->session->data['success'] = $this->language->get('text_success');
            $this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=theme', true));
            return;
        }

        $data = array();
        $data['heading_title'] = $this->language->get('heading_title');
        $data['text_edit'] = $this->language->get('text_edit');
        $data['text_enabled'] = $this->language->get('text_enabled');
        $data['text_disabled'] = $this->language->get('text_disabled');
        $data['entry_directory'] = $this->language->get('entry_directory');
        $data['entry_status'] = $this->language->get('entry_status');
        $data['entry_product_limit'] = $this->language->get('entry_product_limit');
        $data['help_directory'] = $this->language->get('help_directory');
        $data['text_nextgen_info'] = $this->language->get('text_nextgen_info');
        $data['text_builder'] = $this->language->get('text_builder');
        $data['text_demos'] = $this->language->get('text_demos');
        $data['text_engine'] = $this->language->get('text_engine');
        $data['error_warning'] = isset($this->error['warning']) ? $this->error['warning'] : '';

        $data['breadcrumbs'] = array();
        $data['breadcrumbs'][] = array('text'=>$this->language->get('text_home'),'href'=>$this->url->link('common/dashboard','user_token='.$this->session->data['user_token'],true));
        $data['breadcrumbs'][] = array('text'=>$this->language->get('text_extension'),'href'=>$this->url->link('marketplace/extension','user_token='.$this->session->data['user_token'].'&type=theme',true));
        $data['breadcrumbs'][] = array('text'=>$data['heading_title'],'href'=>$this->url->link('extension/theme/nextgen','user_token='.$this->session->data['user_token'].'&store_id='.$store_id,true));

        $data['action'] = $this->url->link('extension/theme/nextgen','user_token='.$this->session->data['user_token'].'&store_id='.$store_id,true);
        $data['cancel'] = $this->url->link('marketplace/extension','user_token='.$this->session->data['user_token'].'&type=theme',true);
        $data['engine_url'] = $this->url->link('extension/theme/nextgen/engine','user_token='.$this->session->data['user_token'],true);
        $data['builder_url'] = $this->url->link('extension/theme/nextgen/builder','user_token='.$this->session->data['user_token'],true);
        $data['demos_url'] = $this->url->link('extension/theme/nextgen/demos','user_token='.$this->session->data['user_token'],true);

        $setting_info = $this->model_setting_setting->getSetting('theme_nextgen', $store_id);
        $data['nextgen_directory'] = 'nextgen';
        $data['nextgen_status'] = 1;
        $data['nextgen_product_limit'] = 15;
        if (isset($setting_info['theme_nextgen_status'])) $data['nextgen_status'] = (int)$setting_info['theme_nextgen_status'];
        elseif (isset($setting_info['nextgen_status'])) $data['nextgen_status'] = (int)$setting_info['nextgen_status'];
        if (isset($setting_info['theme_nextgen_product_limit'])) $data['nextgen_product_limit'] = (int)$setting_info['theme_nextgen_product_limit'];
        elseif (isset($setting_info['nextgen_product_limit'])) $data['nextgen_product_limit'] = (int)$setting_info['nextgen_product_limit'];

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        $this->response->setOutput($this->load->view('extension/theme/nextgen',$data));
    }

    public function install() {
        $this->removeLegacyThemeController();
        $this->repairExtensionRecord();
        $this->installDatabase();
        $this->installEvents();
        $this->grantPermissions();
        $this->ensureThemeSettings();

        $this->session->data['success'] = 'NextGen Theme Builder installed: database, events, permissions and theme settings are ready.';
    }

    public function uninstall() {
        $this->uninstallEvents();
        $this->db->query("DELETE FROM `" . DB_PREFIX . "setting` WHERE `code`='nextgen'");
        $this->db->query("DELETE FROM `" . DB_PREFIX . "nextgen_template_assignment`");
        $this->db->query("DELETE FROM `" . DB_PREFIX . "nextgen_runtime_setting`");
        $current = $this->db->query("SELECT `value` FROM `" . DB_PREFIX . "setting` WHERE `store_id`='0' AND `code`='config' AND `key`='config_theme' LIMIT 1");
        if ($current->num_rows && $current->row['value'] === 'nextgen') {
            $this->db->query("UPDATE `" . DB_PREFIX . "setting` SET `value`='default' WHERE `store_id`='0' AND `code`='config' AND `key`='config_theme'");
        }
    }

    public function menu(&$route = null, &$data = null, &$output = null) {
        if (!$this->user->hasPermission('access','extension/theme/nextgen')) {
            return null;
        }
        if (!is_array($data)) return null;
        $token = isset($this->session->data['user_token']) ? 'user_token=' . $this->session->data['user_token'] : '';
        $children = array(
            array('name'=>'Dashboard','href'=>$this->url->link('extension/theme/nextgen/engine',$token,true),'children'=>array()),
            array('name'=>'Settings','href'=>$this->url->link('extension/theme/nextgen/settings',$token,true),'children'=>array()),
            array('name'=>'Builder','href'=>$this->url->link('extension/theme/nextgen/builder',$token,true),'children'=>array()),
            array('name'=>'Templates','href'=>$this->url->link('extension/theme/nextgen/template_library',$token,true),'children'=>array()),
            array('name'=>'Global Components','href'=>$this->url->link('extension/theme/nextgen/global_component',$token,true),'children'=>array()),
            array('name'=>'Design System','href'=>$this->url->link('extension/theme/nextgen/design_system',$token,true),'children'=>array()),
            array('name'=>'SEO','href'=>$this->url->link('extension/theme/nextgen/seo',$token,true),'children'=>array()),
            array('name'=>'Performance','href'=>$this->url->link('extension/theme/nextgen/performance',$token,true),'children'=>array()),
            array('name'=>'Interactions','href'=>$this->url->link('extension/theme/nextgen/interactions',$token,true),'children'=>array()),
            array('name'=>'Frontend Quality','href'=>$this->url->link('extension/theme/nextgen/frontend_quality',$token,true),'children'=>array()),
            array('name'=>'AI Builder','href'=>$this->url->link('extension/theme/nextgen/ai_builder',$token,true),'children'=>array()),
            array('name'=>'Demo Library','href'=>$this->url->link('extension/theme/nextgen/demos',$token,true),'children'=>array()),
            array('name'=>'Runtime & QA','href'=>$this->url->link('extension/theme/nextgen/final_qa',$token,true),'children'=>array())
        );
        if (!isset($data['menus']) || !is_array($data['menus'])) $data['menus'] = array();
        foreach ($data['menus'] as $existing) { if (isset($existing['id']) && $existing['id'] === 'menu-nextgen-theme-engine') return null; }
        $data['menus'][] = array(
            'id'=>'menu-nextgen-theme-engine',
            'icon'=>'fa fa-magic',
            'name'=>'NextGen Theme Engine',
            'href'=>'',
            'children'=>$children
        );
        return null;
    }

    protected function validate() {
        if (!$this->user->hasPermission('modify','extension/theme/nextgen')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }
        return !$this->error;
    }

    private function removeLegacyThemeController() {
        // OpenCart 3 scans every PHP file directly under this folder as a theme.
        // Older NextGen builds incorrectly placed the Builder controller here.
        $legacy_files = array(
            DIR_APPLICATION . 'controller/extension/theme/nextgen_builder.php',
            DIR_APPLICATION . 'controller/extension/theme/nextgen_builder.php.bak',
            DIR_APPLICATION . 'controller/extension/theme/nextgen_builder.php.old'
        );
        foreach ($legacy_files as $legacy) {
            if (is_file($legacy)) @unlink($legacy);
        }
        if (defined('DIR_MODIFICATION')) {
            $modified = DIR_MODIFICATION . 'admin/controller/extension/theme/nextgen_builder.php';
            if (is_file($modified)) @unlink($modified);
        }
    }

    private function repairExtensionRecord() {
        // OpenCart's theme selector reads the extension registry. Keep exactly
        // one theme/nextgen row and create it when a previous dev build removed it.
        $q = $this->db->query("SELECT extension_id FROM `" . DB_PREFIX . "extension` WHERE type='theme' AND code='nextgen' ORDER BY extension_id ASC");
        if (!$q->num_rows) {
            $this->db->query("INSERT INTO `" . DB_PREFIX . "extension` SET type='theme', code='nextgen'");
            return;
        }
        if ($q->num_rows > 1) {
            $ids = array();
            for ($i = 1; $i < $q->num_rows; $i++) $ids[] = (int)$q->rows[$i]['extension_id'];
            if ($ids) {
                $this->db->query("DELETE FROM `" . DB_PREFIX . "extension` WHERE extension_id IN (" . implode(',', $ids) . ")");
            }
        }
    }

    private function installDatabase() {
        $tables = array(
            "CREATE TABLE IF NOT EXISTS `".DB_PREFIX."nextgen_builder_document` (`document_id` INT(11) NOT NULL AUTO_INCREMENT,`name` VARCHAR(191) NOT NULL,`store_id` INT(11) NOT NULL DEFAULT 0,`route` VARCHAR(191) NOT NULL DEFAULT '',`template_type` VARCHAR(64) NOT NULL DEFAULT 'page',`status` TINYINT(1) NOT NULL DEFAULT 1,`version` INT(11) NOT NULL DEFAULT 1,`document_json` LONGTEXT NOT NULL,`date_added` DATETIME NOT NULL,`date_modified` DATETIME NOT NULL,PRIMARY KEY (`document_id`),KEY `idx_route_status` (`route`,`status`),KEY `idx_template_type` (`template_type`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci",
            "CREATE TABLE IF NOT EXISTS `".DB_PREFIX."nextgen_builder_revision` (`revision_id` INT(11) NOT NULL AUTO_INCREMENT,`document_id` INT(11) NOT NULL,`version` INT(11) NOT NULL,`document_json` LONGTEXT NOT NULL,`created_by` INT(11) NOT NULL DEFAULT 0,`date_added` DATETIME NOT NULL,PRIMARY KEY (`revision_id`),KEY `idx_document_version` (`document_id`,`version`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci",
            "CREATE TABLE IF NOT EXISTS `".DB_PREFIX."nextgen_runtime_setting` (`setting_id` INT NOT NULL AUTO_INCREMENT,`store_id` INT NOT NULL DEFAULT 0,`key` VARCHAR(191) NOT NULL,`value` LONGTEXT NOT NULL,`date_modified` DATETIME NOT NULL,PRIMARY KEY (`setting_id`),UNIQUE KEY `uq_store_key` (`store_id`,`key`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci",
            "CREATE TABLE IF NOT EXISTS `".DB_PREFIX."nextgen_global_section` (`section_id` INT NOT NULL AUTO_INCREMENT,`section_key` VARCHAR(191) NOT NULL,`name` VARCHAR(191) NOT NULL,`status` TINYINT(1) NOT NULL DEFAULT 0,`document_json` LONGTEXT NOT NULL,`version` INT NOT NULL DEFAULT 1,`date_added` DATETIME NOT NULL,`date_modified` DATETIME NOT NULL,PRIMARY KEY (`section_id`),UNIQUE KEY `uq_section_key` (`section_key`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci",
            "CREATE TABLE IF NOT EXISTS `".DB_PREFIX."nextgen_template` (`template_id` INT(11) NOT NULL AUTO_INCREMENT,`template_key` VARCHAR(120) NOT NULL,`name` VARCHAR(255) NOT NULL,`type` VARCHAR(50) NOT NULL DEFAULT 'page',`category` VARCHAR(100) NOT NULL DEFAULT 'general',`status` VARCHAR(30) NOT NULL DEFAULT 'draft',`version` INT(11) NOT NULL DEFAULT 1,`preview_image` VARCHAR(500) NOT NULL DEFAULT '',`document_json` LONGTEXT NOT NULL,`date_added` DATETIME NOT NULL,`date_modified` DATETIME NOT NULL,PRIMARY KEY (`template_id`),UNIQUE KEY `template_key` (`template_key`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci",
            "CREATE TABLE IF NOT EXISTS `".DB_PREFIX."nextgen_template_revision` (`revision_id` INT(11) NOT NULL AUTO_INCREMENT,`template_id` INT(11) NOT NULL,`version` INT(11) NOT NULL,`document_json` LONGTEXT NOT NULL,`created_by` INT(11) NOT NULL DEFAULT 0,`note` VARCHAR(500) NOT NULL DEFAULT '',`date_added` DATETIME NOT NULL,PRIMARY KEY (`revision_id`),KEY `template_id` (`template_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci",
            "CREATE TABLE IF NOT EXISTS `".DB_PREFIX."nextgen_global_component` (`component_id` INT(11) NOT NULL AUTO_INCREMENT,`component_key` VARCHAR(100) NOT NULL,`name` VARCHAR(255) NOT NULL,`type` VARCHAR(50) NOT NULL DEFAULT 'global',`status` TINYINT(1) NOT NULL DEFAULT 1,`version` INT(11) NOT NULL DEFAULT 1,`document_json` LONGTEXT NOT NULL,`date_added` DATETIME NOT NULL,`date_modified` DATETIME NOT NULL,PRIMARY KEY (`component_id`),UNIQUE KEY `component_key` (`component_key`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci",
            "CREATE TABLE IF NOT EXISTS `".DB_PREFIX."nextgen_global_component_revision` (`revision_id` INT(11) NOT NULL AUTO_INCREMENT,`component_id` INT(11) NOT NULL,`version` INT(11) NOT NULL,`document_json` LONGTEXT NOT NULL,`created_by` INT(11) NOT NULL DEFAULT 0,`date_added` DATETIME NOT NULL,PRIMARY KEY (`revision_id`),KEY `component_id` (`component_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci",
            "CREATE TABLE IF NOT EXISTS `".DB_PREFIX."nextgen_template_assignment` (`assignment_id` INT(11) NOT NULL AUTO_INCREMENT,`store_id` INT(11) NOT NULL DEFAULT 0,`language_id` INT(11) NOT NULL DEFAULT 0,`route` VARCHAR(191) NOT NULL DEFAULT '',`template_type` VARCHAR(64) NOT NULL DEFAULT '',`document_id` INT(11) NOT NULL DEFAULT 0,`priority` INT(11) NOT NULL DEFAULT 0,`status` TINYINT(1) NOT NULL DEFAULT 1,`source` VARCHAR(191) NOT NULL DEFAULT '',`date_modified` DATETIME NOT NULL,PRIMARY KEY (`assignment_id`),UNIQUE KEY `uq_assignment` (`store_id`,`language_id`,`route`,`template_type`),KEY `idx_route_status` (`route`,`status`),KEY `idx_document` (`document_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci",
            "CREATE TABLE IF NOT EXISTS `".DB_PREFIX."nextgen_package_state` (`state_id` INT(11) NOT NULL AUTO_INCREMENT,`package_name` VARCHAR(128) NOT NULL,`version` VARCHAR(32) NOT NULL,`status` VARCHAR(32) NOT NULL,`metadata` LONGTEXT NOT NULL,`date_modified` DATETIME NOT NULL,PRIMARY KEY (`state_id`),UNIQUE KEY `package_name` (`package_name`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci",
            "CREATE TABLE IF NOT EXISTS `".DB_PREFIX."nextgen_update_audit` (`audit_id` INT(11) NOT NULL AUTO_INCREMENT,`package_name` VARCHAR(128) NOT NULL,`version` VARCHAR(32) NOT NULL,`action` VARCHAR(64) NOT NULL,`status` VARCHAR(32) NOT NULL,`message` TEXT,`created_by` INT(11) NOT NULL DEFAULT 0,`date_added` DATETIME NOT NULL,PRIMARY KEY (`audit_id`),KEY `package_name` (`package_name`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci"
        );
        foreach ($tables as $sql) $this->db->query($sql);
        $this->ensureBuilderDocumentStoreColumn();
    }

    private function ensureBuilderDocumentStoreColumn() {
        $q = $this->db->query("SHOW COLUMNS FROM `" . DB_PREFIX . "nextgen_builder_document` LIKE 'store_id'");
        if (!$q->num_rows) {
            $this->db->query("ALTER TABLE `" . DB_PREFIX . "nextgen_builder_document` ADD `store_id` INT(11) NOT NULL DEFAULT 0 AFTER `route`");
        }
        $idx = $this->db->query("SHOW INDEX FROM `" . DB_PREFIX . "nextgen_builder_document` WHERE Key_name='idx_store_route'");
        if (!$idx->num_rows) {
            $this->db->query("ALTER TABLE `" . DB_PREFIX . "nextgen_builder_document` ADD KEY `idx_store_route` (`store_id`,`route`,`status`)");
        }
    }

    private function installEvents() {
        require_once DIR_SYSTEM . 'library/nextgen/opencart_event_installer.php';
        $installer = new NextGenOpenCartEventInstaller();
        $installer->install($this->db);
    }

    private function uninstallEvents() {
        require_once DIR_SYSTEM . 'library/nextgen/opencart_event_installer.php';
        $installer = new NextGenOpenCartEventInstaller();
        $installer->uninstall($this->db);
    }

    private function grantPermissions() {
        $routes = array(
            'extension/theme/nextgen','extension/theme/nextgen/settings','extension/theme/nextgen/builder','extension/theme/nextgen/template_library','extension/theme/nextgen/global_component','extension/theme/nextgen/global_component/edit','extension/theme/nextgen/design_system','extension/theme/nextgen/seo','extension/theme/nextgen/performance','extension/theme/nextgen/interactions','extension/theme/nextgen/frontend_quality','extension/theme/nextgen/ai_builder','extension/theme/nextgen/demos','extension/theme/nextgen/final_qa','extension/theme/nextgen/runtime','extension/theme/nextgen/runtime_test','extension/theme/nextgen/storefront_runtime_test'
        );
        $group_ids = array(1);
        $current_user_id = method_exists($this->user, 'getId') ? (int)$this->user->getId() : 0;
        if ($current_user_id) {
            $uq=$this->db->query("SELECT user_group_id FROM `".DB_PREFIX."user` WHERE user_id='".$current_user_id."' LIMIT 1");
            if ($uq->num_rows) $group_ids[]=(int)$uq->row['user_group_id'];
        }
        $group_ids=array_values(array_unique(array_filter($group_ids)));
        foreach ($group_ids as $group_id) {
            $q=$this->db->query("SELECT permission FROM `".DB_PREFIX."user_group` WHERE user_group_id='".$group_id."' LIMIT 1");
            if (!$q->num_rows) continue;
            $permission=json_decode($q->row['permission'],true);
            if (!is_array($permission)) $permission=array('access'=>array(),'modify'=>array());
            foreach (array('access','modify') as $type) {
                if (!isset($permission[$type]) || !is_array($permission[$type])) $permission[$type]=array();
                foreach ($routes as $route) if (!in_array($route,$permission[$type],true)) $permission[$type][]=$route;
            }
            $this->db->query("UPDATE `".DB_PREFIX."user_group` SET permission='".$this->db->escape(json_encode($permission))."' WHERE user_group_id='".$group_id."'");
        }
    }

    private function ensureThemeSettings() {
        // OpenCart 3 theme settings MUST use the theme_<code> namespace.
        // The extension registration remains code=nextgen, but the storefront
        // theme settings live under theme_nextgen.
        $this->dedupeSettings('theme_nextgen');

        // Remove legacy development settings that used the wrong namespace.
        $this->db->query("DELETE FROM `" . DB_PREFIX . "setting` WHERE `code`='nextgen'");

        // Installing NextGen intentionally makes it the active theme for the
        // current development store. The previous theme remains installed and
        // can be selected again later from the normal OpenCart theme settings.
        $this->upsertSetting(0,'config','config_theme','nextgen',0);

        $this->upsertThemeRuntimeSettings(0);

        $stores = $this->db->query("SELECT store_id FROM `" . DB_PREFIX . "store`");
        foreach ($stores->rows as $store) {
            $store_id = (int)$store['store_id'];
            $this->upsertSetting($store_id,'config','config_theme','nextgen',0);
            $this->upsertThemeRuntimeSettings($store_id);
        }
    }


    private function upsertThemeRuntimeSettings($store_id) {
        $this->upsertSetting($store_id,'config','config_theme','nextgen',0);
        $settings = array(
            'theme_nextgen_directory' => 'nextgen',
            'theme_nextgen_status' => '1',
            'theme_nextgen_product_limit' => '15',
            'theme_nextgen_product_description_length' => '100',
            'theme_nextgen_image_product_width' => '600',
            'theme_nextgen_image_product_height' => '600',
            'theme_nextgen_image_thumb_width' => '100',
            'theme_nextgen_image_thumb_height' => '100',
            'theme_nextgen_image_popup_width' => '1000',
            'theme_nextgen_image_popup_height' => '1000',
            'theme_nextgen_image_additional_width' => '100',
            'theme_nextgen_image_additional_height' => '100',
            'theme_nextgen_image_related_width' => '100',
            'theme_nextgen_image_related_height' => '100',
            'theme_nextgen_image_compare_width' => '100',
            'theme_nextgen_image_compare_height' => '100',
            'theme_nextgen_image_wishlist_width' => '100',
            'theme_nextgen_image_wishlist_height' => '100',
            'theme_nextgen_image_cart_width' => '100',
            'theme_nextgen_image_cart_height' => '100',
            'theme_nextgen_image_category_width' => '300',
            'theme_nextgen_image_category_height' => '300'
        );
        foreach ($settings as $key => $value) {
            $q=$this->db->query("SELECT setting_id FROM `".DB_PREFIX."setting` WHERE store_id='".(int)$store_id."' AND code='theme_nextgen' AND `key`='".$this->db->escape($key)."' LIMIT 1");
            if (!$q->num_rows) {
                $this->upsertSetting($store_id,'theme_nextgen',$key,$value,0);
            }
        }
    }

    private function dedupeSettings($code) {
        $q = $this->db->query("SELECT setting_id, store_id, `key` FROM `" . DB_PREFIX . "setting` WHERE code='" . $this->db->escape($code) . "' ORDER BY setting_id ASC");
        $seen = array();
        foreach ($q->rows as $row) {
            $key = (int)$row['store_id'] . ':' . $row['key'];
            if (isset($seen[$key])) {
                $this->db->query("DELETE FROM `" . DB_PREFIX . "setting` WHERE setting_id='" . (int)$row['setting_id'] . "'");
            } else {
                $seen[$key] = true;
            }
        }
    }

    private function upsertSetting($store_id,$code,$key,$value,$serialized=0) {
        $q=$this->db->query("SELECT setting_id FROM `".DB_PREFIX."setting` WHERE store_id='".(int)$store_id."' AND code='".$this->db->escape($code)."' AND `key`='".$this->db->escape($key)."' LIMIT 1");
        if ($q->num_rows) {
            $this->db->query("UPDATE `".DB_PREFIX."setting` SET value='".$this->db->escape($value)."',serialized='".(int)$serialized."' WHERE setting_id='".(int)$q->row['setting_id']."'");
        } else {
            $this->db->query("INSERT INTO `".DB_PREFIX."setting` SET store_id='".(int)$store_id."',code='".$this->db->escape($code)."',`key`='".$this->db->escape($key)."',value='".$this->db->escape($value)."',serialized='".(int)$serialized."'");
        }
    }
}
