<?php
class ControllerExtensionThemeNextgenSettings extends Controller {
    private function token() {
        return 'user_token=' . (isset($this->session->data['user_token']) ? $this->session->data['user_token'] : '');
    }

    public function index() {
        if (!$this->user->hasPermission('access', 'extension/theme/nextgen/settings')) {
            $this->response->redirect($this->url->link('common/dashboard', $this->token(), true));
            return;
        }

        $this->load->model('extension/theme/nextgen/settings');
        $store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

        if ($this->request->server['REQUEST_METHOD'] === 'POST') {
            if (!$this->user->hasPermission('modify', 'extension/theme/nextgen/settings')) {
                $this->session->data['error'] = 'You do not have permission to modify NextGen core settings.';
            } else {
                // Core page owns only storefront runtime values. Other engines save
                // their own settings so opening/saving this page can never overwrite them.
                $all = $this->model_extension_theme_nextgen_settings->getAll($store_id);
                $all['enabled'] = isset($this->request->post['enabled']) ? '1' : '0';
                $all['product_limit'] = max(1, min(100, (int)(isset($this->request->post['product_limit']) ? $this->request->post['product_limit'] : $all['product_limit'])));
                $all['container_width'] = max(760, min(1920, (int)(isset($this->request->post['container_width']) ? $this->request->post['container_width'] : $all['container_width'])));
                $this->model_extension_theme_nextgen_settings->save($all, $store_id);

                $this->load->model('setting/setting');
                $this->model_setting_setting->editSetting('theme_nextgen', array(
                    'theme_nextgen_directory' => 'nextgen',
                    'theme_nextgen_status' => (int)$all['enabled'],
                    'theme_nextgen_product_limit' => (int)$all['product_limit']
                ), $store_id);
                $this->session->data['success'] = 'Core NextGen settings saved successfully.';
            }
            $this->response->redirect($this->url->link('extension/theme/nextgen/settings', $this->token() . '&store_id=' . $store_id, true));
            return;
        }

        if (isset($this->request->get['reset']) && $this->request->get['reset'] === '1' && $this->user->hasPermission('modify', 'extension/theme/nextgen/settings')) {
            $this->model_extension_theme_nextgen_settings->reset($store_id);
            $this->session->data['success'] = 'NextGen settings restored to safe defaults.';
            $this->response->redirect($this->url->link('extension/theme/nextgen/settings', $this->token() . '&store_id=' . $store_id, true));
            return;
        }

        // Seed the complete settings profile once; never overwrite an existing value.
        $seed = $this->model_extension_theme_nextgen_settings->hasProfile($store_id);
        if (!$seed) { $this->model_extension_theme_nextgen_settings->save($this->model_extension_theme_nextgen_settings->defaults(), $store_id); }
        $data = $this->model_extension_theme_nextgen_settings->getAll($store_id);
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        $data['title'] = 'NextGen Settings';
        $data['store_id'] = $store_id;
        $data['can_modify'] = $this->user->hasPermission('modify', 'extension/theme/nextgen/settings');
        $data['action'] = $this->url->link('extension/theme/nextgen/settings', $this->token() . '&store_id=' . $store_id, true);
        $data['reset_url'] = $this->url->link('extension/theme/nextgen/settings', $this->token() . '&store_id=' . $store_id . '&reset=1', true);
        $data['theme_url'] = $this->url->link('extension/theme/nextgen', $this->token() . '&store_id=' . $store_id, true);
        $data['builder_url'] = $this->url->link('extension/theme/nextgen/builder', $this->token(), true);
        $data['demo_url'] = $this->url->link('extension/theme/nextgen/demos', $this->token(), true);
        $data['qa_url'] = $this->url->link('extension/theme/nextgen/final_qa', $this->token(), true);
        $data['design_url']=$this->url->link('extension/theme/nextgen/design_system',$this->token(),true);
        $data['seo_url']=$this->url->link('extension/theme/nextgen/seo',$this->token(),true);
        $data['performance_url']=$this->url->link('extension/theme/nextgen/performance',$this->token(),true);
        $data['interactions_url']=$this->url->link('extension/theme/nextgen/interactions',$this->token(),true);
        $data['quality_url']=$this->url->link('extension/theme/nextgen/frontend_quality',$this->token(),true);
        $data['ai_url']=$this->url->link('extension/theme/nextgen/ai_builder',$this->token(),true);
        $data['success'] = isset($this->session->data['success']) ? $this->session->data['success'] : '';
        $data['error_warning'] = isset($this->session->data['error']) ? $this->session->data['error'] : '';
        unset($this->session->data['success'], $this->session->data['error']);
        $data['font_options'] = array('system'=>'System UI','Inter'=>'Inter','Poppins'=>'Poppins','Roboto'=>'Roboto','Open Sans'=>'Open Sans','custom'=>'Custom / theme stylesheet');
        $data['provider_options'] = array('none'=>'No AI provider','openai'=>'OpenAI adapter','anthropic'=>'Anthropic adapter','custom'=>'Custom provider adapter');

        $this->response->setOutput($this->load->view('extension/theme/nextgen/settings', $data));
    }
}
