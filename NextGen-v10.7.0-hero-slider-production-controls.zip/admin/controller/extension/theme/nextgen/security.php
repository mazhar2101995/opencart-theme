<?php
class ControllerExtensionThemeNextgenSecurity extends Controller {
    public function index() {
        if (!$this->user->hasPermission('access', 'extension/theme/nextgen/security')) {
            $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        $this->response->setOutput(json_encode(array('error'=>'Permission denied')));
            return;
        }

        $this->response->setOutput(json_encode(array(
            'status'=>'ok',
            'security'=>'NextGen Marketplace Verification',
            'checks'=>array(
                'signature'=>'enabled',
                'license'=>'supported',
                'installation_identity'=>'enabled',
                'marketplace_verification'=>'enabled'
            )
        )));
    }
}
