<?php
class ControllerExtensionThemeNextgenLicense extends Controller {
    public function index() {
        if (!$this->user->hasPermission('access', 'extension/theme/nextgen/license')) {
            $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        $this->response->setOutput(json_encode(array('error'=>'Permission denied')));
            return;
        }

        $this->response->setOutput(json_encode(array(
            'status'=>'ok',
            'license_manager'=>'NextGen',
            'actions'=>array(
                'activate','deactivate','renew','refresh','transfer','trial_start','trial_extend'
            )
        )));
    }
}
