<?php
class ControllerExtensionThemeNextgenFrontendRender extends Controller {
    public function index() {
        $this->load->language('extension/theme/nextgen/frontend_render');

        $data['pipeline'] = [
            'document' => 'Builder JSON',
            'resolver' => 'Widget Resolver',
            'renderer' => 'Twig/HTML Renderer',
            'assets' => 'Dependency Collector',
            'optimizer' => 'HTML Optimizer',
            'cache' => 'Page Render Cache'
        ];

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        $this->response->setOutput(
            $this->load->view('extension/theme/nextgen/frontend_render', $data)
        );
    }
}
