<?php
class ControllerExtensionThemeNextgenDemos extends Controller {
    public function index() {
        if (!$this->user->hasPermission('access','extension/theme/nextgen/demos')) {
            $this->response->redirect($this->url->link('common/dashboard',$this->token(),true));
            return;
        }
        $this->load->language('extension/theme/nextgen/demos');
        $this->document->setTitle($this->language->get('heading_title'));
        require_once DIR_SYSTEM . 'library/nextgen/demo_installer.php';
        $installer = new NextGenDemoInstaller($this->db, $this->registry);
        $data=array();
        $data['heading_title']=$this->language->get('heading_title');
        $data['success']=isset($this->session->data['nextgen_demo_success'])?$this->session->data['nextgen_demo_success']:'';
        unset($this->session->data['nextgen_demo_success']);
        $data['error']=isset($this->session->data['nextgen_demo_error'])?$this->session->data['nextgen_demo_error']:'';
        unset($this->session->data['nextgen_demo_error']);
        $data['demos']=array_values($installer->listDemos());
        $data['active_demo']='';
        $active=$this->db->query("SELECT value FROM `".DB_PREFIX."nextgen_runtime_setting` WHERE store_id='0' AND `key`='active_demo' LIMIT 1");
        if ($active->num_rows) $data['active_demo']=(string)$active->row['value'];
        $data['import_urls']=array();
        foreach($data['demos'] as $demo) {
            $data['import_urls'][$demo['slug']]=$this->url->link('extension/theme/nextgen/demos/import',$this->token(),true);
        }
        $data['builder_url']=$this->url->link('extension/theme/nextgen/builder',$this->token(),true);
        $data['storefront_url']=$this->url->link('common/home','',true);
        $data['engine_url']=$this->url->link('extension/theme/nextgen/engine',$this->token(),true);
        $data['settings_url'] = $this->url->link('extension/theme/nextgen/settings', $this->token(), true);
        $data['header']=$this->load->controller('common/header');
        $data['column_left']=$this->load->controller('common/column_left');
        $data['footer']=$this->load->controller('common/footer');
        $this->response->setOutput($this->load->view('extension/theme/nextgen/demos',$data));
    }

    public function import() {
        if (!$this->user->hasPermission('modify','extension/theme/nextgen/demos')) {
            $this->json(array('success'=>false,'error'=>'Permission denied.'),403);
            return;
        }
        $slug=isset($this->request->post['demo'])?$this->request->post['demo']:(isset($this->request->get['demo'])?$this->request->get['demo']:'');
        require_once DIR_SYSTEM . 'library/nextgen/demo_installer.php';
        $installer=new NextGenDemoInstaller($this->db,$this->registry);
        $result=$installer->import($slug,0,(int)$this->config->get('config_language_id'));
        if ($this->isAjax()) {
            $this->json($result, $result['success']?200:400);
            return;
        }
        if ($result['success']) $this->session->data['nextgen_demo_success']=$result['message'];
        else $this->session->data['nextgen_demo_error']=$result['error'];
        $this->response->redirect($this->url->link('extension/theme/nextgen/demos',$this->token(),true));
    }

    private function isAjax() {
        return !empty($this->request->server['HTTP_X_REQUESTED_WITH']) || isset($this->request->get['ajax']);
    }
    private function token() { return 'user_token='.(isset($this->session->data['user_token'])?$this->session->data['user_token']:''); }
    private function json($data,$status=200) {
        $this->response->addHeader('Content-Type: application/json; charset=utf-8');
        $this->response->setOutput(json_encode($data,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE));
    }
}
