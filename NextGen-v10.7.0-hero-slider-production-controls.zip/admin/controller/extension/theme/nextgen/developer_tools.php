<?php
class ControllerExtensionThemeNextgenDeveloperTools extends Controller {
    public function index() {
        $this->load->language('extension/theme/nextgen/developer_tools');

        if (!$this->user->hasPermission('access', 'extension/theme/nextgen/developer_tools')) {
            $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        $this->response->setOutput('Permission denied');
            return;
        }

        $data['title'] = $this->language->get('heading_title');
        $data['version'] = '2.5.0';
        $data['features'] = array(
            'Developer API',
            'Custom Widget SDK',
            'Widget registration',
            'Dynamic provider registration',
            'Hooks',
            'Filters',
            'Widget controls and asset declarations',
            'Developer diagnostics foundation'
        );

        $this->response->setOutput(
            $this->load->view('extension/theme/nextgen/developer_tools', $data)
        );
    }
}
