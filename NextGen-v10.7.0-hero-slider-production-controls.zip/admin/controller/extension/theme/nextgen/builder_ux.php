<?php
class ControllerExtensionThemeNextgenBuilderUx extends Controller {
    public function index() {
        $this->load->language('extension/theme/nextgen/builder_ux');

        if (!$this->user->hasPermission('access', 'extension/theme/nextgen/builder_ux')) {
            $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        $this->response->setOutput('Permission denied');
            return;
        }

        require_once(DIR_SYSTEM . 'library/nextgen/builder_ux.php');

        $data['title'] = $this->language->get('heading_title');
        $data['version'] = '2.7.0';
        $data['devices'] = NextGenBuilderUx::deviceList();
        $data['features'] = array(
            'Desktop / tablet / mobile live editing',
            'Responsive property states',
            'Global token references',
            'Local widget overrides',
            'Template-level style inheritance',
            'Style reset and fallback foundation',
            'Device preview foundation'
        );

        $this->response->setOutput(
            $this->load->view('extension/theme/nextgen/builder_ux', $data)
        );
    }
}
