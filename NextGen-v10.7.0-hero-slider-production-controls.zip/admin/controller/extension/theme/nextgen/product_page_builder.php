<?php
class ControllerExtensionThemeNextgenProductPageBuilder extends Controller {
    public function index() {
        $this->load->language('extension/theme/nextgen/product_page_builder');
        $data['widgets'] = NextGenProductPageSchema::widgets();
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        $this->response->setOutput($this->load->view('extension/theme/nextgen/product_page_builder', $data));
    }

    public function schema() {
        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode([
            'widgets' => NextGenProductPageSchema::widgets(),
            'controls' => array_reduce(array_keys(NextGenProductPageSchema::widgets()), function($carry, $id) {
                $carry[$id] = NextGenProductPageSchema::controls($id);
                return $carry;
            }, [])
        ], JSON_UNESCAPED_SLASHES));
    }
}
