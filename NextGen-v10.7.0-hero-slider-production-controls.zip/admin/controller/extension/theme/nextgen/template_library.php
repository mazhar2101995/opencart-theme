<?php
class ControllerExtensionThemeNextgenTemplateLibrary extends Controller {
    public function index() {
        $this->load->language('extension/theme/nextgen/template_library');
        $this->load->model('extension/theme/nextgen/template_library');

        $this->model_extension_theme_nextgen_template_library->install();
        $data['templates'] = $this->model_extension_theme_nextgen_template_library->getList();
        $data['published_count'] = count($this->model_extension_theme_nextgen_template_library->getList('', '', 'published'));
        $data['draft_count'] = count($this->model_extension_theme_nextgen_template_library->getList('', '', 'draft'));
        $data['can_modify'] = $this->user->hasPermission('modify', 'extension/theme/nextgen/template_library');
        $data['builder_url'] = $this->url->link('extension/theme/nextgen/builder', $this->token(), true);
        $data['add_url'] = $this->url->link('extension/theme/nextgen/template_library/add', $this->token(), true);
        $data['csrf_token'] = $this->token();

        $data['settings_url'] = $this->url->link('extension/theme/nextgen/settings', $this->token(), true);
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        $this->response->setOutput(
            $this->load->view('extension/theme/nextgen/template_library', $data)
        );
    }

    public function add() {
        if (!$this->user->hasPermission('modify', 'extension/theme/nextgen/template_library')) { $this->response->redirect($this->url->link('extension/theme/nextgen/template_library',$this->token(),true)); return; }
        $this->load->model('extension/theme/nextgen/template_library');
        $name=isset($this->request->post['name']) ? trim($this->request->post['name']) : 'New Template';
        $type=isset($this->request->post['type']) ? trim($this->request->post['type']) : 'page';
        $category=isset($this->request->post['category']) ? trim($this->request->post['category']) : 'custom';
        $key='custom-'.preg_replace('/[^a-z0-9_-]/','-',strtolower($name)).'-'.substr(md5(uniqid('',true)),0,6);
        $document=array(
            'type'=>'root', 'version'=>1, 'children'=>array(
                array('id'=>'section_'.substr(md5(uniqid('',true)),0,8),'type'=>'section','settings'=>array('padding'=>'64px 24px','background'=>'#ffffff'),'children'=>array(
                    array('id'=>'container_'.substr(md5(uniqid('',true)),0,8),'type'=>'container','settings'=>array('maxWidth'=>'1200px','margin'=>'0 auto'),'children'=>array(
                        array('id'=>'column_'.substr(md5(uniqid('',true)),0,8),'type'=>'column','settings'=>array(),'children'=>array(
                            array('id'=>'heading_'.substr(md5(uniqid('',true)),0,8),'type'=>'heading','settings'=>array('tag'=>'h1','text'=>$name),'children'=>array())
                        ))
                    ))
                ))
            )
        );
        $id=$this->model_extension_theme_nextgen_template_library->save($key,$name,$type,$category,$document,'draft','',(int)$this->user->getId(),'Created from Template Library');
        $this->response->redirect($this->url->link('extension/theme/nextgen/builder',$this->token().'&template_id='.(int)$id,true));
    }

    public function edit() {
        if (!$this->user->hasPermission('modify','extension/theme/nextgen/template_library')) { $this->response->redirect($this->url->link('extension/theme/nextgen/template_library',$this->token(),true)); return; }
        $id=(int)($this->request->get['template_id'] ?? 0);
        $this->response->redirect($this->url->link('extension/theme/nextgen/builder',$this->token().'&template_id='.$id,true));
    }

    public function status() {
        if (!$this->user->hasPermission('modify','extension/theme/nextgen/template_library')) { $this->json(array('success'=>false,'error'=>'Permission denied.')); return; }
        $id=(int)($this->request->post['template_id'] ?? 0); $status=isset($this->request->post['status'])?$this->request->post['status']:'draft';
        $this->load->model('extension/theme/nextgen/template_library');
        $this->json(array('success'=>$this->model_extension_theme_nextgen_template_library->setStatus($id,$status)));
    }

    public function duplicate() {
        if (!$this->user->hasPermission('modify','extension/theme/nextgen/template_library')) { $this->json(array('success'=>false,'error'=>'Permission denied.')); return; }
        $id=(int)($this->request->post['template_id'] ?? 0); $this->load->model('extension/theme/nextgen/template_library');
        $new=$this->model_extension_theme_nextgen_template_library->duplicate($id,(int)$this->user->getId());
        $this->json(array('success'=>(bool)$new,'template_id'=>(int)$new));
    }

    public function delete() {
        if (!$this->user->hasPermission('modify','extension/theme/nextgen/template_library')) { $this->json(array('success'=>false,'error'=>'Permission denied.')); return; }
        $id=(int)($this->request->post['template_id'] ?? 0); $this->load->model('extension/theme/nextgen/template_library');
        $this->json(array('success'=>$this->model_extension_theme_nextgen_template_library->delete($id)));
    }

    private function token() { return isset($this->session->data['user_token']) ? 'user_token=' . $this->session->data['user_token'] : 'token=' . (isset($this->session->data['token']) ? $this->session->data['token'] : ''); }
    private function json($data) { $this->response->addHeader('Content-Type: application/json; charset=utf-8'); $this->response->setOutput(json_encode($data, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)); }

    public function revisions() {
        $this->load->model('extension/theme/nextgen/template_library');

        $template_id = (int)($this->request->get['template_id'] ?? 0);
        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode([
            'revisions' => $this->model_extension_theme_nextgen_template_library->revisions($template_id)
        ]));
    }

    public function restore() {
        $this->load->model('extension/theme/nextgen/template_library');

        $template_id = (int)($this->request->post['template_id'] ?? 0);
        $revision_id = (int)($this->request->post['revision_id'] ?? 0);
        $user_id = (int)($this->user->getId());

        $ok = $this->model_extension_theme_nextgen_template_library->restore(
            $template_id, $revision_id, $user_id
        );

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode(['success'=>$ok]));
    }
}
