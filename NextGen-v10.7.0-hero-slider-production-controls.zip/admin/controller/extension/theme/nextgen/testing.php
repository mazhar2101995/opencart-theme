<?php
class ControllerExtensionThemeNextgenTesting extends Controller {
    public function index() {
        $this->load->language('extension/theme/nextgen/testing');

        if (!$this->user->hasPermission('access', 'extension/theme/nextgen/testing')) {
            $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        $this->response->setOutput('Permission denied');
            return;
        }

        $data['title'] = $this->language->get('heading_title');
        $data['version'] = '2.4.0';
        $data['suites'] = array(
            'Document structure validation',
            'Widget registry validation',
            'Accessibility checks',
            'Responsive configuration checks',
            'Security boundary checks',
            'Release package checks'
        );

        $this->response->setOutput(
            $this->load->view('extension/theme/nextgen/testing', $data)
        );
    }
}
