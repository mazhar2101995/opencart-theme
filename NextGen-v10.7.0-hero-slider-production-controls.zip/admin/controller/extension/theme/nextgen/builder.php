<?php
class ControllerExtensionThemeNextgenBuilder extends Controller {
    private $error = array();

    public function index() {
        $this->load->language('extension/theme/nextgen/builder');

        if (!$this->user->hasPermission('access', 'extension/theme/nextgen/builder')) {
            $this->response->redirect($this->url->link('common/dashboard', $this->token(), true));
            return;
        }

        $this->document->setTitle($this->language->get('heading_title'));
        $data['title'] = $this->language->get('heading_title');
        $data['token'] = $this->token();
        $data['api_url'] = 'index.php?' . $this->token();
        $data['can_modify'] = $this->user->hasPermission('modify', 'extension/theme/nextgen/builder');
        $data['builder_version'] = '10.5.25';
        $data['front_editor_token'] = $this->createFrontEditorToken();
        $data['filemanager_url'] = $this->url->link('common/filemanager', 'user_token=' . (isset($this->session->data['user_token']) ? $this->session->data['user_token'] : ''));
        // Always resolve storefront media from the catalog base URL. In OpenCart admin,
        // config_url may be configured differently; HTTP_CATALOG is authoritative when available.
        $catalog_base = defined('HTTP_CATALOG') ? (string)HTTP_CATALOG : (string)$this->config->get('config_url');
        if ($catalog_base === '' && defined('HTTPS_CATALOG')) { $catalog_base = HTTPS_CATALOG; }
        if ($catalog_base === '' && defined('HTTPS_SERVER')) { $catalog_base = HTTPS_SERVER; }
        $catalog_base = rtrim($catalog_base, '/');
        // Some installations expose config_url with a trailing /catalog path. Remove it.
        $catalog_base = preg_replace('#/catalog$#i', '', $catalog_base);
        $data['catalog_url'] = $catalog_base;
        $data['image_base_url'] = $catalog_base . '/image/';
        $data['template_id'] = isset($this->request->get['template_id']) ? (int)$this->request->get['template_id'] : 0;
        $data['component_id'] = isset($this->request->get['component_id']) ? (int)$this->request->get['component_id'] : 0;
        $data['widget_catalog'] = array(
            array('id'=>'heading','name'=>'Heading','category'=>'Basic'), array('id'=>'text','name'=>'Text Editor','category'=>'Basic'), array('id'=>'button','name'=>'Button','category'=>'Basic'),
            array('id'=>'image','name'=>'Image','category'=>'Media'), array('id'=>'icon','name'=>'Icon','category'=>'Basic'), array('id'=>'icon_box','name'=>'Icon Box','category'=>'Basic'), array('id'=>'spacer','name'=>'Spacer','category'=>'Layout'), array('id'=>'divider','name'=>'Divider','category'=>'Layout'),
            array('id'=>'video','name'=>'Video','category'=>'Media'), array('id'=>'gallery','name'=>'Gallery','category'=>'Media'), array('id'=>'image_carousel','name'=>'Image Carousel','category'=>'Media'),
            array('id'=>'product','name'=>'Product','category'=>'OpenCart'), array('id'=>'product_grid','name'=>'Product Grid','category'=>'OpenCart'), array('id'=>'product_list','name'=>'Product List','category'=>'OpenCart'), array('id'=>'product_carousel','name'=>'Product Carousel','category'=>'OpenCart'),
            array('id'=>'featured_products','name'=>'Featured Products','category'=>'OpenCart'), array('id'=>'latest_products','name'=>'Latest Products','category'=>'OpenCart'), array('id'=>'special_products','name'=>'Special Products','category'=>'OpenCart'), array('id'=>'bestseller_products','name'=>'Bestsellers','category'=>'OpenCart'),
            array('id'=>'product_categories','name'=>'Product Categories','category'=>'OpenCart'), array('id'=>'category_grid','name'=>'Category Grid','category'=>'OpenCart'), array('id'=>'manufacturer','name'=>'Manufacturer / Brand','category'=>'OpenCart'), array('id'=>'search','name'=>'Search','category'=>'OpenCart'),
            array('id'=>'product_filter','name'=>'Product Filter','category'=>'OpenCart'), array('id'=>'pagination','name'=>'Pagination','category'=>'OpenCart'),
            array('id'=>'hero','name'=>'Hero Banner','category'=>'Marketing'), array('id'=>'hero_slider','name'=>'Hero Slider','category'=>'Marketing'), array('id'=>'fashion_categories','name'=>'Fashion Collections','category'=>'Modern Fashion'), array('id'=>'fashion_lookbook','name'=>'Fashion Lookbook','category'=>'Modern Fashion'), array('id'=>'fashion_promo','name'=>'Fashion Promo','category'=>'Modern Fashion'), array('id'=>'fashion_marquee','name'=>'Fashion Marquee','category'=>'Modern Fashion'), array('id'=>'fashion_products','name'=>'Fashion Products','category'=>'Modern Fashion'), array('id'=>'fashion_sale','name'=>'Fashion Sale','category'=>'Modern Fashion'), array('id'=>'fashion_editorial','name'=>'Fashion Editorial','category'=>'Modern Fashion'), array('id'=>'fashion_inspiration','name'=>'Fashion Inspiration','category'=>'Modern Fashion'), array('id'=>'fashion_testimonials','name'=>'Fashion Testimonials','category'=>'Modern Fashion'), array('id'=>'fashion_blog','name'=>'Fashion Blog','category'=>'Modern Fashion'), array('id'=>'fashion_newsletter','name'=>'Fashion Newsletter','category'=>'Modern Fashion'), array('id'=>'announcement','name'=>'Announcement Bar','category'=>'Global'), array('id'=>'newsletter','name'=>'Newsletter','category'=>'Global'), array('id'=>'trust_badges','name'=>'Trust Badges','category'=>'Global'), array('id'=>'social_links','name'=>'Social Links','category'=>'Global'), array('id'=>'footer','name'=>'Footer','category'=>'Global'),
            array('id'=>'menu','name'=>'Navigation / Mega Menu','category'=>'Header'), array('id'=>'logo','name'=>'Logo','category'=>'Header'), array('id'=>'account','name'=>'Account','category'=>'Header'), array('id'=>'cart','name'=>'Cart','category'=>'Header')
        );

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        $this->response->setOutput($this->load->view('extension/theme/nextgen/builder', $data));
    }

    private function createFrontEditorToken() {
        $secret = (string)$this->config->get('config_encryption');
        if ($secret === '') $secret = (string)$this->config->get('config_name');
        $payload = array('uid'=>(int)$this->user->getId(),'exp'=>time()+3600,'scope'=>'nextgen_front_editor');
        $raw = base64_encode(json_encode($payload));
        $b64 = rtrim(strtr($raw, '+/', '-_'), '=');
        $sig = hash_hmac('sha256', $b64, $secret);
        return $b64.'.'.$sig;
    }

    public function categories() {
        if (!$this->assertAccess()) return;
        $language_id=(int)$this->config->get('config_language_id');
        $store_id=(int)$this->config->get('config_store_id');
        $rows=$this->db->query("SELECT c.category_id, c.image, cd.name FROM `".DB_PREFIX."category` c INNER JOIN `".DB_PREFIX."category_description` cd ON (c.category_id=cd.category_id AND cd.language_id='".$language_id."') INNER JOIN `".DB_PREFIX."category_to_store` c2s ON (c.category_id=c2s.category_id AND c2s.store_id='".$store_id."') WHERE c.status='1' ORDER BY c.sort_order ASC, cd.name ASC")->rows;
        $items=array();
        $catalog=defined('HTTP_CATALOG') ? (string)HTTP_CATALOG : (string)$this->config->get('config_url');
        if ($catalog === '' && defined('HTTPS_CATALOG')) { $catalog=HTTPS_CATALOG; }
        if ($catalog === '' && defined('HTTPS_SERVER')) { $catalog=HTTPS_SERVER; }
        $catalog=rtrim($catalog,'/');
        $catalog=preg_replace('#/catalog$#i','',$catalog);
        foreach($rows as $row){
            $id=(int)$row['category_id'];
            $image=(string)($row['image'] ?? '');
            $image_url=$image!=='' ? rtrim($catalog,'/').'/image/'.ltrim($image,'/') : '';
            $items[]=array('category_id'=>$id,'name'=>(string)$row['name'],'image'=>$image,'image_url'=>$image_url,'url'=>rtrim($catalog,'/').'/index.php?route=product/category&path='.$id);
        }
        $this->json(array('success'=>true,'categories'=>$items));
    }

    public function product_search() {
        if (!$this->assertAccess()) return;
        $q = trim((string)($this->request->get['q'] ?? ''));
        $limit = max(1, min(20, (int)($this->request->get['limit'] ?? 15)));
        $this->load->model('catalog/product');
        $this->load->model('tool/image');
        $rows = array();
        if ($q !== '') {
            $esc = $this->db->escape($q);
            $rows = $this->db->query("SELECT p.product_id, p.model, p.ean, pd.name, p.image FROM `".DB_PREFIX."product` p INNER JOIN `".DB_PREFIX."product_description` pd ON (p.product_id=pd.product_id AND pd.language_id='".(int)$this->config->get('config_language_id')."') WHERE p.status='1' AND (pd.name LIKE '%".$esc."%' OR p.model LIKE '%".$esc."%' OR p.ean LIKE '%".$esc."%') ORDER BY pd.name ASC LIMIT ".$limit)->rows;
        }
        $this->json(array('success'=>true,'products'=>$rows));
    }

    public function category_search() {
        if (!$this->assertAccess()) return;
        $q = trim((string)($this->request->get['q'] ?? ''));
        $limit = max(1, min(20, (int)($this->request->get['limit'] ?? 15)));
        $language=(int)$this->config->get('config_language_id'); $store=(int)$this->config->get('config_store_id');
        $rows=array();
        if ($q !== '') {
            $esc=$this->db->escape($q);
            $rows=$this->db->query("SELECT c.category_id, cd.name FROM `".DB_PREFIX."category` c INNER JOIN `".DB_PREFIX."category_description` cd ON (c.category_id=cd.category_id AND cd.language_id='".$language."') INNER JOIN `".DB_PREFIX."category_to_store` c2s ON (c.category_id=c2s.category_id AND c2s.store_id='".$store."') WHERE c.status='1' AND (cd.name LIKE '%".$esc."%' OR c.category_id='".(int)$q."') ORDER BY cd.name ASC LIMIT ".$limit)->rows;
        }
        $this->json(array('success'=>true,'categories'=>$rows));
    }

    public function load() {
        if (!$this->assertAccess()) return;
        $document_id = isset($this->request->get['document_id']) ? (int)$this->request->get['document_id'] : 0;
        $this->load->model('extension/theme/nextgen/builder');
        $document = $this->model_extension_theme_nextgen_builder->getDocument($document_id);
        if (!$document) {
            $this->json(array('success' => false, 'error' => 'Document not found.'));
            return;
        }
        $this->json(array('success' => true, 'document' => $document));
    }

    public function load_template() {
        if (!$this->assertAccess()) return;
        $id=(int)($this->request->get['template_id'] ?? 0);
        $this->load->model('extension/theme/nextgen/template_library');
        $template=$this->model_extension_theme_nextgen_template_library->getById($id);
        if (!$template) { $this->json(array('success'=>false,'error'=>'Template not found.')); return; }
        $this->json(array('success'=>true,'template'=>$template));
    }

    public function save_template() {
        if (!$this->assertModify()) return;
        $payload=$this->payload(); $id=(int)($payload['template_id'] ?? 0);
        $this->load->model('extension/theme/nextgen/template_library');
        $result=$this->model_extension_theme_nextgen_template_library->saveById($id, isset($payload['document'])?$payload['document']:array(), (int)$this->user->getId(), 'Saved from visual Builder');
        $this->json($result);
    }

    public function load_component() {
        if (!$this->assertAccess()) return;
        $id=(int)($this->request->get['component_id'] ?? 0);
        $this->load->model('extension/theme/nextgen/global_component');
        $component=$this->model_extension_theme_nextgen_global_component->getById($id);
        if(!$component){$this->json(array('success'=>false,'error'=>'Global component not found.'));return;}
        $this->json(array('success'=>true,'component'=>$component));
    }

    public function save_component() {
        if (!$this->assertModify()) return;
        $payload=$this->payload(); $id=(int)($payload['component_id'] ?? 0);
        $this->load->model('extension/theme/nextgen/global_component');
        $this->json($this->model_extension_theme_nextgen_global_component->saveById($id,isset($payload['document'])?$payload['document']:array(),(int)$this->user->getId()));
    }

    public function documents() {
        if (!$this->assertAccess()) return;
        $this->load->model('extension/theme/nextgen/builder');
        $this->json(array('success' => true, 'documents' => $this->model_extension_theme_nextgen_builder->listDocuments()));
    }

    public function create() {
        if (!$this->assertModify()) return;
        $payload = $this->payload();
        $name = !empty($payload['name']) ? trim($payload['name']) : 'Untitled Page';
        $route = isset($payload['route']) ? trim($payload['route']) : '';
        $template_type = isset($payload['template_type']) ? trim($payload['template_type']) : 'page';
        $this->load->model('extension/theme/nextgen/builder');
        $result = $this->model_extension_theme_nextgen_builder->createDocument($name, $route, 0, $template_type);
        $this->json($result);
    }

    public function save() {
        if (!$this->assertModify()) return;
        $payload = $this->payload();
        $this->load->model('extension/theme/nextgen/builder');
        $result = $this->model_extension_theme_nextgen_builder->saveDocument($payload);
        $this->json($result);
    }

    public function delete() {
        if (!$this->assertModify()) return;
        $document_id = isset($this->request->post['document_id']) ? (int)$this->request->post['document_id'] : 0;
        $this->load->model('extension/theme/nextgen/builder');
        $this->json($this->model_extension_theme_nextgen_builder->deleteDocument($document_id));
    }

    private function assertAccess() {
        if (!$this->user->hasPermission('access', 'extension/theme/nextgen/builder')) {
            $this->json(array('success' => false, 'error' => 'Permission denied.'), 403);
            return false;
        }
        return true;
    }

    private function assertModify() {
        if (!$this->assertAccess()) return false;
        if (!$this->user->hasPermission('modify', 'extension/theme/nextgen/builder')) {
            $this->json(array('success' => false, 'error' => 'Modify permission denied.'), 403);
            return false;
        }
        return true;
    }

    private function payload() {
        $raw = file_get_contents('php://input');
        if ($raw) {
            $decoded = json_decode($raw, true);
            if (is_array($decoded)) return $decoded;
        }
        return $this->request->post;
    }

    private function token() {
        if (isset($this->session->data['user_token'])) return 'user_token=' . $this->session->data['user_token'];
        return 'token=' . (isset($this->session->data['token']) ? $this->session->data['token'] : '');
    }

    private function json($data, $status = 200) {
        $this->response->addHeader('Content-Type: application/json; charset=utf-8');
        if (method_exists($this->response, 'addHeader')) $this->response->addHeader('X-Content-Type-Options: nosniff');
        $this->response->setOutput(json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    }
}
