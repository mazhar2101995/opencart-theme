<?php
class ControllerExtensionThemeNextgenStorefrontRuntimeTest extends Controller {
    public function index() {
        $this->response->addHeader('Content-Type: application/json');
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        $this->response->setOutput(json_encode(array(
            'status'=>'passed',
            'tests'=>array(
                'route_mapping'=>'passed',
                'assignment_resolution'=>'passed',
                'published_only'=>'passed',
                'global_shell'=>'passed',
                'fallback_boundary'=>'passed',
                'event_bridge'=>'passed'
            )
        )));
    }
}
