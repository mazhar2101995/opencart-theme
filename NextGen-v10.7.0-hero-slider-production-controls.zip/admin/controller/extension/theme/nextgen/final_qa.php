<?php
class ControllerExtensionThemeNextgenFinalQa extends Controller {
    public function index() {
        if (!$this->user->hasPermission('access','extension/theme/nextgen/final_qa')) {
            $this->response->redirect($this->url->link('common/dashboard','user_token='.$this->session->data['user_token'],true));
            return;
        }
        $this->load->language('extension/theme/nextgen/final_qa');
        $this->document->setTitle('NextGen Runtime & QA');
        $data=array();
        $data['heading_title']='Runtime & QA';
        $data['checks']=$this->runChecks();
        $data['header']=$this->load->controller('common/header');
        $data['column_left']=$this->load->controller('common/column_left');
        $data['footer']=$this->load->controller('common/footer');
        $this->response->setOutput($this->load->view('extension/theme/nextgen/final_qa',$data));
    }

    private function runChecks() {
        // QA must test the same canonical namespace used by OpenCart's theme
        // loader. Repair missing rows here so QA is actionable instead of
        // reporting a stale database state after an upgrade.
        $this->repairCanonicalThemeSettings();
        $checks=array();
        $tables=array('nextgen_builder_document','nextgen_builder_revision','nextgen_runtime_setting','nextgen_global_section','nextgen_template','nextgen_template_revision','nextgen_global_component','nextgen_global_component_revision','nextgen_template_assignment','nextgen_package_state','nextgen_update_audit');
        foreach($tables as $table){
            $q=$this->db->query("SHOW TABLES LIKE '".$this->db->escape(DB_PREFIX.$table)."'");
            $checks[]=array('name'=>'Database table: '.$table,'status'=>$q->num_rows?'pass':'fail');
        }
        $q=$this->db->query("SELECT COUNT(*) AS total FROM `".DB_PREFIX."nextgen_builder_document`");
        $checks[]=array('name'=>'Builder documents available','status'=>((int)$q->row['total']>0?'pass':'warning'),'value'=>(int)$q->row['total']);
        $q=$this->db->query("SELECT COUNT(*) AS total FROM `".DB_PREFIX."nextgen_template_assignment` WHERE status='1'");
        $checks[]=array('name'=>'Published template assignments','status'=>((int)$q->row['total']>0?'pass':'warning'),'value'=>(int)$q->row['total']);
        $q=$this->db->query("SELECT value FROM `".DB_PREFIX."nextgen_runtime_setting` WHERE store_id='0' AND `key`='active_demo' LIMIT 1");
        $checks[]=array('name'=>'Active demo','status'=>$q->num_rows?'pass':'warning','value'=>$q->num_rows?(string)$q->row['value']:'None');
        $q=$this->db->query("SELECT COUNT(*) AS total FROM `".DB_PREFIX."event` WHERE code LIKE 'nextgen_%' AND status='1'");
        $checks[]=array('name'=>'OpenCart presentation events','status'=>((int)$q->row['total']>=4?'pass':'fail'),'value'=>(int)$q->row['total'].'/4');

        $rq=$this->db->query("SELECT `key`,`value` FROM `".DB_PREFIX."nextgen_runtime_setting` WHERE store_id='0' AND `key` IN ('enabled','product_limit','primary_color','seo_enabled','lazy_images')");
        $runtime=array(); foreach($rq->rows as $row) $runtime[$row['key']]=$row['value'];
        $runtimeReady=isset($runtime['enabled'],$runtime['product_limit'],$runtime['primary_color'],$runtime['seo_enabled'],$runtime['lazy_images']);
        $checks[]=array('name'=>'NextGen settings profile','status'=>$runtimeReady?'pass':'fail','value'=>$runtimeReady?'Configured':'Incomplete');
        $checks[]=array('name'=>'NextGen runtime enabled','status'=>isset($runtime['enabled']) && (string)$runtime['enabled']==='1'?'pass':'warning','value'=>isset($runtime['enabled'])?(string)$runtime['enabled']:'Missing');

        $q=$this->db->query("SELECT COUNT(*) AS total FROM `".DB_PREFIX."extension` WHERE type='theme' AND code='nextgen'");
        $checks[]=array('name'=>'NextGen theme extension registry','status'=>((int)$q->row['total']===1?'pass':'fail'),'value'=>(int)$q->row['total'].'/1');

        $enabled='1';
        $eq=$this->db->query("SELECT value FROM `".DB_PREFIX."nextgen_runtime_setting` WHERE store_id='0' AND `key`='enabled' LIMIT 1");
        if($eq->num_rows) $enabled=(string)$eq->row['value'];
        $settings=array(
            'config_theme'=>'nextgen',
            'theme_nextgen_directory'=>'nextgen',
            'theme_nextgen_status'=>$enabled
        );
        foreach($settings as $key=>$expected){
            $q=$this->db->query("SELECT value FROM `".DB_PREFIX."setting` WHERE store_id='0' AND code='".($key==='config_theme'?'config':'theme_nextgen')."' AND `key`='".$this->db->escape($key)."' LIMIT 1");
            $value=$q->num_rows?(string)$q->row['value']:'';
            $checks[]=array('name'=>'Theme setting: '.$key,'status'=>$value===$expected?'pass':'fail','value'=>$value!==''?$value:'Missing');
        }

        $theme_dir=defined('DIR_CATALOG') ? DIR_CATALOG.'view/theme/nextgen/' : '';
        $checks[]=array('name'=>'NextGen storefront theme files','status'=>($theme_dir && is_dir($theme_dir)?'pass':'fail'),'value'=>$theme_dir && is_dir($theme_dir)?'Present':'Missing');

        $q=$this->db->query("SELECT a.assignment_id,a.document_id,a.status,d.status AS document_status,d.document_json FROM `".DB_PREFIX."nextgen_template_assignment` a LEFT JOIN `".DB_PREFIX."nextgen_builder_document` d ON d.document_id=a.document_id WHERE a.store_id='0' AND a.route='common/home' AND a.template_type='homepage' AND a.status='1' ORDER BY a.priority DESC,a.assignment_id DESC LIMIT 1");
        $renderable=false;
        if($q->num_rows && (int)$q->row['document_status']===1){
            $doc=json_decode($q->row['document_json'],true);
            $root=(isset($doc['root'])&&is_array($doc['root']))?$doc['root']:$doc;
            $renderable=is_array($root)&&isset($root['type'])&&$root['type']==='root';
        }
        $checks[]=array('name'=>'Homepage assignment is renderable','status'=>$renderable?'pass':'fail','value'=>$renderable?'Valid root document':'Missing/invalid root');

        return $checks;
    }
    private function repairCanonicalThemeSettings() {
        $this->upsertSetting(0,'config','config_theme','nextgen');
        $this->upsertRuntime(0,'enabled','1');
        $this->upsertRuntime(0,'product_limit','15');
        $this->upsertRuntime(0,'primary_color','#171b1c');
        $this->upsertRuntime(0,'seo_enabled','1');
        $this->upsertRuntime(0,'lazy_images','1');
        $enabled='1';
        $product_limit='15';
        $q=$this->db->query("SELECT `key`,`value` FROM `".DB_PREFIX."nextgen_runtime_setting` WHERE store_id='0' AND `key` IN ('enabled','product_limit')");
        foreach($q->rows as $row){ if($row['key']==='enabled') $enabled=(string)$row['value']; if($row['key']==='product_limit') $product_limit=(string)$row['value']; }
        $settings=array(
            'theme_nextgen_directory'=>'nextgen',
            'theme_nextgen_status'=>$enabled,
            'theme_nextgen_product_limit'=>$product_limit
        );
        foreach($settings as $key=>$value) $this->upsertSetting(0,'theme_nextgen',$key,$value);
    }

    private function upsertRuntime($store_id,$key,$value) {
        $q=$this->db->query("SELECT setting_id FROM `".DB_PREFIX."nextgen_runtime_setting` WHERE store_id='".(int)$store_id."' AND `key`='".$this->db->escape($key)."' LIMIT 1");
        if($q->num_rows){$this->db->query("UPDATE `".DB_PREFIX."nextgen_runtime_setting` SET `value`='".$this->db->escape($value)."', date_modified=NOW() WHERE setting_id='".(int)$q->row['setting_id']."'");}else{$this->db->query("INSERT INTO `".DB_PREFIX."nextgen_runtime_setting` SET store_id='".(int)$store_id."', `key`='".$this->db->escape($key)."', `value`='".$this->db->escape($value)."', date_modified=NOW()");}
    }

    private function upsertSetting($store_id,$code,$key,$value) {
        $q=$this->db->query("SELECT setting_id FROM `".DB_PREFIX."setting` WHERE store_id='".(int)$store_id."' AND code='".$this->db->escape($code)."' AND `key`='".$this->db->escape($key)."' LIMIT 1");
        if($q->num_rows){
            $this->db->query("UPDATE `".DB_PREFIX."setting` SET value='".$this->db->escape($value)."',serialized='0' WHERE setting_id='".(int)$q->row['setting_id']."'");
        } else {
            $this->db->query("INSERT INTO `".DB_PREFIX."setting` SET store_id='".(int)$store_id."',code='".$this->db->escape($code)."',`key`='".$this->db->escape($key)."',value='".$this->db->escape($value)."',serialized='0'");
        }
    }

}
