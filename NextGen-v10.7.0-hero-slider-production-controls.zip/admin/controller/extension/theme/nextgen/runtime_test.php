<?php
class ControllerExtensionThemeNextgenRuntimeTest extends Controller {
    public function index() {
        if (!$this->user->hasPermission('access','extension/theme/nextgen/runtime_test')) {
            $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        $this->response->setOutput(json_encode(array('status'=>'error','message'=>'Permission denied')));
            return;
        }

        $context=array(
            'route'=>'common/home',
            'template_type'=>'homepage',
            'store_id'=>(int)$this->config->get('config_store_id'),
            'language_id'=>(int)$this->config->get('config_language_id'),
            'device'=>'desktop'
        );

        $this->response->setOutput(json_encode(array(
            'status'=>'ready',
            'test'=>'homepage',
            'context'=>$context,
            'message'=>'Connect the configured repository, assignment evaluator and production runtime, then execute the smoke test.'
        )));
    }
}
