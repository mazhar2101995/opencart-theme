<?php
require_once(DIR_SYSTEM . 'library/nextgen/admin_settings_page.php');
class ControllerExtensionThemeNextgenSeo extends Controller {
    public function index() {
        $route='extension/theme/nextgen/seo';
        if (!$this->user->hasPermission('access',$route)) { $this->response->setOutput('Permission denied'); return; }
        $this->load->model('extension/theme/nextgen/settings');
        $store_id=isset($this->request->get['store_id'])?(int)$this->request->get['store_id']:0;
        if ($this->request->server['REQUEST_METHOD']==='POST') {
            if (!$this->user->hasPermission('modify',$route)) { $this->session->data['error']='You do not have permission to modify this module settings.'; } else {
                $all=$this->model_extension_theme_nextgen_settings->getAll($store_id);
                $post=$this->request->post;
                $all['seo_enabled']=isset($post['seo_enabled'])?'1':'0';
                $all['canonical_enabled']=isset($post['canonical_enabled'])?'1':'0';
                $all['og_enabled']=isset($post['og_enabled'])?'1':'0';
                $all['schema_enabled']=isset($post['schema_enabled'])?'1':'0';
                $all['hreflang_enabled']=isset($post['hreflang_enabled'])?'1':'0';
                if (isset($post['robots_default']) && in_array($post['robots_default'],array('index,follow','noindex,follow','index,nofollow','noindex,nofollow'),true)) $all['robots_default']=$post['robots_default'];
                $this->model_extension_theme_nextgen_settings->save($all,$store_id);
                $this->session->data['success']='Settings saved successfully.';
            }
            $this->response->redirect($this->url->link($route,'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id,true));
            return;
        }
        $data=$this->model_extension_theme_nextgen_settings->getAll($store_id);
        $data['header']=$this->load->controller('common/header');
        $data['column_left']=$this->load->controller('common/column_left');
        $data['footer']=$this->load->controller('common/footer');
        $data['title']='SEO Engine'; $data['version']='2.1.0'; $data['description']='Canonical, robots, social metadata, schema and hreflang controls.';
        $data['action']=$this->url->link($route,'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id,true);
        $data['can_modify']=$this->user->hasPermission('modify',$route);
        $data['success']=isset($this->session->data['success'])?$this->session->data['success']:''; $data['error_warning']=isset($this->session->data['error'])?$this->session->data['error']:''; unset($this->session->data['success'],$this->session->data['error']);
        $data['settings_url']=$this->url->link('extension/theme/nextgen/settings','user_token=' . $this->session->data['user_token'],true);
        $data['builder_url']=$this->url->link('extension/theme/nextgen/builder','user_token=' . $this->session->data['user_token'],true);
        $data['qa_url']=$this->url->link('extension/theme/nextgen/final_qa','user_token=' . $this->session->data['user_token'],true);
        $data['font_options']=array('system'=>'System UI','Inter'=>'Inter','Poppins'=>'Poppins','Roboto'=>'Roboto','Open Sans'=>'Open Sans','custom'=>'Custom / theme stylesheet');
        $data['provider_options']=array('none'=>'No provider','openai'=>'OpenAI adapter','anthropic'=>'Anthropic adapter','custom'=>'Custom provider adapter');
        $this->response->setOutput($this->load->view('extension/theme/nextgen/seo', $data));
    }
}
