<?php
class ControllerExtensionThemeNextgenRuntime extends Controller {
    public function index() {
        if (!$this->user->hasPermission('access','extension/theme/nextgen/runtime')) {
            $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        $this->response->setOutput(json_encode(array('error'=>'Permission denied')));
            return;
        }

        $this->response->setOutput(json_encode(array(
            'status'=>'ok',
            'runtime'=>'NextGen Core Runtime',
            'pipeline'=>array(
                'context','template_assignment','document_validation','conditions',
                'dynamic_data','widget_resolution','widget_rendering',
                'asset_collection','seo','performance','finalize'
            )
        )));
    }
}
