<?php
class ControllerExtensionThemeNextgenGlobalComponent extends Controller {
    private function token() {
        if (isset($this->request->get['user_token']) && $this->request->get['user_token'] !== '') return 'user_token=' . $this->request->get['user_token'];
        if (isset($this->session->data['user_token']) && $this->session->data['user_token'] !== '') return 'user_token=' . $this->session->data['user_token'];
        return 'token=' . (isset($this->session->data['token']) ? $this->session->data['token'] : '');
    }

    public function edit() {
        $id=(int)($this->request->get['component_id'] ?? 0);
        if (!$this->user->hasPermission('modify','extension/theme/nextgen/global_component')) { $this->response->redirect($this->url->link('extension/theme/nextgen/global_component',$this->token(),true)); return; }
        // Component editor will use the same visual builder surface in the next component runtime pass.
        $this->response->redirect($this->url->link('extension/theme/nextgen/builder',$this->token().'&component_id='.$id,true));
    }

    public function index() {
        $this->load->language('extension/theme/nextgen/global_component');
        $this->load->model('extension/theme/nextgen/global_component');
        $this->model_extension_theme_nextgen_global_component->install();

        $data['components'] = $this->model_extension_theme_nextgen_global_component->getList();
        $data['edit_base'] = $this->url->link('extension/theme/nextgen/global_component/edit', $this->token(), true);
        $data['list_url'] = $this->url->link('extension/theme/nextgen/global_component', $this->token(), true);
        $data['can_modify'] = $this->user->hasPermission('modify','extension/theme/nextgen/global_component');
        $data['settings_url'] = $this->url->link('extension/theme/nextgen/settings', $this->token(), true);
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        $this->response->setOutput(
            $this->load->view('extension/theme/nextgen/global_component', $data)
        );
    }
}
