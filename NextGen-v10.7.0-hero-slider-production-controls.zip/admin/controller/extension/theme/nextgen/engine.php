<?php
class ControllerExtensionThemeNextgenEngine extends Controller {
    public function index() {
        if (!$this->user->hasPermission('access','extension/theme/nextgen')) {
            $this->response->redirect($this->url->link('common/dashboard',$this->token(),true));
            return;
        }
        $this->document->setTitle('NextGen Theme Engine');
        $data=array();
        $data['heading_title']='NextGen Theme Engine';
        $data['token']=$this->token();
        $data['theme_url']=$this->url->link('extension/theme/nextgen',$this->token(),true);
        $data['builder_url']=$this->url->link('extension/theme/nextgen/builder',$this->token(),true);
        $data['settings_url']=$this->url->link('extension/theme/nextgen/settings',$this->token(),true);
        $data['demos_url']=$this->url->link('extension/theme/nextgen/demos',$this->token(),true);
        $data['template_url']=$this->url->link('extension/theme/nextgen/template_library',$this->token(),true);
        $data['design_url']=$this->url->link('extension/theme/nextgen/design_system',$this->token(),true);
        $data['runtime_url']=$this->url->link('extension/theme/nextgen/final_qa',$this->token(),true);
        $data['status']=$this->getStatus();
        $data['header']=$this->load->controller('common/header');
        $data['column_left']=$this->load->controller('common/column_left');
        $data['footer']=$this->load->controller('common/footer');
        $this->response->setOutput($this->load->view('extension/theme/nextgen/engine',$data));
    }

    private function getStatus() {
        $tables=array('nextgen_builder_document','nextgen_builder_revision','nextgen_runtime_setting','nextgen_global_section','nextgen_template','nextgen_template_revision','nextgen_global_component','nextgen_global_component_revision','nextgen_template_assignment','nextgen_package_state','nextgen_update_audit');
        $result=array('database'=>true,'documents'=>0,'assignments'=>0,'active_demo'=>'');
        foreach($tables as $table) {
            $q=$this->db->query("SHOW TABLES LIKE '".$this->db->escape(DB_PREFIX.$table)."'");
            if (!$q->num_rows) $result['database']=false;
        }
        if ($result['database']) {
            $q=$this->db->query("SELECT COUNT(*) AS total FROM `".DB_PREFIX."nextgen_builder_document`");
            $result['documents']=(int)$q->row['total'];
            $q=$this->db->query("SELECT COUNT(*) AS total FROM `".DB_PREFIX."nextgen_template_assignment` WHERE status='1'");
            $result['assignments']=(int)$q->row['total'];
            $q=$this->db->query("SELECT value FROM `".DB_PREFIX."nextgen_runtime_setting` WHERE store_id='0' AND `key`='active_demo' LIMIT 1");
            if($q->num_rows) $result['active_demo']=$q->row['value'];
        }
        return $result;
    }

    private function token() {
        return 'user_token=' . (isset($this->session->data['user_token']) ? $this->session->data['user_token'] : '');
    }
}
