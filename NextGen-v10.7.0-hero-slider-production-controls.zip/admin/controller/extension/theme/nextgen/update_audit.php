<?php
class ControllerExtensionThemeNextgenUpdateAudit extends Controller {
    public function index() {
        if (!$this->user->hasPermission('access', 'extension/theme/nextgen/update_audit')) {
            $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        $this->response->setOutput(json_encode(array('error'=>'Permission denied')));
            return;
        }

        $this->response->setOutput(json_encode(array(
            'status'=>'ok',
            'audit'=>'NextGen update audit',
            'actions'=>array('install','update','migration','rollback','cache_refresh')
        )));
    }
}
