<?php
require_once(DIR_SYSTEM . 'library/nextgen/admin_settings_page.php');
class ControllerExtensionThemeNextgenInteractions extends Controller {
    public function index() {
        $route='extension/theme/nextgen/interactions';
        if (!$this->user->hasPermission('access',$route)) { $this->response->setOutput('Permission denied'); return; }
        $this->load->model('extension/theme/nextgen/settings');
        $store_id=isset($this->request->get['store_id'])?(int)$this->request->get['store_id']:0;
        if ($this->request->server['REQUEST_METHOD']==='POST') {
            if (!$this->user->hasPermission('modify',$route)) { $this->session->data['error']='You do not have permission to modify this module settings.'; } else {
                $all=$this->model_extension_theme_nextgen_settings->getAll($store_id);
                $post=$this->request->post;
                $all['sticky_header']=isset($post['sticky_header'])?'1':'0';
                $all['scroll_reveal']=isset($post['scroll_reveal'])?'1':'0';
                $all['parallax']=isset($post['parallax'])?'1':'0';
                $all['popup_enabled']=isset($post['popup_enabled'])?'1':'0';
                $all['reduced_motion']=isset($post['reduced_motion'])?'1':'0';
                $this->model_extension_theme_nextgen_settings->save($all,$store_id);
                $this->session->data['success']='Settings saved successfully.';
            }
            $this->response->redirect($this->url->link($route,'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id,true));
            return;
        }
        $data=$this->model_extension_theme_nextgen_settings->getAll($store_id);
        $data['header']=$this->load->controller('common/header');
        $data['column_left']=$this->load->controller('common/column_left');
        $data['footer']=$this->load->controller('common/footer');
        $data['title']='Interactions'; $data['version']='2.8.0'; $data['description']='Sticky, reveal, parallax, popup and motion defaults.';
        $data['action']=$this->url->link($route,'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id,true);
        $data['can_modify']=$this->user->hasPermission('modify',$route);
        $data['success']=isset($this->session->data['success'])?$this->session->data['success']:''; $data['error_warning']=isset($this->session->data['error'])?$this->session->data['error']:''; unset($this->session->data['success'],$this->session->data['error']);
        $data['settings_url']=$this->url->link('extension/theme/nextgen/settings','user_token=' . $this->session->data['user_token'],true);
        $data['builder_url']=$this->url->link('extension/theme/nextgen/builder','user_token=' . $this->session->data['user_token'],true);
        $data['qa_url']=$this->url->link('extension/theme/nextgen/final_qa','user_token=' . $this->session->data['user_token'],true);
        $data['font_options']=array('system'=>'System UI','Inter'=>'Inter','Poppins'=>'Poppins','Roboto'=>'Roboto','Open Sans'=>'Open Sans','custom'=>'Custom / theme stylesheet');
        $data['provider_options']=array('none'=>'No provider','openai'=>'OpenAI adapter','anthropic'=>'Anthropic adapter','custom'=>'Custom provider adapter');
        $this->response->setOutput($this->load->view('extension/theme/nextgen/interactions', $data));
    }
}
