<?php
require_once(DIR_SYSTEM . 'library/nextgen/admin_settings_page.php');
class ControllerExtensionThemeNextgenDesignSystem extends Controller {
    public function index() {
        $route='extension/theme/nextgen/design_system';
        if (!$this->user->hasPermission('access',$route)) { $this->response->setOutput('Permission denied'); return; }
        $this->load->model('extension/theme/nextgen/settings');
        $store_id=isset($this->request->get['store_id'])?(int)$this->request->get['store_id']:0;
        if ($this->request->server['REQUEST_METHOD']==='POST') {
            if (!$this->user->hasPermission('modify',$route)) { $this->session->data['error']='You do not have permission to modify this module settings.'; } else {
                $all=$this->model_extension_theme_nextgen_settings->getAll($store_id);
                if (isset($all['typography']) && is_string($all['typography'])) { $decoded=json_decode($all['typography'],true); if(is_array($decoded)) $all['typography']=$decoded; }
                $post=$this->request->post;
                $all['container_width']=max(760,min(1920,(int)(isset($post['container_width'])?$post['container_width']:$all['container_width'])));
                $all['radius']=max(0,min(48,(int)(isset($post['radius'])?$post['radius']:$all['radius'])));
                $all['spacing']=max(0,min(96,(int)(isset($post['spacing'])?$post['spacing']:$all['spacing'])));
                if (isset($post['font_family']) && in_array($post['font_family'],array('system','Inter','Poppins','Roboto','Open Sans','custom'),true)) $all['font_family']=$post['font_family'];
                if (isset($post['primary_color']) && preg_match('/^#[0-9a-fA-F]{6}$/',$post['primary_color'])) $all['primary_color']=$post['primary_color'];
                if (isset($post['accent_color']) && preg_match('/^#[0-9a-fA-F]{6}$/',$post['accent_color'])) $all['accent_color']=$post['accent_color'];
                if (isset($post['surface_color']) && preg_match('/^#[0-9a-fA-F]{6}$/',$post['surface_color'])) $all['surface_color']=$post['surface_color'];
                if (isset($post['background_color']) && preg_match('/^#[0-9a-fA-F]{6}$/',$post['background_color'])) $all['background_color']=$post['background_color'];
                if (isset($post['text_color']) && preg_match('/^#[0-9a-fA-F]{6}$/',$post['text_color'])) $all['text_color']=$post['text_color'];
                foreach (array('brand_name','brand_logo','favicon','support_url','docs_url') as $text_key) { if (isset($post[$text_key])) $all[$text_key]=trim($post[$text_key]); }
                if (isset($post['typography']) && is_array($post['typography'])) {
                    $all['typography']=$this->sanitizeTypography($post['typography'], isset($all['typography']) && is_array($all['typography']) ? $all['typography'] : array());
                }
                if (isset($post['custom_font_family'])) $all['custom_font_family']=preg_replace('/[^a-zA-Z0-9 _-]/','',trim((string)$post['custom_font_family']));
                if (isset($post['custom_font_weight']) && preg_match('/^(100|200|300|400|500|600|700|800|900)$/',(string)$post['custom_font_weight'])) $all['custom_font_weight']=(string)$post['custom_font_weight'];
                if (isset($this->request->files['custom_font']) && !empty($this->request->files['custom_font']['name'])) { $uploaded=$this->storeCustomFont($this->request->files['custom_font']); if($uploaded) $all['custom_font_file']=$uploaded; else $this->session->data['error']='Custom font upload failed. Allowed formats: woff2, woff, ttf, otf.'; }
                $this->model_extension_theme_nextgen_settings->save($all,$store_id);
                $this->session->data['success']='Settings saved successfully.';
            }
            $this->response->redirect($this->url->link($route,'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id,true));
            return;
        }
        $data=$this->model_extension_theme_nextgen_settings->getAll($store_id);
        if (isset($data['typography']) && is_string($data['typography'])) { $decoded=json_decode($data['typography'],true); if (is_array($decoded)) $data['typography']=$decoded; }
        if (!isset($data['typography']) || !is_array($data['typography'])) $data['typography']=$this->model_extension_theme_nextgen_settings->defaults()['typography'];
        $data['header']=$this->load->controller('common/header');
        $data['column_left']=$this->load->controller('common/column_left');
        $data['footer']=$this->load->controller('common/footer');
        $data['title']='Design System'; $data['version']='7.5.0'; $data['description']='Global visual tokens used by the builder and storefront.';
        $data['action']=$this->url->link($route,'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id,true);
        $data['can_modify']=$this->user->hasPermission('modify',$route);
        $data['success']=isset($this->session->data['success'])?$this->session->data['success']:''; $data['error_warning']=isset($this->session->data['error'])?$this->session->data['error']:''; unset($this->session->data['success'],$this->session->data['error']);
        $data['settings_url']=$this->url->link('extension/theme/nextgen/settings','user_token=' . $this->session->data['user_token'],true);
        $data['builder_url']=$this->url->link('extension/theme/nextgen/builder','user_token=' . $this->session->data['user_token'],true);
        $data['qa_url']=$this->url->link('extension/theme/nextgen/final_qa','user_token=' . $this->session->data['user_token'],true);
        $data['filemanager_url']=$this->url->link('common/filemanager','user_token=' . $this->session->data['user_token']);
        $catalog=defined('HTTP_CATALOG') ? HTTP_CATALOG : (string)$this->config->get('config_url');
        $data['image_base']=rtrim($catalog,'/') . '/image/';
        $data['font_options']=array('system'=>'System UI','Inter'=>'Inter','Poppins'=>'Poppins','Roboto'=>'Roboto','Open Sans'=>'Open Sans','custom'=>'Custom / theme stylesheet');
        $data['provider_options']=array('none'=>'No provider','openai'=>'OpenAI adapter','anthropic'=>'Anthropic adapter','custom'=>'Custom provider adapter');
        $this->response->setOutput($this->load->view('extension/theme/nextgen/design_system', $data));
    }
    private function storeCustomFont($file) {
        $allowed=array('woff2','woff','ttf','otf');
        $name=isset($file['name'])?(string)$file['name']:''; $ext=strtolower(pathinfo($name,PATHINFO_EXTENSION));
        if(!in_array($ext,$allowed,true) || !isset($file['tmp_name']) || !is_uploaded_file($file['tmp_name']) || (isset($file['size']) && (int)$file['size']>5242880)) return '';
        $safe=preg_replace('/[^a-zA-Z0-9_-]/','-',pathinfo($name,PATHINFO_FILENAME)); $safe=trim($safe,'-'); if($safe==='')$safe='nextgen-font';
        $dir=DIR_IMAGE.'catalog/nextgen/fonts/'; if(!is_dir($dir))@mkdir($dir,0755,true); if(!is_dir($dir))return '';
        $filename=$safe.'-'.substr(sha1_file($file['tmp_name']),0,10).'.'.$ext; $dest=$dir.$filename;
        if(!move_uploaded_file($file['tmp_name'],$dest))return '';
        return 'catalog/nextgen/fonts/'.$filename;
    }

    private function sanitizeTypography($posted, $current) {
        $roles=array('body','h1','h2','h3','h4','h5','h6','link','button','form');
        $fields=array('family','size','size_tablet','size_mobile','weight','transform','style','decoration','line_height','letter_spacing','word_spacing','color','hover_color','hover_decoration','text_shadow');
        $out=is_array($current)?$current:array();
        foreach($roles as $role){
            if(!isset($out[$role]) || !is_array($out[$role])) $out[$role]=array();
            if(!isset($posted[$role]) || !is_array($posted[$role])) continue;
            foreach($fields as $field){
                if(!array_key_exists($field,$posted[$role])) continue;
                $value=trim((string)$posted[$role][$field]);
                if(in_array($field,array('color','hover_color'),true)) {
                    if ($value!=='' && !preg_match('/^(#[0-9a-fA-F]{3,8}|rgba?\([^)]*\)|transparent|inherit|currentColor)$/',$value)) continue;
                }
                if($field==='weight' && !in_array($value,array('100','200','300','400','500','600','700','800','900','inherit','normal'),true)) continue;
                if($field==='transform' && !in_array($value,array('none','capitalize','uppercase','lowercase','inherit'),true)) continue;
                if($field==='style' && !in_array($value,array('normal','italic','oblique','inherit'),true)) continue;
                if($field==='decoration' && !in_array($value,array('none','underline','overline','line-through','inherit'),true)) continue;
                if($field==='hover_decoration' && !in_array($value,array('none','underline','overline','line-through','inherit'),true)) continue;
                $out[$role][$field]=$value;
            }
        }
        return $out;
    }

}
