<?php
require_once(DIR_SYSTEM . 'library/nextgen/admin_settings_page.php');
class ControllerExtensionThemeNextgenPerformance extends Controller {
    public function index() {
        $route='extension/theme/nextgen/performance';
        if (!$this->user->hasPermission('access',$route)) { $this->response->setOutput('Permission denied'); return; }
        $this->load->model('extension/theme/nextgen/settings');
        $store_id=isset($this->request->get['store_id'])?(int)$this->request->get['store_id']:0;
        if ($this->request->server['REQUEST_METHOD']==='POST') {
            if (!$this->user->hasPermission('modify',$route)) { $this->session->data['error']='You do not have permission to modify this module settings.'; } else {
                $all=$this->model_extension_theme_nextgen_settings->getAll($store_id);
                $post=$this->request->post;
                $all['lazy_images']=isset($post['lazy_images'])?'1':'0';
                $all['defer_js']=isset($post['defer_js'])?'1':'0';
                $all['critical_css']=isset($post['critical_css'])?'1':'0';
                $all['html_minify']=isset($post['html_minify'])?'1':'0';
                $all['public_cache']=isset($post['public_cache'])?'1':'0';
                $all['cache_ttl']=max(60,min(86400,(int)(isset($post['cache_ttl'])?$post['cache_ttl']:$all['cache_ttl'])));
                $this->model_extension_theme_nextgen_settings->save($all,$store_id);
                $this->session->data['success']='Settings saved successfully.';
            }
            $this->response->redirect($this->url->link($route,'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id,true));
            return;
        }
        $data=$this->model_extension_theme_nextgen_settings->getAll($store_id);
        $data['header']=$this->load->controller('common/header');
        $data['column_left']=$this->load->controller('common/column_left');
        $data['footer']=$this->load->controller('common/footer');
        $data['title']='Performance Engine'; $data['version']='2.2.0'; $data['description']='Image loading, assets, JavaScript and public cache controls.';
        $data['action']=$this->url->link($route,'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id,true);
        $data['can_modify']=$this->user->hasPermission('modify',$route);
        $data['success']=isset($this->session->data['success'])?$this->session->data['success']:''; $data['error_warning']=isset($this->session->data['error'])?$this->session->data['error']:''; unset($this->session->data['success'],$this->session->data['error']);
        $data['settings_url']=$this->url->link('extension/theme/nextgen/settings','user_token=' . $this->session->data['user_token'],true);
        $data['builder_url']=$this->url->link('extension/theme/nextgen/builder','user_token=' . $this->session->data['user_token'],true);
        $data['qa_url']=$this->url->link('extension/theme/nextgen/final_qa','user_token=' . $this->session->data['user_token'],true);
        $data['font_options']=array('system'=>'System UI','Inter'=>'Inter','Poppins'=>'Poppins','Roboto'=>'Roboto','Open Sans'=>'Open Sans','custom'=>'Custom / theme stylesheet');
        $data['provider_options']=array('none'=>'No provider','openai'=>'OpenAI adapter','anthropic'=>'Anthropic adapter','custom'=>'Custom provider adapter');
        $this->response->setOutput($this->load->view('extension/theme/nextgen/performance', $data));
    }
}
