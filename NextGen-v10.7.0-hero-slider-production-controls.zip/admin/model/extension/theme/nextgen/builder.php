<?php
class ModelExtensionThemeNextgenBuilder extends Model {
    public function getDocument($document_id) {
        $query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "nextgen_builder_document` WHERE document_id = '" . (int)$document_id . "' LIMIT 1");
        if (!$query->num_rows) return null;
        $row = $query->row;
        $row['document'] = json_decode($row['document_json'], true);
        if (is_array($row['document'])) {
            $normalized = $this->normalizeDocument($row['document']);
            $encoded_old = json_encode($row['document'], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
            $encoded_new = json_encode($normalized, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
            if ($encoded_old !== $encoded_new) {
                $this->db->query("UPDATE `" . DB_PREFIX . "nextgen_builder_document` SET document_json='" . $this->db->escape($encoded_new) . "', date_modified='" . date('Y-m-d H:i:s') . "' WHERE document_id='" . (int)$document_id . "'");
                $row['document'] = $normalized;
            }
        }
        return $row;
    }

    public function listDocuments($limit = 100) {
        $query = $this->db->query("SELECT document_id, name, route, template_type, status, version, date_modified FROM `" . DB_PREFIX . "nextgen_builder_document` ORDER BY date_modified DESC LIMIT 0," . (int)$limit);
        return $query->rows;
    }

    public function createDocument($name, $route = '', $store_id = 0, $template_type = 'page') {
        // Elementor-style structure: Section -> Container -> Widgets.
        // Columns are grid tracks, not document nodes.
        $document = array('type' => 'root', 'version' => 1, 'children' => array(array(
            'id' => $this->newNodeId('section'), 'type' => 'section', 'settings' => array(), 'children' => array(array(
                'id' => $this->newNodeId('container'), 'type' => 'container', 'settings' => array(), 'children' => array()
            ))
        )));
        return $this->saveDocument(array('name' => $name, 'route' => $route, 'store_id' => (int)$store_id, 'template_type' => $template_type ? $template_type : 'page', 'document' => $document));
    }

    public function saveDocument($data) {
        $document = isset($data['document']) && is_array($data['document']) ? $data['document'] : null;
        if ($document && isset($document['root']) && is_array($document['root'])) $document = $document['root'];
        if (!$document) return array('success' => false, 'error' => 'A valid document is required.');
        if (!isset($document['type']) || $document['type'] !== 'root') return array('success' => false, 'error' => 'Invalid document root.');
        $document = $this->normalizeDocument($document);

        $name = $this->db->escape(isset($data['name']) ? $data['name'] : 'Untitled Page');
        $store_id = isset($data['store_id']) ? (int)$data['store_id'] : 0;
        $route = $this->db->escape(isset($data['route']) ? $data['route'] : '');
        $template_type = $this->db->escape(isset($data['template_type']) ? $data['template_type'] : 'page');
        $status = isset($data['status']) ? (int)$data['status'] : 1;
        $json = $this->db->escape(json_encode($document, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
        $now = date('Y-m-d H:i:s');
        $document_id = isset($data['document_id']) ? (int)$data['document_id'] : 0;

        if ($document_id) {
            $exists = $this->db->query("SELECT * FROM `" . DB_PREFIX . "nextgen_builder_document` WHERE document_id='" . $document_id . "' LIMIT 1");
            if (!$exists->num_rows) return array('success' => false, 'error' => 'Document not found.');
            $old = $exists->row;
            $old_json = isset($old['document_json']) ? $old['document_json'] : '';
            $old_version = isset($old['version']) ? (int)$old['version'] : 0;
            $this->db->query("INSERT INTO `" . DB_PREFIX . "nextgen_builder_revision` SET document_id='" . $document_id . "', version='" . max(1,$old_version) . "', document_json='" . $this->db->escape($old_json) . "', created_by='" . (isset($this->session->data['user_id']) ? (int)$this->session->data['user_id'] : 0) . "', date_added='" . $now . "'");
            $this->db->query("UPDATE `" . DB_PREFIX . "nextgen_builder_document` SET `store_id`='" . $store_id . "', `name`='" . $name . "', `route`='" . $route . "', `template_type`='" . $template_type . "', `status`='" . $status . "', `version`=`version`+1, `document_json`='" . $json . "', `date_modified`='" . $now . "' WHERE document_id='" . $document_id . "'");
        } else {
            $this->db->query("INSERT INTO `" . DB_PREFIX . "nextgen_builder_document` SET `store_id`='" . $store_id . "', `name`='" . $name . "', `route`='" . $route . "', `template_type`='" . $template_type . "', `status`='" . $status . "', `version`='1', `document_json`='" . $json . "', `date_added`='" . $now . "', `date_modified`='" . $now . "'");
            $document_id = $this->db->getLastId();
        }

        // Saving a published builder document must also publish its route assignment.
        // Otherwise the Builder appears to save successfully but the storefront has
        // no presentation document to render.
        if ($status && $route !== '' && $template_type !== '') {
            // A demo can have language-specific assignments. The visual Builder
            // edits the canonical document, so publishing from Builder must also
            // repoint every active assignment for this route/store to that same
            // document. Otherwise the storefront can continue rendering the old
            // demo document for language_id > 0 while Builder appears to save.
            $this->db->query("UPDATE `" . DB_PREFIX . "nextgen_template_assignment` SET document_id='" . $document_id . "', priority='1000', status='1', source='builder', date_modified='" . $now . "' WHERE store_id='" . $store_id . "' AND route='" . $route . "' AND template_type='" . $template_type . "'");

            $check = $this->db->query("SELECT assignment_id FROM `" . DB_PREFIX . "nextgen_template_assignment` WHERE store_id='" . $store_id . "' AND language_id='0' AND route='" . $route . "' AND template_type='" . $template_type . "' LIMIT 1");
            if (!$check->num_rows) {
                $this->db->query("INSERT INTO `" . DB_PREFIX . "nextgen_template_assignment` SET store_id='" . $store_id . "', language_id='0', route='" . $route . "', template_type='" . $template_type . "', document_id='" . $document_id . "', priority='1000', status='1', source='builder', date_modified='" . $now . "'");
            }
        }
        return array('success' => true, 'document_id' => (int)$document_id, 'version' => $this->getVersion($document_id));
    }

    public function deleteDocument($document_id) {
        $document_id = (int)$document_id;
        if (!$document_id) return array('success' => false, 'error' => 'Invalid document.');
        $this->db->query("DELETE FROM `" . DB_PREFIX . "nextgen_template_assignment` WHERE document_id='" . $document_id . "'");
        $this->db->query("DELETE FROM `" . DB_PREFIX . "nextgen_builder_revision` WHERE document_id='" . $document_id . "'");
        $this->db->query("DELETE FROM `" . DB_PREFIX . "nextgen_builder_document` WHERE document_id='" . $document_id . "'");
        return array('success' => true);
    }


    private function normalizeDocument($document) {
        if (isset($document['root']) && is_array($document['root'])) $document = $document['root'];
        $used=array();
        $walk = function(&$node) use (&$walk,&$used) {
            if (!is_array($node)) return;
            $type = isset($node['type']) ? (string)$node['type'] : 'node';
            if (empty($node['id']) || isset($used[$node['id']])) {
                do { $node['id'] = $type . '_' . substr(md5(uniqid('', true)), 0, 10); } while(isset($used[$node['id']]));
            }
            $used[$node['id']]=true;
            if (!isset($node['settings']) || !is_array($node['settings'])) $node['settings'] = array();
            if (in_array($type, array('heading','text','button'), true) && !isset($node['settings']['text']) && isset($node['settings']['content'])) $node['settings']['text'] = $node['settings']['content'];
            if (!isset($node['children']) || !is_array($node['children'])) $node['children'] = array();
            foreach ($node['children'] as &$child) $walk($child);
            unset($child);
        };
        $walk($document);
        return $document;
    }

    private function getVersion($document_id) {
        $q = $this->db->query("SELECT version FROM `" . DB_PREFIX . "nextgen_builder_document` WHERE document_id='" . (int)$document_id . "' LIMIT 1");
        return $q->num_rows ? (int)$q->row['version'] : 0;
    }

    private function newNodeId($prefix) {
        return $prefix . '_' . substr(md5(uniqid('', true)), 0, 10);
    }
}
