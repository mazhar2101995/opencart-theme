<?php
class ModelExtensionThemeNextgenGlobalComponent extends Model {
    public function install() {
        require_once DIR_SYSTEM . 'library/nextgen/global_component_repository.php';
        $repository = new NextGenGlobalComponentRepository($this->db);
        $repository->install();
    }

    public function getById($id) { require_once DIR_SYSTEM . 'library/nextgen/global_component_repository.php'; return (new NextGenGlobalComponentRepository($this->db))->getById($id); }

    public function saveById($id,$document,$user_id=0) { require_once DIR_SYSTEM . 'library/nextgen/global_component_repository.php'; return (new NextGenGlobalComponentRepository($this->db))->saveById($id,$document,$user_id); }

    public function get($key) {
        require_once DIR_SYSTEM . 'library/nextgen/global_component_repository.php';
        $repository = new NextGenGlobalComponentRepository($this->db);
        return $repository->get($key);
    }

    public function getList() {
        require_once DIR_SYSTEM . 'library/nextgen/global_component_repository.php';
        $repository = new NextGenGlobalComponentRepository($this->db);
        return $repository->list();
    }

    public function save($key, $name, $type, $document_json, $user_id = 0) {
        require_once DIR_SYSTEM . 'library/nextgen/global_component_repository.php';
        $repository = new NextGenGlobalComponentRepository($this->db);
        return $repository->save($key, $name, $type, $document_json, $user_id);
    }
}
