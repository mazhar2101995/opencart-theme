<?php
class ModelExtensionThemeNextgenSettings extends Model {
    private $defaults = array(
        'enabled' => '1',
        'product_limit' => '15',
        'container_width' => '1200',
        'primary_color' => '#2563eb',
        'accent_color' => '#7c3aed',
        'surface_color' => '#ffffff',
        'background_color' => '#f6f8fb',
        'text_color' => '#172033',
        'radius' => '12',
        'spacing' => '24',
        'font_family' => 'system',
        'seo_enabled' => '1',
        'canonical_enabled' => '1',
        'robots_default' => 'index,follow',
        'og_enabled' => '1',
        'schema_enabled' => '1',
        'hreflang_enabled' => '1',
        'lazy_images' => '1',
        'defer_js' => '1',
        'critical_css' => '0',
        'html_minify' => '0',
        'public_cache' => '0',
        'cache_ttl' => '3600',
        'reduced_motion' => '1',
        'strict_accessibility' => '1',
        'touch_target_check' => '1',
        'sticky_header' => '1',
        'scroll_reveal' => '1',
        'parallax' => '0',
        'popup_enabled' => '1',
        'ai_enabled' => '0',
        'ai_review_required' => '1',
        'ai_provider' => 'none',
        'brand_name' => 'NextGen Store',
        'brand_logo' => '',
        'favicon' => '',
        'support_url' => '',
        'docs_url' => '',
        'custom_font_family' => '',
        'custom_font_file' => '',
        'custom_font_weight' => '400',
        'typography' => array(
            'body'=>array('family'=>'system-ui','size'=>'16px','size_tablet'=>'16px','size_mobile'=>'15px','weight'=>'400','transform'=>'none','style'=>'normal','decoration'=>'none','line_height'=>'1.5','letter_spacing'=>'0','word_spacing'=>'0','color'=>'#172033','text_shadow'=>'none'),
            'h1'=>array('family'=>'inherit','size'=>'48px','size_tablet'=>'42px','size_mobile'=>'34px','weight'=>'700','transform'=>'none','style'=>'normal','decoration'=>'none','line_height'=>'1.15','letter_spacing'=>'0','word_spacing'=>'0','color'=>'#111827','text_shadow'=>'none'),
            'h2'=>array('family'=>'inherit','size'=>'36px','size_tablet'=>'32px','size_mobile'=>'28px','weight'=>'700','transform'=>'none','style'=>'normal','decoration'=>'none','line_height'=>'1.2','letter_spacing'=>'0','word_spacing'=>'0','color'=>'#111827','text_shadow'=>'none'),
            'h3'=>array('family'=>'inherit','size'=>'28px','size_tablet'=>'25px','size_mobile'=>'22px','weight'=>'600','transform'=>'none','style'=>'normal','decoration'=>'none','line_height'=>'1.25','letter_spacing'=>'0','word_spacing'=>'0','color'=>'#111827','text_shadow'=>'none'),
            'h4'=>array('family'=>'inherit','size'=>'22px','size_tablet'=>'20px','size_mobile'=>'18px','weight'=>'600','transform'=>'none','style'=>'normal','decoration'=>'none','line_height'=>'1.3','letter_spacing'=>'0','word_spacing'=>'0','color'=>'#111827','text_shadow'=>'none'),
            'h5'=>array('family'=>'inherit','size'=>'18px','size_tablet'=>'17px','size_mobile'=>'16px','weight'=>'600','transform'=>'none','style'=>'normal','decoration'=>'none','line_height'=>'1.35','letter_spacing'=>'0','word_spacing'=>'0','color'=>'#111827','text_shadow'=>'none'),
            'h6'=>array('family'=>'inherit','size'=>'16px','size_tablet'=>'15px','size_mobile'=>'14px','weight'=>'600','transform'=>'none','style'=>'normal','decoration'=>'none','line_height'=>'1.4','letter_spacing'=>'0','word_spacing'=>'0','color'=>'#111827','text_shadow'=>'none'),
            'link'=>array('family'=>'inherit','size'=>'inherit','size_tablet'=>'inherit','size_mobile'=>'inherit','weight'=>'400','transform'=>'none','style'=>'normal','decoration'=>'none','line_height'=>'inherit','letter_spacing'=>'0','word_spacing'=>'0','color'=>'#2563eb','hover_color'=>'#1d4ed8','hover_decoration'=>'underline','text_shadow'=>'none'),
            'button'=>array('family'=>'inherit','size'=>'14px','size_tablet'=>'14px','size_mobile'=>'14px','weight'=>'600','transform'=>'none','style'=>'normal','decoration'=>'none','line_height'=>'1.2','letter_spacing'=>'0','word_spacing'=>'0','color'=>'#ffffff','hover_color'=>'#ffffff','text_shadow'=>'none'),
            'form'=>array('family'=>'inherit','size'=>'14px','size_tablet'=>'14px','size_mobile'=>'14px','weight'=>'400','transform'=>'none','style'=>'normal','decoration'=>'none','line_height'=>'1.4','letter_spacing'=>'0','word_spacing'=>'0','color'=>'#172033','text_shadow'=>'none')
        )
    );

    public function hasProfile($store_id = 0) {
        $query = $this->db->query("SELECT setting_id FROM `" . DB_PREFIX . "nextgen_runtime_setting` WHERE store_id='" . (int)$store_id . "' AND `key`='enabled' LIMIT 1");
        return (bool)$query->num_rows;
    }

    public function getAll($store_id = 0) {
        $settings = $this->defaults;
        $query = $this->db->query("SELECT `key`, `value` FROM `" . DB_PREFIX . "nextgen_runtime_setting` WHERE store_id='" . (int)$store_id . "'");
        foreach ($query->rows as $row) {
            $settings[$row['key']] = $row['value'];
        }
        return $settings;
    }

    public function get($key, $store_id = 0, $default = null) {
        $query = $this->db->query("SELECT `value` FROM `" . DB_PREFIX . "nextgen_runtime_setting` WHERE store_id='" . (int)$store_id . "' AND `key`='" . $this->db->escape($key) . "' LIMIT 1");
        if ($query->num_rows) return $query->row['value'];
        if (array_key_exists($key, $this->defaults)) return $this->defaults[$key];
        return $default;
    }

    public function save($values, $store_id = 0) {
        foreach ($this->defaults as $key => $default) {
            if (!array_key_exists($key, $values)) continue;
            $value = is_array($values[$key]) ? json_encode($values[$key]) : (string)$values[$key];
            $value = $this->db->escape($value);
            $query = $this->db->query("SELECT setting_id FROM `" . DB_PREFIX . "nextgen_runtime_setting` WHERE store_id='" . (int)$store_id . "' AND `key`='" . $this->db->escape($key) . "' LIMIT 1");
            if ($query->num_rows) {
                $this->db->query("UPDATE `" . DB_PREFIX . "nextgen_runtime_setting` SET `value`='" . $value . "', date_modified=NOW() WHERE setting_id='" . (int)$query->row['setting_id'] . "'");
            } else {
                $this->db->query("INSERT INTO `" . DB_PREFIX . "nextgen_runtime_setting` SET store_id='" . (int)$store_id . "', `key`='" . $this->db->escape($key) . "', `value`='" . $value . "', date_modified=NOW()");
            }
        }
    }

    public function reset($store_id = 0) {
        $this->db->query("DELETE FROM `" . DB_PREFIX . "nextgen_runtime_setting` WHERE store_id='" . (int)$store_id . "' AND `key` NOT IN ('active_demo')");
        $this->save($this->defaults, $store_id);
    }

    public function defaults() {
        return $this->defaults;
    }
}
