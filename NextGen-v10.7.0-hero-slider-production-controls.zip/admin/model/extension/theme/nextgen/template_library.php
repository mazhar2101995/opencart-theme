<?php
class ModelExtensionThemeNextgenTemplateLibrary extends Model {
    private function repository() {
        require_once DIR_SYSTEM . 'library/nextgen/template_library.php';
        return new NextGenTemplateLibrary($this->db);
    }

    public function install() {
        return $this->repository()->install();
    }

    public function getById($id) { return $this->repository()->getById($id); }

    public function saveById($id,$document,$user_id=0,$note='') { return $this->repository()->saveById($id,$document,$user_id,$note); }

    public function setStatus($id,$status) { return $this->repository()->setStatus($id,$status); }

    public function duplicate($id,$user_id=0) { return $this->repository()->duplicate($id,$user_id); }

    public function delete($id) { return $this->repository()->delete($id); }

    public function linkBuilderDocument($template_id,$document_id,$route='',$template_type='page',$store_id=0) { return $this->repository()->linkBuilderDocument($template_id,$document_id,$route,$template_type,$store_id); }

    public function get($key) {
        return $this->repository()->get($key);
    }

    public function getList($type = '', $category = '', $status = '') {
        return $this->repository()->list($type, $category, $status);
    }

    public function revisions($template_id) {
        return $this->repository()->revisions($template_id);
    }

    public function restore($template_id, $revision_id, $user_id = 0) {
        return $this->repository()->restore($template_id, $revision_id, $user_id);
    }
}
