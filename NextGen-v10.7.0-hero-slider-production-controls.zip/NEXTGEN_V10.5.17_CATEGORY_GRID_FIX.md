# NextGen v10.5.18 — Category Grid / Inspector Interaction Fix

## Base
This package preserves the complete NextGen v10.5.17 package structure. It is a full-package fix, not a two-file patch.

## Problems addressed

### 1. Category Grid inspector controls
Fixed/hardened:
- Category search field
- Category checkbox selection
- Grid/Slider display mode
- Columns
- Gap
- Show Category Name
- Name Position
- Button Display: On Hover / Always / Never
- Button Text
- Image Fit
- Image Height
- Autoplay
- Slide Interval
- Arrows
- Dots
- Loop

All dynamically-created inspector form controls now receive an `id` and `name`, which removes the anonymous-form-field browser Issues warning and improves keyboard/autofill behavior.

### 2. Slider frontend runtime
The Category Grid PHP renderer contained a malformed JavaScript initialization expression:
`var root=document.currentScript.previousElementSibling:null;`

This was corrected to safely obtain the previous sibling from `document.currentScript`.

Slider behavior remains:
- arrows
- dots
- autoplay
- interval
- loop
- pause on hover
- responsive column count

### 3. HTTP_CATALOG fatal error
Removed direct dependency on `HTTP_CATALOG` / `HTTPS_CATALOG` constants from the relevant runtime/controller URL building.

The runtime now uses OpenCart `config_url` with a safe `HTTPS_SERVER` fallback.

This prevents:
`Undefined constant "HTTP_CATALOG"`

### 4. Cache/version mismatch
Builder assets were bumped to v10.5.18 cache keys so the browser does not silently continue loading the previous inspector JavaScript/CSS.

## Important
The Chrome DevTools message:
`Content Security Policy of your site blocks the use of eval in JavaScript`
is not caused by an `eval()` call in the NextGen Builder source in this package. The package was checked for `eval()` / `new Function()` usage in the relevant builder source.

Likewise, the reported `200.js` / `M_ID` console error is not present in the supplied package source. It should be checked in the browser Network/Sources panel to identify the external/stale script producing it.

## Verification performed
- PHP syntax checked for modified runtime/controller files.
- JavaScript syntax checked for builder UI and inspector schema.
- Full ZIP contents retained; no unrelated package files were removed.
