# NextGen v10.5.16 — Category Grid

## Goal
Build the OpenCart Category Grid widget as a real storefront widget, matching the supplied fashion reference: category image cards, configurable category labels, optional buttons, and Elementor-style visual controls.

## Admin Builder
- Category Grid remains an OpenCart widget.
- Category selector loads active categories for the current OpenCart store.
- Selector shows category thumbnail + name and supports search.
- Selected categories are stored by category ID with cached preview metadata.
- Desktop/tablet/mobile column and spacing controls.
- Show/hide category name.
- Category name placement: Overlay or Below Image.
- Button display: On Hover, Always, Never.
- Button text.
- Image fit and image height.

## Styling
### Card
- Background
- Border color / width
- Radius
- Box shadow

### Category Name
- Text color
- Background color
- Padding
- Radius
- Font family
- Font size
- Weight
- Letter spacing
- Transform
- Text shadow

### Button
- Text color
- Background color
- Border color / width / style
- Radius
- Padding
- Font size / weight
- Hover text/background/border colors

### Overlay
- Overlay color
- Overlay opacity

## Frontend Runtime
- Category data is resolved from OpenCart category/category_description/category_to_store tables.
- Category name follows the active storefront language.
- Category image and category URL are generated at runtime.
- Selected category IDs are rendered in saved order.
- Hover/always/never button behavior is rendered server-side with CSS.
- Widget has responsive grid variables for tablet/mobile.

## Validation
- PHP syntax checked for modified PHP files.
- JavaScript syntax checked for Builder UI and inspector schema.

## Next
After Category Grid is visually verified, the next step should be Product Grid/card controls rather than adding another widget immediately. The same selection, responsive, typography, color, hover and spacing patterns should be reused so the builder stays consistent.
