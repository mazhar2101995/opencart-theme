# NextGen Theme v10.5.22 — Category Slider Window Fix

## Required behavior
When Slider mode is enabled and 4 columns are configured, the slider keeps four category cards visible and advances by exactly one category.

Example with 5 selected categories:

`1 2 3 4` → `2 3 4 5` → `3 4 5 1` → `4 5 1 2` → `5 1 2 3` → `1 2 3 4` → loop

## Fixes
- Slider cards use the configured column count instead of forcing one full-width card.
- Loop mode clones the first visible cards internally, preventing empty space at the end.
- Next/previous navigation loops continuously.
- Autoplay moves one category at a time.
- Dots represent each one-card position.
- Grid mode is untouched.

## Installation
Refresh OpenCart modifications and clear theme/system cache after replacing the package, then hard-refresh the storefront with `Ctrl + F5`.
