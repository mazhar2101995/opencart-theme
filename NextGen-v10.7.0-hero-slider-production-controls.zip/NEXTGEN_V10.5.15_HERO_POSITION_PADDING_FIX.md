# NextGen v10.5.15 — Hero Position & Padding Fix

## Purpose
Fix Hero `Content Position` so vertical positioning is real and independent from padding.

## Changes
- `Center Top`, `Center`, `Center Bottom` and all 9 horizontal/vertical combinations are supported.
- Blank Hero Content Padding now means `0`, not an implicit 70px/7vw padding.
- Hero content receives the Hero minimum height so `justify-content` can actually position content vertically.
- Tablet/mobile padding falls back to the base padding instead of injecting hidden defaults.
- Builder Hero defaults no longer seed `70px 7vw` padding for new/migrated Hero settings.

## Expected behaviour
`Center Top` + blank padding = content at the top center of the Hero.
Padding is then an explicit spacing control and no longer changes the meaning of the position selector.
