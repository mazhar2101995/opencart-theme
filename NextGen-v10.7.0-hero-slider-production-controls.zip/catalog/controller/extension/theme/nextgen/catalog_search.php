<?php
class ControllerExtensionThemeNextgenCatalogSearch extends Controller {
    public function schema() {
        $this->response->addHeader('Content-Type: application/json');
        $widgets = NextGenCatalogSearchSchema::widgets();
        foreach ($widgets as $id => &$widget) {
            $widget['controls'] = NextGenCatalogSearchSchema::controls($id);
        }
        $this->response->setOutput(json_encode(['widgets'=>$widgets], JSON_UNESCAPED_SLASHES));
    }
}
