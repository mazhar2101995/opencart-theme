<?php
class ControllerExtensionThemeNextgenRuntime extends Controller {
    public function index() {
        $this->response->setOutput(json_encode(array(
            'status'=>'ok',
            'service'=>'nextgen-runtime',
            'pipeline'=>array(
                'context','template_assignment','document_validation','conditions',
                'dynamic_data','widget_resolution','widget_rendering',
                'asset_collection','seo','performance','finalize'
            )
        )));
    }
}
