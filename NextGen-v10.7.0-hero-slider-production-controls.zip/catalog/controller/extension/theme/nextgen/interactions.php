<?php
class ControllerExtensionThemeNextgenInteractions extends Controller {
    public function index() {
        require_once(DIR_SYSTEM . 'library/nextgen/interaction_engine.php');
        require_once(DIR_SYSTEM . 'library/nextgen/overlay_manager.php');
        require_once(DIR_SYSTEM . 'library/nextgen/scroll_interactions.php');

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode(array(
            'version' => '2.8.0',
            'status' => 'ready',
            'interaction_types' => array(
                'popup','modal','drawer','offcanvas','lightbox',
                'sticky','scroll-reveal','parallax'
            )
        )));
    }
}
