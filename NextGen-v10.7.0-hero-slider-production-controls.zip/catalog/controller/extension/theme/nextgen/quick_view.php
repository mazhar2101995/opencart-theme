<?php
class ControllerExtensionThemeNextgenQuickView extends Controller {
    public function index() {
        $product_id=(int)($this->request->get['product_id']??0);
        $this->load->model('catalog/product');
        $this->load->model('tool/image');
        $product=$this->model_catalog_product->getProduct($product_id);
        if(!$product){$this->response->addHeader('HTTP/1.1 404 Not Found');$this->response->setOutput('<div class="ng-quick-view-error">Product not found.</div>');return;}
        $image=!empty($product['image'])?$this->model_tool_image->resize($product['image'],700,700):'';
        $currency=isset($this->session->data['currency'])?$this->session->data['currency']:$this->config->get('config_currency');
        $price=$this->currency->format($product['price'],$currency);
        $special=isset($product['special'])&&$product['special']!==null?$this->currency->format($product['special'],$currency):'';
        $name=htmlspecialchars((string)$product['name'],ENT_QUOTES,'UTF-8');
        $desc=strip_tags(html_entity_decode((string)($product['description']??''),ENT_QUOTES,'UTF-8'));
        $desc=htmlspecialchars(function_exists('mb_substr')?mb_substr($desc,0,450):substr($desc,0,450),ENT_QUOTES,'UTF-8');
        $html='<article class="ng-quick-view-product"><div class="ng-quick-view-product__media">'.($image?'<img src="'.htmlspecialchars($image,ENT_QUOTES,'UTF-8').'" alt="'.$name.'">':'').'</div><div class="ng-quick-view-product__body"><div class="ng-quick-view-product__eyebrow">Quick View</div><h2>'.$name.'</h2>';
        if(!empty($product['model']))$html.='<div class="ng-quick-view-product__model">'.htmlspecialchars((string)$product['model'],ENT_QUOTES,'UTF-8').'</div>';
        $html.='<div class="ng-quick-view-product__price">'.($special?'<span>'.$special.'</span><del>'.$price.'</del>':'<strong>'.$price.'</strong>').'</div>';
        if($desc!=='')$html.='<p>'.$desc.'</p>';
        $html.='<button type="button" class="ng-product-add-cart" data-action="add-to-cart" data-product-id="'.$product_id.'">Add to Cart</button><a class="ng-quick-view-product__link" href="'.$this->url->link('product/product','product_id='.$product_id).'">View Product</a></div></article>';
        $this->response->setOutput($html);
    }
}
