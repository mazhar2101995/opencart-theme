<?php
class ControllerExtensionThemeNextgenSeo extends Controller {
    public function index($context = array()) {
        if (!is_array($context)) $context = array();

        require_once(DIR_SYSTEM . 'library/nextgen/seo_engine.php');
        require_once(DIR_SYSTEM . 'library/nextgen/structured_data.php');
        require_once(DIR_SYSTEM . 'library/nextgen/canonical_manager.php');
        require_once(DIR_SYSTEM . 'library/nextgen/hreflang_manager.php');

        $engine = new NextGenSeoEngine($this->registry);
        $seo = $engine->build($context);

        if (!empty($context['hreflang']) && is_array($context['hreflang'])) {
            $seo['hreflang_html'] = NextGenHreflangManager::render($context['hreflang']);
        } else {
            $seo['hreflang_html'] = '';
        }

        if (!empty($seo['structured_data']) && is_array($seo['structured_data'])) {
            $seo['structured_data_html'] = NextGenStructuredData::scriptTags($seo['structured_data']);
        } else {
            $seo['structured_data_html'] = '';
        }

        return $seo;
    }
}
