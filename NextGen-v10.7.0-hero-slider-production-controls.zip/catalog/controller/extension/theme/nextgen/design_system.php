<?php
class ControllerExtensionThemeNextgenDesignSystem extends Controller {
    public function index() {
        require_once(DIR_SYSTEM . 'library/nextgen/global_style_engine.php');

        $defaults = NextGenGlobalStyleEngine::defaults();

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode(array(
            'version' => '2.6.0',
            'defaults' => $defaults,
            'status' => 'ready'
        )));
    }
}
