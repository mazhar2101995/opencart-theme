<?php
class ControllerExtensionThemeNextgenPackage extends Controller {
    public function index() {
        $this->response->setOutput(json_encode(array(
            'status'=>'ok',
            'service'=>'nextgen-package',
            'mode'=>'read-only'
        )));
    }
}
