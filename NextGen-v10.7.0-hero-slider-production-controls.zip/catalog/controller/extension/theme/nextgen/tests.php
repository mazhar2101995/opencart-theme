<?php
class ControllerExtensionThemeNextgenTests extends Controller {
    public function index() {
        require_once(DIR_SYSTEM . 'library/nextgen/theme_test_runner.php');

        $document = array(
            'type' => 'root',
            'children' => array()
        );

        $runner = new NextGenThemeTestRunner();
        $report = $runner->run($document);

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($report));
    }
}
