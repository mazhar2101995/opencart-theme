<?php
class ControllerExtensionThemeNextgenHeader extends Controller {
    public function schema() {
        $this->response->addHeader('Content-Type: application/json');
        $widgets = NextGenHeaderSchema::widgets();
        foreach ($widgets as $id => &$widget) {
            $widget['controls'] = NextGenHeaderSchema::controls($id);
        }
        $this->response->setOutput(json_encode(['widgets'=>$widgets], JSON_UNESCAPED_SLASHES));
    }
}
