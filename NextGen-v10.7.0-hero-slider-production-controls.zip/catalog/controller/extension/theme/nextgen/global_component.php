<?php
class ControllerExtensionThemeNextgenGlobalComponent extends Controller {
    public function render($key, array $context = []) {
        $this->load->model('extension/theme/nextgen/global_component');
        $component = $this->model_extension_theme_nextgen_global_component->get($key);

        if (!$component) {
            return '';
        }

        $data = array_merge($context, [
            'component' => $component,
            'document' => $component['document'],
            'version' => (int)$component['version']
        ]);

        return $this->load->view(
            'theme/nextgen/' . $component['document']['template'],
            $data
        );
    }
}
