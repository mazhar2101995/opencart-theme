<?php
class ControllerExtensionThemeNextgenFrontendRenderer extends Controller {
    public function render($document, array $context = [], array $registry = []) {
        require_once DIR_SYSTEM . 'library/nextgen/frontend_render_engine.php';
        require_once DIR_SYSTEM . 'library/nextgen/asset_dependency_collector.php';
        require_once DIR_SYSTEM . 'library/nextgen/html_optimizer.php';

        $engine = new NextGenFrontendRenderEngine($this->load, $registry);
        $assets = new NextGenAssetDependencyCollector();
        $optimizer = new NextGenHtmlOptimizer();

        $html = $engine->renderDocument($document, $context);
        $html = $optimizer->optimize($html);

        return [
            'html' => $html,
            'assets' => $assets->get(),
            'css_tags' => $assets->cssTags(),
            'js_tags' => $assets->jsTags()
        ];
    }
}
