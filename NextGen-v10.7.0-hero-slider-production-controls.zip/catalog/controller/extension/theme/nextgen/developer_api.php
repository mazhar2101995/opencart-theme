<?php
class ControllerExtensionThemeNextgenDeveloperApi extends Controller {
    public function index() {
        require_once(DIR_SYSTEM . 'library/nextgen/developer_api.php');
        require_once(DIR_SYSTEM . 'library/nextgen/developer_registry.php');

        $api = NextGenDeveloperRegistry::boot($this->registry);

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode(array(
            'status' => 'ready',
            'version' => '2.5.0',
            'registered_widgets' => count($api->getWidgets()),
            'registered_providers' => count($api->getProviders())
        )));
    }
}
