<?php
class ControllerExtensionThemeNextgenPerformance extends Controller {
    public function index() {
        require_once(DIR_SYSTEM . 'library/nextgen/performance_engine.php');
        require_once(DIR_SYSTEM . 'library/nextgen/asset_dependency_collector.php');

        $collector = new NextGenAssetDependencyCollector();
        $collector->requireCss(
            'nextgen-performance',
            'catalog/view/theme/nextgen/assets/css/performance.css'
        );
        $collector->requireJs(
            'nextgen-performance',
            'catalog/view/theme/nextgen/assets/js/performance.js',
            true
        );

        $this->response->setOutput(json_encode(array(
            'assets' => $collector->all(),
            'status' => 'ready'
        )));
    }
}
