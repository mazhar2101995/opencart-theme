<?php
require_once(DIR_SYSTEM . 'library/nextgen/media_url.php');
/**
 * NextGen storefront presentation boundary.
 * OpenCart controllers, sessions, cart, checkout, customer, payment and
 * shipping remain authoritative. This event only replaces presentation output
 * when a published NextGen document is explicitly assigned to the route.
 */
class ControllerExtensionThemeNextgenPresentation extends Controller {
    public function index() { return $this->context(); }

    // OpenCart resolves theme settings before the controller output is rendered.
    // Bootstrap the NextGen theme values at the presentation boundary so an
    // incomplete/stale admin settings cache cannot stop the storefront before
    // our published-document renderer gets a chance to run.
    public function before(&$route = null, &$args = null, &$output = null) {
        // Controller BEFORE is intentionally lightweight. It keeps the NextGen
        // theme settings available to the normal OpenCart controller lifecycle.
        // Actual storefront replacement happens in view/*/before below, where
        // OpenCart 3.x provides the template output boundary reliably.
        $this->bootstrapThemeRuntime();
        return null;
    }

    private function bootstrapThemeRuntime() {
        $store_id = (int)$this->config->get('config_store_id');
        $enabled = 1;
        $product_limit = 15;
        $q = $this->db->query("SELECT `key`,`value` FROM `".DB_PREFIX."nextgen_runtime_setting` WHERE store_id='".(int)$store_id."' AND `key` IN ('enabled','product_limit')");
        foreach ($q->rows as $row) {
            if ($row['key'] === 'enabled') $enabled = (int)$row['value'];
            if ($row['key'] === 'product_limit') $product_limit = max(1, min(100, (int)$row['value']));
        }
        $this->config->set('config_theme', 'nextgen');
        $this->config->set('theme_nextgen_directory', 'nextgen');
        $this->config->set('theme_nextgen_status', $enabled);
        $this->config->set('theme_nextgen_product_limit', $product_limit);

        // Keep standard OpenCart theme dimensions available to legacy product
        // and category controllers while NextGen controls presentation.
        $defaults = array(
            'product_width'=>600,'product_height'=>600,'thumb_width'=>100,'thumb_height'=>100,
            'popup_width'=>1000,'popup_height'=>1000,'additional_width'=>100,'additional_height'=>100,
            'related_width'=>100,'related_height'=>100,'compare_width'=>100,'compare_height'=>100,
            'wishlist_width'=>100,'wishlist_height'=>100,'cart_width'=>100,'cart_height'=>100,
            'category_width'=>300,'category_height'=>300,'product_description_length'=>100
        );
        foreach ($defaults as $suffix => $value) {
            $key = 'theme_nextgen_' . $suffix;
            if ($this->config->get($key) === null || $this->config->get($key) === false || $this->config->get($key) === '') {
                $this->config->set($key, $value);
            }
        }

        // Runtime-only presentation configuration. Do not mutate OpenCart
        // commerce/session/customer/cart/order/payment/shipping state here.
        return $store_id;
    }

    public function view_before(&$route = null, &$data = null, &$output = null) {
        $request_route=isset($this->request->get['route']) ? (string)$this->request->get['route'] : 'common/home';
        if (!$request_route || !$this->isNextGenRoute($request_route)) return null;
        if (in_array((string)$route,array('common/header','common/footer','common/column_left','common/column_right','common/content_top','common/content_bottom'),true)) return null;
        if (!$this->isEnabled()) return null;
        try {
            $assignment=$this->findAssignment($request_route);
            if (!$assignment) return null;
            $document=$this->getDocument((int)$assignment['document_id']);
            if (!$document || (int)$document['status']!==1 || empty($document['document_json'])) return null;
            $decoded=json_decode($document['document_json'],true);
            if (!is_array($decoded)) return null;
            if (isset($decoded['root']) && is_array($decoded['root'])) $decoded=$decoded['root'];
            if (!isset($decoded['type']) || $decoded['type']!=='root') return null;
            $context=array('route'=>$request_route,'template_type'=>$assignment['template_type'],'language_id'=>(int)$this->config->get('config_language_id'),'store_id'=>(int)$this->config->get('config_store_id'),'nextgen_enabled'=>true,'front_editor'=>$this->frontEditorEnabled(),'products'=>$this->getProductsForRoute($request_route),'product_source_lookup'=>function($source){return $this->getProductSource($source);},'product_lookup'=>function($ids){return $this->getProductsByIds($ids);},'category_lookup'=>function($id){return $this->getCategoryProductsById($id);},'current_product'=>$this->getCurrentProduct($request_route),'categories'=>$this->getNextGenCategories());
            $html=$this->renderDocument($decoded,$context);
            if ($html==='') return null;
            return $this->renderShell($html,$request_route);
        } catch (Exception $e) {
            if (isset($this->log)) $this->log->write('NextGen view presentation error ['.$request_route.']: '.$e->getMessage().' @ '.$e->getFile().':'.$e->getLine());
            return null;
        }
    }

    private function isNextGenRoute($route) {
        return in_array($route,array('common/home','product/product','product/category','product/search','product/manufacturer','product/manufacturer/info','information/information','checkout/cart','account/account','error/not_found'),true);
    }

    public function header(&$route = null, &$data = null, &$output = null) { return null; }
    public function footer(&$route = null, &$data = null, &$output = null) { return null; }

    public function after(&$route = null, &$data = null, &$output = null) {
        $route = (string)$route;
        if (!$route || in_array($route, array('common/header','common/footer'), true)) return null;
        // If another NextGen event already rendered the response, never render
        // it twice. This allows both wildcard and exact-route events to coexist
        // safely on OpenCart 3.x installations.
        if (is_string($output) && strpos($output, 'data-nextgen-runtime="1"') !== false) return null;
        if (!$this->isEnabled()) return null;

        try {
            $assignment = $this->findAssignment($route);
            if (!$assignment) return null;
            $document = $this->getDocument((int)$assignment['document_id']);
            if (!$document || empty($document['status']) || empty($document['document_json'])) return null;
            $decoded = json_decode($document['document_json'], true);
            if (!is_array($decoded)) return null;
            // Builder documents may be stored either as {root:{...}} or as the
            // root node itself. Normalize both forms at the presentation boundary.
            if (isset($decoded['root']) && is_array($decoded['root'])) {
                $decoded = $decoded['root'];
            }
            if (!isset($decoded['type']) || $decoded['type'] !== 'root') return null;
            $document['document_json'] = $decoded;

            $context = array(
                'route'=>$route,
                'template_type'=>$assignment['template_type'],
                'language_id'=>(int)$this->config->get('config_language_id'),
                'store_id'=>(int)$this->config->get('config_store_id'),
                'nextgen_enabled'=>true,
                'front_editor'=>$this->frontEditorEnabled(),
                'products'=>$this->getProductsForRoute($route),
                'product_source_lookup'=>function($source){return $this->getProductSource($source);},
                'product_lookup'=>function($ids){return $this->getProductsByIds($ids);},
                'category_lookup'=>function($id){return $this->getCategoryProductsById($id);},
                'current_product'=>$this->getCurrentProduct($route)
            );

            $html = $this->renderDocument($document['document_json'], $context);
            if ($html === '') return null;
            $output = $this->renderShell($html, $route);
        } catch (Exception $e) {
            if (isset($this->log)) $this->log->write('NextGen presentation error ['.$route.']: '.$e->getMessage().' @ '.$e->getFile().':'.$e->getLine());
            return null;
        }
        return null;
    }

    private function isEnabled() {
        // The OpenCart config object is the runtime authority. This avoids a
        // false negative when an older installation has stale/missing theme
        // setting rows but config_theme is already nextgen.
        $this->bootstrapThemeRuntime();
        $status = $this->config->get('theme_nextgen_status');
        if ($status !== null && $status !== false && $status !== '') return (int)$status === 1;
        $q=$this->db->query("SELECT value FROM `".DB_PREFIX."setting` WHERE store_id='".(int)$this->config->get('config_store_id')."' AND code='theme_nextgen' AND `key`='theme_nextgen_status' LIMIT 1");
        if ($q->num_rows) return (int)$q->row['value'] === 1;
        return in_array((string)$this->config->get('config_theme'), array('nextgen','theme_nextgen'), true);
    }

    private function findAssignment($route) {
        $store=(int)$this->config->get('config_store_id');
        $language=(int)$this->config->get('config_language_id');
        $type=$this->mapType($route);
        $q=$this->db->query("SELECT * FROM `".DB_PREFIX."nextgen_template_assignment` WHERE status='1' AND store_id='".$store."' AND language_id IN ('0','".$language."') AND route='".$this->db->escape($route)."' AND template_type='".$this->db->escape($type)."' ORDER BY language_id DESC, priority DESC, assignment_id DESC LIMIT 1");
        return $q->num_rows ? $q->row : null;
    }

    private function mapType($route) {
        $map=array('common/home'=>'homepage','product/product'=>'product','product/category'=>'category','product/search'=>'search','product/manufacturer'=>'manufacturer','information/information'=>'information','checkout/cart'=>'cart','account/account'=>'account','error/not_found'=>'404');
        return isset($map[$route])?$map[$route]:'custom';
    }

    private function getDocument($id) {
        $q=$this->db->query("SELECT document_id,status,document_json FROM `".DB_PREFIX."nextgen_builder_document` WHERE document_id='".(int)$id."' LIMIT 1");
        return $q->num_rows ? $q->row : null;
    }

    private function getProductsForRoute($route) {
        $products=array();
        if (!in_array($route,array('common/home','product/category','product/search','product/manufacturer'),true)) return $products;
        $this->load->model('catalog/product');
        $this->load->model('tool/image');
        $limit=(int)$this->config->get('theme_nextgen_product_limit');
        if ($limit < 1) $limit=15;
        $filter=array('start'=>0,'limit'=>$limit,'filter_status'=>1);
        if ($route==='product/category' && isset($this->request->get['path'])) {
            $parts=explode('_',(string)$this->request->get['path']);
            $filter['filter_category_id']=(int)end($parts);
        }
        if ($route==='product/search' && isset($this->request->get['search'])) {
            $filter['filter_name']=(string)$this->request->get['search'];
        }
        if ($route==='product/manufacturer' && isset($this->request->get['manufacturer_id'])) {
            $filter['filter_manufacturer_id']=(int)$this->request->get['manufacturer_id'];
        }
        $rows=$this->model_catalog_product->getProducts($filter);
        foreach($rows as $product) {
            $product['thumb']=!empty($product['image']) ? $this->model_tool_image->resize($product['image'],600,600) : '';
            $product['href']=$this->url->link('product/product','product_id='.(int)$product['product_id']);
            $currency=isset($this->session->data['currency'])?$this->session->data['currency']:$this->config->get('config_currency');
            $product['price']=$this->currency->format($product['price'],$currency);
            $product['special']=isset($product['special']) && $product['special'] !== null ? $this->currency->format($product['special'],$currency) : null;
            $products[]=$product;
        }
        return $products;
    }

    private function getProductSource($source) {
        $source=(string)$source;$this->load->model('catalog/product');$this->load->model('tool/image');$limit=60;$currency=isset($this->session->data['currency'])?$this->session->data['currency']:$this->config->get('config_currency');$rows=array();
        if($source==='latest'){try{$rows=$this->model_catalog_product->getLatestProducts($limit);}catch(Exception $e){$rows=array();}}
        elseif($source==='special'){try{$rows=$this->model_catalog_product->getProductSpecials(array('start'=>0,'limit'=>$limit));}catch(Exception $e){$rows=array();}}
        elseif($source==='bestseller'){try{$rows=$this->model_catalog_product->getBestSellerProducts($limit);}catch(Exception $e){$rows=array();}}
        elseif($source==='featured'){
            try{
                $q=$this->db->query("SELECT value, code, `key` FROM `".DB_PREFIX."setting` WHERE store_id='".(int)$this->config->get('config_store_id')."' AND (`key` IN ('module_featured_product','featured_product','module_featured_products') OR code IN ('module_featured','featured')) ORDER BY setting_id DESC");
                $ids=array();
                foreach($q->rows as $row){$raw=(string)$row['value'];$v=json_decode($raw,true);if(is_array($v)){$ids=$v;break;} $v=@unserialize($raw);if(is_array($v)){$ids=$v;break;} if(preg_match('/[0-9]+(?:\s*,\s*[0-9]+)*/',$raw,$mm)){$ids=array_filter(array_map('intval',preg_split('/[,\s]+/',$mm[0])));if($ids)break;}}
                if($ids)return $this->getProductsByIds(array_slice(array_map('intval',$ids),0,$limit));
            }catch(Exception $e){}
            return array();
        }
        foreach((array)$rows as $product){if(!is_array($product))continue;$product['thumb']=!empty($product['image'])?$this->model_tool_image->resize($product['image'],600,600):'';$product['href']=$this->url->link('product/product','product_id='.(int)$product['product_id']);$product['price']=$this->currency->format($product['price'],$currency);$product['special']=isset($product['special'])&&$product['special']!==null?$this->currency->format($product['special'],$currency):null;$products[]=$product;}
        return isset($products)?$products:array();
    }

    private function getProductsByIds($ids) {
        $ids=array_values(array_unique(array_filter(array_map('intval',(array)$ids))));if(!$ids)return array();$this->load->model('catalog/product');$this->load->model('tool/image');$currency=isset($this->session->data['currency'])?$this->session->data['currency']:$this->config->get('config_currency');$out=array();foreach($ids as $id){$p=$this->model_catalog_product->getProduct($id);if(!$p)continue;$p['thumb']=!empty($p['image'])?$this->model_tool_image->resize($p['image'],600,600):'';$p['href']=$this->url->link('product/product','product_id='.$id);$p['price']=$this->currency->format($p['price'],$currency);$p['special']=isset($p['special'])&&$p['special']!==null?$this->currency->format($p['special'],$currency):null;$out[]=$p;}return $out;
    }

    private function getCategoryProductsById($categoryId) {
        $categoryId=(int)$categoryId;if($categoryId<1)return array();$this->load->model('catalog/product');$this->load->model('tool/image');$currency=isset($this->session->data['currency'])?$this->session->data['currency']:$this->config->get('config_currency');$rows=$this->model_catalog_product->getProducts(array('filter_category_id'=>$categoryId,'start'=>0,'limit'=>60,'filter_status'=>1));$out=array();foreach($rows as $p){$p['thumb']=!empty($p['image'])?$this->model_tool_image->resize($p['image'],600,600):'';$p['href']=$this->url->link('product/product','product_id='.(int)$p['product_id']);$p['price']=$this->currency->format($p['price'],$currency);$p['special']=isset($p['special'])&&$p['special']!==null?$this->currency->format($p['special'],$currency):null;$out[]=$p;}return $out;
    }

    private function getNextGenCategories() {
        $language_id=(int)$this->config->get('config_language_id');
        $store_id=(int)$this->config->get('config_store_id');
        $q=$this->db->query("SELECT c.category_id,c.image,cd.name FROM `".DB_PREFIX."category` c INNER JOIN `".DB_PREFIX."category_description` cd ON (c.category_id=cd.category_id AND cd.language_id='".$language_id."') INNER JOIN `".DB_PREFIX."category_to_store` c2s ON (c.category_id=c2s.category_id AND c2s.store_id='".$store_id."') WHERE c.status='1' ORDER BY c.sort_order ASC, cd.name ASC");
        $items=array();
        foreach($q->rows as $row){
            $id=(int)$row['category_id'];
            $catalog_base = defined('HTTPS_SERVER') && $this->config->get('config_ssl') ? (string)HTTPS_SERVER : (defined('HTTP_SERVER') ? (string)HTTP_SERVER : (string)$this->config->get('config_url'));
            $catalog_base = rtrim($catalog_base, '/');
            $catalog_base = preg_replace('#/catalog$#i', '', $catalog_base);
            $items[$id]=array('category_id'=>$id,'name'=>(string)$row['name'],'image'=>(string)($row['image'] ?? ''),'image_url'=>!empty($row['image']) ? rtrim($catalog_base,'/').'/image/'.ltrim($row['image'],'/') : '','url'=>$this->url->link('product/category','path='.$id));
        }
        return $items;
    }

    private function getCurrentProduct($route) {
        if ($route!=='product/product' || empty($this->request->get['product_id'])) return null;
        $this->load->model('catalog/product');
        $this->load->model('tool/image');
        $product=$this->model_catalog_product->getProduct((int)$this->request->get['product_id']);
        if (!$product) return null;
        $product['thumb']=!empty($product['image']) ? $this->model_tool_image->resize($product['image'],900,900) : '';
        $product['href']=$this->url->link('product/product','product_id='.(int)$product['product_id']);
        $currency=isset($this->session->data['currency'])?$this->session->data['currency']:$this->config->get('config_currency');
        $product['price_formatted']=$this->currency->format($product['price'],$currency);
        $product['special_formatted']=isset($product['special']) && $product['special'] !== null ? $this->currency->format($product['special'],$currency) : null;
        return $product;
    }

    private function renderDocument(array $document,array $context) {
        require_once DIR_SYSTEM.'library/nextgen/runtime_registry.php';
        require_once DIR_SYSTEM.'library/nextgen/widget_render_engine.php';
        require_once DIR_SYSTEM.'library/nextgen/default_widget_renderers.php';
        require_once DIR_SYSTEM.'library/nextgen/opencart_product_adapter.php';
        require_once DIR_SYSTEM.'library/nextgen/ecommerce_widget_renderers.php';
        require_once DIR_SYSTEM.'library/nextgen/widget_registry_global.php';
        require_once DIR_SYSTEM.'library/nextgen/widget_registry_catalog_search.php';
        require_once DIR_SYSTEM.'library/nextgen/universal_widget_renderers.php';

        $registry=new NextGenRuntimeRegistry();
        $defaults=new NextGenDefaultWidgetRenderers();
        $defaults->register($registry);
        $commerce=new NextGenEcommerceWidgetRenderers(new NextGenOpenCartProductAdapter());
        $commerce->register($registry);
        $universal=new NextGenUniversalWidgetRenderers();
        $universal->register($registry);

        // The universal renderer owns the `hero` widget. Do not replace it
        // here with a legacy minimal renderer: that would discard image, width,
        // responsive, overlay, typography and slider-aware settings saved by Builder.
        // Small presentation widgets used by the starter demos follow below.
        $registry->registerWidget('announcement',function($node){
            $s=isset($node['settings'])?$node['settings']:array(); return '<div class="ng-announcement">'.htmlspecialchars(isset($s['text'])?$s['text']:'',ENT_QUOTES,'UTF-8').'</div>';
        });
        $registry->registerWidget('newsletter',function(){ return '<section class="ng-newsletter"><h2>Stay in the loop</h2><p>Subscribe for updates.</p></section>'; });
        $registry->registerWidget('trust_badges',function(){ return '<div class="ng-trust-badges"><span>Secure checkout</span><span>Fast delivery</span><span>Trusted store</span></div>'; });
        // Modern Fashion reference demo widgets. These are presentation-only and
        // never modify OpenCart catalog/commerce data.
        $registry->registerWidget('fashion_categories',function($node){
            $s=isset($node['settings'])&&is_array($node['settings'])?$node['settings']:array();
            $items=isset($s['items'])&&is_array($s['items'])?$s['items']:array(); $html='<div class="ng-fashion-categories">';
            foreach($items as $item){$img=htmlspecialchars($this->nextgenAssetUrl($item['image']??''),ENT_QUOTES,'UTF-8');$title=htmlspecialchars((string)($item['title']??''),ENT_QUOTES,'UTF-8');$url=htmlspecialchars((string)($item['url']??'index.php?route=product/category'),ENT_QUOTES,'UTF-8');$html.='<a class="ng-fashion-category" href="'.$url.'"><img src="'.$img.'" alt="'.$title.'" loading="lazy"><span>'.$title.'</span></a>';}
            return $html.'</div>';
        });
        $registry->registerWidget('fashion_lookbook',function($node){
            $s=isset($node['settings'])&&is_array($node['settings'])?$node['settings']:array();
            $items=isset($s['items'])&&is_array($s['items'])?$s['items']:array(); $html='<div class="ng-fashion-lookbook">';
            foreach($items as $item){$img=htmlspecialchars($this->nextgenAssetUrl($item['image']??''),ENT_QUOTES,'UTF-8');$title=htmlspecialchars((string)($item['title']??''),ENT_QUOTES,'UTF-8');$sub=htmlspecialchars((string)($item['subtitle']??''),ENT_QUOTES,'UTF-8');$html.='<article><img src="'.$img.'" alt="'.$title.'" loading="lazy"><div class="ng-fashion-lookbook__copy"><span>'.$sub.'</span><h3>'.$title.'</h3></div></article>';}
            return $html.'</div>';
        });
        $registry->registerWidget('fashion_promo',function($node){
            $s=isset($node['settings'])&&is_array($node['settings'])?$node['settings']:array();$img=htmlspecialchars($this->nextgenAssetUrl($s['image']??'image/catalog/nextgen/demos/fashion/promo.jpg'),ENT_QUOTES,'UTF-8');$h=htmlspecialchars((string)($s['heading']??'Private Sale'),ENT_QUOTES,'UTF-8');$t=htmlspecialchars((string)($s['text']??'Up to 30% off selected styles'),ENT_QUOTES,'UTF-8');$u=htmlspecialchars((string)($s['url']??'index.php?route=product/category'),ENT_QUOTES,'UTF-8');return '<section class="ng-fashion-promo" style="--fashion-promo-image:url(\''.$img.'\')"><div><span>MEMBERS</span><h2>'.$h.'</h2><p>'.$t.'</p><a href="'.$u.'" class="ng-fashion-button ng-fashion-button--light">Shop the edit</a></div></section>';
        });
        $registry->registerWidget('fashion_marquee',function($node){
            $s=isset($node['settings'])&&is_array($node['settings'])?$node['settings']:array();
            $text=htmlspecialchars((string)($s['text']??'LIMITED EDITION  ·  NEW SEASON  ·  UP TO 70% OFF'),ENT_QUOTES,'UTF-8');
            return '<div class="ng-fashion-marquee"><div>'.$text.' &nbsp; '.$text.'</div></div>';
        });
        $registry->registerWidget('fashion_products',function($node){
            $s=isset($node['settings'])&&is_array($node['settings'])?$node['settings']:array();
            $items=isset($s['items'])&&is_array($s['items'])?$s['items']:array();
            if(!$items){$items=array(
                array('name'=>'High Fashion 1','price'=>'$946.88','old'=>'','image'=>'image/catalog/nextgen/demos/fashion/product-01.jpg','badge'=>'NEW'),
                array('name'=>'High Fashion 10','price'=>'$602.05','old'=>'$1,550.00','image'=>'image/catalog/nextgen/demos/fashion/product-02.jpg','badge'=>'SALE'),
                array('name'=>'High Fashion 2','price'=>'$697.99','old'=>'','image'=>'image/catalog/nextgen/demos/fashion/product-03.jpg','badge'=>'')
            );}
            $intro='<div class="ng-fashion-products__intro"><span>NEW ARRIVALS</span><h2>'.htmlspecialchars((string)($s['title']??'New Arrivals'),ENT_QUOTES,'UTF-8').'</h2><p>'.htmlspecialchars((string)($s['subtitle']??'Just in! Shop our newest arrivals.'),ENT_QUOTES,'UTF-8').'</p><a class="ng-fashion-pill" href="index.php?route=product/category">Shop now</a></div>';
            $html='<div class="ng-fashion-products">'.$intro;
            foreach($items as $item){
                $img=htmlspecialchars($this->nextgenAssetUrl($item['image']??''),ENT_QUOTES,'UTF-8');
                $name=htmlspecialchars((string)($item['name']??'Product'),ENT_QUOTES,'UTF-8');
                $price=htmlspecialchars((string)($item['price']??''),ENT_QUOTES,'UTF-8');
                $old=htmlspecialchars((string)($item['old']??''),ENT_QUOTES,'UTF-8');
                $badge=htmlspecialchars((string)($item['badge']??''),ENT_QUOTES,'UTF-8');
                $html.='<article class="ng-fashion-product">'.($badge?'<span class="ng-fashion-product__badge">'.$badge.'</span>':'').'<div class="ng-fashion-product__media"><img src="'.$img.'" alt="'.$name.'" loading="lazy"></div><div class="ng-fashion-product__meta"><small>MODERN FASHION</small><h3>'.$name.'</h3><div>'.($old?'<del>'.$old.'</del> ':'').'<strong>'.$price.'</strong></div><div class="ng-fashion-stars">★★★★★</div></div></article>';
            }
            return $html.'</div>';
        });
        $registry->registerWidget('fashion_sale',function($node){
            $s=isset($node['settings'])&&is_array($node['settings'])?$node['settings']:array();
            $img=htmlspecialchars($this->nextgenAssetUrl($s['image']??'image/catalog/nextgen/demos/fashion/product-04.jpg'),ENT_QUOTES,'UTF-8');
            $h=htmlspecialchars((string)($s['heading']??'SALE'),ENT_QUOTES,'UTF-8');
            $t=htmlspecialchars((string)($s['text']??'Up to 70% off selected pieces. Discover the final edit of the season.'),ENT_QUOTES,'UTF-8');
            return '<section class="ng-fashion-sale"><div class="ng-fashion-sale__media"><img src="'.$img.'" alt="Sale" loading="lazy"></div><div class="ng-fashion-sale__copy"><span>LIMITED EDIT</span><h2>'.$h.'</h2><p>'.$t.'</p><a class="ng-fashion-pill" href="index.php?route=product/category">Shop now</a></div></section>';
        });
        $registry->registerWidget('fashion_editorial',function($node){
            $s=isset($node['settings'])&&is_array($node['settings'])?$node['settings']:array();
            $a=isset($s['image_a'])?$s['image_a']:'image/catalog/nextgen/demos/fashion/editorial-01.jpg';
            $b=isset($s['image_b'])?$s['image_b']:'image/catalog/nextgen/demos/fashion/editorial-02.jpg';
            $a=htmlspecialchars($this->nextgenAssetUrl($a),ENT_QUOTES,'UTF-8');$b=htmlspecialchars($this->nextgenAssetUrl($b),ENT_QUOTES,'UTF-8');
            return '<section class="ng-fashion-editorial"><article><img src="'.$a.'" alt="New Collection" loading="lazy"><div><span>NEW COLLECTION</span><h2>'.htmlspecialchars((string)($s['heading_a']??'New Collection'),ENT_QUOTES,'UTF-8').'</h2><p>'.htmlspecialchars((string)($s['text_a']??'A quiet study in shape, texture and everyday confidence.'),ENT_QUOTES,'UTF-8').'</p><a class="ng-fashion-pill" href="index.php?route=product/category">Shop the collection</a></div></article><article class="ng-fashion-editorial--reverse"><div><span>THE EVERYDAY EDIT</span><h2>'.htmlspecialchars((string)($s['heading_b']??'Chic in One Piece'),ENT_QUOTES,'UTF-8').'</h2><p>'.htmlspecialchars((string)($s['text_b']??'Simple pieces, considered details and effortless silhouettes for every day.'),ENT_QUOTES,'UTF-8').'</p><a class="ng-fashion-pill" href="index.php?route=product/category">Shop the edit</a></div><img src="'.$b.'" alt="Everyday edit" loading="lazy"></article></section>';
        });
        $registry->registerWidget('fashion_inspiration',function($node){
            $s=isset($node['settings'])&&is_array($node['settings'])?$node['settings']:array();
            $items=isset($s['items'])&&is_array($s['items'])?$s['items']:array();
            if(!$items){$items=array();for($i=1;$i<=6;$i++)$items[]=array('image'=>'image/catalog/nextgen/demos/fashion/inspiration-0'.$i.'.jpg','title'=>'@modernfashion');}
            $html='<section class="ng-fashion-inspiration"><div class="ng-fashion-inspiration__head"><span>INSPO / JOURNAL</span><h2>Inspiration</h2><p>Join our visual diary of Modern Fashion. Follow us and keep up with the latest looks.</p></div><div class="ng-fashion-inspiration__grid">';
            foreach($items as $it){$img=htmlspecialchars($this->nextgenAssetUrl($it['image']??''),ENT_QUOTES,'UTF-8');$title=htmlspecialchars((string)($it['title']??'@modernfashion'),ENT_QUOTES,'UTF-8');$html.='<a href="#" class="ng-fashion-inspiration__item"><img src="'.$img.'" alt="'.$title.'" loading="lazy"><span>'.$title.'</span></a>';}
            return $html.'</div></section>';
        });
        $registry->registerWidget('fashion_testimonials',function($node){
            return '<section class="ng-fashion-testimonials"><span>WORDS FROM OUR CUSTOMERS</span><blockquote>“The collection feels considered without ever feeling complicated. Every piece has become part of my everyday wardrobe.”</blockquote><strong>— CHARLOTTE M.</strong><div class="ng-fashion-dots">○ ● ○</div></section>';
        });
        $registry->registerWidget('fashion_blog',function($node){
            $items=array(
                array('image'=>'image/catalog/nextgen/demos/fashion/blog-01.jpg','title'=>'Journal: Big Hues','text'=>'The new season is here — explore the colours, textures and shapes defining the edit.'),
                array('image'=>'image/catalog/nextgen/demos/fashion/blog-02.jpg','title'=>'Red Tones, Updates','text'=>'A closer look at the pieces and details that are shaping the season.'),
                array('image'=>'image/catalog/nextgen/demos/fashion/blog-03.jpg','title'=>'Another Magic Mood','text'=>'Editorial notes, styling ideas and effortless combinations to try now.'),
                array('image'=>'image/catalog/nextgen/demos/fashion/blog-04.jpg','title'=>'Office Essentials','text'=>'Four pieces that make weekday dressing feel considered and easy.')
            );
            $html='<section class="ng-fashion-blog"><div class="ng-fashion-blog__head"><span>JOURNAL</span><h2>From the Blog</h2><p>Notes on style, new arrivals and the stories behind the collection.</p></div><div class="ng-fashion-blog__grid">';
            foreach($items as $it){$img=htmlspecialchars($this->nextgenAssetUrl($it['image']),ENT_QUOTES,'UTF-8');$title=htmlspecialchars($it['title'],ENT_QUOTES,'UTF-8');$text=htmlspecialchars($it['text'],ENT_QUOTES,'UTF-8');$html.='<article><img src="'.$img.'" alt="'.$title.'" loading="lazy"><small>02 / 10 / 2026</small><h3>'.$title.'</h3><p>'.$text.'</p><a href="#">Continue reading →</a></article>';}
            return $html.'</div></section>';
        });
        $registry->registerWidget('fashion_newsletter',function($node){
            return '<section class="ng-fashion-newsletter"><span>JOIN THE LIST</span><h2>Sign up now &amp; get 10% off</h2><p>Stay up to date with new arrivals, private events and seasonal stories.</p><form onsubmit="return false"><input type="email" placeholder="Your email"><button>Sign up</button></form></section>';
        });
        $registry->registerWidget('product',function($node,$ctx){
            $settings=isset($node['settings'])&&is_array($node['settings'])?$node['settings']:array();
            $p=array();
            $selectedId=isset($settings['productId'])?(int)$settings['productId']:0;
            if($selectedId>0 && isset($ctx['product_lookup']) && is_callable($ctx['product_lookup'])){
                $rows=call_user_func($ctx['product_lookup'],array($selectedId));
                if(!empty($rows[0])) $p=$rows[0];
            }
            if(!$p && isset($ctx['current_product'])&&is_array($ctx['current_product'])) $p=$ctx['current_product'];
            if(!$p) return '<div class="ng-product-empty">Select a product from the widget settings.</div>';
            $esc=function($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');};
            $name=$esc($p['name']??'Product'); $href=$esc($p['href']??'#');
            $image=$esc($p['thumb']??''); $price=$esc($p['price']??($p['price_formatted']??'')); $special=$esc($p['special']??($p['special_formatted']??''));
            $brand=$esc($p['manufacturer']??''); $model=$esc($p['model']??'');
            $description=strip_tags(html_entity_decode((string)($p['description']??''),ENT_QUOTES,'UTF-8')); $description=$esc(mb_substr($description,0,700));
            $showImage=($settings['showImage']??true)!==false; $showBrand=($settings['showBrand']??true)!==false; $showModel=($settings['showModel']??false)===true; $showDescription=($settings['showDescription']??true)!==false; $showRating=($settings['showRating']??true)!==false; $showPrice=($settings['showPrice']??true)!==false; $showSpecial=($settings['showSpecialPrice']??true)!==false; $showQty=($settings['showQuantity']??false)===true; $showCart=($settings['showAddToCart']??true)!==false; $showBuy=($settings['showBuyNow']??false)===true;
            $layout=in_array(($settings['layout']??'image-left'),array('image-left','image-right','image-top'),true)?$settings['layout']:'image-left';
            $scope='ng-product-widget-'.preg_replace('/[^a-zA-Z0-9_-]/','-',(string)($node['id']??uniqid('product_',false)));
            $css=''; $css.='.'.$scope.'{display:grid;grid-template-columns:'.($layout==='image-top'?'1fr':($layout==='image-right'?'minmax(0,1fr) minmax(0,1fr)':'minmax(0,1fr) minmax(0,1fr)')).';gap:'.($esc($settings['gap']??'40px')).';background:'.$esc($settings['cardBackground']??'#fff').';border:'.($esc($settings['cardBorderWidth']??'1px')).' '.($esc($settings['cardBorderStyle']??'solid')).' '.($esc($settings['cardBorderColor']??'#e5e7eb')).';border-radius:'.($esc($settings['cardRadius']??'18px')).';box-shadow:'.($esc($settings['cardShadow']??'none')).';padding:'.($esc($settings['cardPadding']??'28px')).';overflow:hidden;}';
            $css.='.'.$scope.' .ng-product-widget-media{'.($layout==='image-top'?'grid-column:1/-1;':'').'background:'.$esc($settings['imageBackground']??'#f8fafc').';border-radius:'.$esc($settings['imageRadius']??'16px').';overflow:hidden;display:flex;align-items:center;justify-content:center;}';
            $css.='.'.$scope.' .ng-product-widget-media img{width:100%;height:auto;max-height:620px;display:block;object-fit:'.$esc($settings['imageFit']??'contain').';}';
            $css.='.'.$scope.' .ng-product-widget-body{display:flex;flex-direction:column;justify-content:center;min-width:0;}';
            $css.='.'.$scope.' .ng-product-widget-brand{color:'.$esc($settings['brandColor']??'#94a3b8').';font-size:11px;letter-spacing:.13em;text-transform:uppercase;margin-bottom:8px;}';
            $css.='.'.$scope.' .ng-product-widget-title{color:'.$esc($settings['titleColor']??'#111827').';font-size:'.$esc($settings['titleSize']??'32px').';font-weight:'.$esc($settings['titleWeight']??'700').';line-height:1.15;margin:0 0 12px;}';
            $css.='.'.$scope.' .ng-product-widget-title a{color:inherit;text-decoration:none;}';
            $css.='.'.$scope.' .ng-product-widget-description{color:'.$esc($settings['descriptionColor']??'#64748b').';font-size:'.$esc($settings['descriptionSize']??'15px').';line-height:1.7;margin:0 0 18px;}';
            $css.='.'.$scope.' .ng-product-widget-rating{color:'.$esc($settings['ratingColor']??'#f59e0b').';letter-spacing:2px;margin-bottom:10px;}';
            $css.='.'.$scope.' .ng-product-widget-price{color:'.$esc($settings['priceColor']??'#111827').';font-size:'.$esc($settings['priceSize']??'22px').';font-weight:700;margin:4px 0 18px;}';
            $css.='.'.$scope.' .ng-product-widget-price del{opacity:.45;margin-right:8px;}';
            $css.='.'.$scope.' .ng-product-widget-buttons{display:flex;gap:10px;align-items:center;flex-wrap:wrap;}';
            $css.='.'.$scope.' .ng-product-widget-btn{background:'.$esc($settings['buttonBackground']??'#111827').';color:'.$esc($settings['buttonColor']??'#fff').';border:'.$esc($settings['buttonBorderWidth']??'0').' '.($esc($settings['buttonBorderStyle']??'solid')).' '.$esc($settings['buttonBorderColor']??'transparent').';border-radius:'.$esc($settings['buttonRadius']??'8px').';padding:'.$esc($settings['buttonPadding']??'12px 20px').';font-size:'.$esc($settings['buttonFontSize']??'14px').';font-weight:'.$esc($settings['buttonFontWeight']??'700').';cursor:pointer;text-decoration:none;}';
            $css.='.'.$scope.' .ng-product-widget-btn:hover{background:'.$esc($settings['buttonHoverBackground']??'#000').';color:'.$esc($settings['buttonHoverColor']??'#fff').';}';
            if($layout==='image-right') $css.='.'.$scope.' .ng-product-widget-media{grid-column:2;grid-row:1;} .'.$scope.' .ng-product-widget-body{grid-column:1;grid-row:1;}';
            $css.='@media(max-width:760px){.'.$scope.'{grid-template-columns:1fr!important;}.'.$scope.' .ng-product-widget-media,.'.$scope.' .ng-product-widget-body{grid-column:1!important;grid-row:auto!important;}}';
            $html='<style>'.$css.'</style><article class="ng-product-detail ng-product-widget '.$scope.'">';
            if($showImage) $html.='<div class="ng-product-widget-media">'.($image?'<a href="'.$href.'"><img src="'.$image.'" alt="'.$name.'" loading="lazy"></a>':'').'</div>';
            $html.='<div class="ng-product-widget-body">';
            if($showBrand&&$brand!=='')$html.='<div class="ng-product-widget-brand">'.$brand.'</div>';
            $html.='<h1 class="ng-product-widget-title"><a href="'.$href.'">'.$name.'</a></h1>';
            if($showModel&&$model!=='')$html.='<div class="ng-product-widget-model">'.$esc($model).'</div>';
            if($showDescription&&$description!=='')$html.='<p class="ng-product-widget-description">'.$description.'</p>';
            if($showRating && !empty($p['rating'])){$html.='<div class="ng-product-widget-rating" aria-label="Rating '.(float)$p['rating'].' out of 5">'.str_repeat('★',(int)round($p['rating'])).'</div>';}
            if($showPrice){$html.='<div class="ng-product-widget-price">';if($showSpecial&&$special!=='')$html.='<del>'.$price.'</del><strong>'.$special.'</strong>';else $html.='<strong>'.$price.'</strong>';$html.='</div>';}
            if($showQty)$html.='<input class="ng-product-widget-qty" type="number" min="1" value="1" aria-label="Quantity">';
            if($showCart||$showBuy){$html.='<div class="ng-product-widget-buttons">';if($showCart)$html.='<button type="button" class="ng-product-widget-btn" data-ng-action="add-to-cart" data-product-id="'.(int)$p['product_id'].'">'.$esc($settings['addToCartText']??'Add to Cart').'</button>';if($showBuy)$html.='<button type="button" class="ng-product-widget-btn" data-ng-action="buy-now" data-product-id="'.(int)$p['product_id'].'">'.$esc($settings['buyNowText']??'Buy Now').'</button>';$html.='</div>';}
            return $html.'</div></article>';
        });

        $engine=new NextGenWidgetRenderEngine($registry);
        $result=$engine->renderDocument($document,$context);
        return isset($result['html']) ? (string)$result['html'] : '';
    }

    private function frontEditorEnabled() {
        if (empty($this->request->get['nextgen_editor']) || (string)$this->request->get['nextgen_editor'] !== '1') return false;
        return $this->verifyFrontEditorToken(isset($this->request->get['nextgen_edit_token']) ? (string)$this->request->get['nextgen_edit_token'] : '');
    }

    private function verifyFrontEditorToken($token) {
        $parts=explode('.',(string)$token,2); if(count($parts)!==2)return false;
        $secret=(string)$this->config->get('config_encryption'); if($secret==='')$secret=(string)$this->config->get('config_name');
        $expected=hash_hmac('sha256',$parts[0],$secret);
        if(!hash_equals($expected,$parts[1]))return false;
        $json=strtr($parts[0],'-_','+/'); $json.=str_repeat('=',(4-strlen($json)%4)%4);
        $payload=json_decode(base64_decode($json),true);
        if(!is_array($payload) || empty($payload['exp']) || (int)$payload['exp']<time() || (($payload['scope']??'')!=='nextgen_front_editor'))return false;
        return true;
    }

    private function renderShell($content,$route) {
        $this->load->model('tool/image');
        $name=htmlspecialchars((string)$this->config->get('config_name'),ENT_QUOTES,'UTF-8');
        $logo=$this->config->get('config_logo');
        $logo_url=$logo ? $this->model_tool_image->resize($logo,220,70) : '';
        if (!$logo_url) $logo_url=$this->config->get('config_ssl') ? HTTPS_SERVER.'image/logo.png' : HTTP_SERVER.'image/logo.png';
        $home=$this->url->link('common/home');
        $cart=$this->url->link('checkout/cart');
        $account=$this->url->link('account/account');
        $activeDemo=$this->activeDemoSlug();

        $settings = array(
            'enabled'=>'1','primary_color'=>'#2563eb','accent_color'=>'#7c3aed','surface_color'=>'#ffffff','background_color'=>'#f6f8fb','text_color'=>'#172033',
            'container_width'=>'1200','radius'=>'12','spacing'=>'24','font_family'=>'system','lazy_images'=>'1','defer_js'=>'1','html_minify'=>'0',
            'reduced_motion'=>'1','seo_enabled'=>'1','canonical_enabled'=>'1','og_enabled'=>'1','schema_enabled'=>'1','hreflang_enabled'=>'1',
            'brand_name'=>$name,'brand_logo'=>'','favicon'=>'','custom_font_family'=>'','custom_font_file'=>'','custom_font_weight'=>'400',
            'typography'=>array(
                'body'=>array('family'=>'system-ui','size'=>'16px','weight'=>'400','transform'=>'none','style'=>'normal','decoration'=>'none','line_height'=>'1.5','letter_spacing'=>'0','word_spacing'=>'0','color'=>'#172033','text_shadow'=>'none'),
                'h1'=>array('family'=>'inherit','size'=>'48px','weight'=>'700','transform'=>'none','style'=>'normal','decoration'=>'none','line_height'=>'1.15','letter_spacing'=>'0','word_spacing'=>'0','color'=>'#111827','text_shadow'=>'none'),
                'h2'=>array('family'=>'inherit','size'=>'36px','weight'=>'700','transform'=>'none','style'=>'normal','decoration'=>'none','line_height'=>'1.2','letter_spacing'=>'0','word_spacing'=>'0','color'=>'#111827','text_shadow'=>'none'),
                'h3'=>array('family'=>'inherit','size'=>'28px','weight'=>'600','transform'=>'none','style'=>'normal','decoration'=>'none','line_height'=>'1.25','letter_spacing'=>'0','word_spacing'=>'0','color'=>'#111827','text_shadow'=>'none'),
                'h4'=>array('family'=>'inherit','size'=>'22px','weight'=>'600','transform'=>'none','style'=>'normal','decoration'=>'none','line_height'=>'1.3','letter_spacing'=>'0','word_spacing'=>'0','color'=>'#111827','text_shadow'=>'none'),
                'h5'=>array('family'=>'inherit','size'=>'18px','weight'=>'600','transform'=>'none','style'=>'normal','decoration'=>'none','line_height'=>'1.35','letter_spacing'=>'0','word_spacing'=>'0','color'=>'#111827','text_shadow'=>'none'),
                'h6'=>array('family'=>'inherit','size'=>'16px','weight'=>'600','transform'=>'none','style'=>'normal','decoration'=>'none','line_height'=>'1.4','letter_spacing'=>'0','word_spacing'=>'0','color'=>'#111827','text_shadow'=>'none'),
                'link'=>array('family'=>'inherit','size'=>'inherit','weight'=>'400','transform'=>'none','style'=>'normal','decoration'=>'none','line_height'=>'inherit','letter_spacing'=>'0','word_spacing'=>'0','color'=>'#2563eb','hover_color'=>'#1d4ed8','hover_decoration'=>'underline','text_shadow'=>'none'),
                'button'=>array('family'=>'inherit','size'=>'14px','weight'=>'600','transform'=>'none','style'=>'normal','decoration'=>'none','line_height'=>'1.2','letter_spacing'=>'0','word_spacing'=>'0','color'=>'#ffffff','hover_color'=>'#ffffff','text_shadow'=>'none'),
                'form'=>array('family'=>'inherit','size'=>'14px','weight'=>'400','transform'=>'none','style'=>'normal','decoration'=>'none','line_height'=>'1.4','letter_spacing'=>'0','word_spacing'=>'0','color'=>'#172033','text_shadow'=>'none')
            )
        );
        $sq=$this->db->query("SELECT `key`,`value` FROM `".DB_PREFIX."nextgen_runtime_setting` WHERE store_id='".(int)$this->config->get('config_store_id')."'");
        foreach($sq->rows as $row) if(array_key_exists($row['key'],$settings)) $settings[$row['key']]=$row['value'];
        if (isset($settings['typography']) && is_string($settings['typography'])) { $decoded=json_decode($settings['typography'],true); if(is_array($decoded)) $settings['typography']=$decoded; }
        $settings['typography']=$this->normalizeGlobalTypography(isset($settings['typography'])&&is_array($settings['typography'])?$settings['typography']:array());
        foreach(array('primary_color','accent_color','surface_color','background_color','text_color') as $c){ if(!preg_match('/^#[0-9a-fA-F]{6}$/',(string)$settings[$c])) $settings[$c]='#2563eb'; }
        $container=(int)$settings['container_width']; if($container<760||$container>1920)$container=1200;
        $radius=(int)$settings['radius']; if($radius<0||$radius>48)$radius=12;
        $spacing=(int)$settings['spacing']; if($spacing<0||$spacing>96)$spacing=24;
        $font = '-apple-system,BlinkMacSystemFont,\"Segoe UI\",sans-serif';
        if ($settings['font_family'] !== 'system' && $settings['font_family'] !== '') {
            $font = '"' . htmlspecialchars((string)$settings['font_family'], ENT_QUOTES, 'UTF-8') . '",sans-serif';
        }

        $css=array(
            'catalog/view/theme/nextgen/assets/css/nextgen-tokens.css',
            'catalog/view/theme/nextgen/assets/css/nextgen-base.css',
            'catalog/view/theme/nextgen/assets/css/frontend-core.css',
            'catalog/view/theme/nextgen/assets/css/widgets/basic.css',
            'catalog/view/theme/nextgen/assets/css/widgets/ecommerce.css',
            'catalog/view/theme/nextgen/assets/css/global-components.css',
            'catalog/view/theme/nextgen/stylesheet/storefront-document.css',
            'catalog/view/theme/nextgen/stylesheet/ecommerce-widgets.css',
            'catalog/view/theme/nextgen/stylesheet/nextgen-v5-storefront.css',
            'catalog/view/theme/nextgen/stylesheet/nextgen-fashion-demo.css',
            'catalog/view/theme/nextgen/stylesheet/widget-runtime.css',
            'catalog/view/theme/nextgen/assets/css/motion.css'
        );
        $style='';
        // Design System is the final global visual authority. Keep these values
        // in one runtime layer after all theme/demo stylesheets so demo defaults
        // cannot silently replace admin settings.
        $style.='html.nextgen-runtime body.nextgen-theme[data-nextgen-demo]{';
        $style.='--ng-primary:'.$settings['primary_color'].'!important;';
        $style.='--ng-accent:'.$settings['accent_color'].'!important;';
        $style.='--ng-surface:'.$settings['surface_color'].'!important;';
        $style.='--ng-bg:'.$settings['background_color'].'!important;';
        $style.='--ng-text:'.$settings['text_color'].'!important;';
        $style.='--ng-container:'.$container.'px!important;--ng-container-width:'.$container.'px!important;--theme-container-width:'.$container.'px!important;--ng-content-max-width:'.$container.'px!important;';
        $style.='--ng-radius:'.$radius.'px!important;';
        $style.='--ng-space:'.$spacing.'px!important;';
        $style.='--ng-font:'.$font.'!important;';
        $style.='background-color:var(--ng-bg)!important;color:var(--ng-text)!important;font-family:var(--ng-font)!important;';
        $style.='}';
        // The demo skin may set literal page/background values with equal or
        // higher specificity. Re-apply the Design System at the final layer
        // using the demo attribute so the saved admin background is actually
        // visible on the storefront.
        $style.='html.nextgen-runtime body.nextgen-theme[data-nextgen-demo],html.nextgen-runtime body.nextgen-theme[data-nextgen-demo] .ng-nextgen-page,html.nextgen-runtime body.nextgen-theme[data-nextgen-demo] .ng-storefront-document{background-color:var(--ng-bg)!important;color:var(--ng-text)!important;}';
        $style.='html.nextgen-runtime body.nextgen-theme[data-nextgen-demo] .ng-site-header{background-color:var(--ng-surface)!important;color:var(--ng-text)!important;}';
        $style.='html.nextgen-runtime body.nextgen-theme[data-nextgen-demo] .ng-site-footer{font-family:var(--ng-font)!important;}';
        // The document wrapper is a full-width canvas. Do not impose the global
        // Design System container width on builder Containers: their own Width /
        // Max Width / Full Container settings are the source of truth.
        $style.='html.nextgen-runtime body.nextgen-theme[data-nextgen-demo] .ng-storefront-document{width:100%!important;max-width:none!important;margin-left:0!important;margin-right:0!important;padding-left:0!important;padding-right:0!important;}';
        $style.='html.nextgen-runtime body.nextgen-theme[data-nextgen-demo] .ng-container{box-sizing:border-box;}';
                $style.='html.nextgen-runtime body.nextgen-theme a{color:var(--ng-primary);}';
        $style.='html.nextgen-runtime body.nextgen-theme .ng-fashion-button,html.nextgen-runtime body.nextgen-theme button.btn-primary,html.nextgen-runtime body.nextgen-theme .btn-primary{background-color:var(--ng-primary)!important;border-color:var(--ng-primary)!important;}';
        $style.='html.nextgen-runtime body.nextgen-theme .ng-fashion-button:hover,html.nextgen-runtime body.nextgen-theme button.btn-primary:hover,html.nextgen-runtime body.nextgen-theme .btn-primary:hover{background-color:var(--ng-accent)!important;border-color:var(--ng-accent)!important;}';
        $style.='html.nextgen-runtime body.nextgen-theme .ng-fashion-logo img,html.nextgen-runtime body.nextgen-theme .ng-logo img{max-width:220px;max-height:70px;width:auto;height:auto;display:block;}';
        $style.='html.nextgen-runtime body.nextgen-theme[data-nextgen-demo] .ng-fashion-button,html.nextgen-runtime body.nextgen-theme[data-nextgen-demo] .ng-fashion-pill,html.nextgen-runtime body.nextgen-theme[data-nextgen-demo] .ng-widget-button{border-radius:var(--ng-radius);}' ;
        $style.='html.nextgen-runtime body.nextgen-theme[data-nextgen-demo] .ng-fashion-category,html.nextgen-runtime body.nextgen-theme[data-nextgen-demo] .ng-fashion-product__media,html.nextgen-runtime body.nextgen-theme[data-nextgen-demo] .ng-widget-image img{border-radius:var(--ng-radius);}' ;

        if (!empty($settings['custom_font_family']) && !empty($settings['custom_font_file'])) { $cf=preg_replace('/[^a-zA-Z0-9 _-]/','',(string)$settings['custom_font_family']); $cfu=NextGenMediaUrl::url($settings['custom_font_file']); $cw=preg_match('/^(100|200|300|400|500|600|700|800|900)$/',(string)$settings['custom_font_weight'])?$settings['custom_font_weight']:'400'; $ext=strtolower(pathinfo(parse_url($cfu,PHP_URL_PATH),PATHINFO_EXTENSION)); $fmt=$ext==='woff2'?'woff2':($ext==='woff'?'woff':($ext==='ttf'?'truetype':'opentype')); $style.='@font-face{font-family:"'.$cf.'";src:url("'.htmlspecialchars($cfu,ENT_QUOTES,'UTF-8').'") format("'.$fmt.'");font-weight:'.$cw.';font-style:normal;font-display:swap;}'; }
        $style .= $this->globalTypographyCss(isset($settings['typography']) && is_array($settings['typography']) ? $settings['typography'] : array());
        if((string)$settings['reduced_motion']==='1') $style.='@media(prefers-reduced-motion:reduce){*,*::before,*::after{animation-duration:.01ms!important;animation-iteration-count:1!important;scroll-behavior:auto!important;transition-duration:.01ms!important}}';
        if((string)$settings['lazy_images']==='1') $content=preg_replace_callback('/<img(?![^>]*\bloading=)[^>]*>/i',function($m){$tag=$m[0]; return preg_replace('/<img/i','<img loading="lazy" decoding="async"',$tag,1);},$content);
        $brandName = isset($settings['brand_name']) && trim((string)$settings['brand_name']) !== '' ? trim((string)$settings['brand_name']) : $name;
        $title=$brandName;
        $name=$brandName;
        $brandLogoUrl = !empty($settings['brand_logo']) ? NextGenMediaUrl::url($settings['brand_logo']) : '';
        $faviconUrl = !empty($settings['favicon']) ? NextGenMediaUrl::url($settings['favicon']) : '';

        $meta='';
        if((string)$settings['seo_enabled']==='1'){
            $meta.='<meta name="robots" content="index,follow">';
            if((string)$settings['canonical_enabled']==='1') $meta.='<link rel="canonical" href="'.htmlspecialchars($this->url->link($route==='common/home'?'common/home':$route),ENT_QUOTES,'UTF-8').'">';
            if((string)$settings['og_enabled']==='1') $meta.='<meta property="og:title" content="'.$title.'"><meta property="og:type" content="website">';
        }
        $out='<!doctype html><html class="nextgen-runtime" lang="'.htmlspecialchars((string)$this->config->get('config_language'),ENT_QUOTES,'UTF-8').'"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'.$title.'</title>'.$meta;
        foreach($css as $href) $out.='<link rel="stylesheet" href="'.htmlspecialchars($this->nextgenAssetUrl($href),ENT_QUOTES,'UTF-8').'">';
        $frontEditor=$this->frontEditorEnabled();
        if($frontEditor) $out.='<link rel="stylesheet" href="'.htmlspecialchars($this->nextgenAssetUrl('catalog/view/theme/nextgen/stylesheet/frontend-editor.css'),ENT_QUOTES,'UTF-8').'">';
        $fashionHeader = $activeDemo === 'fashion';
        if ($fashionHeader) {
            $fashionLogo = $brandLogoUrl ? '<img src="'.htmlspecialchars($brandLogoUrl,ENT_QUOTES,'UTF-8').'" alt="'.$name.'">' : '<span>'.htmlspecialchars($name,ENT_QUOTES,'UTF-8').'</span>';
            $headerHtml='<div class="ng-fashion-topbar"><span>WORLDWIDE SHIPPING</span><span>FREE SHIPPING ON ORDERS OVER $100</span><span>FOLLOW @MODERNFASHION</span></div><header class="ng-site-header ng-fashion-site-header"><div class="ng-site-header__inner"><div class="ng-fashion-header-left"><button class="ng-fashion-menu" type="button" aria-label="Menu">☰</button><nav class="ng-main-nav ng-fashion-nav"><a href="'.$home.'">Women</a><a href="'.$this->url->link('product/category').'">Men</a><a href="'.$this->url->link('product/category').'">Collections</a><a href="'.$this->url->link('product/category').'">Sale</a></nav></div><a class="ng-logo ng-fashion-logo" href="'.$home.'">'.$fashionLogo.'</a><div class="ng-fashion-actions"><a href="'.$this->url->link('product/search').'" aria-label="Search">⌕</a><a href="'.$account.'" aria-label="Account">♙</a><a href="'.$cart.'" aria-label="Shopping bag">⌑</a></div></div></header>';
            $footerHtml='<footer class="ng-site-footer ng-fashion-site-footer"><div class="ng-site-footer__inner"><div class="ng-fashion-footer-brand"><strong>'.htmlspecialchars($name,ENT_QUOTES,'UTF-8').'</strong><p>Considered essentials, modern silhouettes and stories from the studio.</p><small>© '.date('Y').' '.htmlspecialchars($name,ENT_QUOTES,'UTF-8').'. All Rights Reserved.</small></div><div><h4>ABOUT</h4><a href="'.$home.'">Our Story</a><a href="'.$this->url->link('information/information').'">Journal</a><a href="'.$this->url->link('information/information').'">Terms & Conditions</a></div><div><h4>MY ACCOUNT</h4><a href="'.$account.'">Login</a><a href="'.$account.'">Order History</a><a href="'.$cart.'">Shopping Bag</a></div><div><h4>CUSTOMER SERVICE</h4><a href="'.$this->url->link('information/information').'">Contact Us</a><a href="'.$this->url->link('information/information').'">Shipping</a><a href="'.$this->url->link('information/information').'">Returns</a></div></div></footer>';
        } else {
            $headerLogo = $brandLogoUrl ? '<img src="'.htmlspecialchars($brandLogoUrl,ENT_QUOTES,'UTF-8').'" alt="'.$name.'">' : ($logo_url?'<img src="'.htmlspecialchars($logo_url,ENT_QUOTES,'UTF-8').'" alt="'.$name.'">':'<strong>'.$name.'</strong>');
            $headerHtml='<header class="ng-site-header"><div class="ng-site-header__inner"><a class="ng-logo" href="'.$home.'">'.$headerLogo.'</a><nav class="ng-main-nav"><a href="'.$home.'">Home</a><a href="'.$this->url->link('product/category').'">Shop</a><a href="'.$account.'">Account</a><a href="'.$cart.'">Cart</a></nav></div></header>';
            $footerHtml='<footer class="ng-site-footer"><div class="ng-site-footer__inner"><span>&copy; '.date('Y').' '.$name.'</span><a href="'.$home.'">Home</a><a href="'.$cart.'">Cart</a></div></footer>';
        }
        $out.='<link rel="stylesheet" href="'.htmlspecialchars($this->nextgenAssetUrl('catalog/view/theme/nextgen/stylesheet/premium-widgets-v6.css'),ENT_QUOTES,'UTF-8').'">';
        $out.='<link rel="stylesheet" href="'.htmlspecialchars($this->nextgenAssetUrl('catalog/view/theme/nextgen/stylesheet/opencart-interactions.css'),ENT_QUOTES,'UTF-8').'">';
        if($faviconUrl) $out.='<link rel="icon" href="'.htmlspecialchars($faviconUrl,ENT_QUOTES,'UTF-8').'">';
        $out.='<style id="nextgen-runtime-tokens">'.$style.'</style></head><body class="nextgen-theme" data-nextgen-runtime="1" data-nextgen-demo="'.htmlspecialchars($activeDemo,ENT_QUOTES,'UTF-8').'" data-nextgen-route="'.htmlspecialchars($route,ENT_QUOTES,'UTF-8').'" data-nextgen-lazy="'.htmlspecialchars((string)$settings['lazy_images'],ENT_QUOTES,'UTF-8').'" data-nextgen-defer="'.htmlspecialchars((string)$settings['defer_js'],ENT_QUOTES,'UTF-8').'" data-nextgen-editor="'.($frontEditor?'1':'0').'">'.$headerHtml.'<div class="ng-quick-view" hidden aria-hidden="true"><div class="ng-quick-view-backdrop" data-quick-view-close></div><div class="ng-quick-view-dialog" role="dialog" aria-modal="true" aria-label="Quick View"><button type="button" class="ng-quick-view-close" data-quick-view-close aria-label="Close">×</button><div class="ng-quick-view-content" data-quick-view-content></div></div></div><main id="nextgen-page" class="ng-nextgen-page"><div class="ng-storefront-document">'.$content.'</div></main>'.$footerHtml.'<script src="'.htmlspecialchars($this->nextgenAssetUrl('catalog/view/theme/nextgen/assets/js/nextgen-core.js'),ENT_QUOTES,'UTF-8').'"'.((string)$settings['defer_js']==='1'?' defer':'').'></script><script src="'.htmlspecialchars($this->nextgenAssetUrl('catalog/view/theme/nextgen/assets/js/widgets/ecommerce.js'),ENT_QUOTES,'UTF-8').'"'.((string)$settings['defer_js']==='1'?' defer':'').'></script><script src="'.htmlspecialchars($this->nextgenAssetUrl('catalog/view/theme/nextgen/assets/js/widgets/ecommerce-interactions.js'),ENT_QUOTES,'UTF-8').'"></script><script src="'.htmlspecialchars($this->nextgenAssetUrl('catalog/view/theme/nextgen/assets/js/motion-runtime.js'),ENT_QUOTES,'UTF-8').'" defer></script>'.($frontEditor?'<script src="'.htmlspecialchars($this->nextgenAssetUrl('catalog/view/javascript/nextgen/frontend-editor.js'),ENT_QUOTES,'UTF-8').'"></script>':'').'<script src="'.htmlspecialchars($this->nextgenAssetUrl('catalog/view/theme/nextgen/javascript/premium-widgets-v6.js'),ENT_QUOTES,'UTF-8').'"></script></body></html>';
        if((string)$settings['html_minify']==='1') $out=preg_replace('/>\s+</','><',$out);
        return $out;
    }

    private function nextgenAssetUrl($path) {
        $path = trim((string)$path);
        if ($path === '') return '';
        if (preg_match('#^(?:https?:)?//#i', $path)) return $path;
        $base = '';
        if (defined('HTTPS_SERVER') && $this->config->get('config_ssl')) {
            $base = rtrim(HTTPS_SERVER, '/');
        } elseif (defined('HTTP_SERVER')) {
            $base = rtrim(HTTP_SERVER, '/');
        }
        // Media selected through OpenCart Image Manager must always resolve through /image/.
        // Theme CSS/JS assets remain under catalog/view/theme/nextgen/.
        $clean = preg_replace('/[?#].*$/', '', $path);
        if (preg_match('#^image/catalog/#i', $clean) || preg_match('#^catalog/(?!view/)#i', $clean) || preg_match('#^theme/#i', $clean) || preg_match('#/catalog/(?!view/)#i', $clean)) {
            $media = NextGenMediaUrl::url($path, $base . '/');
            return $media;
        }
        return $base . '/' . ltrim($path, '/') . (strpos($path, '?') === false ? '?v=8.1.0' : '&v=8.1.0');
    }

    private function activeDemoSlug() {
        $q=$this->db->query("SELECT value FROM `".DB_PREFIX."nextgen_runtime_setting` WHERE store_id='".(int)$this->config->get('config_store_id')."' AND `key`='active_demo' LIMIT 1");
        return $q->num_rows ? (string)$q->row['value'] : '';
    }

    private function context() {
        $route=isset($this->request->get['route'])?$this->request->get['route']:'common/home';
        return array('route'=>$route,'template_type'=>$this->mapType($route),'nextgen'=>true);
    }
    private function normalizeGlobalTypography($value) {
        $defaults=array(
            'body'=>array('family'=>'system-ui','size'=>'16px','size_tablet'=>'16px','size_mobile'=>'15px','weight'=>'400','transform'=>'none','style'=>'normal','decoration'=>'none','line_height'=>'1.5','letter_spacing'=>'0','word_spacing'=>'0','color'=>'#172033','text_shadow'=>'none'),
            'h1'=>array('family'=>'inherit','size'=>'48px','size_tablet'=>'42px','size_mobile'=>'34px','weight'=>'700','transform'=>'none','style'=>'normal','decoration'=>'none','line_height'=>'1.15','letter_spacing'=>'0','word_spacing'=>'0','color'=>'#111827','text_shadow'=>'none'),
            'h2'=>array('family'=>'inherit','size'=>'36px','size_tablet'=>'32px','size_mobile'=>'28px','weight'=>'700','transform'=>'none','style'=>'normal','decoration'=>'none','line_height'=>'1.2','letter_spacing'=>'0','word_spacing'=>'0','color'=>'#111827','text_shadow'=>'none'),
            'h3'=>array('family'=>'inherit','size'=>'28px','size_tablet'=>'25px','size_mobile'=>'22px','weight'=>'600','transform'=>'none','style'=>'normal','decoration'=>'none','line_height'=>'1.25','letter_spacing'=>'0','word_spacing'=>'0','color'=>'#111827','text_shadow'=>'none'),
            'h4'=>array('family'=>'inherit','size'=>'22px','size_tablet'=>'20px','size_mobile'=>'18px','weight'=>'600','transform'=>'none','style'=>'normal','decoration'=>'none','line_height'=>'1.3','letter_spacing'=>'0','word_spacing'=>'0','color'=>'#111827','text_shadow'=>'none'),
            'h5'=>array('family'=>'inherit','size'=>'18px','size_tablet'=>'17px','size_mobile'=>'16px','weight'=>'600','transform'=>'none','style'=>'normal','decoration'=>'none','line_height'=>'1.35','letter_spacing'=>'0','word_spacing'=>'0','color'=>'#111827','text_shadow'=>'none'),
            'h6'=>array('family'=>'inherit','size'=>'16px','size_tablet'=>'15px','size_mobile'=>'14px','weight'=>'600','transform'=>'none','style'=>'normal','decoration'=>'none','line_height'=>'1.4','letter_spacing'=>'0','word_spacing'=>'0','color'=>'#111827','text_shadow'=>'none'),
            'link'=>array('family'=>'inherit','size'=>'inherit','size_tablet'=>'inherit','size_mobile'=>'inherit','weight'=>'400','transform'=>'none','style'=>'normal','decoration'=>'none','line_height'=>'inherit','letter_spacing'=>'0','word_spacing'=>'0','color'=>'#2563eb','hover_color'=>'#1d4ed8','hover_decoration'=>'underline','text_shadow'=>'none'),
            'button'=>array('family'=>'inherit','size'=>'14px','size_tablet'=>'14px','size_mobile'=>'14px','weight'=>'600','transform'=>'none','style'=>'normal','decoration'=>'none','line_height'=>'1.2','letter_spacing'=>'0','word_spacing'=>'0','color'=>'#ffffff','hover_color'=>'#ffffff','text_shadow'=>'none'),
            'form'=>array('family'=>'inherit','size'=>'14px','size_tablet'=>'14px','size_mobile'=>'14px','weight'=>'400','transform'=>'none','style'=>'normal','decoration'=>'none','line_height'=>'1.4','letter_spacing'=>'0','word_spacing'=>'0','color'=>'#172033','text_shadow'=>'none')
        );
        $out=array(); foreach($defaults as $role=>$d){$out[$role]=isset($value[$role])&&is_array($value[$role])?array_merge($d,$value[$role]):$d;} return $out;
    }

    private function globalTypographyCss($typography) {
        if (!is_array($typography)) return '';

        /*
         * Global typography is a real frontend layer, not metadata.  The old
         * implementation emitted selectors such as `body h1`, but the demo
         * skin has more-specific rules (for example `.ng-fashion-hero h1`)
         * and many widgets use their own classes.  The result was that the
         * Design System could save correctly while the storefront appeared
         * unchanged.
         *
         * Keep this layer after the theme stylesheets and give it enough
         * specificity to win over theme defaults, while deliberately NOT
         * using !important so a widget's inline/local typography can still
         * override the global default.
         */
        $css='';
        $esc=function($v){
            return str_replace(array('</style>','</STYLE>'),'',(string)$v);
        };
        $font=function($v) use ($esc){
            $v=(string)$v;
            if ($v==='' || $v==='inherit') return 'inherit';
            if ($v==='system' || $v==='system-ui') return '-apple-system,BlinkMacSystemFont,"Segoe UI",system-ui,sans-serif';
            $v=preg_replace('/[^a-zA-Z0-9 _,-]/','',$v);
            return '"'.$v.'",sans-serif';
        };

        $emit=function($selectors,$t) use (&$css,$font,$esc){
            if (!is_array($t)) return;
            $rules=array();
            $map=array(
                'family'=>'font-family',
                'size'=>'font-size',
                'weight'=>'font-weight',
                'transform'=>'text-transform',
                'style'=>'font-style',
                'decoration'=>'text-decoration',
                'line_height'=>'line-height',
                'letter_spacing'=>'letter-spacing',
                'word_spacing'=>'word-spacing',
                'color'=>'color',
                'text_shadow'=>'text-shadow'
            );
            foreach($map as $k=>$prop){
                if(isset($t[$k]) && $t[$k]!=='' && $t[$k]!==null){
                    $v=$k==='family' ? $font($t[$k]) : $esc($t[$k]);
                    $rules[]=$prop.':'.$v.';';
                }
            }
            if($rules) $css.=implode(',',$selectors).'{'.implode('',$rules).'}';
        };

        $base='html.nextgen-runtime body.nextgen-theme[data-nextgen-demo]';
        // Keep a plain body selector as a defensive fallback for cached/embedded previews.
        $plainBase='html.nextgen-runtime body.nextgen-theme[data-nextgen-demo]';

        // Body/global text.  Include the common NextGen text/content classes
        // because many theme widgets deliberately set their own font-size.
        $emit(array(
            $base,
            $base.' .ng-widget-text',
            $base.' .ng-widget-icon-box',
            $base.' .ng-fashion-hero p',
            $base.' .ng-fashion-editorial p',
            $base.' .ng-fashion-sale__copy p',
            $base.' .ng-fashion-blog article p',
            $base.' .ng-fashion-newsletter p'
        ),$typography['body']??array());

        // Heading roles.  Map both semantic HTML and NextGen/editorial
        // heading classes so global H1-H6 settings visibly affect the demo.
        $headingSelectors=array(
            'h1'=>array('h1','.ng-widget-heading[data-ng-heading-level="1"]','.ng-widget-heading.ng-heading-1','.ng-fashion-hero h1'),
            'h2'=>array('h2','.ng-widget-heading[data-ng-heading-level="2"]','.ng-widget-heading.ng-heading-2','.ng-fashion-sale__copy h2','.ng-fashion-editorial h2','.ng-fashion-products__intro h2','.ng-fashion-inspiration__head h2','.ng-fashion-blog__head h2','.ng-fashion-newsletter h2'),
            'h3'=>array('h3','.ng-widget-heading[data-ng-heading-level="3"]','.ng-widget-heading.ng-heading-3','.ng-fashion-product__meta h3','.ng-fashion-blog article h3'),
            'h4'=>array('h4','.ng-widget-heading[data-ng-heading-level="4"]','.ng-widget-heading.ng-heading-4'),
            'h5'=>array('h5','.ng-widget-heading[data-ng-heading-level="5"]','.ng-widget-heading.ng-heading-5'),
            'h6'=>array('h6','.ng-widget-heading[data-ng-heading-level="6"]','.ng-widget-heading.ng-heading-6')
        );
        foreach($headingSelectors as $role=>$selectors){
            $full=array();
            foreach($selectors as $selector) $full[]=$base.' '.$selector;
            $emit($full,$typography[$role]??array());
        }

        // Links and buttons are kept separate from body typography.
        $emit(array(
            $base.' a',
            $base.' .ng-widget-button',
            $base.' .ng-fashion-button'
        ),$typography['link']??array());

        $emit(array(
            $base.' button',
            $base.' .btn',
            $base.' .ng-widget-button',
            $base.' .ng-fashion-button'
        ),$typography['button']??array());

        $emit(array(
            $base.' input',
            $base.' select',
            $base.' textarea',
            $base.' label'
        ),$typography['form']??array());

        // Responsive font-size values follow the same role selectors.
        foreach($typography as $role=>$t){
            if(!is_array($t)) continue;
            if($role==='body') {
                $selectors=array($base,$base.' .ng-widget-text',$base.' .ng-fashion-hero p',$base.' .ng-fashion-editorial p',$base.' .ng-fashion-sale__copy p',$base.' .ng-fashion-blog article p',$base.' .ng-fashion-newsletter p');
            } elseif(isset($headingSelectors[$role])) {
                $selectors=array(); foreach($headingSelectors[$role] as $selector) $selectors[]=$base.' '.$selector;
            } elseif($role==='link') {
                $selectors=array($base.' a',$base.' .ng-widget-button',$base.' .ng-fashion-button');
            } elseif($role==='button') {
                $selectors=array($base.' button',$base.' .btn',$base.' .ng-widget-button',$base.' .ng-fashion-button');
            } elseif($role==='form') {
                $selectors=array($base.' input',$base.' select',$base.' textarea',$base.' label');
            } else continue;

            if(isset($t['size_tablet']) && $t['size_tablet']!=='') {
                $css.='@media(max-width:900px){'.implode(',',$selectors).'{font-size:'.$esc($t['size_tablet']).';}}';
            }
            if(isset($t['size_mobile']) && $t['size_mobile']!=='') {
                $css.='@media(max-width:600px){'.implode(',',$selectors).'{font-size:'.$esc($t['size_mobile']).';}}';
            }
        }

        $link=$typography['link']??array();
        if(!empty($link['hover_color']) || !empty($link['hover_decoration'])){
            $css.=$base.' a:hover{';
            if(!empty($link['hover_color'])) $css.='color:'.$esc($link['hover_color']).';';
            if(!empty($link['hover_decoration'])) $css.='text-decoration:'.$esc($link['hover_decoration']).';';
            $css.='}';
        }
        $button=$typography['button']??array();
        if(!empty($button['hover_color'])) $css.=$base.' button:hover,'.$base.' .btn:hover,'.$base.' .ng-widget-button:hover,'.$base.' .ng-fashion-button:hover{color:'.$esc($button['hover_color']).';}';

        // Final global typography layer.  This intentionally uses !important only for
        // global typography defaults so legacy demo CSS cannot silently override the
        // values saved in Design System. Widget-local typography is emitted separately
        // with the same priority and therefore remains the intended override path.
        foreach($typography as $role=>$t){
            if(!is_array($t)) continue;
            $selectors=array();
            if($role==='body') $selectors=array($plainBase,$plainBase.' .ng-widget-text',$plainBase.' .ng-fashion-hero p',$plainBase.' .ng-fashion-editorial p',$plainBase.' .ng-fashion-sale__copy p',$plainBase.' .ng-fashion-blog article p',$plainBase.' .ng-fashion-newsletter p');
            elseif(isset($headingSelectors[$role])) foreach($headingSelectors[$role] as $selector) $selectors[]=$plainBase.' '.$selector;
            elseif($role==='link') $selectors=array($plainBase.' a',$plainBase.' .ng-widget-button',$plainBase.' .ng-fashion-button');
            elseif($role==='button') $selectors=array($plainBase.' button',$plainBase.' .btn',$plainBase.' .ng-widget-button',$plainBase.' .ng-fashion-button');
            elseif($role==='form') $selectors=array($plainBase.' input',$plainBase.' select',$plainBase.' textarea',$plainBase.' label');
            else continue;
            $rules=array();
            $map=array('family'=>'font-family','size'=>'font-size','weight'=>'font-weight','transform'=>'text-transform','style'=>'font-style','decoration'=>'text-decoration','line_height'=>'line-height','letter_spacing'=>'letter-spacing','word_spacing'=>'word-spacing','color'=>'color','text_shadow'=>'text-shadow');
            foreach($map as $k=>$prop){ if(isset($t[$k]) && $t[$k]!=='' && $t[$k]!==null){ $v=$k==='family'?$font($t[$k]):$esc($t[$k]); $rules[]=$prop.':'.$v.' !important;'; } }
            if($rules) $css.=implode(',',$selectors).'{'.implode('',$rules).'}';
            if(isset($t['size_tablet']) && $t['size_tablet']!=='') $css.='@media(max-width:900px){'.implode(',',$selectors).'{font-size:'.$esc($t['size_tablet']).' !important;}}';
            if(isset($t['size_mobile']) && $t['size_mobile']!=='') $css.='@media(max-width:600px){'.implode(',',$selectors).'{font-size:'.$esc($t['size_mobile']).' !important;}}';
        }
        return $css;
    }

}
