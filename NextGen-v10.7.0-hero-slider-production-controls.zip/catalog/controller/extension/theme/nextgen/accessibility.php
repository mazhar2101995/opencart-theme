<?php
class ControllerExtensionThemeNextgenAccessibility extends Controller {
    public function index() {
        require_once(DIR_SYSTEM . 'library/nextgen/accessibility_engine.php');
        require_once(DIR_SYSTEM . 'library/nextgen/responsive_engine.php');

        $this->response->setOutput(json_encode(array(
            'status' => 'ready',
            'version' => '2.3.0',
            'principles' => array(
                'keyboard-first',
                'visible-focus',
                'semantic-html',
                'aria-when-needed',
                'reduced-motion',
                'responsive-fallbacks'
            )
        )));
    }
}
