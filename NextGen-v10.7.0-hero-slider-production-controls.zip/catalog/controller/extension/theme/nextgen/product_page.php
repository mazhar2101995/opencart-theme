<?php
class ControllerExtensionThemeNextgenProductPage extends Controller {
    public function renderWidget($widget_id, array $product = [], array $settings = []) {
        $this->load->model('extension/theme/nextgen/product_page');
        $data = $this->model_extension_theme_nextgen_product_page->normalize($product);
        $data['settings'] = $settings;
        $data['widget_id'] = $widget_id;
        $registry = NextGenProductPageSchema::widgets();
        if (!isset($registry[$widget_id])) {
            return '';
        }
        $template = $registry[$widget_id]['template'];
        return $this->load->view('theme/nextgen/' . $template, $data);
    }
}
