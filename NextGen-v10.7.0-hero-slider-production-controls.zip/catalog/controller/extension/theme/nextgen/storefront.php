<?php
class ControllerExtensionThemeNextgenStorefront extends Controller {
    public function index() {
        /*
         * Production integration entry contract.
         * Existing OpenCart route/controller output remains authoritative
         * until the NextGen template assignment resolver selects a published
         * document for this route.
         */
        $this->response->setOutput(json_encode(array(
            'status'=>'nextgen-ready',
            'message'=>'NextGen storefront render service is available.'
        )));
    }
}
