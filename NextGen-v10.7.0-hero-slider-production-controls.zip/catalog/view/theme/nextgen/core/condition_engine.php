<?php
/**
 * Presentation condition evaluator.
 *
 * Supported operators:
 * equals, not_equals, contains, not_contains,
 * greater_than, less_than, greater_or_equal, less_or_equal,
 * exists, not_exists, in, not_in.
 */
class NextGenConditionEngine {
    public function evaluate(array $conditions, array $context = array()) {
        if (!$conditions) {
            return true;
        }

        $mode = isset($conditions['relation']) && $conditions['relation'] === 'OR' ? 'OR' : 'AND';
        $rules = isset($conditions['rules']) && is_array($conditions['rules'])
            ? $conditions['rules'] : array();

        if (!$rules) {
            return true;
        }

        $results = array();

        foreach ($rules as $rule) {
            $results[] = $this->evaluateRule($rule, $context);
        }

        if ($mode === 'OR') {
            return in_array(true, $results, true);
        }

        return !in_array(false, $results, true);
    }

    public function evaluateRule(array $rule, array $context = array()) {
        $path = isset($rule['field']) ? $rule['field'] : '';
        $operator = isset($rule['operator']) ? $rule['operator'] : 'equals';
        $expected = isset($rule['value']) ? $rule['value'] : null;

        $found = false;
        $actual = $this->getPath($context, $path, $found);

        switch ($operator) {
            case 'exists':
                return $found && $actual !== null && $actual !== '';
            case 'not_exists':
                return !$found || $actual === null || $actual === '';
            case 'equals':
                return $this->normalize($actual) === $this->normalize($expected);
            case 'not_equals':
                return $this->normalize($actual) !== $this->normalize($expected);
            case 'contains':
                return is_scalar($actual) && stripos((string)$actual, (string)$expected) !== false;
            case 'not_contains':
                return !(is_scalar($actual) && stripos((string)$actual, (string)$expected) !== false);
            case 'greater_than':
                return is_numeric($actual) && is_numeric($expected) && $actual > $expected;
            case 'less_than':
                return is_numeric($actual) && is_numeric($expected) && $actual < $expected;
            case 'greater_or_equal':
                return is_numeric($actual) && is_numeric($expected) && $actual >= $expected;
            case 'less_or_equal':
                return is_numeric($actual) && is_numeric($expected) && $actual <= $expected;
            case 'in':
                return is_array($expected) && in_array($this->normalize($actual), array_map(array($this,'normalize'), $expected), true);
            case 'not_in':
                return is_array($expected) && !in_array($this->normalize($actual), array_map(array($this,'normalize'), $expected), true);
            default:
                return false;
        }
    }

    protected function getPath(array $context, $path, &$found) {
        $found = false;
        if (!$path) return null;

        $parts = explode('.', $path);
        $value = $context;

        foreach ($parts as $part) {
            if (is_array($value) && array_key_exists($part, $value)) {
                $value = $value[$part];
            } else {
                return null;
            }
        }

        $found = true;
        return $value;
    }

    protected function normalize($value) {
        if (is_bool($value)) return $value ? '1' : '0';
        if ($value === null) return '';
        return strtolower(trim((string)$value));
    }
}
