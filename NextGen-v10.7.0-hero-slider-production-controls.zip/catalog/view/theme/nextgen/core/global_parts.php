<?php
/**
 * NextGen Global Parts Registry.
 *
 * Global parts are reusable presentation documents such as header/footer.
 * They are resolved independently from commerce/controller logic.
 */
class NextGenGlobalParts {
    protected $parts = array();

    public function register($id, $label, $type, $documentId = null, array $meta = array()) {
        if (!$id || !$type) return false;

        $this->parts[$id] = array(
            'id' => $id,
            'label' => $label ?: $id,
            'type' => $type,
            'document_id' => $documentId,
            'meta' => $meta
        );

        return true;
    }

    public function get($id) {
        return isset($this->parts[$id]) ? $this->parts[$id] : null;
    }

    public function all($type = null) {
        $result = array();

        foreach ($this->parts as $part) {
            if ($type === null || $part['type'] === $type) {
                $result[] = $part;
            }
        }

        return $result;
    }

    public function assignDocument($id, $documentId) {
        if (!isset($this->parts[$id])) return false;
        $this->parts[$id]['document_id'] = $documentId;
        return true;
    }
}
