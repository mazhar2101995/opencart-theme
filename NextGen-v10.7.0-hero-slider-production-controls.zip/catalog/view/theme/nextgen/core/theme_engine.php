<?php
/**
 * OpenCart NextGen Theme Engine
 *
 * Foundation rendering service.
 * Keeps builder document resolution separate from OpenCart controllers.
 */
class NextGenThemeEngine {
    protected $registry;
    protected $config;
    protected $loader;
    protected $document = null;

    public function __construct($registry) {
        $this->registry = $registry;
        $this->config = $registry->get('config');
        $this->loader = $registry->get('load');
    }

    public function setDocument($document) {
        $this->document = $this->normalizeDocument($document);
        return $this;
    }

    public function getDocument() {
        return $this->document;
    }

    public function renderDocument($document = null) {
        if ($document !== null) {
            $this->setDocument($document);
        }

        if (!$this->document) {
            return '';
        }

        return $this->renderNode($this->document);
    }

    protected function renderNode($node) {
        if (!is_array($node)) {
            return '';
        }

        $type = isset($node['type']) ? $node['type'] : 'root';
        $settings = isset($node['settings']) && is_array($node['settings']) ? $node['settings'] : array();
        $children = isset($node['children']) && is_array($node['children']) ? $node['children'] : array();

        if ($type === 'root' || $type === 'section' || $type === 'container' || $type === 'column') {
            return $this->renderLayoutNode($type, $settings, $children);
        }

        return $this->renderWidget($type, $settings, $children);
    }

    protected function renderLayoutNode($type, $settings, $children) {
        $html = '';

        foreach ($children as $child) {
            $html .= $this->renderNode($child);
        }

        if ($type === 'root') {
            return $html;
        }

        $class = 'ng-' . preg_replace('/[^a-z0-9_-]/i', '-', $type);

        if (!empty($settings['class'])) {
            $class .= ' ' . preg_replace('/[^a-z0-9_\-\s]/i', '', $settings['class']);
        }

        $attrs = '';

        if (!empty($settings['id'])) {
            $attrs .= ' id="' . htmlspecialchars($settings['id'], ENT_QUOTES, 'UTF-8') . '"';
        }

        return '<div class="' . trim($class) . '"' . $attrs . '>' . $html . '</div>';
    }

    protected function renderWidget($type, $settings, $children) {
        $template = $this->resolveWidgetTemplate($type);

        if (!$template) {
            return '';
        }

        $data = array(
            'settings' => $settings,
            'children' => $children,
            'engine'   => $this
        );

        return $this->loader->view($template, $data);
    }

    protected function resolveWidgetTemplate($type) {
        $map = array(
            'heading' => 'theme/nextgen/builder/widget/heading',
            'text'    => 'theme/nextgen/builder/widget/text',
            'button'  => 'theme/nextgen/builder/widget/button'
        );

        return isset($map[$type]) ? $map[$type] : null;
    }

    public function normalizeDocument($document) {
        if (is_string($document)) {
            $decoded = json_decode($document, true);
            $document = is_array($decoded) ? $decoded : array();
        }

        if (!is_array($document)) {
            return array('version' => 1, 'type' => 'root', 'children' => array());
        }

        return $this->normalizeNode($document, 'root');
    }

    protected function normalizeNode($node, $fallbackType) {
        $result = array(
            'id'       => !empty($node['id']) ? (string)$node['id'] : uniqid('ng_', true),
            'type'     => !empty($node['type']) ? (string)$node['type'] : $fallbackType,
            'settings' => isset($node['settings']) && is_array($node['settings']) ? $node['settings'] : array(),
            'children' => array()
        );

        if (isset($node['children']) && is_array($node['children'])) {
            foreach ($node['children'] as $child) {
                if (is_array($child)) {
                    $result['children'][] = $this->normalizeNode($child, 'widget');
                }
            }
        }

        return $result;
    }
}
