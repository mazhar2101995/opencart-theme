<?php
/**
 * Dynamic binding helper.
 *
 * A bound value has the shape:
 * {
 *   "dynamic": true,
 *   "provider": "product.name",
 *   "fallback": "..."
 * }
 */
class NextGenDynamicBinding {
    public function isBinding($value) {
        return is_array($value)
            && !empty($value['dynamic'])
            && !empty($value['provider']);
    }

    public function resolve($value, NextGenDynamicData $registry, array $context = array()) {
        if (!$this->isBinding($value)) {
            return $value;
        }

        $resolved = $registry->resolve($value['provider'], $context);

        if ($resolved === null && array_key_exists('fallback', $value)) {
            return $value['fallback'];
        }

        return $resolved;
    }
}
