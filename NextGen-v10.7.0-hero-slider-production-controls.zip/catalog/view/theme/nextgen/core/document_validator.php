<?php
/**
 * Validates and sanitizes the builder document structure.
 */
class NextGenDocumentValidator {
    public function validate($document) {
        $errors = array();

        if (!is_array($document)) {
            $errors[] = 'Document must be an array.';
            return $errors;
        }

        if (!isset($document['version'])) {
            $errors[] = 'Document version is required.';
        }

        if (!isset($document['type']) || $document['type'] !== 'root') {
            $errors[] = 'Document root type must be root.';
        }

        if (isset($document['children']) && !is_array($document['children'])) {
            $errors[] = 'Document children must be an array.';
        }

        if (!$errors && isset($document['children'])) {
            foreach ($document['children'] as $index => $node) {
                $nodeErrors = $this->validateNode($node, 'root');
                foreach ($nodeErrors as $error) {
                    $errors[] = 'children[' . $index . ']: ' . $error;
                }
            }
        }

        return $errors;
    }

    protected function validateNode($node, $parentType) {
        $errors = array();

        if (!is_array($node)) {
            return array('Node must be an object/array.');
        }

        if (empty($node['type'])) {
            $errors[] = 'Node type is required.';
        }

        if (!isset($node['settings']) || !is_array($node['settings'])) {
            $errors[] = 'Node settings must be an array.';
        }

        if (!isset($node['children']) || !is_array($node['children'])) {
            $errors[] = 'Node children must be an array.';
        }

        $type = isset($node['type']) ? $node['type'] : '';

        if ($parentType === 'root' && !in_array($type, array('section'), true)) {
            $errors[] = 'Only section nodes are allowed directly under root.';
        }

        if ($type === 'section' && !empty($node['children'])) {
            foreach ($node['children'] as $index => $child) {
                if (!is_array($child) || !isset($child['type']) || !in_array($child['type'], array('container'), true)) {
                    $errors[] = 'Section children must be containers.';
                    break;
                }
            }
        }

        if ($type === 'container' && !empty($node['children'])) {
            foreach ($node['children'] as $index => $child) {
                if (!is_array($child) || !isset($child['type'])) {
                    $errors[] = 'Container child is invalid.';
                    break;
                }
                // Modern containers own their children directly. Nested containers are allowed.
                // Legacy column nodes are still accepted so existing saved documents can migrate safely.
            }
        }

        if ($type === 'column' && !empty($node['children'])) {
            foreach ($node['children'] as $index => $child) {
                if (!is_array($child) || !isset($child['type'])) {
                    $errors[] = 'Column child is invalid.';
                    break;
                }
            }
        }

        if (!empty($node['children'])) {
            foreach ($node['children'] as $index => $child) {
                $childErrors = $this->validateNode($child, $type);
                foreach ($childErrors as $error) {
                    $errors[] = 'children[' . $index . ']: ' . $error;
                }
            }
        }

        return $errors;
    }
}
