<?php
/**
 * Database repository for builder documents.
 */
class NextGenDocumentRepository {
    protected $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function get($document_id) {
        $query = $this->db->query(
            "SELECT * FROM `" . DB_PREFIX . "nextgen_builder_document` " .
            "WHERE document_id = '" . (int)$document_id . "' LIMIT 1"
        );

        if (!$query->num_rows) {
            return null;
        }

        $row = $query->row;
        $row['document'] = json_decode($row['document_json'], true);

        return $row;
    }

    public function save($data) {
        $document = isset($data['document']) && is_array($data['document']) ? $data['document'] : array();

        $name = $this->db->escape(isset($data['name']) ? $data['name'] : 'Untitled');
        $route = $this->db->escape(isset($data['route']) ? $data['route'] : '');
        $template_type = $this->db->escape(isset($data['template_type']) ? $data['template_type'] : 'page');
        $json = $this->db->escape(json_encode($document, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
        $status = isset($data['status']) ? (int)$data['status'] : 1;
        $now = date('Y-m-d H:i:s');

        if (!empty($data['document_id'])) {
            $document_id = (int)$data['document_id'];

            $this->db->query(
                "UPDATE `" . DB_PREFIX . "nextgen_builder_document` SET " .
                "`name` = '" . $name . "', " .
                "`route` = '" . $route . "', " .
                "`template_type` = '" . $template_type . "', " .
                "`status` = '" . $status . "', " .
                "`version` = `version` + 1, " .
                "`document_json` = '" . $json . "', " .
                "`date_modified` = '" . $now . "' " .
                "WHERE document_id = '" . $document_id . "'"
            );

            return $document_id;
        }

        $this->db->query(
            "INSERT INTO `" . DB_PREFIX . "nextgen_builder_document` SET " .
            "`name` = '" . $name . "', " .
            "`route` = '" . $route . "', " .
            "`template_type` = '" . $template_type . "', " .
            "`status` = '" . $status . "', " .
            "`version` = '1', " .
            "`document_json` = '" . $json . "', " .
            "`date_added` = '" . $now . "', " .
            "`date_modified` = '" . $now . "'"
        );

        return $this->db->getLastId();
    }

    public function delete($document_id) {
        $this->db->query(
            "DELETE FROM `" . DB_PREFIX . "nextgen_builder_document` " .
            "WHERE document_id = '" . (int)$document_id . "'"
        );
    }

    public function listDocuments($limit = 50, $start = 0) {
        $query = $this->db->query(
            "SELECT document_id, name, route, template_type, status, version, date_modified " .
            "FROM `" . DB_PREFIX . "nextgen_builder_document` " .
            "ORDER BY date_modified DESC " .
            "LIMIT " . (int)$start . ", " . (int)$limit
        );

        return $query->rows;
    }
}
