<?php
class NextGenDefaultTemplates {
    public static function register(NextGenTemplateRegistry $registry) {
        $registry->register('global-header', 'Global Header', 'header');
        $registry->register('global-footer', 'Global Footer', 'footer');
        $registry->register('homepage', 'Homepage', 'page', array('route'=>'common/home'));
        $registry->register('product-default', 'Default Product', 'product', array('route'=>'product/product'));
        $registry->register('category-default', 'Default Category', 'category', array('route'=>'product/category'));
        $registry->register('search-default', 'Default Search', 'search', array('route'=>'product/search'));
        $registry->register('manufacturer-default', 'Default Manufacturer', 'manufacturer', array('route'=>'product/manufacturer'));
        $registry->register('information-default', 'Default Information', 'information', array('route'=>'information/information'));
        $registry->register('cart-default', 'Default Cart', 'cart', array('route'=>'checkout/cart'));
        $registry->register('account-default', 'Default Account', 'account');
        $registry->register('checkout-compatible', 'Checkout Compatible', 'checkout');
        $registry->register('error-404', '404 Page', 'error', array('route'=>'error/not_found'));
        $registry->register('custom-landing', 'Custom Landing Page', 'landing');
        $registry->register('popup-template', 'Popup Template', 'popup');
    }
}
