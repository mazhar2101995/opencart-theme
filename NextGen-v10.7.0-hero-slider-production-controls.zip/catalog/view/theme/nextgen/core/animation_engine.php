<?php
/**
 * NextGen Animation Engine.
 *
 * Declarative animation definitions are normalized server-side and rendered
 * only when a node actually uses animation. The storefront should not load
 * animation runtime globally.
 */
class NextGenAnimationEngine {
    protected $presets = array(
        'fade'       => array('name'=>'Fade','keyframes'=>'ngFade'),
        'fade-up'    => array('name'=>'Fade Up','keyframes'=>'ngFadeUp'),
        'fade-down'  => array('name'=>'Fade Down','keyframes'=>'ngFadeDown'),
        'fade-left'  => array('name'=>'Fade Left','keyframes'=>'ngFadeLeft'),
        'fade-right' => array('name'=>'Fade Right','keyframes'=>'ngFadeRight'),
        'zoom-in'    => array('name'=>'Zoom In','keyframes'=>'ngZoomIn'),
        'zoom-out'   => array('name'=>'Zoom Out','keyframes'=>'ngZoomOut'),
        'slide-up'   => array('name'=>'Slide Up','keyframes'=>'ngSlideUp'),
        'slide-down' => array('name'=>'Slide Down','keyframes'=>'ngSlideDown'),
        'slide-left' => array('name'=>'Slide Left','keyframes'=>'ngSlideLeft'),
        'slide-right'=> array('name'=>'Slide Right','keyframes'=>'ngSlideRight')
    );

    public function normalize(array $animation) {
        if (empty($animation['enabled'])) {
            return null;
        }

        $preset = isset($animation['preset']) ? $animation['preset'] : 'fade-up';
        if (!isset($this->presets[$preset])) {
            $preset = 'fade-up';
        }

        return array(
            'enabled'  => true,
            'preset'   => $preset,
            'trigger'  => isset($animation['trigger']) ? $animation['trigger'] : 'viewport',
            'duration' => $this->number($animation, 'duration', 600, 50, 5000),
            'delay'    => $this->number($animation, 'delay', 0, 0, 5000),
            'easing'   => isset($animation['easing']) ? $animation['easing'] : 'ease',
            'once'     => isset($animation['once']) ? (bool)$animation['once'] : true,
            'distance' => $this->number($animation, 'distance', 24, 0, 300),
            'threshold'=> $this->number($animation, 'threshold', 0.15, 0, 1)
        );
    }

    public function getPresets() {
        return $this->presets;
    }

    public function classes(array $animation) {
        $normalized = $this->normalize($animation);
        if (!$normalized) return '';

        return ' ng-motion ng-motion-' . preg_replace('/[^a-z0-9\-]/', '', $normalized['preset'])
            . ($normalized['once'] ? ' ng-motion-once' : '');
    }

    protected function number(array $source, $key, $default, $min, $max) {
        if (!isset($source[$key]) || !is_numeric($source[$key])) return $default;
        return max($min, min($max, $source[$key]));
    }
}
