<?php
/**
 * Template renderer bridge.
 *
 * The builder owns document presentation; OpenCart remains responsible for
 * commerce data/controller flow. This class receives a resolved document
 * definition and delegates node rendering to the existing theme engine.
 */
class NextGenTemplateRenderer {
    protected $engine;

    public function __construct($engine) {
        $this->engine = $engine;
    }

    public function render(array $document, array $context = array()) {
        if (!isset($document['root'])) {
            return '';
        }

        return $this->engine->renderDocument($document, $context);
    }
}
