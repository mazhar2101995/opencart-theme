<?php
/**
 * NextGen Template Registry.
 *
 * Defines template surfaces without replacing OpenCart routes/controllers.
 * A template is a presentation definition assigned to an OpenCart surface.
 */
class NextGenTemplateRegistry {
    protected $templates = array();

    public function register($id, $label, $type, array $meta = array()) {
        if (!$id || !$type) return false;

        $this->templates[$id] = array(
            'id' => $id,
            'label' => $label ?: $id,
            'type' => $type,
            'meta' => $meta
        );

        return true;
    }

    public function get($id) {
        return isset($this->templates[$id]) ? $this->templates[$id] : null;
    }

    public function all() {
        return array_values($this->templates);
    }

    public function byType($type) {
        $result = array();
        foreach ($this->templates as $template) {
            if ($template['type'] === $type) $result[] = $template;
        }
        return $result;
    }
}
