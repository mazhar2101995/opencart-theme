<?php
/**
 * Builder document schema helpers.
 *
 * The schema is intentionally simple in v0.2:
 * root -> section -> container -> column -> widget
 *
 * Later versions can add flex/grid/container variants without
 * changing the fundamental document model.
 */
class NextGenDocumentSchema {
    public static function emptyDocument() {
        return array(
            'version' => 1,
            'type' => 'root',
            'children' => array()
        );
    }

    public static function starterDocument() {
        return array(
            'version' => 2,
            'type' => 'root',
            'children' => array(
                array(
                    'id' => 'section_1',
                    'type' => 'section',
                    'settings' => array(),
                    'children' => array(
                        array(
                            'id' => 'container_1',
                            'type' => 'container',
                            'settings' => array(
                                'layout' => 'flex',
                                'widthMode' => 'boxed',
                                'width' => '100%',
                                'maxWidth' => '1320px',
                                'gap' => '24px',
                                'direction' => 'column',
                                'gridColumnCount' => 1,
                                'gridColumns' => 'repeat(1,minmax(0,1fr))'
                            ),
                            'children' => array(
                                array(
                                    'id' => 'heading_1',
                                    'type' => 'heading',
                                    'settings' => array('text' => 'Build your OpenCart store'),
                                    'children' => array()
                                )
                            )
                        )
                    )
                )
            )
        );
    }

}
