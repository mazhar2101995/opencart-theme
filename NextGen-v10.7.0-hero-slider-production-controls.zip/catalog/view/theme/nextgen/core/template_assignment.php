<?php
/**
 * Template assignment evaluator.
 *
 * Specificity:
 * 1. exact route
 * 2. template type
 * 3. condition match
 * 4. priority
 *
 * Assignment is presentation routing only; OpenCart controller authorization
 * remains authoritative.
 */
class NextGenTemplateAssignment {
    protected $conditionEngine;

    public function __construct($conditionEngine = null) {
        $this->conditionEngine = $conditionEngine;
    }

    public function choose(array $assignments, array $context = array()) {
        $matches = array();

        foreach ($assignments as $assignment) {
            if (!$this->matches($assignment, $context)) continue;

            $matches[] = $assignment;
        }

        if (!$matches) return null;

        usort($matches, array($this, 'compare'));
        return $matches[0];
    }

    protected function matches(array $assignment, array $context) {
        if (!empty($assignment['route']) && !empty($context['route'])) {
            if ($assignment['route'] !== $context['route']) return false;
        }

        if (!empty($assignment['store_id']) && isset($context['store_id'])) {
            if ((string)$assignment['store_id'] !== (string)$context['store_id']) return false;
        }

        if (!empty($assignment['language']) && isset($context['language'])) {
            if ($assignment['language'] !== $context['language']) return false;
        }

        if (!empty($assignment['conditions']) && $this->conditionEngine) {
            if (!$this->conditionEngine->evaluate($assignment['conditions'], $context)) {
                return false;
            }
        }

        return true;
    }

    protected function compare($a, $b) {
        $pa = isset($a['priority']) ? (int)$a['priority'] : 0;
        $pb = isset($b['priority']) ? (int)$b['priority'] : 0;

        if ($pa === $pb) {
            $ra = !empty($a['route']) ? 1 : 0;
            $rb = !empty($b['route']) ? 1 : 0;
            return $rb <=> $ra;
        }

        return $pb <=> $pa;
    }
}
