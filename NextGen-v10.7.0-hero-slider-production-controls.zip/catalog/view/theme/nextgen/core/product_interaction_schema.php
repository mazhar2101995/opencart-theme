<?php
class NextGenProductInteractionSchema {
    public static function defaults() {
        return array(
            'quantity' => 1,
            'option_values' => array(),
            'quick_view' => array(
                'enabled' => true,
                'load' => 'ajax'
            ),
            'gallery' => array(
                'enabled' => true,
                'arrows' => true,
                'dots' => false,
                'swipe' => true,
                'autoplay' => false,
                'autoplay_speed' => 4000,
                'loop' => true
            )
        );
    }
}
