<?php
/**
 * Coordinates validation, normalization and persistence.
 */
class NextGenDocumentManager {
    protected $repository;
    protected $validator;
    protected $schema;

    public function __construct($repository, $validator, $schema) {
        $this->repository = $repository;
        $this->validator = $validator;
        $this->schema = $schema;
    }

    public function createStarter($name, $route = '') {
        return $this->save(array(
            'name' => $name,
            'route' => $route,
            'template_type' => 'page',
            'document' => $this->schema->starterDocument()
        ));
    }

    public function save($data) {
        $document = isset($data['document']) ? $data['document'] : $this->schema->emptyDocument();

        $errors = $this->validator->validate($document);

        if ($errors) {
            return array(
                'success' => false,
                'errors' => $errors
            );
        }

        $id = $this->repository->save(array(
            'document_id' => isset($data['document_id']) ? $data['document_id'] : 0,
            'name' => isset($data['name']) ? $data['name'] : 'Untitled',
            'route' => isset($data['route']) ? $data['route'] : '',
            'template_type' => isset($data['template_type']) ? $data['template_type'] : 'page',
            'status' => isset($data['status']) ? $data['status'] : 1,
            'document' => $document
        ));

        return array(
            'success' => true,
            'document_id' => $id
        );
    }
}
