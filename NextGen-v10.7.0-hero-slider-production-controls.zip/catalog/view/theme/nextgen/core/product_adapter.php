<?php
/**
 * NextGen Product Adapter.
 *
 * Normalizes OpenCart product arrays into a stable presentation contract.
 * Commerce/business rules remain in OpenCart models/controllers.
 */
class NextGenProductAdapter {
    public function normalize(array $product) {
        return array(
            'product_id' => isset($product['product_id']) ? (int)$product['product_id'] : 0,
            'name' => isset($product['name']) ? $product['name'] : '',
            'model' => isset($product['model']) ? $product['model'] : '',
            'image' => isset($product['image']) ? $product['image'] : '',
            'images' => isset($product['images']) && is_array($product['images']) ? $product['images'] : array(),
            'manufacturer' => isset($product['manufacturer']) ? $product['manufacturer'] : '',
            'price' => isset($product['price']) ? $product['price'] : '',
            'special' => isset($product['special']) ? $product['special'] : '',
            'tax' => isset($product['tax']) ? $product['tax'] : '',
            'rating' => isset($product['rating']) ? (float)$product['rating'] : 0,
            'reviews' => isset($product['reviews']) ? (int)$product['reviews'] : 0,
            'href' => isset($product['href']) ? $product['href'] : '#',
            'stock_status' => isset($product['stock_status']) ? $product['stock_status'] : '',
            'quantity' => isset($product['quantity']) ? (int)$product['quantity'] : null,
            'options' => isset($product['options']) && is_array($product['options']) ? $product['options'] : array(),
            'labels' => isset($product['labels']) && is_array($product['labels']) ? $product['labels'] : array(),
            'is_new' => !empty($product['is_new']),
            'is_featured' => !empty($product['is_featured']),
            'is_special' => !empty($product['special'])
        );
    }

    public function normalizeCollection(array $products) {
        $result = array();
        foreach ($products as $product) {
            if (is_array($product)) {
                $result[] = $this->normalize($product);
            }
        }
        return $result;
    }
}
