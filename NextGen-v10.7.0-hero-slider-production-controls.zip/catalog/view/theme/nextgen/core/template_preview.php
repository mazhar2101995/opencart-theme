<?php
/**
 * Preview context builder.
 *
 * Preview uses sample presentation context only. It does not authorize,
 * create orders, modify carts or execute payment/shipping actions.
 */
class NextGenTemplatePreview {
    public function build($templateType, array $overrides = array()) {
        $context = array(
            'route' => 'common/home',
            'language' => 'en-gb',
            'store_id' => 0,
            'device' => 'desktop',
            'template_type' => $templateType
        );

        return array_replace_recursive($context, $overrides);
    }
}
