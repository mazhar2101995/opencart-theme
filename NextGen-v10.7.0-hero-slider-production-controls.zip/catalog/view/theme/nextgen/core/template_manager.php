<?php
/**
 * Presentation template manager.
 *
 * This class combines registered templates, assignments and global parts.
 * It is intentionally independent of OpenCart commerce controllers.
 */
class NextGenTemplateManager {
    protected $registry;
    protected $assignment;
    protected $parts;

    public function __construct($registry, $assignment, $parts) {
        $this->registry = $registry;
        $this->assignment = $assignment;
        $this->parts = $parts;
    }

    public function resolve($templateType, array $assignments, array $context = array()) {
        $available = $this->registry->byType($templateType);
        $availableIds = array();

        foreach ($available as $template) {
            $availableIds[] = $template['id'];
        }

        $match = $this->assignment->choose($assignments, $context);

        if ($match && in_array($match['template_id'], $availableIds, true)) {
            return $this->registry->get($match['template_id']);
        }

        return $available ? $available[0] : null;
    }

    public function resolveGlobal($type) {
        $parts = $this->parts->all($type);
        return $parts ? $parts[0] : null;
    }
}
