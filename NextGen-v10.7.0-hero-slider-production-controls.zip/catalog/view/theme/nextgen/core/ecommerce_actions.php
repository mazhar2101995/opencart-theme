<?php
/**
 * NextGen Ecommerce Action Contract.
 *
 * Presentation widgets emit action intents. This adapter describes the
 * OpenCart endpoint contract without embedding checkout/business logic.
 */
class NextGenEcommerceActions {
    public function definitions() {
        return array(
            'add_to_cart' => array(
                'event' => 'nextgen:add-to-cart',
                'endpoint' => 'index.php?route=checkout/cart/add',
                'method' => 'POST'
            ),
            'wishlist' => array(
                'event' => 'nextgen:wishlist',
                'endpoint' => 'index.php?route=account/wishlist/add',
                'method' => 'POST'
            ),
            'compare' => array(
                'event' => 'nextgen:compare',
                'endpoint' => 'index.php?route=product/compare/add',
                'method' => 'POST'
            ),
            'quick_view' => array(
                'event' => 'nextgen:quick-view',
                'endpoint' => 'index.php?route=product/product/quickview',
                'method' => 'GET'
            )
        );
    }
}
