<?php
/**
 * Product Card schema.
 *
 * The card is deliberately configuration-driven so the same component can
 * power grids, lists, carousels, featured/latest/special collections, etc.
 */
class NextGenProductCardSchema {
    public static function defaults() {
        return array(
            'image_mode' => 'single',
            'show_brand' => true,
            'show_rating' => true,
            'show_price' => true,
            'show_stock' => false,
            'show_labels' => true,
            'show_model' => false,
            'show_quick_view' => true,
            'show_add_to_cart' => true,
            'show_wishlist' => true,
            'show_compare' => true,
            'show_quantity' => false,
            'hover_image' => true,
            'image_arrows' => false,
            'image_dots' => false,
            'image_swipe' => true,
            'image_autoplay' => false,
            'action_style' => 'icon',
            'action_position' => 'overlay',
            'card_layout' => 'vertical'
        );
    }
}
