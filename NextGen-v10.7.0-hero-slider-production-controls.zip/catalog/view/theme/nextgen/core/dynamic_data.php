<?php
/**
 * NextGen Dynamic Data Provider Registry.
 *
 * Providers are read-only presentation data sources. They must not be used
 * for authorization or permission decisions.
 */
class NextGenDynamicData {
    protected $providers = array();

    public function register($id, $label, $callback, array $meta = array()) {
        if (!$id || !is_callable($callback)) {
            return false;
        }

        $this->providers[$id] = array(
            'id'       => $id,
            'label'    => $label ?: $id,
            'callback' => $callback,
            'meta'     => $meta
        );

        return true;
    }

    public function has($id) {
        return isset($this->providers[$id]);
    }

    public function listProviders() {
        $result = array();

        foreach ($this->providers as $provider) {
            $result[] = array(
                'id' => $provider['id'],
                'label' => $provider['label'],
                'meta' => $provider['meta']
            );
        }

        return $result;
    }

    public function resolve($id, array $context = array()) {
        if (!$this->has($id)) {
            return null;
        }

        try {
            return call_user_func($this->providers[$id]['callback'], $context);
        } catch (Exception $e) {
            return null;
        }
    }
}
