<?php
/**
 * Default dynamic data definitions.
 *
 * The callbacks intentionally depend on the supplied context. Controllers
 * can populate product/category/customer/cart/store values without making
 * the builder aware of OpenCart controllers.
 */
class NextGenDefaultDynamicData {
    public static function register(NextGenDynamicData $registry) {
        $registry->register('product.name', 'Product Name', function($ctx) {
            return isset($ctx['product']['name']) ? $ctx['product']['name'] : null;
        }, array('type'=>'text','group'=>'product'));

        $registry->register('product.price', 'Product Price', function($ctx) {
            return isset($ctx['product']['price']) ? $ctx['product']['price'] : null;
        }, array('type'=>'price','group'=>'product'));

        $registry->register('product.special', 'Product Special Price', function($ctx) {
            return isset($ctx['product']['special']) ? $ctx['product']['special'] : null;
        }, array('type'=>'price','group'=>'product'));

        $registry->register('product.image', 'Product Image', function($ctx) {
            return isset($ctx['product']['image']) ? $ctx['product']['image'] : null;
        }, array('type'=>'image','group'=>'product'));

        $registry->register('product.model', 'Product Model', function($ctx) {
            return isset($ctx['product']['model']) ? $ctx['product']['model'] : null;
        }, array('type'=>'text','group'=>'product'));

        $registry->register('product.manufacturer', 'Product Manufacturer', function($ctx) {
            return isset($ctx['product']['manufacturer']) ? $ctx['product']['manufacturer'] : null;
        }, array('type'=>'text','group'=>'product'));

        $registry->register('category.name', 'Category Name', function($ctx) {
            return isset($ctx['category']['name']) ? $ctx['category']['name'] : null;
        }, array('type'=>'text','group'=>'category'));

        $registry->register('category.image', 'Category Image', function($ctx) {
            return isset($ctx['category']['image']) ? $ctx['category']['image'] : null;
        }, array('type'=>'image','group'=>'category'));

        $registry->register('customer.firstname', 'Customer First Name', function($ctx) {
            return isset($ctx['customer']['firstname']) ? $ctx['customer']['firstname'] : null;
        }, array('type'=>'text','group'=>'customer'));

        $registry->register('cart.total', 'Cart Total', function($ctx) {
            return isset($ctx['cart']['total']) ? $ctx['cart']['total'] : null;
        }, array('type'=>'price','group'=>'cart'));

        $registry->register('store.name', 'Store Name', function($ctx) {
            return isset($ctx['store']['name']) ? $ctx['store']['name'] : null;
        }, array('type'=>'text','group'=>'store'));

        $registry->register('route', 'Current Route', function($ctx) {
            return isset($ctx['route']) ? $ctx['route'] : null;
        }, array('type'=>'text','group'=>'system'));

        $registry->register('language', 'Current Language', function($ctx) {
            return isset($ctx['language']) ? $ctx['language'] : null;
        }, array('type'=>'text','group'=>'system'));
    }
}
