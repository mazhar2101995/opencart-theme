(function(){'use strict';
function init(root){
 root.querySelectorAll('[data-ng-premium-slider]').forEach(function(slider){
  if(slider.__ngInit)return; slider.__ngInit=true;
  var track=slider.querySelector('.ng-premium-slider-track'), slides=[].slice.call(slider.querySelectorAll('.ng-premium-slide')),
      prev=slider.querySelector('.ng-premium-slider-prev'), next=slider.querySelector('.ng-premium-slider-next'),
      dots=[].slice.call(slider.querySelectorAll('.ng-premium-slider-dots button')), progress=slider.querySelector('.ng-premium-slider-progress span'),
      index=0, timer=null, startedAt=0, touchStartX=0, touchStartY=0, dragging=false,
      interval=Math.max(500,parseInt(slider.getAttribute('data-interval')||'5000',10)), speed=Math.max(100,parseInt(slider.getAttribute('data-speed')||'650',10)),
      transition=slider.getAttribute('data-transition')||'slide', loop=slider.getAttribute('data-loop')==='1';
  slider.style.setProperty('--ng-slider-speed',speed+'ms');
  function updateUI(){dots.forEach(function(d,j){d.classList.toggle('active',j===index);d.setAttribute('aria-selected',j===index?'true':'false');});slides.forEach(function(s,j){s.classList.toggle('is-active',j===index);});}
  function go(i){if(!slides.length)return; if(loop){index=(i+slides.length)%slides.length;}else{index=Math.max(0,Math.min(slides.length-1,i));} if(transition==='fade'){track.style.transform='none';}else{track.style.transform='translate3d('+(-index*100)+'%,0,0)';} updateUI(); resetProgress(); playActiveVideo();}
  function playActiveVideo(){slides.forEach(function(slide,j){var v=slide.querySelector('video');if(!v)return;if(j===index){v.play().catch(function(){});}else{v.pause();}});}
  function stop(){if(timer){clearInterval(timer);timer=null;} if(progress){progress.style.transition='none';progress.style.transform='scaleX(0)';}}
  function start(){if(slider.getAttribute('data-autoplay')!=='1'||slides.length<2)return;stop();startedAt=Date.now();if(progress){progress.style.transform='scaleX(0)';requestAnimationFrame(function(){progress.style.transition='transform '+interval+'ms linear';progress.style.transform='scaleX(1)';});}timer=setInterval(function(){go(index+1);},interval);}
  function resetProgress(){if(!progress)return;progress.style.transition='none';progress.style.transform='scaleX(0)';if(slider.getAttribute('data-autoplay')==='1')requestAnimationFrame(function(){progress.style.transition='transform '+interval+'ms linear';progress.style.transform='scaleX(1)';});}
  if(prev)prev.addEventListener('click',function(){go(index-1);start();});
  if(next)next.addEventListener('click',function(){go(index+1);start();});
  dots.forEach(function(d){d.addEventListener('click',function(){go(parseInt(d.getAttribute('data-slide')||'0',10));start();});});
  if(slider.getAttribute('data-pause-hover')==='1'){slider.addEventListener('mouseenter',stop);slider.addEventListener('mouseleave',start);}
  if(slider.getAttribute('data-keyboard')==='1'){slider.setAttribute('tabindex','0');slider.addEventListener('keydown',function(e){if(e.key==='ArrowLeft'){e.preventDefault();go(index-1);start();}if(e.key==='ArrowRight'){e.preventDefault();go(index+1);start();}if(e.key==='Home'){e.preventDefault();go(0);start();}if(e.key==='End'){e.preventDefault();go(slides.length-1);start();}});}
  if(slider.getAttribute('data-swipe')==='1'){
   slider.addEventListener('touchstart',function(e){if(!e.touches[0])return;touchStartX=e.touches[0].clientX;touchStartY=e.touches[0].clientY;dragging=true;stop();},{passive:true});
   slider.addEventListener('touchend',function(e){if(!dragging||!e.changedTouches[0])return;dragging=false;var dx=e.changedTouches[0].clientX-touchStartX,dy=e.changedTouches[0].clientY-touchStartY;if(Math.abs(dx)>45&&Math.abs(dx)>Math.abs(dy)){go(dx<0?index+1:index-1);}start();},{passive:true});
  }
  go(0);start();
 });
}
document.addEventListener('click',function(e){var a=e.target.closest&&e.target.closest('[data-ng-lightbox]');if(!a)return;e.preventDefault();var ov=document.createElement('div');ov.className='ng-premium-lightbox';var img=document.createElement('img');img.src=a.getAttribute('href');ov.appendChild(img);ov.addEventListener('click',function(){ov.remove();});document.body.appendChild(ov);});
document.addEventListener('DOMContentLoaded',function(){init(document);});
window.NextGenPremiumWidgets={init:init};
})();
