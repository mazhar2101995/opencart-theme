(function(){
'use strict';

document.addEventListener('keydown',function(event){
    if(event.key!=='Escape') return;
    document.querySelectorAll('.ng-mega-menu').forEach(function(menu){
        menu.removeAttribute('data-ng-open');
    });
});

document.addEventListener('click',function(event){
    var trigger=event.target.closest('[data-ng-mobile-menu]');
    if(!trigger) return;
    var nav=document.querySelector('.ng-storefront-nav');
    if(nav) nav.classList.toggle('ng-mobile-open');
});

var search=document.querySelector('[data-ng-search]');
if(search){
    var input=search.querySelector('input');
    if(input){
        input.addEventListener('input',function(){
            var min=parseInt(search.getAttribute('data-min-chars')||'2',10);
            if(input.value.length<min) return;
            search.dispatchEvent(new CustomEvent('ng:search-suggestions',{
                detail:{query:input.value}
            }));
        });
    }
}
})();
