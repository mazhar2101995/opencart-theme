(function(){
  'use strict';

  function quantity(card){
    var input=card.querySelector('[data-ng-quantity]');
    var value=input ? parseInt(input.value,10) : 1;
    return isNaN(value) || value < 1 ? 1 : value;
  }

  function options(card){
    var result={};
    card.querySelectorAll('select[name^="option["]').forEach(function(select){
      var match=select.name.match(/option\[(\d+)\]/);
      if(match) result[match[1]]=select.value;
    });
    return result;
  }

  function contract(action,card){
    var id=card.getAttribute('data-product-id');
    var payload={
      product_id:parseInt(id,10),
      quantity:quantity(card),
      options:options(card)
    };

    if(action==='add-to-cart') {
      payload.route='checkout/cart/add';
      payload.method='POST';
    } else if(action==='buy-now') {
      payload.route='checkout/cart/add';
      payload.method='POST';
      payload.after_success='checkout/cart';
    } else if(action==='wishlist') {
      payload.route='account/wishlist/add';
      payload.method='POST';
    } else if(action==='compare') {
      payload.route='product/compare/add';
      payload.method='POST';
    } else if(action==='quick-view') {
      payload.route='product/product/quickview';
      payload.method='GET';
    }

    return payload;
  }

  document.addEventListener('click',function(event){
    var control=event.target.closest('[data-ng-action]');
    if(!control) return;

    var card=control.closest('.ng-product-card--production');
    if(!card) return;

    var action=control.getAttribute('data-ng-action');
    var payload=contract(action,card);

    /*
     * Integration contract:
     * production adapter may intercept this event and submit through
     * the site's existing OpenCart AJAX/cart implementation.
     */
    card.dispatchEvent(new CustomEvent('nextgen:product-action',{
      bubbles:true,
      detail:payload
    }));
  });
})();
