(function(){
  'use strict';

  function serializeOptions(card){
    var data={};
    card.querySelectorAll('select[name^="option["],input[name^="option["],textarea[name^="option["]').forEach(function(input){
      if(!input.name) return;
      data[input.name]=input.value;
    });
    return data;
  }

  function request(url,method,data){
    var options={method:method || 'POST',headers:{'X-Requested-With':'XMLHttpRequest'}};

    if(options.method==='GET'){
      var query=new URLSearchParams(data || {}).toString();
      if(query) url+=(url.indexOf('?')>=0?'&':'?')+query;
    } else {
      var form=new URLSearchParams(data || {});
      options.headers['Content-Type']='application/x-www-form-urlencoded; charset=UTF-8';
      options.body=form.toString();
    }

    return fetch(url,options).then(function(response){
      return response.text().then(function(text){
        var payload=null;
        try { payload=JSON.parse(text); } catch(e) {}
        return {ok:response.ok,status:response.status,data:payload,text:text};
      });
    });
  }

  function setBusy(card,busy){
    if(!card) return;
    card.classList.toggle('ng-is-loading',busy);
    card.querySelectorAll('[data-ng-action]').forEach(function(button){
      button.disabled=busy;
    });
  }

  function refreshCart(){
    document.dispatchEvent(new CustomEvent('nextgen:cart-refresh'));
  }

  function showQuickView(html){
    var existing=document.querySelector('.ng-quick-view-modal');
    if(existing) existing.remove();

    var modal=document.createElement('div');
    modal.className='ng-quick-view-modal';
    modal.innerHTML='<div class="ng-quick-view-modal__backdrop" data-ng-close></div>'+
      '<div class="ng-quick-view-modal__dialog" role="dialog" aria-modal="true">'+
      '<button type="button" class="ng-quick-view-modal__close" data-ng-close aria-label="Close">×</button>'+
      '<div class="ng-quick-view-modal__content">'+html+'</div></div>';

    document.body.appendChild(modal);

    modal.querySelectorAll('[data-ng-close]').forEach(function(button){
      button.addEventListener('click',function(){ modal.remove(); });
    });

    document.addEventListener('keydown',function handler(event){
      if(event.key==='Escape'){
        if(document.body.contains(modal)) modal.remove();
        document.removeEventListener('keydown',handler);
      }
    });
  }

  document.addEventListener('nextgen:product-action',function(event){
    var detail=event.detail || {};
    var card=event.target.closest('.ng-product-card--production');
    if(!card || !detail.route) return;

    var id=card.getAttribute('data-product-id');
    var quantity=1;
    var quantityInput=card.querySelector('[data-ng-quantity]');
    if(quantityInput) quantity=Math.max(1,parseInt(quantityInput.value,10) || 1);

    var data=detail.data || {};
    if(detail.route==='checkout/cart/add'){
      data.product_id=parseInt(id,10);
      data.quantity=quantity;
      Object.assign(data,serializeOptions(card));
    } else {
      data.product_id=parseInt(id,10);
    }

    var url='index.php?route='+encodeURIComponent(detail.route);
    setBusy(card,true);

    request(url,detail.method || 'POST',data).then(function(result){
      if(detail.route==='product/product/quickview'){
        if(result.ok) showQuickView(result.data && result.data.html ? result.data.html : result.text);
        return;
      }

      if(result.data && result.data.redirect){
        window.location.href=result.data.redirect;
        return;
      }

      if(detail.route==='checkout/cart/add'){
        refreshCart();
      }

      card.dispatchEvent(new CustomEvent('nextgen:product-response',{
        bubbles:true,
        detail:result
      }));
    }).catch(function(error){
      card.dispatchEvent(new CustomEvent('nextgen:product-error',{
        bubbles:true,
        detail:{error:error}
      }));
    }).finally(function(){
      setBusy(card,false);
    });
  });

  document.addEventListener('nextgen:cart-refresh',function(){
    /*
     * Adapter event for the existing OpenCart theme/cart component.
     * A theme-specific cart provider can listen here and refresh its
     * count, subtotal and mini-cart markup without replacing checkout logic.
     */
  });
})();
