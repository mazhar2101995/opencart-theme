(function(){
  'use strict';
  document.documentElement.classList.add('ng-widget-runtime-ready');
})();
