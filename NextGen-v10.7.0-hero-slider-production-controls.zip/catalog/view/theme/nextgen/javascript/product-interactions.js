(function(){
'use strict';

function post(url,data){
    return fetch(url,{
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},
        body:new URLSearchParams(data).toString()
    }).then(function(r){return r.text();});
}

document.addEventListener('click',function(event){
    var action=event.target.closest('[data-ng-action]');
    if(!action) return;

    var type=action.getAttribute('data-ng-action');
    var id=action.getAttribute('data-product-id');
    if(!id) return;

    if(type==='cart'){
        var quantity=1;
        var page=action.closest('.ng-product-page');
        var input=page && page.querySelector('.ng-product-quantity');
        if(input) quantity=Math.max(1,parseInt(input.value||'1',10));

        var options={product_id:id,quantity:quantity};
        if(page){
            page.querySelectorAll('[data-ng-option]').forEach(function(field){
                var optionId=field.getAttribute('data-ng-option');
                if(optionId) options['option['+optionId+']']=field.value;
            });
        }
        post('index.php?route=checkout/cart/add',options).then(function(){
            action.setAttribute('data-ng-state','added');
        });
    }

    if(type==='wishlist'){
        post('index.php?route=account/wishlist/add',{product_id:id}).then(function(){
            action.setAttribute('data-ng-state','active');
        });
    }

    if(type==='compare'){
        post('index.php?route=product/compare/add',{product_id:id}).then(function(){
            action.setAttribute('data-ng-state','active');
        });
    }

    if(type==='quick-view'){
        post('index.php?route=product/product/quickview',{product_id:id}).then(function(html){
            var modal=document.querySelector('.ng-quick-view-modal');
            if(!modal){
                modal=document.createElement('div');
                modal.className='ng-quick-view-modal';
                document.body.appendChild(modal);
            }
            modal.innerHTML='<div class="ng-quick-view-modal__backdrop"></div><div class="ng-quick-view-modal__dialog">'+html+'</div>';
            modal.hidden=false;
        });
    }
});

document.addEventListener('click',function(event){
    if(event.target.matches('.ng-quick-view-modal__backdrop,.ng-quick-view-close')){
        var modal=document.querySelector('.ng-quick-view-modal');
        if(modal) modal.hidden=true;
    }
});

document.addEventListener('keydown',function(event){
    if(event.key==='Escape'){
        var modal=document.querySelector('.ng-quick-view-modal');
        if(modal) modal.hidden=true;
    }
});

document.addEventListener('click',function(event){
    var thumb=event.target.closest('[data-ng-gallery-src]');
    if(!thumb) return;
    var gallery=thumb.closest('[data-ng-gallery]');
    if(!gallery) return;
    var image=gallery.querySelector('[data-ng-gallery-main]');
    if(image) image.src=thumb.getAttribute('data-ng-gallery-src');
});
})();
