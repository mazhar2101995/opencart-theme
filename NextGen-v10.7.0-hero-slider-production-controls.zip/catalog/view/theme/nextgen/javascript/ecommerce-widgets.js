(function(){
'use strict';
document.addEventListener('click',function(event){
    var button=event.target.closest('.ng-add-to-cart');
    if(!button) return;

    var productId=button.getAttribute('data-product-id');
    if(!productId) return;

    var quantity=1;
    var page=button.closest('.ng-product-page');
    if(page){
        var input=page.querySelector('.ng-product-quantity');
        if(input) quantity=Math.max(1,parseInt(input.value||'1',10));
    }

    var body='product_id='+encodeURIComponent(productId)+'&quantity='+encodeURIComponent(quantity);

    fetch('index.php?route=checkout/cart/add',{
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},
        body:body
    }).then(function(response){
        return response.text();
    }).then(function(){
        button.setAttribute('data-added','1');
    }).catch(function(){});
});
})();
