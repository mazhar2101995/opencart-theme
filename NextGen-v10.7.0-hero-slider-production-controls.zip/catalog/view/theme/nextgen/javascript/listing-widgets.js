(function(){
'use strict';

function updateQuery(key,value){
    var url=new URL(window.location.href);
    if(value) url.searchParams.set(key,value);
    else url.searchParams.delete(key);
    window.location.href=url.toString();
}

document.addEventListener('change',function(event){
    var sort=event.target.closest('[data-ng-sort]');
    if(sort){
        updateQuery('sort',sort.value);
        return;
    }

    var filter=event.target.closest('[data-ng-filter]');
    if(filter){
        var key=filter.getAttribute('data-ng-filter');
        if(key) updateQuery(key,filter.value);
    }
});
})();
