(function(){
  'use strict';

  document.addEventListener('click', function(event){
    var button=event.target.closest('.ng-product-card__add');
    if(!button) return;

    var productId=button.getAttribute('data-product-id');
    if(!productId) return;

    /* Integration contract only. Actual OpenCart cart behavior remains server-owned. */
    button.setAttribute('data-nextgen-cart-ready','1');
  });
})();
