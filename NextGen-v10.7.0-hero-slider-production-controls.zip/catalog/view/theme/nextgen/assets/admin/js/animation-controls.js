(function (window, document) {
    'use strict';

    window.NextGenAnimationControls = {
        presets: [
            ['fade','Fade'],['fade-up','Fade Up'],['fade-down','Fade Down'],
            ['fade-left','Fade Left'],['fade-right','Fade Right'],
            ['zoom-in','Zoom In'],['zoom-out','Zoom Out'],
            ['slide-up','Slide Up'],['slide-down','Slide Down'],
            ['slide-left','Slide Left'],['slide-right','Slide Right']
        ],

        defaults: {
            enabled: false,
            preset: 'fade-up',
            trigger: 'viewport',
            duration: 600,
            delay: 0,
            easing: 'ease',
            once: true,
            distance: 24,
            threshold: 0.15
        },

        normalize: function (value) {
            var result = Object.assign({}, this.defaults, value || {});
            result.duration = Math.max(50, Math.min(5000, Number(result.duration) || 600));
            result.delay = Math.max(0, Math.min(5000, Number(result.delay) || 0));
            result.distance = Math.max(0, Math.min(300, Number(result.distance) || 24));
            result.threshold = Math.max(0, Math.min(1, Number(result.threshold)));
            return result;
        }
    };
})(window, document);
