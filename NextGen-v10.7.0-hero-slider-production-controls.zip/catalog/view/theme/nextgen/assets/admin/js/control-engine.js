(function (window, document) {
    'use strict';

    window.NextGenControls = {
        devices: ['desktop', 'tablet', 'mobile'],
        state: 'default',

        getValue: function (settings, control) {
            var value = settings && settings[control.id];
            if (value === undefined) return control.default !== undefined ? control.default : '';
            return value;
        },

        setValue: function (settings, control, value, device, state) {
            device = device || 'desktop';
            state = state || 'default';

            if (!settings[control.id]) settings[control.id] = {};

            if (control.responsive) {
                if (!settings[control.id].responsive) settings[control.id].responsive = {};
                if (!settings[control.id].responsive[device]) settings[control.id].responsive[device] = {};
                settings[control.id].responsive[device][state] = value;
            } else if (control.states && control.states.length > 1) {
                if (!settings[control.id].states) settings[control.id].states = {};
                settings[control.id].states[state] = value;
            } else {
                settings[control.id].value = value;
            }
            return settings;
        },

        renderControl: function (control, value, onChange) {
            var wrap = document.createElement('div');
            wrap.className = 'ng-control ng-control-' + control.type;
            wrap.dataset.controlId = control.id;

            var label = document.createElement('label');
            label.textContent = control.label || control.id;
            wrap.appendChild(label);

            var input;
            if (control.type === 'select' || control.type === 'button_group') {
                input = document.createElement('select');
                (control.options || []).forEach(function (option) {
                    var o = document.createElement('option');
                    o.value = option;
                    o.textContent = option;
                    if (String(option) === String(value)) o.selected = true;
                    input.appendChild(o);
                });
            } else if (control.type === 'textarea' || control.type === 'code') {
                input = document.createElement('textarea');
                input.value = value || '';
            } else if (control.type === 'range') {
                input = document.createElement('input');
                input.type = 'range';
                input.min = control.min !== undefined ? control.min : 0;
                input.max = control.max !== undefined ? control.max : 100;
                input.step = control.step !== undefined ? control.step : 1;
                input.value = value !== '' ? value : input.min;
            } else if (control.type === 'color') {
                input = document.createElement('input');
                input.type = 'text';
                input.placeholder = '#000000';
                input.value = value || '';
            } else {
                input = document.createElement('input');
                input.type = 'text';
                input.value = value || '';
                if (control.placeholder) input.placeholder = control.placeholder;
            }

            input.addEventListener('change', function () {
                onChange(control, input.value);
            });
            wrap.appendChild(input);
            return wrap;
        }
    };
})(window, document);
