(function (window, document) {
    'use strict';

    window.NextGenTemplateManagerUI = {
        state: {
            selectedType: 'page',
            selectedTemplate: null,
            assignments: [],
            parts: []
        },

        selectType: function (type) {
            this.state.selectedType = type;
            return type;
        },

        selectTemplate: function (template) {
            this.state.selectedTemplate = template || null;
            return this.state.selectedTemplate;
        },

        addAssignment: function (assignment) {
            if (!assignment || !assignment.template_id) return false;
            this.state.assignments.push(assignment);
            return assignment;
        },

        removeAssignment: function (templateId) {
            this.state.assignments = this.state.assignments.filter(function (item) {
                return item.template_id !== templateId;
            });
        },

        setGlobalPart: function (part) {
            if (!part || !part.type) return false;
            this.state.parts = this.state.parts.filter(function (item) {
                return item.type !== part.type;
            });
            this.state.parts.push(part);
            return part;
        }
    };
})(window, document);
