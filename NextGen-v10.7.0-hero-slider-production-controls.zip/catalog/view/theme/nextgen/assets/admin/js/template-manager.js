(function (window, document) {
    'use strict';

    window.NextGenTemplateManager = {
        types: ['header','footer','page','product','category','search','manufacturer','information','cart','account','checkout','error','landing','popup'],

        createAssignment: function (templateId, options) {
            options = options || {};
            return {
                template_id: templateId,
                route: options.route || '',
                store_id: options.store_id || '',
                language: options.language || '',
                priority: Number(options.priority || 0),
                conditions: options.conditions || {relation:'AND', rules:[]}
            };
        },

        validateAssignment: function (assignment) {
            if (!assignment || !assignment.template_id) return false;
            if (assignment.priority !== undefined && isNaN(Number(assignment.priority))) return false;
            return true;
        }
    };
})(window, document);
