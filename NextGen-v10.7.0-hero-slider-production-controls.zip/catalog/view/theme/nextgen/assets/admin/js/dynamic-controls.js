(function (window, document) {
    'use strict';

    window.NextGenDynamicControls = {
        providers: [],

        setProviders: function (providers) {
            this.providers = Array.isArray(providers) ? providers : [];
        },

        binding: function (provider, fallback) {
            return {
                dynamic: true,
                provider: provider,
                fallback: fallback === undefined ? '' : fallback
            };
        },

        renderButton: function (currentValue, onBind) {
            var button = document.createElement('button');
            button.type = 'button';
            button.className = 'ng-dynamic-button';
            button.textContent = currentValue && currentValue.dynamic ? 'Dynamic: ' + currentValue.provider : 'fx Dynamic';
            button.addEventListener('click', function () {
                onBind();
            });
            return button;
        },

        providerOptions: function (group) {
            return this.providers.filter(function (provider) {
                return !group || !provider.meta || provider.meta.group === group;
            });
        }
    };
})(window, document);
