/**
 * Storefront builder runtime.
 *
 * v0.2 intentionally contains no editor/runtime dependency.
 * This file is reserved for lightweight enhancements needed by
 * rendered builder widgets.
 */
(function () {
  'use strict';

  window.NextGenTheme = window.NextGenTheme || {};
  window.NextGenTheme.version = '0.2.0';
})();
