(function () {
  'use strict';

  function applyTokenPreview(root) {
    var nodes = (root || document).querySelectorAll('[data-nextgen-token]');
    nodes.forEach(function (node) {
      var token = node.getAttribute('data-nextgen-token');
      if (!token) return;
      node.style.setProperty(
        '--nextgen-active-token',
        'var(--ng-' + token + ')'
      );
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      applyTokenPreview(document);
    });
  } else {
    applyTokenPreview(document);
  }
})();
