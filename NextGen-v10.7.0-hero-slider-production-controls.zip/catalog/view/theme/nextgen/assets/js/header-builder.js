(function () {
  'use strict';

  function debounce(fn, wait) {
    var timer;
    return function () {
      var args = arguments, ctx = this;
      clearTimeout(timer);
      timer = setTimeout(function () { fn.apply(ctx, args); }, wait);
    };
  }

  document.addEventListener('click', function (event) {
    var toggle = event.target.closest('[data-mobile-menu-toggle]');
    if (toggle) {
      var drawer = document.querySelector('[data-mobile-menu-drawer]');
      if (!drawer) return;
      var open = drawer.classList.toggle('is-open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    }
  });

  document.addEventListener('click', function (event) {
    var trigger = event.target.closest('[data-mega-menu-toggle]');
    if (!trigger) return;
    var menu = trigger.parentElement && trigger.parentElement.querySelector('.ng-mega-menu');
    if (!menu) return;
    menu.classList.toggle('is-open');
  });

  document.querySelectorAll('.ng-header-search').forEach(function (form) {
    var input = form.querySelector('input[name="search"]');
    var box = form.parentElement.querySelector('.ng-header-search-suggestions');
    if (!input || !box) return;

    var load = debounce(function () {
      var q = input.value.trim();
      if (q.length < 2) {
        box.innerHTML = '';
        return;
      }

      var url = 'index.php?route=product/search/suggestion&search=' + encodeURIComponent(q) + '&limit=8';
      fetch(url, {credentials:'same-origin'})
        .then(function (r) { return r.json().catch(function(){ return []; }); })
        .then(function (items) {
          if (!Array.isArray(items)) items = [];
          box.innerHTML = items.map(function (item) {
            return '<a href="' + (item.href || '#') + '">' + (item.name || '') + '</a>';
          }).join('');
        })
        .catch(function () { box.innerHTML = ''; });
    }, 180);

    input.addEventListener('input', load);
  });

  var sticky = document.querySelector('[data-sticky-header="1"]');
  if (sticky) {
    var header = sticky.parentElement;
    if (header) {
      header.classList.add('ng-sticky-header-active');
      var offset = parseInt(sticky.getAttribute('data-offset') || '0', 10);
      header.style.top = offset + 'px';
    }
  }
})();
