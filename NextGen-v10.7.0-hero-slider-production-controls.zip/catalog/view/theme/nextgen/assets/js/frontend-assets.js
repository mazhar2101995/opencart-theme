(function () {
  'use strict';

  // Small runtime foundation for optional assets.
  // Individual widgets should register their own behavior only when present.
  document.documentElement.classList.add('ng-frontend-ready');
})();
