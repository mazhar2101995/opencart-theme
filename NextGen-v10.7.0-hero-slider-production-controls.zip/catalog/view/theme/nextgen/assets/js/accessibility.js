(function () {
  'use strict';

  function initDisclosure(root) {
    var buttons = root.querySelectorAll('[data-nextgen-disclosure]');
    buttons.forEach(function (button) {
      button.addEventListener('keydown', function (event) {
        if (event.key !== 'Enter' && event.key !== ' ') return;
        event.preventDefault();
        button.click();
      });
    });
  }

  function initDialogs(root) {
    var dialogs = root.querySelectorAll('[data-nextgen-dialog]');
    dialogs.forEach(function (dialog) {
      dialog.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') {
          dialog.setAttribute('aria-hidden', 'true');
          dialog.classList.remove('is-open');
        }
      });
    });
  }

  function init() {
    initDisclosure(document);
    initDialogs(document);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
