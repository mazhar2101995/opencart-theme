(function () {
  'use strict';

  document.addEventListener('click', function (event) {
    var link = event.target.closest('[data-global-component]');
    if (!link) return;
    var key = link.getAttribute('data-global-component');
    if (!key) return;
    document.dispatchEvent(new CustomEvent('nextgen:global-component-click', {
      detail: {key: key}
    }));
  });

  document.querySelectorAll('.ng-global-newsletter form').forEach(function (form) {
    form.addEventListener('submit', function () {
      form.setAttribute('data-state', 'submitting');
    });
  });
})();
