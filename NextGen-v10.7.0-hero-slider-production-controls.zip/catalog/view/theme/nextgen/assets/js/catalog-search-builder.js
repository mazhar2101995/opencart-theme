(function () {
  'use strict';

  function debounce(fn, wait) {
    var timer;
    return function () {
      var args = arguments, ctx = this;
      clearTimeout(timer);
      timer = setTimeout(function () { fn.apply(ctx, args); }, wait);
    };
  }

  document.addEventListener('change', function (event) {
    var sort = event.target.closest('.ng-product-sort select');
    if (!sort) return;

    var url = new URL(window.location.href);
    url.searchParams.set('sort', sort.value);
    url.searchParams.delete('page');
    window.location.href = url.toString();
  });

  var suggestionContainers = document.querySelectorAll('.ng-search-suggestions');
  suggestionContainers.forEach(function (container) {
    var input = document.querySelector('[name="search"]');
    if (!input) return;

    var minimum = parseInt(container.getAttribute('data-minimum-chars') || '2', 10);
    var limit = parseInt(container.getAttribute('data-limit') || '8', 10);

    var load = debounce(function () {
      var q = input.value.trim();
      if (q.length < minimum) {
        container.innerHTML = '';
        return;
      }

      var url = 'index.php?route=product/search/suggestion&search=' +
        encodeURIComponent(q) + '&limit=' + limit;

      fetch(url, {credentials:'same-origin'})
        .then(function (r) { return r.json(); })
        .then(function (items) {
          if (!Array.isArray(items)) items = [];
          container.innerHTML = items.map(function (item) {
            return '<a href="' + (item.href || '#') + '">' +
              (item.name || '') + '</a>';
          }).join('');
        })
        .catch(function () { container.innerHTML = ''; });
    }, 180);

    input.addEventListener('input', load);
  });
})();
