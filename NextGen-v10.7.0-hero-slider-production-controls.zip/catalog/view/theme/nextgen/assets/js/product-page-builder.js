(function () {
  'use strict';

  function formDataForProduct(root) {
    var data = new FormData();
    var productId = root.getAttribute('data-product-id');
    if (productId) data.append('product_id', productId);
    var qty = root.querySelector('#ng-product-qty');
    if (qty) data.append('quantity', qty.value || '1');
    root.querySelectorAll('[name^="option["]').forEach(function (field) {
      if ((field.type === 'radio' || field.type === 'checkbox') && !field.checked) return;
      data.append(field.name, field.value);
    });
    return data;
  }

  document.addEventListener('click', function (event) {
    var button = event.target.closest('.ng-product-action');
    if (!button) return;

    var root = button.closest('[data-product-page]');
    if (!root) return;

    var productId = button.getAttribute('data-product-id');
    var action = button.classList.contains('ng-add-to-cart') ? 'add_to_cart' :
                 button.classList.contains('ng-buy-now') ? 'buy_now' :
                 button.classList.contains('ng-wishlist') ? 'wishlist' :
                 button.classList.contains('ng-compare') ? 'compare' : '';

    if (!action || !productId) return;

    button.disabled = true;
    button.setAttribute('data-loading', '1');

    if (action === 'buy_now') {
      var cartUrl = 'index.php?route=checkout/cart/add';
      var data = formDataForProduct(root);
      fetch(cartUrl, {method:'POST', body:data, credentials:'same-origin'})
        .then(function () { window.location.href = 'index.php?route=checkout/checkout'; })
        .catch(function () { button.removeAttribute('data-loading'); button.disabled = false; });
      return;
    }

    var routes = {
      add_to_cart: 'index.php?route=checkout/cart/add',
      wishlist: 'index.php?route=account/wishlist/add',
      compare: 'index.php?route=product/compare/add'
    };

    var fd = formDataForProduct(root);
    fetch(routes[action], {method:'POST', body:fd, credentials:'same-origin'})
      .then(function (r) { return r.json().catch(function(){ return {}; }); })
      .then(function (payload) {
        button.setAttribute('data-state', payload.error ? 'error' : 'success');
        button.removeAttribute('data-loading');
        button.disabled = false;
      })
      .catch(function () {
        button.setAttribute('data-state', 'error');
        button.removeAttribute('data-loading');
        button.disabled = false;
      });
  });

  document.addEventListener('click', function (event) {
    var thumb = event.target.closest('.ng-gallery-thumbs button');
    if (!thumb) return;
    var gallery = thumb.closest('.ng-product-gallery');
    var image = thumb.querySelector('img');
    var main = gallery && gallery.querySelector('.ng-gallery-main img');
    if (image && main) main.src = image.src;
  });
})();
