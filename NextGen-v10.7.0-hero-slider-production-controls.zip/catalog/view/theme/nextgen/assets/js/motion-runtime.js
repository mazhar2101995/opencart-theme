(function (window, document) {
    'use strict';

    if (window.NextGenMotionRuntime) return;

    var runtime = {
        init: function (root) {
            root = root || document;
            var nodes = root.querySelectorAll('[data-ng-motion]');
            if (!nodes.length) return;

            if (!('IntersectionObserver' in window)) {
                Array.prototype.forEach.call(nodes, function (node) {
                    node.classList.add('ng-motion-visible');
                });
                return;
            }

            var observer = new IntersectionObserver(function (entries) {
                entries.forEach(function (entry) {
                    if (!entry.isIntersecting) return;

                    entry.target.classList.add('ng-motion-visible');

                    if (entry.target.dataset.ngMotionOnce !== 'false') {
                        observer.unobserve(entry.target);
                    }
                });
            }, { threshold: 0.01 });

            Array.prototype.forEach.call(nodes, function (node) {
                observer.observe(node);
            });
        }
    };

    window.NextGenMotionRuntime = runtime;

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () { runtime.init(); });
    } else {
        runtime.init();
    }
})(window, document);
