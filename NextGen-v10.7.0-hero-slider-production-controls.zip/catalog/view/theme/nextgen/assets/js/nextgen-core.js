(function () {
  'use strict';

  window.NextGenTheme = window.NextGenTheme || {};

  NextGenTheme.ready = function (callback) {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', callback, { once: true });
      return;
    }
    callback();
  };
})();
