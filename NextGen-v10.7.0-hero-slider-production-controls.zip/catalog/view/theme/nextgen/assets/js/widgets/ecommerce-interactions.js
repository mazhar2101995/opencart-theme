(function (window, document) {
    'use strict';

    var NextGenCommerce = {
        busy: {},

        request: function (url, data, method) {
            var options = {
                method: method || 'POST',
                credentials: 'same-origin',
                headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}
            };

            if (data) {
                options.body = new URLSearchParams(data).toString();
            }

            return fetch(url, options).then(function (response) {
                if (!response.ok) throw new Error('Request failed');
                return response.json().catch(function () { return {}; });
            });
        },

        setState: function (button, state) {
            if (!button) return;
            button.dataset.state = state;
            button.classList.remove('is-loading','is-success','is-error','is-active');
            if (state === 'loading') button.classList.add('is-loading');
            if (state === 'success') button.classList.add('is-success');
            if (state === 'error') button.classList.add('is-error');
            if (state === 'active') button.classList.add('is-active');
        },

        addToCart: function (button) {
            var productId = button.dataset.productId;
            if (!productId || this.busy[productId]) return;

            this.busy[productId] = true;
            this.setState(button, 'loading');

            var data = {product_id: productId, quantity: button.dataset.quantity || 1};

            this.request('index.php?route=checkout/cart/add', data, 'POST')
                .then(function () {
                    this.setState(button, 'success');
                    document.dispatchEvent(new CustomEvent('nextgen:cart-updated', {detail:{productId:productId}}));
                }.bind(this))
                .catch(function () {
                    this.setState(button, 'error');
                }.bind(this))
                .finally(function () {
                    delete this.busy[productId];
                }.bind(this));
        },

        wishlist: function (button) {
            var productId = button.dataset.productId;
            this.setState(button, 'loading');

            this.request('index.php?route=account/wishlist/add', {product_id:productId}, 'POST')
                .then(function () {
                    this.setState(button, 'active');
                }.bind(this))
                .catch(function () {
                    this.setState(button, 'error');
                }.bind(this));
        },

        compare: function (button) {
            var productId = button.dataset.productId;
            this.setState(button, 'loading');

            this.request('index.php?route=product/compare/add', {product_id:productId}, 'POST')
                .then(function () {
                    this.setState(button, 'active');
                }.bind(this))
                .catch(function () {
                    this.setState(button, 'error');
                }.bind(this));
        },

        quickView: function (button) {
            var productId = button.dataset.productId;
            var modal = document.querySelector('.ng-quick-view');
            var content = modal && modal.querySelector('[data-quick-view-content]');
            if (!modal || !content || !productId) return;

            content.innerHTML = '<div class="ng-quick-view-loading">Loading…</div>';
            modal.hidden = false;
            modal.setAttribute('aria-hidden', 'false');

            fetch('index.php?route=extension/theme/nextgen/quick_view&product_id=' + encodeURIComponent(productId), {
                credentials: 'same-origin'
            })
            .then(function (response) { return response.text(); })
            .then(function (html) {
                content.innerHTML = html;
            })
            .catch(function () {
                content.innerHTML = '<div class="ng-quick-view-error">Unable to load product.</div>';
            });
        },

        closeQuickView: function () {
            var modal = document.querySelector('.ng-quick-view');
            if (!modal) return;
            modal.hidden = true;
            modal.setAttribute('aria-hidden', 'true');
        },

        init: function (root) {
            root = root || document;
            var self = this;

            root.addEventListener('click', function (event) {
                var cart = event.target.closest('[data-action="add-to-cart"], .ng-product-add-cart');
                var wish = event.target.closest('[data-action="wishlist"]');
                var compare = event.target.closest('[data-action="compare"]');
                var quick = event.target.closest('[data-action="quick-view"]');

                if (cart) { event.preventDefault(); self.addToCart(cart); }
                if (wish) { event.preventDefault(); self.wishlist(wish); }
                if (compare) { event.preventDefault(); self.compare(compare); }
                if (quick) { event.preventDefault(); self.quickView(quick); }

                if (event.target.closest('[data-quick-view-close]')) {
                    self.closeQuickView();
                }
            });
        }
    };

    window.NextGenCommerceInteractions = NextGenCommerce;

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () { NextGenCommerce.init(); });
    } else {
        NextGenCommerce.init();
    }
})(window, document);
