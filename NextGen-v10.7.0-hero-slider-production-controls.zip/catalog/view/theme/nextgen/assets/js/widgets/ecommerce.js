(function (window, document) {
'use strict';
function initImages(root){
 Array.prototype.forEach.call((root||document).querySelectorAll('img[data-ng-image-fallback]'),function(img){
  if(img.dataset.ngImageBound==='1')return; img.dataset.ngImageBound='1';
  img.addEventListener('error',function(){var f=img.getAttribute('data-ng-image-fallback');if(!f||img.dataset.ngImageFallbackUsed==='1')return;img.dataset.ngImageFallbackUsed='1';img.src=f;});
 });
}
function initProductsSliders(root){
 Array.prototype.forEach.call((root||document).querySelectorAll('[data-ng-products][data-mode="slider"]'),function(widget){
  if(widget.dataset.ngSliderReady==='1')return;
  var viewport=widget.querySelector('.ng-products-viewport'),track=widget.querySelector('.ng-products__track'); if(!viewport||!track)return;
  widget.dataset.ngSliderReady='1';
  var cards=Array.prototype.slice.call(track.children).filter(function(e){return e.classList.contains('ng-product-card');});
  var prev=widget.querySelector('.ng-products-prev'),next=widget.querySelector('.ng-products-next'),dots=Array.prototype.slice.call(widget.querySelectorAll('.ng-products-dot')),index=0,timer=null;
  function cols(){var st=getComputedStyle(widget),w=window.innerWidth||document.documentElement.clientWidth||1200;if(w<=600)return Math.max(1,parseInt(st.getPropertyValue('--ng-products-mobile'),10)||2);if(w<=900)return Math.max(1,parseInt(st.getPropertyValue('--ng-products-tablet'),10)||3);return Math.max(1,parseInt(widget.dataset.columns,10)||4);}
  function step(){if(!cards.length)return 0;var gap=parseFloat(getComputedStyle(track).columnGap||getComputedStyle(track).gap)||0;return cards[0].getBoundingClientRect().width+gap;}
  function max(){return Math.max(0,cards.length-cols());}
  function paint(){var m=max();index=Math.max(0,Math.min(m,index));track.style.transform='translate3d(-'+(index*step())+'px,0,0)';dots.forEach(function(d,i){d.classList.toggle('is-active',i===index);});if(prev)prev.disabled=widget.dataset.loop!=='1'&&index<=0;if(next)next.disabled=widget.dataset.loop!=='1'&&index>=m;}
  function go(i){var m=max();if(!m){index=0;paint();return;}if(widget.dataset.loop==='1'){if(i<0)i=m;if(i>m)i=0;}index=Math.max(0,Math.min(m,i));paint();}
  function stop(){if(timer){clearInterval(timer);timer=null;}}
  function start(){stop();if(widget.dataset.autoplay!=='1'||cards.length<=cols())return;timer=setInterval(function(){go(index+1);},Math.max(1000,parseInt(widget.dataset.interval,10)||4500));}
  if(prev)prev.addEventListener('click',function(){go(index-1);});if(next)next.addEventListener('click',function(){go(index+1);});
  dots.forEach(function(d,i){d.addEventListener('click',function(){go(i);});});
  widget.addEventListener('mouseenter',stop);widget.addEventListener('mouseleave',start);
  window.addEventListener('resize',function(){requestAnimationFrame(function(){paint();start();});});
  paint();start();
 });
}
window.NextGenEcommerceWidgets={init:function(root){
 root=root||document;initImages(root);initProductsSliders(root);
 Array.prototype.forEach.call(root.querySelectorAll('.ng-product-add-cart'),function(button){if(button.dataset.ngBound==='1')return;button.dataset.ngBound='1';button.addEventListener('click',function(){document.dispatchEvent(new CustomEvent('nextgen:add-to-cart',{detail:{productId:button.dataset.productId}}));});});
 Array.prototype.forEach.call(root.querySelectorAll('.ng-product-action'),function(button){if(button.dataset.ngBound==='1')return;button.dataset.ngBound='1';button.addEventListener('click',function(){document.dispatchEvent(new CustomEvent('nextgen:product-action',{detail:{action:button.dataset.action,productId:button.dataset.productId}}));});});
}};
function boot(){window.NextGenEcommerceWidgets.init(document);}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
})(window,document);
