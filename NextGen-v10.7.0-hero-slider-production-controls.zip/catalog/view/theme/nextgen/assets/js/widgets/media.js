(function (window, document) {
    'use strict';

    window.NextGenMediaWidgets = {
        init: function (root) {
            root = root || document;
            Array.prototype.forEach.call(root.querySelectorAll('.ng-media-video-popup'), function (button) {
                button.addEventListener('click', function () {
                    var event = new CustomEvent('nextgen:video-popup', {detail:{source:button.dataset.video}});
                    document.dispatchEvent(event);
                });
            });
        }
    };
})(window, document);
