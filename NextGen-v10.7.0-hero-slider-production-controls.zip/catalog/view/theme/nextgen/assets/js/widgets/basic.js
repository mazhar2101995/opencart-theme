(function (window, document) {
    'use strict';

    window.NextGenBasicWidgets = {
        init: function (root) {
            root = root || document;
            var buttons = root.querySelectorAll('.ng-widget-button');
            Array.prototype.forEach.call(buttons, function (button) {
                button.addEventListener('click', function () {
                    if (button.getAttribute('href') === '#') return;
                });
            });
        }
    };
})(window, document);
