(function () {
  'use strict';

  function hydrateLazyImages() {
    var images = document.querySelectorAll('img[data-nextgen-lazy]');
    if (!('IntersectionObserver' in window)) {
      images.forEach(function (img) {
        if (img.dataset.src) img.src = img.dataset.src;
        if (img.dataset.srcset) img.srcset = img.dataset.srcset;
        img.removeAttribute('data-nextgen-lazy');
      });
      return;
    }

    var observer = new IntersectionObserver(function (entries, obs) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) return;
        var img = entry.target;
        if (img.dataset.src) img.src = img.dataset.src;
        if (img.dataset.srcset) img.srcset = img.dataset.srcset;
        img.removeAttribute('data-nextgen-lazy');
        obs.unobserve(img);
      });
    }, { rootMargin: '200px 0px' });

    images.forEach(function (img) { observer.observe(img); });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', hydrateLazyImages);
  } else {
    hydrateLazyImages();
  }
})();
