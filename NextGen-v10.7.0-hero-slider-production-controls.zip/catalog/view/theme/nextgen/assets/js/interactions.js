(function () {
  'use strict';

  function lockScroll(lock) {
    document.documentElement.classList.toggle('nextgen-scroll-locked', !!lock);
    document.body.classList.toggle('nextgen-scroll-locked', !!lock);
  }

  function closeOverlay(overlay) {
    overlay.classList.remove('is-open');
    overlay.setAttribute('aria-hidden', 'true');
    if (overlay.dataset.lockScroll === 'true') lockScroll(false);
  }

  function openOverlay(overlay) {
    overlay.classList.add('is-open');
    overlay.setAttribute('aria-hidden', 'false');
    if (overlay.dataset.lockScroll === 'true') lockScroll(true);

    var focusTarget = overlay.querySelector('[autofocus], button, a, input, select, textarea');
    if (focusTarget) {
      setTimeout(function () { focusTarget.focus(); }, 20);
    }
  }

  function initOverlays() {
    document.querySelectorAll('[data-nextgen-overlay]').forEach(function (overlay) {
      overlay.querySelectorAll('[data-nextgen-close]').forEach(function (button) {
        button.addEventListener('click', function () { closeOverlay(overlay); });
      });

      overlay.addEventListener('click', function (event) {
        if (event.target === overlay && overlay.dataset.closeOutside !== 'false') {
          closeOverlay(overlay);
        }
      });
    });

    document.addEventListener('keydown', function (event) {
      if (event.key !== 'Escape') return;
      document.querySelectorAll('[data-nextgen-overlay].is-open').forEach(function (overlay) {
        if (overlay.dataset.closeEscape !== 'false') closeOverlay(overlay);
      });
    });

    document.querySelectorAll('[data-nextgen-open]').forEach(function (trigger) {
      trigger.addEventListener('click', function () {
        var selector = trigger.getAttribute('data-nextgen-open');
        var overlay = selector ? document.querySelector(selector) : null;
        if (overlay) openOverlay(overlay);
      });
    });
  }

  function initReveal() {
    var nodes = document.querySelectorAll('[data-nextgen-reveal]');
    if (!('IntersectionObserver' in window)) {
      nodes.forEach(function (node) { node.classList.add('is-visible'); });
      return;
    }

    var observer = new IntersectionObserver(function (entries, obs) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) return;
        entry.target.classList.add('is-visible');
        if (entry.target.dataset.once !== 'false') obs.unobserve(entry.target);
      });
    }, { threshold: 0.15 });

    nodes.forEach(function (node) { observer.observe(node); });
  }

  function initParallax() {
    var nodes = document.querySelectorAll('[data-nextgen-parallax]');
    if (!nodes.length || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

    var ticking = false;

    function update() {
      ticking = false;
      nodes.forEach(function (node) {
        var speed = parseFloat(node.dataset.speed || '0.15');
        var rect = node.getBoundingClientRect();
        var offset = (window.innerHeight / 2) - (rect.top + rect.height / 2);
        node.style.transform = 'translate3d(0,' + (offset * speed) + 'px,0)';
      });
    }

    window.addEventListener('scroll', function () {
      if (!ticking) {
        window.requestAnimationFrame(update);
        ticking = true;
      }
    }, { passive: true });

    update();
  }

  function init() {
    initOverlays();
    initReveal();
    initParallax();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
