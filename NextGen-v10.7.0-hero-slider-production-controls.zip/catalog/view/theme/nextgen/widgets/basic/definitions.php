<?php
class NextGenBasicWidgetDefinitions {
    public static function all() {
        return array(
            'heading' => array(
                'template'=>'widgets/basic/heading',
                'defaults'=>array('text'=>'Heading','tag'=>'h2'),
                'controls'=>array('content','typography','color','advanced')
            ),
            'text' => array(
                'template'=>'widgets/basic/text',
                'defaults'=>array('content'=>'Add your text here.'),
                'controls'=>array('content','typography','color','advanced')
            ),
            'image' => array(
                'template'=>'widgets/basic/image',
                'defaults'=>array('source'=>'','alt'=>'','link'=>''),
                'controls'=>array('image','link','layout','advanced')
            ),
            'icon' => array(
                'template'=>'widgets/basic/icon',
                'defaults'=>array('icon'=>'star','size'=>'24px'),
                'controls'=>array('icon','style','advanced')
            ),
            'button' => array(
                'template'=>'widgets/basic/button',
                'defaults'=>array('text'=>'Button','url'=>'#'),
                'controls'=>array('content','typography','style','advanced')
            ),
            'spacer' => array(
                'template'=>'widgets/basic/spacer',
                'defaults'=>array('height'=>'40px'),
                'controls'=>array('layout','responsive','advanced')
            ),
            'divider' => array(
                'template'=>'widgets/basic/divider',
                'defaults'=>array('style'=>'solid','width'=>'100%'),
                'controls'=>array('style','responsive','advanced')
            )
        );
    }
}
