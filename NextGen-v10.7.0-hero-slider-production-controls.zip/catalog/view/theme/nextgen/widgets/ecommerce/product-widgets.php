<?php
class NextGenEcommerceWidgets {
    public static function definitions() {
        return array(
            'product' => array('template'=>'widgets/ecommerce/product-card','data_source'=>'single'),
            'product-grid' => array('template'=>'widgets/ecommerce/product-grid','data_source'=>'collection'),
            'product-list' => array('template'=>'widgets/ecommerce/product-list','data_source'=>'collection'),
            'product-carousel' => array('template'=>'widgets/ecommerce/product-carousel','data_source'=>'collection'),
            'product-slider' => array('template'=>'widgets/ecommerce/product-carousel','data_source'=>'collection'),
            'featured-products' => array('template'=>'widgets/ecommerce/product-grid','data_source'=>'featured'),
            'latest-products' => array('template'=>'widgets/ecommerce/product-grid','data_source'=>'latest'),
            'best-sellers' => array('template'=>'widgets/ecommerce/product-grid','data_source'=>'bestsellers'),
            'popular-products' => array('template'=>'widgets/ecommerce/product-grid','data_source'=>'popular'),
            'special-products' => array('template'=>'widgets/ecommerce/product-grid','data_source'=>'special'),
            'related-products' => array('template'=>'widgets/ecommerce/product-grid','data_source'=>'related'),
            'recently-viewed-products' => array('template'=>'widgets/ecommerce/product-grid','data_source'=>'recently_viewed')
        );
    }
}
