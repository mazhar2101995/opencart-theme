<?php
require_once DIR_APPLICATION . '../view/theme/nextgen/widgets/core/control_groups.php';

class NextGenDefaultWidgetSchemas {
    public static function heading() {
        return array(
            'content' => array(
                array('id'=>'text','type'=>'textarea','label'=>'Heading','default'=>'Heading'),
                array('id'=>'tag','type'=>'select','label'=>'HTML Tag','options'=>array('h1','h2','h3','h4','h5','h6','div')),
                array('id'=>'link','type'=>'link','label'=>'Link')
            ),
            'style' => array_merge(
                NextGenControlGroups::typography(),
                array(
                    array('id'=>'text_color','type'=>'color','label'=>'Text Color','states'=>array('default','hover')),
                    array('id'=>'background','type'=>'background','label'=>'Background')
                )
            ),
            'advanced' => NextGenControlGroups::advanced()
        );
    }

    public static function button() {
        return array(
            'content' => array(
                array('id'=>'text','type'=>'text','label'=>'Button Text','default'=>'Button'),
                array('id'=>'link','type'=>'link','label'=>'Link'),
                array('id'=>'icon','type'=>'icon','label'=>'Icon'),
                array('id'=>'icon_position','type'=>'select','label'=>'Icon Position','options'=>array('before','after'))
            ),
            'style' => array_merge(
                NextGenControlGroups::typography(),
                NextGenControlGroups::border(),
                NextGenControlGroups::effects(),
                array(
                    array('id'=>'background','type'=>'background','label'=>'Background'),
                    array('id'=>'button_color','type'=>'color','label'=>'Text Color','states'=>array('default','hover')),
                    array('id'=>'icon_size','type'=>'unit','label'=>'Icon Size','units'=>array('px','em','rem'),'responsive'=>true)
                )
            ),
            'advanced' => NextGenControlGroups::advanced()
        );
    }
}
