<?php
/**
 * NextGen Widget Catalog.
 *
 * Central metadata registry for core widgets. Rendering remains delegated
 * to widget templates and the existing theme engine.
 */
class NextGenWidgetCatalog {
    protected $widgets = array();

    public function register(array $widget) {
        if (empty($widget['id']) || empty($widget['category'])) {
            return false;
        }

        $widget['version'] = isset($widget['version']) ? $widget['version'] : '1.0.0';
        $widget['supports'] = isset($widget['supports']) ? $widget['supports'] : array();
        $widget['controls'] = isset($widget['controls']) ? $widget['controls'] : array();

        $this->widgets[$widget['id']] = $widget;
        return true;
    }

    public function get($id) {
        return isset($this->widgets[$id]) ? $this->widgets[$id] : null;
    }

    public function all() {
        return array_values($this->widgets);
    }

    public function byCategory($category) {
        $result = array();
        foreach ($this->widgets as $widget) {
            if ($widget['category'] === $category) {
                $result[] = $widget;
            }
        }
        return $result;
    }
}
