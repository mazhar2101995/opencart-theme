<?php
/**
 * Central widget registry.
 *
 * Widget definitions are data-driven so the future visual editor can
 * build its widget panel from the same registry used by rendering.
 */
class NextGenWidgetRegistry {
    protected $widgets = array();

    public function register($id, $definition) {
        if (!$this->isValidId($id) || !is_array($definition)) {
            return false;
        }

        $definition['id'] = $id;
        $definition['name'] = isset($definition['name']) ? $definition['name'] : $id;
        $definition['category'] = isset($definition['category']) ? $definition['category'] : 'basic';
        $definition['version'] = isset($definition['version']) ? $definition['version'] : 1;
        $definition['settings'] = isset($definition['settings']) && is_array($definition['settings'])
            ? $definition['settings'] : array();

        $this->widgets[$id] = $definition;

        return true;
    }

    public function unregister($id) {
        if (isset($this->widgets[$id])) {
            unset($this->widgets[$id]);
            return true;
        }

        return false;
    }

    public function has($id) {
        return isset($this->widgets[$id]);
    }

    public function get($id) {
        return $this->has($id) ? $this->widgets[$id] : null;
    }

    public function all() {
        return $this->widgets;
    }

    public function byCategory($category) {
        $result = array();

        foreach ($this->widgets as $id => $widget) {
            if ($widget['category'] === $category) {
                $result[$id] = $widget;
            }
        }

        return $result;
    }

    protected function isValidId($id) {
        return is_string($id) && preg_match('/^[a-z0-9_-]+$/', $id);
    }
}
