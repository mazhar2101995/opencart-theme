<?php
/**
 * NextGen universal widget control schema.
 *
 * Controls are declarative. A widget can expose the same control types
 * without coupling itself to the admin inspector implementation.
 */
class NextGenControlSchema {
    public function normalize(array $definition) {
        $allowed = array(
            'id','type','label','default','options','units','responsive',
            'states','conditions','section','description','min','max','step',
            'placeholder','control','group','devices','dynamic','depends_on','visibility'
        );

        $out = array();
        foreach ($definition as $key => $value) {
            if (in_array($key, $allowed, true)) {
                $out[$key] = $value;
            }
        }

        if (empty($out['id']) || empty($out['type'])) {
            return null;
        }

        if (!isset($out['responsive'])) {
            $out['responsive'] = false;
        }
        if (!isset($out['states'])) {
            $out['states'] = array('default');
        }

        return $out;
    }

    public function normalizeGroup(array $controls) {
        $result = array();
        foreach ($controls as $control) {
            $normalized = $this->normalize($control);
            if ($normalized !== null) {
                $result[] = $normalized;
            }
        }
        return $result;
    }
}
