<?php
require_once DIR_APPLICATION . '../view/theme/nextgen/widgets/core/widget_catalog.php';

class NextGenDefaultCatalog {
    public static function register(NextGenWidgetCatalog $catalog) {
        $basic = array(
            array('id'=>'heading','name'=>'Heading','category'=>'basic','icon'=>'heading'),
            array('id'=>'text','name'=>'Text Editor','category'=>'basic','icon'=>'text'),
            array('id'=>'image','name'=>'Image','category'=>'basic','icon'=>'image'),
            array('id'=>'icon','name'=>'Icon','category'=>'basic','icon'=>'icon'),
            array('id'=>'icon-box','name'=>'Icon Box','category'=>'basic','icon'=>'icon-box'),
            array('id'=>'button','name'=>'Button','category'=>'basic','icon'=>'button'),
            array('id'=>'button-group','name'=>'Button Group','category'=>'basic','icon'=>'button-group'),
            array('id'=>'link','name'=>'Link','category'=>'basic','icon'=>'link'),
            array('id'=>'html','name'=>'HTML','category'=>'basic','icon'=>'code'),
            array('id'=>'shortcode','name'=>'Shortcode','category'=>'basic','icon'=>'brackets'),
            array('id'=>'spacer','name'=>'Spacer','category'=>'layout','icon'=>'space'),
            array('id'=>'divider','name'=>'Divider','category'=>'layout','icon'=>'divider')
        );

        foreach ($basic as $widget) {
            $widget['version'] = '1.0.0';
            $widget['supports'] = array('responsive'=>true,'dynamic'=>true,'conditions'=>true,'animation'=>true);
            $catalog->register($widget);
        }

        $media = array(
            array('id'=>'gallery','name'=>'Gallery','category'=>'media','icon'=>'gallery'),
            array('id'=>'image-carousel','name'=>'Image Carousel','category'=>'media','icon'=>'carousel'),
            array('id'=>'video','name'=>'Video','category'=>'media','icon'=>'video'),
            array('id'=>'video-popup','name'=>'Video Popup','category'=>'media','icon'=>'play'),
            array('id'=>'youtube','name'=>'YouTube','category'=>'media','icon'=>'youtube'),
            array('id'=>'vimeo','name'=>'Vimeo','category'=>'media','icon'=>'vimeo'),
            array('id'=>'audio','name'=>'Audio','category'=>'media','icon'=>'audio'),
            array('id'=>'lightbox','name'=>'Lightbox','category'=>'media','icon'=>'lightbox'),
            array('id'=>'before-after','name'=>'Before / After','category'=>'media','icon'=>'compare')
        );

        foreach ($media as $widget) {
            $widget['version'] = '1.0.0';
            $widget['supports'] = array('responsive'=>true,'dynamic'=>true,'conditions'=>true,'animation'=>true);
            $catalog->register($widget);
        }
    }
}
