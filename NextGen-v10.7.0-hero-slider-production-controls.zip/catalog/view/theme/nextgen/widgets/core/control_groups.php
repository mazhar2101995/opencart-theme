<?php
class NextGenControlGroups {
    public static function typography() {
        return array(
            array('id'=>'font_family','type'=>'select','label'=>'Font Family','responsive'=>true),
            array('id'=>'font_size','type'=>'unit','label'=>'Font Size','units'=>array('px','rem','em'),'responsive'=>true),
            array('id'=>'font_weight','type'=>'select','label'=>'Font Weight','options'=>array('300','400','500','600','700','800'),'responsive'=>true),
            array('id'=>'line_height','type'=>'unit','label'=>'Line Height','units'=>array('','px','em','rem'),'responsive'=>true),
            array('id'=>'letter_spacing','type'=>'unit','label'=>'Letter Spacing','units'=>array('px','em'),'responsive'=>true),
            array('id'=>'text_transform','type'=>'select','label'=>'Text Transform','options'=>array('none','uppercase','lowercase','capitalize')),
            array('id'=>'text_align','type'=>'button_group','label'=>'Text Align','options'=>array('left','center','right','justify'),'responsive'=>true),
            array('id'=>'color','type'=>'color','label'=>'Color','states'=>array('default','hover'))
        );
    }

    public static function spacing() {
        return array(
            array('id'=>'margin','type'=>'spacing','label'=>'Margin','responsive'=>true),
            array('id'=>'padding','type'=>'spacing','label'=>'Padding','responsive'=>true),
            array('id'=>'gap','type'=>'unit','label'=>'Gap','units'=>array('px','rem','em'),'responsive'=>true)
        );
    }

    public static function border() {
        return array(
            array('id'=>'border_style','type'=>'select','label'=>'Border Style','options'=>array('none','solid','dashed','dotted','double')),
            array('id'=>'border_width','type'=>'spacing','label'=>'Border Width','responsive'=>true),
            array('id'=>'border_color','type'=>'color','label'=>'Border Color','states'=>array('default','hover')),
            array('id'=>'border_radius','type'=>'spacing','label'=>'Border Radius','responsive'=>true)
        );
    }

    public static function effects() {
        return array(
            array('id'=>'box_shadow','type'=>'shadow','label'=>'Box Shadow','states'=>array('default','hover')),
            array('id'=>'opacity','type'=>'range','label'=>'Opacity','min'=>0,'max'=>1,'step'=>0.01,'responsive'=>true),
            array('id'=>'transform','type'=>'transform','label'=>'Transform','states'=>array('default','hover'))
        );
    }

    public static function advanced() {
        return array(
            array('id'=>'custom_class','type'=>'text','label'=>'CSS Classes'),
            array('id'=>'custom_id','type'=>'text','label'=>'CSS ID'),
            array('id'=>'custom_attributes','type'=>'code','label'=>'Custom Attributes'),
            array('id'=>'custom_css','type'=>'code','label'=>'Custom CSS')
        );
    }
}
