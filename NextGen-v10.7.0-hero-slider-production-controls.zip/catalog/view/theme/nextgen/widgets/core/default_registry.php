<?php
/**
 * Built-in widget definitions.
 */
class NextGenDefaultWidgetRegistry {
    public static function register($registry) {
        $registry->register('heading', array(
            'name' => 'Heading',
            'category' => 'basic',
            'icon' => 'type',
            'version' => 1,
            'template' => 'theme/nextgen/builder/widget/heading',
            'settings' => array(
                'text' => array('type' => 'text', 'default' => 'Heading'),
                'tag' => array(
                    'type' => 'select',
                    'default' => 'h2',
                    'options' => array('h1', 'h2', 'h3', 'h4', 'h5', 'h6')
                )
            )
        ));

        $registry->register('text', array(
            'name' => 'Text',
            'category' => 'basic',
            'icon' => 'align-left',
            'version' => 1,
            'template' => 'theme/nextgen/builder/widget/text',
            'settings' => array(
                'text' => array('type' => 'textarea', 'default' => '')
            )
        ));

        $registry->register('button', array(
            'name' => 'Button',
            'category' => 'basic',
            'icon' => 'mouse-pointer',
            'version' => 1,
            'template' => 'theme/nextgen/builder/widget/button',
            'settings' => array(
                'text' => array('type' => 'text', 'default' => 'Button'),
                'url' => array('type' => 'url', 'default' => '#')
            )
        ));
    }
}
