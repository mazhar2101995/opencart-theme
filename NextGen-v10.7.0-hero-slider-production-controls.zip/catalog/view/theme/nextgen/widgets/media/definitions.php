<?php
class NextGenMediaWidgetDefinitions {
    public static function all() {
        return array(
            'gallery'=>array('template'=>'widgets/media/gallery','defaults'=>array('items'=>array())),
            'image-carousel'=>array('template'=>'widgets/media/image-carousel','defaults'=>array('items'=>array(),'autoplay'=>true)),
            'video'=>array('template'=>'widgets/media/video','defaults'=>array('source'=>'','poster'=>'')),
            'video-popup'=>array('template'=>'widgets/media/video-popup','defaults'=>array('source'=>'','button_text'=>'Play Video')),
            'youtube'=>array('template'=>'widgets/media/youtube','defaults'=>array('video_id'=>'')),
            'vimeo'=>array('template'=>'widgets/media/vimeo','defaults'=>array('video_id'=>'')),
            'audio'=>array('template'=>'widgets/media/audio','defaults'=>array('source'=>'')),
            'lightbox'=>array('template'=>'widgets/media/lightbox','defaults'=>array('source'=>'')),
            'before-after'=>array('template'=>'widgets/media/before-after','defaults'=>array('before'=>'','after'=>''))
        );
    }
}
