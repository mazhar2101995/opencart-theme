(function(window, document){
'use strict';
if(window.__NextGenFrontEditor) return;
window.__NextGenFrontEditor=true;
var editing=true, hoverToolbar=null, activeHover=null;
function post(type,payload){try{window.parent.postMessage(Object.assign({source:'nextgen-front-editor',type:type},payload||{}),'*');}catch(e){}}
function mark(el){document.querySelectorAll('[data-nextgen-edit-selected]').forEach(function(x){x.removeAttribute('data-nextgen-edit-selected');});if(el)el.setAttribute('data-nextgen-edit-selected','1');}
function closestNode(el){return el&&el.closest?el.closest('[data-nextgen-node-id]'):null;}
function isSection(el){return el&&el.getAttribute&&el.getAttribute('data-nextgen-node-type')==='section';}
function nodeId(el){return el&&el.getAttribute?el.getAttribute('data-nextgen-node-id'):'';}
function hideToolbar(){if(hoverToolbar){hoverToolbar.remove();hoverToolbar=null;}activeHover=null;}
function makeButton(label,title,fn){var b=document.createElement('button');b.type='button';b.textContent=label;b.title=title;b.addEventListener('mousedown',function(e){e.preventDefault();e.stopPropagation();});b.addEventListener('click',function(e){e.preventDefault();e.stopPropagation();fn();});return b;}
function showToolbar(node){
 if(!editing)return;hideToolbar();activeHover=node;hoverToolbar=document.createElement('div');hoverToolbar.className='ng-fe-node-toolbar';var rect=node.getBoundingClientRect();hoverToolbar.style.top=(window.scrollY+rect.top-34)+'px';hoverToolbar.style.left=Math.max(8,window.scrollX+rect.left+Math.min(120,rect.width/2-90))+'px';
 hoverToolbar.appendChild(makeButton('↕','Move',function(){post('select',{id:nodeId(node),widget:node.getAttribute('data-nextgen-node-type')||''});}));
 hoverToolbar.appendChild(makeButton('✎','Edit',function(){mark(node);post('select',{id:nodeId(node),widget:node.getAttribute('data-nextgen-node-type')||''});}));
 var type=node.getAttribute('data-nextgen-node-type')||'';
 if(type==='section') hoverToolbar.appendChild(makeButton('＋','Add Container',function(){post('add-container',{id:nodeId(node)});}));
 else if(type==='container') hoverToolbar.appendChild(makeButton('＋','Add Container',function(){post('add-container',{id:nodeId(node)});}));
 else if(type!=='root') hoverToolbar.appendChild(makeButton('＋','Add Element',function(){post('add-child',{id:nodeId(node)});}));
 if(type!=='section'&&type!=='root'){hoverToolbar.appendChild(makeButton('□','Copy',function(){post('copy-node',{id:nodeId(node)});}));hoverToolbar.appendChild(makeButton('▣','Paste',function(){post('paste-node',{id:nodeId(node)});}));}
 hoverToolbar.appendChild(makeButton('⧉','Duplicate',function(){post('duplicate-node',{id:nodeId(node)});}));
 if(type!=='root')hoverToolbar.appendChild(makeButton('×','Delete',function(){post('delete-node',{id:nodeId(node)});}));
 document.body.appendChild(hoverToolbar);
}
function insertControl(beforeNode,afterNode){var el=document.createElement('div');el.className='ng-fe-section-insert';el.appendChild(makeButton('+','Add Section',function(){post(beforeNode?'add-section-before':'add-section-after',{id:nodeId(beforeNode||afterNode)});}));return el;}
function buildSectionInsertControls(){document.querySelectorAll('[data-nextgen-node-type="section"]').forEach(function(section){if(section.previousElementSibling&&!section.previousElementSibling.classList.contains('ng-fe-section-insert')){var before=insertControl(section,null);section.parentNode.insertBefore(before,section);}if(section.nextElementSibling&&!section.nextElementSibling.classList.contains('ng-fe-section-insert')){var after=insertControl(null,section);section.parentNode.insertBefore(after,section.nextSibling);}});}
document.addEventListener('mouseover',function(e){if(!editing)return;var node=closestNode(e.target);if(node){showToolbar(node);}},true);
document.addEventListener('mouseout',function(e){if(!editing)return;if(hoverToolbar&&e.relatedTarget&&hoverToolbar.contains(e.relatedTarget))return;var node=closestNode(e.target);if(node&&e.relatedTarget&&!node.contains(e.relatedTarget))hideToolbar();},true);
document.addEventListener('click',function(e){if(!editing)return;var node=closestNode(e.target);if(node){e.preventDefault();e.stopPropagation();mark(node);post('select',{id:nodeId(node),widget:node.getAttribute('data-nextgen-node-type')||''});}},true);
document.addEventListener('dblclick',function(e){if(!editing)return;var node=closestNode(e.target);if(!node)return;var target=e.target;if(!/^(INPUT|TEXTAREA|SELECT|BUTTON)$/i.test(target.tagName)&&target.childElementCount===0){e.preventDefault();e.stopPropagation();target.contentEditable='true';target.focus();var id=nodeId(node);function done(){target.contentEditable='false';target.removeEventListener('blur',done);post('inline-change',{id:id,value:target.innerHTML,text:target.textContent});}target.addEventListener('blur',done);post('inline-start',{id:id});}},true);
window.addEventListener('resize',function(){if(activeHover)showToolbar(activeHover);});
window.addEventListener('scroll',function(){if(activeHover)showToolbar(activeHover);},{passive:true});
window.addEventListener('message',function(e){var d=e.data||{};if(d.source!=='nextgen-front-editor-parent')return;if(d.type==='refresh'){window.location.reload();return;}if(d.type==='select'){var id=String(d.id||'').replace(/"/g,'');var el=document.querySelector('[data-nextgen-node-id="'+id+'"]');mark(el);return;}if(d.type==='mode'){editing=!!d.enabled;if(!editing)hideToolbar();return;}if(d.type==='rebuild-controls'){buildSectionInsertControls();}});
post('ready',{route:document.body.getAttribute('data-nextgen-route')||''});
setTimeout(function(){buildSectionInsertControls();document.querySelectorAll('[data-nextgen-node-type="section"]').forEach(function(section){if(!section.querySelector('.ng-fe-add-container')){var b=document.createElement('button');b.type='button';b.className='ng-fe-add-container';b.textContent='+ Add Container';b.addEventListener('mousedown',function(e){e.preventDefault();e.stopPropagation();});b.addEventListener('click',function(e){e.preventDefault();e.stopPropagation();post('add-container',{id:nodeId(section)});});section.appendChild(b);}});},80);
})(window,document);
