<?php
class ModelExtensionThemeNextgenProductPage extends Model {
    public function normalize(array $product) {
        return [
            'product_id' => (int)($product['product_id'] ?? 0),
            'name' => (string)($product['name'] ?? ''),
            'model' => (string)($product['model'] ?? ''),
            'sku' => (string)($product['sku'] ?? ''),
            'ean' => (string)($product['ean'] ?? ''),
            'manufacturer' => (string)($product['manufacturer'] ?? ''),
            'manufacturer_id' => (int)($product['manufacturer_id'] ?? 0),
            'description' => (string)($product['description'] ?? ''),
            'meta_description' => (string)($product['meta_description'] ?? ''),
            'image' => (string)($product['image'] ?? ''),
            'images' => isset($product['images']) && is_array($product['images']) ? $product['images'] : [],
            'price' => $product['price'] ?? '',
            'special' => $product['special'] ?? '',
            'tax' => $product['tax'] ?? '',
            'discounts' => isset($product['discounts']) && is_array($product['discounts']) ? $product['discounts'] : [],
            'quantity' => (int)($product['quantity'] ?? 0),
            'stock_status' => (string)($product['stock_status'] ?? ''),
            'rating' => (float)($product['rating'] ?? 0),
            'reviews' => (int)($product['reviews'] ?? 0),
            'minimum' => (int)($product['minimum'] ?? 1),
            'options' => isset($product['options']) && is_array($product['options']) ? $product['options'] : [],
            'attributes' => isset($product['attribute_groups']) ? $product['attribute_groups'] : [],
            'downloads' => isset($product['downloads']) && is_array($product['downloads']) ? $product['downloads'] : [],
            'related' => isset($product['related']) && is_array($product['related']) ? $product['related'] : [],
        ];
    }
}
