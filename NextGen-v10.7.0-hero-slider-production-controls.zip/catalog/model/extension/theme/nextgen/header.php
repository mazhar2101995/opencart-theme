<?php
class ModelExtensionThemeNextgenHeader extends Model {
    public function normalize(array $data) {
        return [
            'logo' => (string)($data['logo'] ?? ''),
            'logo_alt' => (string)($data['logo_alt'] ?? ''),
            'name' => (string)($data['name'] ?? ''),
            'categories' => is_array($data['categories'] ?? null) ? $data['categories'] : [],
            'currency' => is_array($data['currency'] ?? null) ? $data['currency'] : [],
            'language' => is_array($data['language'] ?? null) ? $data['language'] : [],
            'cart' => is_array($data['cart'] ?? null) ? $data['cart'] : [],
            'wishlist_total' => (int)($data['wishlist_total'] ?? 0),
            'compare_total' => (int)($data['compare_total'] ?? 0),
            'logged' => !empty($data['logged']),
            'firstname' => (string)($data['firstname'] ?? ''),
            'contact' => (string)($data['contact'] ?? ''),
            'social' => is_array($data['social'] ?? null) ? $data['social'] : [],
        ];
    }
}
