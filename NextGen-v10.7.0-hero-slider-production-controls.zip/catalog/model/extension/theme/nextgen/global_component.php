<?php
class ModelExtensionThemeNextgenGlobalComponent extends Model {
    public function get($key) {
        $this->load->library('nextgen/global_component_repository');
        $repository = new NextGenGlobalComponentRepository($this->db);
        return $repository->get($key);
    }
}
