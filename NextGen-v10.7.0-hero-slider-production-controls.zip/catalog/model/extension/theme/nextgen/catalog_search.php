<?php
class ModelExtensionThemeNextgenCatalogSearch extends Model {
    public function normalizeCategory(array $data) {
        return [
            'category_id' => (int)($data['category_id'] ?? 0),
            'name' => (string)($data['name'] ?? ''),
            'description' => (string)($data['description'] ?? ''),
            'image' => (string)($data['image'] ?? ''),
            'children' => is_array($data['children'] ?? null) ? $data['children'] : [],
            'products' => is_array($data['products'] ?? null) ? $data['products'] : [],
            'pagination' => (string)($data['pagination'] ?? ''),
            'results' => (int)($data['results'] ?? 0),
        ];
    }

    public function normalizeSearch(array $data) {
        return [
            'query' => (string)($data['query'] ?? ''),
            'products' => is_array($data['products'] ?? null) ? $data['products'] : [],
            'pagination' => (string)($data['pagination'] ?? ''),
            'results' => (int)($data['results'] ?? 0),
            'sorts' => is_array($data['sorts'] ?? null) ? $data['sorts'] : [],
            'filters' => is_array($data['filters'] ?? null) ? $data['filters'] : [],
        ];
    }

    public function normalizeManufacturer(array $data) {
        return [
            'manufacturer_id' => (int)($data['manufacturer_id'] ?? 0),
            'name' => (string)($data['name'] ?? ''),
            'image' => (string)($data['image'] ?? ''),
            'description' => (string)($data['description'] ?? ''),
            'products' => is_array($data['products'] ?? null) ? $data['products'] : [],
            'pagination' => (string)($data['pagination'] ?? ''),
        ];
    }
}
