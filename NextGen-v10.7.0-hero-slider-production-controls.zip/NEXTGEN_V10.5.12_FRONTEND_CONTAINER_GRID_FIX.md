# NextGen V10.5.12 — Frontend Container/Grid Runtime Fix

## Problem
The Builder correctly showed Container settings such as `Full Container`, width, max-width and Grid settings in the admin preview, but the live storefront did not always receive those settings.

## Root Cause
`system/library/nextgen/widget_render_engine.php` rendered Container nodes on the storefront, but desktop responsive values stored under `settings.responsive.*.desktop` were not resolved when generating the base inline layout styles.

This caused the Builder preview and live storefront to use different layout values. In particular, a Container could be configured as `full` in the Builder while the storefront fell back to the default boxed `1320px` container.

## Fix
The frontend Widget Render Engine now:

- Resolves desktop responsive Container settings before rendering.
- Keeps tablet/mobile responsive rules for media queries.
- Resolves `layout`, `gridColumns`, `gridColumnCount`, `gap`, `columnGap`, `rowGap`, `width`, `maxWidth`, `minHeight`, `padding`, `margin`, `direction`, `wrap`, and related layout settings from the same responsive data used by Builder.
- Supports `full`, `full_bleed`, `full-width`, and `viewport` as full-viewport Container modes.
- Applies full-width layout as:
  - `width: 100vw`
  - `max-width: 100vw`
  - `margin-left: calc(50% - 50vw)`
  - `margin-right: calc(50% - 50vw)`
- Preserves Grid as a Container-owned layout system. No separate Column node is required for new layouts.

## Expected Result
When a Container is configured in Builder as:

`Layout → Container → Content Width → Full Container`

and the document is saved, the storefront must render the same full-width result rather than falling back to the boxed container.

For Grid:

`Container → Layout → Grid → Grid Columns`

controls the grid tracks directly inside the Container. Grid cells remain Container-based and widgets can be placed inside them.

## Files Changed
- `system/library/nextgen/widget_render_engine.php`

## Validation
- PHP syntax check passed for the modified renderer.
- Existing widget rendering architecture remains in place.
- No OCMOD/VQMOD changes were introduced.
