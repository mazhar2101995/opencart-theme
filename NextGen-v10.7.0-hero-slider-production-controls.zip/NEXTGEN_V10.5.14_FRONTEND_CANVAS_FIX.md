# NextGen v10.5.14 — Frontend Canvas / Full Width Fix

## Root causes found

1. Section inspector exposes `Content Width` (Boxed / Full Width), but the frontend layout renderer did not apply `contentWidth` at all.
2. Container `Full Container` was rendered as `100vw` in the runtime path, while the inspector semantics distinguish it from `Full Width / Viewport`.
3. Universal Hero `widthMode=full` injected `width:min(var(--ng-container,1320px),100vw)` and a 50% translate, which reintroduced a container cap even when the parent was full width.
4. Fashion demo CSS used `max-width:var(--ng-container)!important` on section containers, overriding the container's saved `Max Width` setting.
5. Builder-created sections did not default explicitly to full-width canvas.

## v10.5.14 changes

- Section `contentWidth=full` now renders as width 100%, max-width none.
- Section `contentWidth=boxed` respects its configured max-width.
- Container `widthMode=full` now means 100% of its parent container.
- Container `widthMode=full_bleed` remains the viewport/full-bleed mode (100vw).
- Hero `widthMode=full` now fills its parent container with no forced 1320px cap and no translate transform.
- Removed the fashion demo `!important` max-width override that blocked saved container widths.
- New sections default to full-width canvas.
- Existing sections with no `contentWidth` value are normalized to full width in the Builder.

## Intended Elementor-style semantics

- Section: controls the page canvas.
- Container: controls the layout inside the section.
- `Full Container`: fills the section/container width.
- `Full Width / Viewport`: intentionally escapes to the viewport width.
- Child widgets: never impose a hidden global 1200/1320px cap.
