# NextGen v10.6.0 — Builder / Products / Live Cascade

Based on the uploaded v10.5.26 package.

## Changes

- One **Products** widget replaces the duplicated new palette entries for Product Grid/List/Carousel/Featured/Latest/Special/Bestseller.
- Products supports **Grid / Slider / Tabs**.
- Product source supports **Latest / Featured / Special / Best Sellers / Category / Custom**.
- Product cards include cart, wishlist, compare and quick-view action hooks using the existing NextGen commerce interaction contract.
- Product source context is populated from OpenCart product APIs at the presentation boundary.
- Grid containers now expose **Add Grid Item**, allowing a grid cell to contain a nested container with multiple widgets.
- Builder product preview now uses one unified product component.
- Version/cache-buster updated to 10.6.0.

## Verification still required on the real store

- exact OpenCart featured-module setting format;
- quick-view endpoint availability;
- Chrome computed-style parity;
- real database product/category results;
- live slider/tabs behavior;
- full frontend/editor visual parity.
