# NextGen v10.6.8 — Products Widget Container + CSS Cascade Fix

## Problems addressed
- Products widget always occupied the full parent width even when the user wanted a contained/boxed widget.
- Several global Products CSS rules used `!important`, preventing per-widget admin settings from taking effect.
- Legacy storefront CSS limited `.ng-product-add-cart` to `max-width:260px`, overriding the Products widget's configurable button width.
- Responsive widget width settings were not emitted by the renderer.

## New admin controls
### Products → Widget Container
- Widget Width: Full Width / Boxed / Container / Custom Width
- Widget Width
- Maximum Width
- Horizontal Alignment: Left / Center / Right
- Horizontal Outer Spacing

Default behavior is **Boxed / Container** with a 1400px maximum width and centered alignment.

## CSS cascade changes
- Removed authoritative `!important` values from the base Products widget stylesheet.
- Per-widget scoped renderer styles remain the source of truth for admin settings.
- Removed the legacy 260px maximum width from the storefront Add to Cart rule.
- Added responsive widget width/max-width/alignment/padding output for tablet and mobile settings.

## Expected result
A full-width parent/section can now contain a Products widget such as:

Full parent:
`|--------------------------------------------------------------|`

Products widget (boxed):
`|        |---------------- Products ----------------|          |`

The widget can instead be set to full width or a custom width without changing the parent section.

## Validation
- PHP syntax: passed
- Builder JavaScript syntax: passed
- Ecommerce widget JavaScript syntax: passed
