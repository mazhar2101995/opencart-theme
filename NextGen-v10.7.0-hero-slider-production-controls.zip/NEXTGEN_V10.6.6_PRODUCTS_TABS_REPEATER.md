# NextGen v10.6.6 — Products Widget Custom Tabs / Conditions

## Purpose
The Products widget Tabs mode is now a real user-defined tab system instead of a fixed Latest / Featured / Special preset.

## Admin Builder
When Display = Tabs:
- Create unlimited tabs with `+ Add Tab`.
- Custom tab name.
- Independent Product Condition / Source per tab:
  - Latest Products
  - Featured Products
  - Special Products
  - Best Sellers
  - Category Products
  - Custom Product Selection
- Category ID field appears only for Category Products.
- Product IDs field appears only for Custom Product Selection.
- Independent product limit per tab.
- Move tab up/down.
- Duplicate tab.
- Delete tab.
- Each tab keeps its own configuration.

## Frontend
- Tab labels are generated from the saved tab list.
- No hard-coded Latest / Featured / Special tab set.
- Each tab loads its own source independently.
- Each tab respects its own product limit.
- Category tabs use the selected category.
- Custom tabs use the selected Product IDs.
- Existing `tabs_json` documents remain compatible because the runtime still accepts the stored `tabs` array and JSON migration path.

## Example
Create:
1. `New T-Shirts` → Category Products → category ID 25 → 8 products
2. `Latest Products` → Latest Products → 8 products
3. `Sale T-Shirts` → Custom Product Selection → Product IDs `101,102,103`

The frontend will render exactly those three tabs and their independent product sets.

## UI
The old raw Tabs JSON field is no longer shown in the normal Products inspector. The repeater is the primary editor so clients do not need to write JSON manually.
