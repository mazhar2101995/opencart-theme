# NextGen V10.5.7 — Hero Color Pipeline Audit

## Root cause found

The Hero renderer already supported the requested color values, but the builder had multiple layers for inspector controls and asset/version caching. The previous patch relied on the browser receiving the matching `builder-ui.js` + `inspector-schema.js`. If an older builder asset/template remained cached, the UI could show typography controls while silently omitting the newer color controls.

## V10.5.7 changes

- Unique builder asset version: `10.5.7.0`.
- Controller builder version bumped to `10.5.7`.
- `builder.twig` loads matching versions for CSS, state store, inspector schema and builder UI.
- Hero typography color controls now use the shared `H.color()` control factory instead of ad-hoc color definitions.
- Hero normal button colors use the shared color factory:
  - Text Color
  - Background Color
  - Border Color
- Hero hover button colors use the shared color factory:
  - Text Color
  - Background Color
  - Border Color
- Hero background/overlay/hover colors use the same shared color factory.
- Added explicit CSS visibility/layout rules for advanced color controls.
- Builder console logs loaded UI/Inspector versions to detect stale/mismatched assets immediately.

## Existing frontend pipeline

The supplied V10.5.6 renderer already maps these values:

- `heroEyebrowColor`
- `heroHeadingColor`
- `heroBodyColor`
- `buttonColor`
- `buttonBackground`
- `buttonBorderColor`
- `buttonHoverColor`
- `buttonHoverBackground`
- `buttonHoverBorderColor`

Therefore this patch does not replace the frontend renderer; it fixes the inspector-to-document pipeline and asset consistency.

## Required browser verification

After installation:

1. Clear OpenCart modification/cache if applicable.
2. Hard reload the admin page with Ctrl+Shift+R.
3. Open browser Console.
4. Confirm a message similar to:
   `[NextGen Builder] UI 10.5.7.0 / Inspector 10.5.7.0`
5. Select Hero → Style → Normal.
6. Confirm Text Color appears inside:
   - Eyebrow Typography
   - Heading Typography
   - Description Typography
   - Hero Button
7. Confirm Hero Button contains Text / Background / Border Color.
8. Select Hover.
9. Confirm Hero Button Hover contains Text / Background / Border Color.
10. Change Heading color to a very obvious color such as red and verify the canvas changes.
11. Save and verify storefront computed style.
