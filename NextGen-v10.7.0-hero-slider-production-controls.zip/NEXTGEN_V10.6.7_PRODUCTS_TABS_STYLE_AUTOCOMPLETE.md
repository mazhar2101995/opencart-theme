# NextGen v10.6.7 — Products Tabs Style + Source Search

## Fixed
- Added real tab styling controls for alignment, text/active/hover colors, backgrounds, borders, radius, padding, gap, typography and bottom spacing.
- Added category autocomplete in Products > Tabs > Category Products.
- Added product autocomplete in Products > Tabs > Custom Product Selection.
- Custom products are stored as IDs plus display names/chips; manual Product IDs remain available as a fallback.
- Added admin builder endpoints for category and product search.
- Hardened Featured Products source loading to accept JSON, serialized PHP arrays, or comma/space separated IDs from common OpenCart setting formats.
- Featured tabs now return an empty result only when no featured products are configured instead of silently switching to Latest Products.

## Validation
- PHP syntax checked for modified PHP files.
- JavaScript syntax checked with Node.
