# NextGen v10.5.25 — Basic Widgets Frontend Runtime Fix

## Problem fixed
The v10.5.24 widget renderer referenced `$type` inside `decorateWidget()` without defining it. This generated repeated `Undefined variable $type` warnings on the storefront.

More importantly, visual controls were being calculated on the outer rendered wrapper while the actual widget element owns the visual presentation. This could make Heading, Text Editor and Button inspector changes appear in the builder but not reliably on the storefront.

## Fix
- Define widget `$type` from the current node before decoration.
- Apply saved visual settings directly to the actual `.ng-widget` element as inline styles.
- Preserve the existing wrapper/layout architecture.
- Preserve responsive CSS generation.
- Preserve Button-specific settings and hover settings.
- Preserve existing widget renderers and content.
- Do not use OCMOD/VQMOD.

## Covered widgets
- Heading
- Text Editor
- Text
- Button

## Button
Normal settings include text color, background, border, border width/style, radius, padding, typography and shadow. Hover settings continue to use the existing Button Hover controls.

## Verification
The renderer was syntax-checked with PHP and tested with a simulated Heading, Text Editor and Button document. The generated storefront HTML contains the visual styles directly on the actual widget elements.

## Installation
1. Replace the package files.
2. Refresh OpenCart Modifications.
3. Clear OpenCart/theme caches.
4. Hard refresh the browser with Ctrl+F5.
