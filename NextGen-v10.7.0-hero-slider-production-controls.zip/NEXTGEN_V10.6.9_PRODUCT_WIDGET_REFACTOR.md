# NextGen v10.6.9 — Product Widget Refactor

## Removed standalone widgets
- Rating
- Add to Cart
- Wishlist
- Compare
- Quick View

These are now product-card/product-widget controls instead of separate builder widgets.

## Product widget
Added a configurable single Product widget with product autocomplete and controls for product content, layout, image, card design, typography and buttons.

## Product selection
Uses the existing builder product-search endpoint and stores `productId` / `productName`. Frontend resolves the selected product through the existing `product_lookup` context callback.

## Layout
- Image left
- Image right
- Image top
- Responsive stacking below 760px

## Content
- Image, brand, model, description, rating, price/special price
- Quantity, Add to Cart, Buy Now
- Custom button labels

## Styling
- Image fit/background/radius
- Card background/border/radius/shadow/padding
- Title/description/price/brand/rating typography
- Button normal/hover colors, border, radius, padding and typography
