# NextGen Theme v10.6.1 — Unified Products Widget Fix

## Fixed

### 1. Latest Products now returns the configured product count
OpenCart 3.x `getLatestProducts()` expects an integer limit. The previous implementation passed an array, which could be cast to `1` and resulted in exactly one product.

Changed:
- `getLatestProducts(array('start'=>0,'limit'=>$limit))`
- to `getLatestProducts($limit)`

This is the main reason the **Latest Products** source was showing only one product.

### 2. Products widget is now one unified widget with 3 presentation modes
The Products inspector now starts with:

- Tabs
- Slider
- Grid

Mode-specific controls are hidden automatically:

- **Grid:** no Tabs JSON or Slider controls
- **Slider:** slider controls are shown
- **Tabs:** Tabs JSON is shown and source-specific controls are hidden

Common product source/layout/card controls remain available where applicable.

### 3. Slider controls improved
The unified slider now supports:
- Previous / Next arrows
- Dots
- Autoplay
- Loop
- Responsive visible-column calculation
- Correct navigation bounds after viewport changes

### 4. Frontend Text Editor dotted border removed
`.ng-inner-widget-slot` is a runtime nesting wrapper and was incorrectly styled as a visible dashed border on the storefront.

The storefront wrapper is now visually neutral:
- no border
- no background
- no extra margin/padding

Builder/editor styling remains available in the admin/editor CSS.

### 5. Product image URL handling
The product source continues to use OpenCart's native image model resize output. For a default OpenCart image such as:

`catalog/demo/samsung_tab_1.jpg`

the 600x600 product thumbnail is expected to resolve to:

`http://localhost/mazhar/oc_new_3035/image/cache/catalog/demo/samsung_tab_1-600x600.jpg`

No `catalog/` or theme path is incorrectly inserted before `/image/`.

## Files changed

- `catalog/controller/extension/theme/nextgen/presentation.php`
- `admin/view/javascript/nextgen-builder/builder-ui.js`
- `admin/view/javascript/nextgen-builder/inspector-schema.js`
- `system/library/nextgen/universal_widget_renderers.php`
- `catalog/view/theme/nextgen/stylesheet/nextgen-v5-storefront.css`
- `catalog/view/theme/nextgen/stylesheet/ecommerce-widgets.css`

## Verification checklist

1. Select **Products** widget.
2. Confirm **Display** is the first setting.
3. Test **Grid** — only grid-relevant controls should remain.
4. Test **Slider** — slider controls should appear.
5. Test **Tabs** — Tabs JSON should appear.
6. Set Product Source = **Latest Products** and Products = 4; at least four active latest products should render when available.
7. Inspect the product image URL; it should use `/image/cache/...`.
8. Confirm Text Editor has no dotted border on the storefront.
9. Refresh OpenCart modifications/theme caches after installing the package.
