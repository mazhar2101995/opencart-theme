# NextGen v10.7.0 — Hero Slider Production Controls

## Goal
Reworked Hero Slider as a real configurable builder widget. No JSON-only slide editing.

## Slide-level controls
- Slide name/order/duplicate/delete
- Desktop image + Mobile image via OpenCart Image Manager
- Image/video media type
- Video URL + poster
- Eyebrow, heading, description
- Button text, URL, target
- Content position and text alignment
- Image position/fit/repeat
- Per-slide overlay color + opacity

## Global controls
- Container width mode/custom width
- Height/content max width/padding/gap
- Background/media/overlay
- Full typography controls for eyebrow, heading and body
- Button normal + hover controls
- Slider transition/easing/autoplay/interval/speed/loop
- Pause on hover/focus, touch swipe, keyboard navigation
- Arrow icons, position, offsets, size, icon size, colors, hover, border, radius, shadow
- Dots position, offsets, size, gap, colors, active width/radius
- Progress bar and slide counter
- Container background/border/radius/shadow

## Runtime
- Slide and fade transitions
- Responsive mobile image support
- Keyboard, touch, hover/focus interaction
- Scoped CSS per widget node
- No dependency on the legacy premium slider runtime
